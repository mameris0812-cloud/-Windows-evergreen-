#!/usr/bin/env python3
"""7단계 화면 확인: ① 앱 정보 대화상자의 업데이트 카드(상태 5가지) ② 탭이 생기고 닫히는 움직임(애니메이션을 멈춰서 프레임별로).
   사용: python3 tools/preview_update.py [출력폴더]   (playwright 필요) → 자바스크립트 오류가 있으면 끝에 목록을 보여 준다."""
import json, sys, time, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/ev_upd")
OUT.mkdir(parents=True, exist_ok=True)
NOW = int(time.time() * 1000)
CHANGELOG = json.loads(__import__("subprocess").check_output(["node", "-e", "console.log(JSON.stringify(require('./src/shared/changelog').ENTRIES))"], cwd=ROOT))

def tab(i, title, active=False): return {"id": i, "title": title, "url": "https://example.com/" + str(i), "favicon": "", "loading": False, "incognito": False, "audible": False, "canBack": False, "canFwd": False, "secure": True, "zoom": 100, "zoomOnly": False, "bookmarked": False}
def state(n_tabs, active, upd=None):
    names = ["evergreen - Google 검색", "위키백과", "GitHub", "MDN Web Docs", "Hacker News"]
    return {"activeWin": 1, "wins": [{"id": 1, "num": 1, "name": "창 1", "active": active, "tabs": [tab(i + 1, names[i]) for i in range(n_tabs)]}],
            "prefs": {"theme": "system", "engine": "google", "zoom": 100, "bookmarkBar": False}, "ai": {"open": False}, "sec": None, "dl": {"count": 0, "progress": 0},
            "version": "0.7.0", "extTheme": None, "changelog": CHANGELOG, "update": upd, "engines": [{"key": "google", "name": "Google"}]}

PHASES = [
  ("1_idle", {"phase": "none", "supported": True, "checkedAt": NOW - 3600000, "auto": True, "percent": 0, "version": None, "error": None}),
  ("2_checking", {"phase": "checking", "supported": True, "checkedAt": NOW - 3600000, "auto": True, "percent": 0, "version": None, "error": None}),
  ("3_downloading", {"phase": "downloading", "supported": True, "checkedAt": NOW, "auto": True, "percent": 62, "version": "0.8.0", "error": None}),
  ("4_ready", {"phase": "ready", "supported": True, "checkedAt": NOW, "auto": True, "percent": 100, "version": "0.8.0", "error": None}),
  ("5_error", {"phase": "error", "supported": True, "checkedAt": NOW - 86400000, "auto": False, "percent": 0, "version": None, "error": "인터넷에 연결되어 있는지 확인해 주세요"}),
]
MOCK = """(function(){ var H={}; window.__sent=[]; window.__fire=function(c,p){(H[c]||[]).forEach(function(f){f(p)})};
 window.evergreen={send:function(c,p){window.__sent.push([c,p])},on:function(c,cb){(H[c]=H[c]||[]).push(cb)},invoke:function(){return Promise.resolve(null)}}; })();"""

errors = []
def newpage(br, scheme, w, h):
    ctx = br.new_context(viewport={"width": w, "height": h}, color_scheme=scheme, device_scale_factor=1)
    ctx.add_init_script(MOCK); pg = ctx.new_page()
    pg.on("pageerror", lambda e: errors.append(f"[{scheme}] pageerror: {e}"))
    pg.on("console", lambda m: errors.append(f"[{scheme}] console: {m.text}") if m.type == "error" and "Failed to load" not in m.text else None)
    return ctx, pg

def run():
    with sync_playwright() as p:
        br = p.chromium.launch()
        for scheme in ("light", "dark"):
            # ① 앱 정보 — 상태별 카드
            for name, upd in PHASES:
                ctx, pg = newpage(br, scheme, 640, 700)
                pg.goto(f"file://{SRC}/overlay/overlay.html"); time.sleep(0.3)
                pg.evaluate("s=>{__fire('overlay:show',{kind:'none',anchor:{x:600,y:50,w:40,h:40},left:false,data:null,state:s})}", state(3, 2, upd)); time.sleep(0.3)
                pg.evaluate("EvDlg.open('about',{})"); time.sleep(0.5)
                if name == "3_downloading":   # 받는 중 → 진행 막대가 상태 변화로 바로 바뀌는지
                    pg.evaluate("s=>__fire('state',s)", state(3, 2, dict(upd, percent=88))); time.sleep(0.6)
                    assert "88%" in pg.inner_text("#updBox"), "진행률이 대화상자에 반영되지 않음"
                pg.screenshot(path=str(OUT / f"upd_{name}_{scheme}.png")); ctx.close()
            # ② 탭 움직임 — 애니메이션을 멈추고 시간별 프레임
            ctx, pg = newpage(br, scheme, 760, 70)
            pg.goto(f"file://{SRC}/renderer/index.html"); time.sleep(0.4)
            pg.evaluate("s=>__fire('state',s)", state(3, 2)); time.sleep(0.5)
            pg.evaluate("s=>__fire('state',s)", state(4, 4)); time.sleep(0.05)   # 새 탭 하나 추가
            assert pg.evaluate("document.querySelectorAll('.tab.born').length") == 1, "새 탭만 .born 이어야 함"
            for ms in (0, 60, 120, 200):
                pg.evaluate("t=>document.getAnimations().forEach(a=>{a.pause();a.currentTime=t})", ms)
                pg.screenshot(path=str(OUT / f"tabin_{ms}_{scheme}.png"), clip={"x": 0, "y": 0, "width": 760, "height": 48})
            pg.evaluate("s=>__fire('state',s)", state(4, 4)); time.sleep(0.4)           # 같은 상태 다시 → 다시 나타나지 않아야 함
            assert pg.evaluate("document.querySelectorAll('.tab.born').length") == 0, "다시 그릴 때 .born 이 남아 있음"
            pg.evaluate("document.querySelectorAll('.tab')[1].classList.add('dying')")
            for ms in (0, 50, 100, 140):
                pg.evaluate("t=>document.getAnimations().forEach(a=>{a.pause();a.currentTime=t})", ms)
                pg.screenshot(path=str(OUT / f"tabout_{ms}_{scheme}.png"), clip={"x": 0, "y": 0, "width": 760, "height": 48})
            # 닫기 단추: 눌러도 바로 닫기 명령이 가지 않고 0.14초 뒤에 간다
            pg.evaluate("s=>__fire('state',s)", state(4, 4)); time.sleep(0.3); pg.evaluate("window.__sent.length=0")
            pg.click(".tab >> nth=1 >> .x"); time.sleep(0.04)
            assert not [x for x in pg.evaluate("__sent") if x[0] == "app:cmd" and x[1].get("name") == "tab:close"], "닫기 명령이 너무 빨리 감"
            time.sleep(0.25)
            assert [x for x in pg.evaluate("__sent") if x[0] == "app:cmd" and x[1].get("name") == "tab:close"], "닫기 명령이 안 감"
            ctx.close()
        br.close()
try:
    run()
except Exception as ex:
    errors.append("실행 중단: " + str(ex).splitlines()[0])
print("JS 오류/검사 실패:", "없음" if not errors else "")
for e in errors: print("  ", e)
