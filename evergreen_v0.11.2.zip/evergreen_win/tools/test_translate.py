#!/usr/bin/env python3
"""페이지 번역 스크립트(pagetools.trCollectFn/trApplyFn/trRestoreFn)를 진짜 크롬에서 확인하고 전/후 화면을 저장한다. (Gemini 대신 가짜 번역)
   사용: python3 tools/test_translate.py [출력폴더]"""
import json, subprocess, sys, pathlib
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/ev_tr"); OUT.mkdir(parents=True, exist_ok=True)
js = subprocess.check_output(["node", "-e", "const P=require('./src/main/pagetools');console.log(JSON.stringify({c:P.call(P.trCollectFn,1500),r:P.call(P.trRestoreFn),s:P.call(P.trStateFn)}))"], cwd=ROOT)
CODE = json.loads(js)
HTML = """<!doctype html><meta charset=utf-8><body style="font:16px/1.6 sans-serif;padding:24px;max-width:640px">
<h1>Welcome to Evergreen</h1><p>A fast, <b>private</b> browser for everyone. Download it today.</p>
<ul><li>Block ads and trackers</li><li>Built-in video player</li><li hidden>Hidden item</li></ul>
<pre>const x = 1; // code stays</pre><p class="notranslate">Evergreen™</p><button>Sign in</button><p id=ko>이미 한국어 문장입니다</p>"""
KO = {"Welcome to Evergreen": "Evergreen에 오신 것을 환영합니다", "A fast,": "빠르고", "private": "안전한", "browser for everyone. Download it today.": "모두를 위한 브라우저예요. 오늘 받아 보세요.",
      "Block ads and trackers": "광고와 추적기 차단", "Built-in video player": "내장 동영상 플레이어", "Sign in": "로그인"}
bad = []
with sync_playwright() as p:
    br = p.chromium.launch(); pg = br.new_page(viewport={"width": 720, "height": 360}); pg.set_content(HTML)
    before = pg.inner_html("body"); pg.screenshot(path=str(OUT / "tr_before.png"))
    nodes = pg.evaluate(CODE["c"]); texts = [n["t"] for n in nodes]
    for must in ["Welcome to Evergreen", "Block ads and trackers", "Sign in"]:
        if must not in texts: bad.append("모으기 실패: " + must)
    for never in ["const x = 1; // code stays", "Evergreen™", "Hidden item"]:
        if any(never in t for t in texts): bad.append("건너뛰어야 할 글을 모음: " + never)
    pairs = [[n["i"], KO[n["t"]]] for n in nodes if n["t"] in KO]
    apply_code = subprocess.check_output(["node", "-e", f"const P=require('./src/main/pagetools');console.log(P.call(P.trApplyFn,{json.dumps(pairs)}))"], cwd=ROOT).decode().strip()
    n = pg.evaluate(apply_code)
    if n != len(pairs): bad.append(f"적용 개수 {n} != {len(pairs)}")
    body = pg.inner_text("body")
    if "환영합니다" not in body or "const x = 1" not in body or "Evergreen™" not in body: bad.append("번역 후 본문이 이상함")
    if pg.evaluate(CODE["s"])["on"] is not True: bad.append("상태 on 아님")
    if pg.evaluate("document.querySelector('b').textContent") != "안전한": bad.append("<b> 안 글이 안 바뀜(서식 유지 실패)")
    pg.screenshot(path=str(OUT / "tr_after.png"))
    pg.evaluate(CODE["r"])
    if pg.inner_html("body") != before: bad.append("되돌린 뒤 원문과 다름")
    if pg.evaluate(CODE["s"])["on"]: bad.append("복원 뒤에도 on")
    br.close()
print("페이지 번역 스크립트:", "통과" if not bad else "")
for b in bad: print("  ", b)
