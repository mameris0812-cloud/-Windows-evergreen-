# 안드로이드 벡터 드로어블(ic_*.xml) → SVG 조각(src/renderer/icons.js)으로 변환
import glob, os, json
import xml.etree.ElementTree as ET
NS='{http://schemas.android.com/apk/res/android}'
SRC=os.environ.get('EV_DRAWABLE','/tmp/ev/app/src/main/res/drawable')
SKIP=('launcher','shortcut','notif','samsung','leaf_pixel','extension')
out={}
for f in sorted(glob.glob(SRC+'/ic_*.xml')):
    n=os.path.basename(f)[:-4]
    if any(s in n for s in SKIP): continue
    t=ET.parse(f).getroot()
    if t.tag!='vector': continue
    if t.find('group') is not None or t.find('.//{*}attr') is not None: continue
    vw=t.get(NS+'viewportWidth','24'); vh=t.get(NS+'viewportHeight','24')
    parts=[]
    for p in t.findall('path'):
        d=p.get(NS+'pathData')
        if not d: continue
        fill=p.get(NS+'fillColor','#00000000'); stroke=p.get(NS+'strokeColor')
        a=['d="%s"'%d]
        a.append('fill="none"' if fill.upper() in('#00000000','@ANDROID:COLOR/TRANSPARENT') or fill.lower()=='@android:color/transparent' else 'fill="currentColor"')
        if stroke and stroke.upper()!='#00000000':
            a.append('stroke="currentColor"')
            a.append('stroke-width="%s"'%p.get(NS+'strokeWidth','1'))
            a.append('stroke-linecap="%s"'%p.get(NS+'strokeLineCap','butt'))
            a.append('stroke-linejoin="%s"'%p.get(NS+'strokeLineJoin','miter'))
        if p.get(NS+'fillType')=='evenOdd': a.append('fill-rule="evenodd"')
        parts.append('<path '+' '.join(a)+'/>')
    out[n[3:]]={'vb':'0 0 %s %s'%(vw,vh),'body':''.join(parts)}
js='// 자동 생성: tools/make_icons.py (안드로이드 ic_*.xml 에서 변환)\nwindow.EV_ICONS='+json.dumps(out,ensure_ascii=False)+';\n'
js+='window.icon=function(n,s){var i=window.EV_ICONS[n];if(!i)return"";s=s||24;return \'<svg xmlns="http://www.w3.org/2000/svg" viewBox="\'+i.vb+\'" width="\'+s+\'" height="\'+s+\'" aria-hidden="true">\'+i.body+"</svg>"};\n'
open('src/renderer/icons.js','w').write(js)
print(len(out),'icons:',' '.join(sorted(out))[:1200])
