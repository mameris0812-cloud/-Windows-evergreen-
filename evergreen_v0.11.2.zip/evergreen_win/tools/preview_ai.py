#!/usr/bin/env python3
"""AI 패널 화면 미리보기: 실제 src/ai/ai.html 을 헤드리스 크롬으로 열고, 메인 프로세스 대신 가짜 이벤트를 넣어 PNG 로 저장한다.
   사용: python3 tools/preview_ai.py [출력폴더]   → 자바스크립트 오류가 있으면 끝에 목록을 보여 준다. 페이지 조작 스크립트(pagetools.js)도 진짜 크롬에서 확인한다."""
import json, sys, pathlib, subprocess
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/ev_ai"); OUT.mkdir(parents=True, exist_ok=True)
NOW = 1_790_000_000_000
INFO = {"keys": [{"mask": "AIza…x9Qk", "status": None, "today": {"calls": 14}}, {"mask": "AIza…77Lm", "status": "한도 도달 · 3분 뒤 다시 사용", "today": {"calls": 9}}],
  "settings": {"search": True, "sources": True, "thoughts": True, "agent": True, "pageRef": True, "auto": False, "width": 400},
  "models": {"lite": "3.5 Flash-Lite", "hydrogen": "4 Hydrogen"}, "resting": "3.5 Flash-Lite 3분", "keyNo": 1, "keyCount": 2,
  "usage": {"today": {"calls": 23, "limit": 2, "errors": 1}, "tokens": "4.2만", "byModel": [{"model": "3.5 Flash-Lite", "calls": 17, "limit": 2, "errors": 0, "tokens": "2.6만"}, {"model": "4 Hydrogen", "calls": 6, "limit": 0, "errors": 1, "tokens": "1.6만"}],
    "days": [{"day": "20261116", "calls": 4, "limit": 0}, {"day": "20261117", "calls": 11, "limit": 0}, {"day": "20261118", "calls": 0, "limit": 0}, {"day": "20261119", "calls": 19, "limit": 1}, {"day": "20261120", "calls": 8, "limit": 0}, {"day": "20261121", "calls": 27, "limit": 3}, {"day": "20261122", "calls": 23, "limit": 2}], "resetIn": "5시간 12분", "any": True},
  "chats": [{"id": "c1", "title": "이차함수 꼭짓점 구하는 법", "updated": NOW - 3600000, "count": 6}, {"id": "c2", "title": "탭 정리해 줘", "updated": NOW - 86400000, "count": 4}, {"id": "c3", "title": "이 페이지 요약해 줘", "updated": NOW - 3 * 86400000, "count": 2}]}
STATE = {"activeWin": 1, "wins": [{"id": 1, "num": 1, "name": "창 1", "active": 1, "tabs": [{"id": 1, "title": "위키백과", "url": "https://ko.wikipedia.org/wiki/위키백과"}]}], "extTheme": None}
MOCK = """(function(){ var H={}, INFO=%s, STATE=%s;
 window.__sent=[]; window.__fire=function(c,p){(H[c]||[]).forEach(function(f){f(p)})};
 window.evergreen={send:function(c,p){window.__sent.push([c,p])},on:function(c,cb){(H[c]=H[c]||[]).push(cb)},
   invoke:function(c,p){window.__sent.push([c,p]); if(c==='ai:info')return Promise.resolve(INFO); if(c==='ai:page-title')return Promise.resolve({title:'위키백과',url:'https://ko.wikipedia.org/'}); return Promise.resolve(null)}};
 window.addEventListener('load',function(){ __fire('state', STATE) });
})();""" % (json.dumps(INFO, ensure_ascii=False), json.dumps(STATE))

ANSWER = """이차함수 $f(x)=x^2-2x-3$ 의 꼭짓점은 **완전제곱식**으로 바꾸면 바로 보여요.

$$f(x)=(x-1)^2-4$$

그래서 꼭짓점은 $(1,\\,-4)$ 이고, 근의 공식으로 구한 해는 $x=\\dfrac{-b\\pm\\sqrt{b^2-4ac}}{2a}$ 입니다.

```graph
title: 이차함수
x: -3..5
fn: x^2-2x-3 | f(x)
point: 1, -4, 꼭짓점
point: -1, 0
point: 3, 0
```

| 구분 | 값 |
|:--|--:|
| 꼭짓점 | (1, −4) |
| 축 | x = 1 |
| 근 | −1, 3 |

- 위로 볼록하지 않고 **아래로 볼록**해요 (a > 0)
- 최솟값은 −4 입니다

```python
def vertex(a, b, c):
    return -b / (2 * a)
```"""

errors = []
def fire(pg, m): pg.evaluate("m => window.__fire('ai:event', m)", m)
def stream(pg, text, step=70):
    for i in range(0, len(text), step): fire(pg, {"type": "text", "delta": text[i:i + step]})

def scene(br, scheme, name, fn, size=(400, 820)):
    ctx = br.new_context(viewport={"width": size[0], "height": size[1]}, color_scheme=scheme, device_scale_factor=2)
    pg = ctx.new_page()
    pg.on("pageerror", lambda e: errors.append(f"{name}: {e}")); pg.on("console", lambda m: m.type == "error" and errors.append(f"{name}: {m.text}"))
    pg.add_init_script(MOCK)
    pg.goto(f"file://{ROOT}/src/ai/ai.html"); pg.wait_for_timeout(350)
    fn(pg); pg.wait_for_timeout(500)
    pg.screenshot(path=str(OUT / f"{name}_{scheme}.png"))
    ctx.close()

def s_empty(pg): pass
def s_chat(pg):
    pg.fill("#input", "이차함수 x^2-2x-3 의 꼭짓점을 구하고 그래프로 보여 줘"); pg.press("#input", "Enter"); pg.wait_for_timeout(150)
    fire(pg, {"type": "start"}); fire(pg, {"type": "model", "label": "4 Hydrogen", "reason": "코딩·깊은 추론 → 4 Hydrogen"})
    fire(pg, {"type": "thought", "delta": "**식 정리**\n\n완전제곱식으로 바꿔 꼭짓점을 구한다."}); fire(pg, {"type": "think-ms", "ms": 2300})
    stream(pg, ANSWER)
    fire(pg, {"type": "grounding", "queries": ["이차함수 꼭짓점 공식"], "sources": [{"title": "ko.wikipedia.org", "url": "https://ko.wikipedia.org/wiki/이차_함수"}, {"title": "namu.wiki", "url": "https://namu.wiki/w/이차함수"}]})
    fire(pg, {"type": "done", "thinkMs": 2300, "chats": INFO["chats"], "id": "c1", "keyNo": 1, "keyCount": 2})
    pg.wait_for_timeout(300); pg.evaluate("document.querySelector('#scroll').scrollTop=0")
def s_chat_bottom(pg):
    s_chat(pg); pg.evaluate("document.querySelector('#scroll').scrollTop=1e5")
def s_agent(pg):
    pg.fill("#input", "열려 있는 탭 중에 광고 많은 거 닫고 북마크 지워 줘"); pg.press("#input", "Enter"); pg.wait_for_timeout(150)
    fire(pg, {"type": "model", "label": "4 Hydrogen", "reason": "앱 조작 질문 → 4 Hydrogen"})
    for t in [{"id": 1, "name": "list_tabs", "label": "열린 탭 확인", "status": "ok", "detail": ""}, {"id": 2, "name": "close_tab", "label": "탭 닫기", "status": "ok", "detail": "3번 탭"},
              {"id": 3, "name": "search_bookmarks", "label": "북마크 찾기", "status": "ok", "detail": "광고"}, {"id": 4, "name": "delete_bookmarks", "label": "북마크 삭제", "status": "run", "detail": "https://spam.example.com"}]:
        fire(pg, {"type": "tool", "tool": t})
    pg.wait_for_timeout(200)
    fire(pg, {"type": "confirm", "id": 9, "tool": "delete_bookmarks", "text": "북마크 2개를 지울까요?\n· https://spam.example.com/\n· https://ads.example.net/promo"})
def s_running(pg):
    pg.fill("#input", "오늘 서울 날씨 어때?"); pg.press("#input", "Enter"); pg.wait_for_timeout(150)
    fire(pg, {"type": "model", "label": "3.5 Flash-Lite", "reason": "낱말·길이 규칙으로 3.5 Flash-Lite 선택"}); fire(pg, {"type": "keyswitch", "text": "키 1 한도 도달 → 키 2 사용", "from": 1, "to": 2, "total": 2})
def s_settings(pg): pg.click("#bSet"); pg.wait_for_timeout(250)
def s_history(pg): pg.click("#bHist"); pg.wait_for_timeout(250)
def s_nokey(pg):
    pg.evaluate("window.__fire('ai:event', {type:'error', code:'nokey', text:'API 키가 없어요. ⚙ 설정에서 구글 AI 스튜디오의 무료 API 키를 넣어 주세요'})")

# ── 페이지 조작 스크립트 (pagetools.js) 를 진짜 크롬에서 확인 ──
def check_pagetools(br):
    code = subprocess.check_output(["node", "-e", f"""const p=require('{ROOT}/src/main/pagetools.js');
console.log(JSON.stringify({{read:p.call(p.readPageFn,{{all:false,maxText:3000,maxEls:50}}),click:p.call(p.clickFn,2),fill:p.call(p.fillFn,3,'서울 날씨',true),fillSel:p.call(p.fillFn,4,'부산',false),scroll:p.call(p.scrollFn,'bottom',1),el:p.call(p.elementFn,1),snap:p.call(p.snapshotFn,500)}}))"""]).decode()
    c = json.loads(code)
    pg = br.new_page(viewport={"width": 900, "height": 600})
    pg.on("pageerror", lambda e: errors.append(f"pagetools: {e}"))
    pg.set_content("""<body style="margin:0"><nav><a href="/x">홈</a> <button id=b onclick="window.hit=(window.hit||0)+1">더보기</button></nav>
      <form onsubmit="event.preventDefault();window.sub=document.getElementById('q').value"><input id=q placeholder="검색창"><select id=s><option value=a>서울</option><option value=b>부산</option></select></form>
      <input type=password placeholder=비밀번호><div style="height:2000px">긴 글</div><button style="display:none">숨김</button><button id=far>맨 아래 버튼</button></body>""")
    r = pg.evaluate(c["read"]); assert r["title"] == "" and any(e["label"] == "더보기" for e in r["elements"]), r
    assert not any(e["label"] == "숨김" for e in r["elements"]), "보이지 않는 요소는 빼야 해요"
    assert not any(e["label"] == "맨 아래 버튼" for e in r["elements"]), "화면 밖 요소는 scope=all 에서만"
    pw = [e for e in r["elements"] if e.get("type") == "password"][0]; assert "value" not in pw
    n_btn = [e["n"] for e in r["elements"] if e["label"] == "더보기"][0]; n_in = [e["n"] for e in r["elements"] if e.get("label") == "검색창"][0]; n_sel = [e["n"] for e in r["elements"] if e["tag"] == "select"][0]
    helper = subprocess.check_output(["node", "-e", f"""const p=require('{ROOT}/src/main/pagetools.js');console.log(JSON.stringify([p.call(p.clickFn,{n_btn}),p.call(p.fillFn,{n_in},'서울 날씨',true),p.call(p.fillFn,{n_sel},'부산',false),p.call(p.scrollFn,'bottom',1),p.call(p.elementFn,{n_in}),p.call(p.clickFn,999),p.call(p.readPageFn,{{all:true,maxText:3000,maxEls:50}})]))"""]).decode()
    codes = json.loads(helper)
    assert pg.evaluate(codes[0])["ok"] and pg.evaluate("window.hit") == 1
    assert pg.evaluate(codes[1])["submitted"] and pg.evaluate("window.sub") == "서울 날씨"
    assert pg.evaluate(codes[2])["ok"] and pg.evaluate("document.getElementById('s').value") == "b"
    assert pg.evaluate(codes[3])["moved"] > 100
    assert pg.evaluate(codes[4])["label"] == "검색창"
    assert "찾지 못했어요" in pg.evaluate(codes[5])["error"]
    assert any(e["label"] == "맨 아래 버튼" for e in pg.evaluate(codes[6])["elements"]), "scope=all 은 화면 밖 요소도 읽어야 해요"
    pg.close(); print("pagetools: 읽기·누르기·입력(제출)·선택·스크롤·없는 번호·scope=all 확인 완료")

with sync_playwright() as p:
    br = p.chromium.launch()
    for scheme in ("light", "dark"):
        scene(br, scheme, "1_empty", s_empty); scene(br, scheme, "2_chat_top", s_chat); scene(br, scheme, "3_chat_bottom", s_chat_bottom)
        scene(br, scheme, "4_agent_confirm", s_agent); scene(br, scheme, "5_running", s_running); scene(br, scheme, "6_settings", s_settings); scene(br, scheme, "7_history", s_history)
    scene(br, "light", "8_nokey", s_nokey)
    check_pagetools(br)
    br.close()
print("화면 PNG:", sorted(x.name for x in OUT.glob("*.png")))
print("JS 오류:", errors if errors else "없음")
