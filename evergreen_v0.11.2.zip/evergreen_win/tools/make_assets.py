#!/usr/bin/env python3
"""앱 아이콘(.ico) · 설치 프로그램 그림(NSIS 사이드바/헤더 .bmp) 만들기.
   assets/icon.svg(큰 크기) 와 assets/icon_small.svg(16~24px 용, 고리 없이 잎을 키움) 를 크롬(헤드리스)으로 그려서 PIL 로 묶는다.
   사용: python3 tools/make_assets.py   (playwright · pillow 필요)"""
import io, pathlib
from PIL import Image, ImageDraw, ImageFont
from playwright.sync_api import sync_playwright

A = pathlib.Path(__file__).resolve().parent.parent / "assets"
SIZES = [16, 20, 24, 32, 40, 48, 64, 96, 128, 256]

def render(pg, svg, px):
    pg.set_viewport_size({"width": px, "height": px})
    pg.set_content(f'<body style="margin:0;background:transparent"><img src="data:image/svg+xml;utf8,{svg}" width="{px}" height="{px}"></body>')
    return Image.open(io.BytesIO(pg.screenshot(omit_background=True, clip={"x": 0, "y": 0, "width": px, "height": px}))).convert("RGBA")

def font(sz, bold=True):
    for f in ["/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc", "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]:
        if pathlib.Path(f).exists(): return ImageFont.truetype(f, sz)
    return ImageFont.load_default()

def gradient(w, h, c1, c2):
    im = Image.new("RGB", (w, h)); px = im.load()
    for y in range(h):
        for x in range(w):
            t = (x / w * .35 + y / h * .65)
            px[x, y] = tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))
    return im

def main():
    big = (A / "icon.svg").read_text().replace("\n", "").replace("#", "%23").replace('"', "'")
    small = (A / "icon_small.svg").read_text().replace("\n", "").replace("#", "%23").replace('"', "'")
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page()
        imgs = {s: render(pg, small if s <= 24 else big, s) for s in SIZES}
        hi = render(pg, big, 512)
        b.close()
    imgs[256].save(A / "icon.ico", sizes=[(s, s) for s in SIZES], append_images=[imgs[s] for s in SIZES if s != 256])
    hi.save(A / "icon.png")
    # NSIS 사이드바 164x314 (설치 시작·끝 화면 왼쪽) — 초록 그라데이션 + 큰 아이콘 + 이름
    for name in ("installerSidebar", "uninstallerSidebar"):
        c1, c2 = ((0x2F, 0xA3, 0x5B), (0x0F, 0x5C, 0x33)) if name.startswith("inst") else ((0x4A, 0x55, 0x60), (0x1B, 0x20, 0x26))
        sb = gradient(164, 314, c1, c2).convert("RGBA")
        d = ImageDraw.Draw(sb)
        for r, a in ((150, 22), (112, 28), (78, 34)):          # 은은한 동심원
            ov = Image.new("RGBA", sb.size, (0, 0, 0, 0)); ImageDraw.Draw(ov).ellipse((82 - r, 70 - r, 82 + r, 70 + r), fill=(255, 255, 255, a))
            sb = Image.alpha_composite(sb, ov)
        ic = hi.resize((84, 84), Image.LANCZOS); sb.alpha_composite(ic, (40, 28))
        d = ImageDraw.Draw(sb)
        d.text((82, 150), "Evergreen", font=font(21), fill=(255, 255, 255, 255), anchor="mm")
        d.text((82, 176), "Windows", font=font(12), fill=(255, 255, 255, 190), anchor="mm")
        sb.convert("RGB").save(A / f"{name}.bmp")
    # NSIS 헤더 150x57 (설치 중 화면 오른쪽 위)
    hd = Image.new("RGB", (150, 57), (255, 255, 255)); ic = hi.resize((40, 40), Image.LANCZOS).convert("RGBA")
    base = hd.convert("RGBA"); base.alpha_composite(ic, (101, 8)); base.convert("RGB").save(A / "installerHeader.bmp")
    print("done:", ", ".join(sorted(f.name for f in A.iterdir())))

if __name__ == "__main__": main()
