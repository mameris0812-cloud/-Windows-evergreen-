#!/usr/bin/env python3
"""영상 자막 번역(v0.9.0)을 진짜 player.html(미러링 컨트롤 모드, 영상 파일 없이)에서 확인하고 화면을 저장한다. Gemini 대신 가짜 번역.
   사용: python3 tools/test_subtr.py [출력폴더]"""
import sys, pathlib, json
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/ev_subtr"); OUT.mkdir(parents=True, exist_ok=True)
SRT = "1\n00:00:01,000 --> 00:00:05,000\nI thought you said you would be here by noon.\n\n2\n00:00:06,000 --> 00:00:09,000\nSorry, the train was late again.\n\n3\n00:00:10,000 --> 00:00:12,000\n이미 한국어 자막이에요\n\n4\n00:00:13,000 --> 00:00:16,000\n<i>Let's go get dinner.</i>\n"
KO = {"I thought you said you would be here by noon.": "정오까지 온다고 했잖아.", "Sorry, the train was late again.": "미안, 기차가 또 늦었어.", "Let's go get dinner.": "저녁 먹으러 가자.", "Hello there": "안녕하세요"}
MOCK = """(function(){var H={};window.__sent=[];window.__tr=[];window.__fail=false;window.__fire=function(c,p){(H[c]||[]).forEach(function(f){f(p)})};var KO=%s;
window.evergreen={send:function(c,p){window.__sent.push([c,p])},on:function(c,cb){(H[c]=H[c]||[]).push(cb)},
invoke:function(c,p){if(c==='pl:tr'){window.__tr.push(p.texts.slice());if(window.__fail)return Promise.resolve({error:'Gemini API 키가 필요해요 (AI 창 설정에서 키를 넣어 주세요)'});return Promise.resolve({out:p.texts.map(function(t){return KO[t]||t})})}return Promise.resolve(null)}};})();""" % json.dumps(KO, ensure_ascii=False)
errors, ok = [], {}
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1000, "height": 560}, color_scheme="dark", bypass_csp=True, device_scale_factor=2)
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.add_init_script(MOCK)
    pg.goto((ROOT / "src/player/player.html").as_uri() + "?mode=mirror")
    pg.add_style_tag(content="body{background:linear-gradient(135deg,#2c4a6e,#7a9a62) !important}")
    pg.evaluate("window.__fire('pl:init',{mode:'mirror',url:'',title:'여행 브이로그 #3',host:'example.com',prefs:{},trLang:'ko',dark:true,capRight:0})")
    def state(pos, cue=''): pg.evaluate("window.__fire('pl:mstate',{on:true,pos:%s,dur:600,playing:true,speed:1,buffered:100,volume:1,muted:false,title:'t',host:'h',tracks:[{idx:0,label:'English'}],track:-1,cue:%s,fit:'contain'})" % (pos, json.dumps(cue)))
    state(2.0); pg.mouse.move(500, 300); pg.wait_for_timeout(300)
    ok["자막 없으면 번역 칩 숨김"] = pg.evaluate("document.getElementById('cTr').hidden")
    pg.evaluate("window.__player.loadSubFile('scene.srt'," + json.dumps(SRT) + ")"); pg.wait_for_timeout(300)
    ok["자막 켜면 번역 칩 보임(번역 끔)"] = pg.evaluate("!document.getElementById('cTr').hidden") and pg.inner_text("#cTr") == "번역 끔"
    pg.screenshot(path=str(OUT / "sub_off.png"))
    ok["번역 끔: 원문 그대로"] = pg.inner_text("#subMain").startswith("I thought")
    ok["번역 끔: 요청 없음"] = pg.evaluate("window.__tr.length") == 0
    # ① 번역만
    pg.click("#cTr"); pg.wait_for_timeout(700)
    ok["칩 → 자막 번역"] = pg.inner_text("#cTr") == "자막 번역"
    pre = pg.evaluate("window.__tr")
    ok["미리 번역: 영어 줄만 한 번에(중복·한국어 제외)"] = len(pre) >= 1 and sorted(sum(pre, [])) == sorted(["I thought you said you would be here by noon.", "Sorry, the train was late again.", "Let's go get dinner."])
    ok["번역만: 한국어로 표시"] = pg.inner_text("#subMain") == "정오까지 온다고 했잖아." and not pg.evaluate("document.getElementById('subOrig').classList.contains('on')")
    ok["번역 도착 뒤 흐림 해제"] = not pg.evaluate("document.getElementById('subMain').classList.contains('wait')")
    pg.screenshot(path=str(OUT / "sub_tr.png"))
    # ② 번역 + 원문
    pg.click("#cTr"); pg.wait_for_timeout(300)
    ok["칩 → 번역+원문"] = pg.inner_text("#cTr") == "번역+원문"
    ok["번역+원문: 두 줄"] = pg.inner_text("#subMain") == "정오까지 온다고 했잖아." and pg.inner_text("#subOrig").startswith("I thought")
    pg.screenshot(path=str(OUT / "sub_both.png"))
    n_before = len(pg.evaluate("window.__tr"))
    state(7.0); pg.wait_for_timeout(300)
    ok["다음 줄은 캐시에서(추가 요청 없음)"] = pg.inner_text("#subMain") == "미안, 기차가 또 늦었어." and len(pg.evaluate("window.__tr")) == n_before
    state(11.0); pg.wait_for_timeout(300)
    ok["한국어 자막은 번역하지 않음"] = pg.inner_text("#subMain") == "이미 한국어 자막이에요" and not pg.evaluate("document.getElementById('subOrig').classList.contains('on')")
    # ③ 영상 안 자막(트랙): 줄이 나오는 순간 요청 → 원문이 흐리게 먼저
    pg.click("#cTr"); pg.wait_for_timeout(200)   # 끔
    ok["칩 → 번역 끔 / 원문 복귀"] = pg.inner_text("#cTr") == "번역 끔" and pg.inner_text("#subMain") == "이미 한국어 자막이에요"
    pg.evaluate("window.__player.setSub('track',{idx:0,label:'English'})"); state(30.0, "Hello there"); pg.wait_for_timeout(300)
    ok["트랙 자막(번역 끔)"] = pg.inner_text("#subMain") == "Hello there"
    pg.evaluate("window.__player.openPanel('subs')"); pg.wait_for_timeout(300)
    pg.click("#panel >> text=자막 번역"); pg.wait_for_timeout(300); pg.screenshot(path=str(OUT / "sub_panel.png"))
    pg.click("#panel >> text=한국어 번역"); pg.wait_for_timeout(700)
    ok["패널에서 번역만 선택 → 트랙 줄 번역"] = pg.inner_text("#subMain") == "안녕하세요"
    pg.keyboard.press("Escape")
    # ④ 오류: 키 없음
    pg.evaluate("window.__fail=true"); state(31.0, "Brand new line"); pg.wait_for_timeout(900)
    ok["오류 안내(OSD)"] = "API 키" in pg.inner_text("#osd")
    ok["오류여도 원문은 보임"] = pg.inner_text("#subMain") == "Brand new line"
    pg.screenshot(path=str(OUT / "sub_error.png"))
    b.close()
bad = [k for k, v in ok.items() if not v]
print("자막 번역(진짜 크롬):", "통과" if not bad and not errors else "")
for k in bad: print("  실패:", k)
for e in errors: print("  오류:", e)
sys.exit(1 if bad or errors else 0)
