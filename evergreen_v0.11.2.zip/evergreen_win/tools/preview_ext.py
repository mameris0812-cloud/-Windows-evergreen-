#!/usr/bin/env python3
"""확장 프로그램 · 테마 대화상자 미리보기: 진짜 overlay.html 에 가짜 메인(확장 목록)을 연결해 PNG 로 저장하고 동작을 확인한다.  사용: python3 tools/preview_ext.py [출력폴더]"""
import sys, json, base64, io, pathlib
from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw
ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/ev_ext"); OUT.mkdir(parents=True, exist_ok=True)
def icon(color, ch):
    im = Image.new("RGBA", (96, 96), (0, 0, 0, 0)); d = ImageDraw.Draw(im); d.rounded_rectangle((6, 6, 90, 90), 22, fill=color); d.ellipse((30, 30, 66, 66), fill=(255, 255, 255, 235))
    b = io.BytesIO(); im.save(b, "PNG"); return "data:image/png;base64," + base64.b64encode(b.getvalue()).decode()
EXTS = [
 {"id": "cjpalhdlnbpafiamejdnhcphjbkeiagm", "eid": "x", "name": "uBlock Origin", "version": "1.60.0", "description": "광고와 추적기를 막아 주는 효율적인 차단 도구입니다.", "theme": False, "enabled": True, "icon": icon("#8B1A1A", "u"), "mv": 3, "popup": True, "options": True, "warning": "일부 기능이 동작하지 않을 수 있어요: 요청 차단 규칙 · 탐색 감지", "error": "", "source": "웹스토어", "perms": []},
 {"id": "local-1a2b3c4d5e6f", "eid": "y", "name": "밝은 번역기", "version": "2.3", "description": "선택한 글을 바로 번역해 줍니다.", "theme": False, "enabled": True, "icon": icon("#2F6FDB", "t"), "mv": 3, "popup": True, "options": False, "warning": None, "error": "", "source": "파일", "perms": []},
 {"id": "bkdgflcldnnnapblkhphbgpggdiikppg", "eid": "", "name": "다크 모드 도우미", "version": "0.9", "description": "", "theme": False, "enabled": False, "icon": "", "mv": 2, "popup": False, "options": True, "warning": "일부 기능이 동작하지 않을 수 있어요: 북마크", "error": "", "source": "웹스토어", "perms": []},
 {"id": "abcdefghijklmnopabcdefghijklmnop", "eid": "", "name": "깨진 확장", "version": "1", "description": "", "theme": False, "enabled": True, "icon": "", "mv": 3, "popup": False, "options": False, "warning": None, "error": "Manifest 오류", "source": "파일", "perms": []},
 {"id": "theme1", "eid": "", "name": "밤하늘", "version": "1.0", "description": "", "theme": True, "enabled": False, "icon": "", "mv": 3, "popup": False, "options": False, "warning": None, "error": "", "source": "웹스토어", "perms": [], "active": False},
 {"id": "theme2", "eid": "", "name": "따뜻한 모래", "version": "1.2", "description": "", "theme": True, "enabled": False, "icon": "", "mv": 3, "popup": False, "options": False, "warning": None, "error": "", "source": "웹스토어", "perms": [], "active": False},
]
MOCK = """(function(){var H={},L=%s;window.__sent=[];window.__fire=function(c,p){(H[c]||[]).forEach(function(f){f(p)})};
window.evergreen={send:function(c,p){window.__sent.push([c,p])},on:function(c,cb){(H[c]=H[c]||[]).push(cb)},
invoke:function(c,p){window.__sent.push([c,p]);
 if(c==='ext:list')return Promise.resolve(JSON.parse(JSON.stringify(L)));
 if(c==='ext:toggle'){L.forEach(function(x){if(x.id===p.id)x.enabled=p.on});return Promise.resolve(JSON.parse(JSON.stringify(L)))}
 if(c==='ext:theme'){L.forEach(function(x){if(x.theme)x.active=(x.id===p)});return Promise.resolve({ok:true})}
 if(c==='ext:store'){return new Promise(function(r){setTimeout(function(){r(p.indexOf('bad')>=0?{ok:false,error:'웹스토어에서 이 확장 프로그램을 찾지 못했어요 (없어졌거나 내려받을 수 없는 항목)'}:{ok:true,ext:{name:'Bitwarden',version:'2024.9',warning:null,theme:false}})},300)})}
 return Promise.resolve(null)}};})();""" % json.dumps(EXTS)
errors = []; ok = {}
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 900, "height": 760}, color_scheme="dark", bypass_csp=True)
    pg.on("pageerror", lambda e: errors.append(str(e))); pg.add_init_script(MOCK)
    pg.goto((ROOT / "src/overlay/overlay.html").as_uri())
    pg.evaluate("window.EvOv.S={version:'0.5.0',changelog:[]}; window.EvDlg.open('extensions',{})"); pg.wait_for_selector(".xrow"); pg.wait_for_timeout(500)
    pg.screenshot(path=str(OUT / "1_extensions.png"))
    ok["목록 4개"] = pg.locator("#xList .xrow").count() == 4
    pg.click(".xsw >> nth=2"); pg.wait_for_timeout(300); ok["켜기"] = pg.locator(".xsw.on").count() == 4
    pg.fill("#xIn", "https://chromewebstore.google.com/detail/bitwarden/nngceckbapebfimnlniiiahkandclblb"); pg.click("#xGo"); pg.wait_for_timeout(120); pg.screenshot(path=str(OUT / "2_installing.png")); pg.wait_for_timeout(600)
    ok["설치 메시지"] = "Bitwarden" in pg.inner_text("#xMsg")
    pg.fill("#xIn", "bad"); pg.click("#xGo"); pg.wait_for_timeout(700); pg.screenshot(path=str(OUT / "3_install_error.png")); ok["오류 표시"] = "찾지 못했어요" in pg.inner_text("#xMsg")
    pg.click("#xTabT"); pg.wait_for_timeout(300); pg.screenshot(path=str(OUT / "4_themes.png"))
    pg.click("text=적용 >> nth=0"); pg.wait_for_timeout(300)
    pg.evaluate("EvTheme.apply(EvTheme.themeVars({theme:{colors:{frame:[16,20,44],toolbar:[26,32,64],omnibox_background:[40,48,90],tab_text:[230,230,255],button_background:[120,160,255]}}}))"); pg.wait_for_timeout(300)
    pg.screenshot(path=str(OUT / "5_theme_applied.png")); ok["테마 호출"] = any(x[0] == "ext:theme" for x in pg.evaluate("window.__sent"))
    pg.click('[data-x="tab"][data-t="ext"]'); pg.click(".xb.del >> nth=0"); pg.wait_for_timeout(400); pg.screenshot(path=str(OUT / "6_delete_confirm.png"))
    b.close()
for k, v in ok.items(): print("OK  " if v else "FAIL", k)
print("JS 오류:", errors or "없음")
