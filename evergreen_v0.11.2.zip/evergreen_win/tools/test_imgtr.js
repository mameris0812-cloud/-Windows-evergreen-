#!/usr/bin/env node
'use strict';
// 이미지 속 글자 번역을 진짜 크롬에서 확인한다: 만화 칸(말풍선·자막·그림 위 글자)과 아주 긴 웹툰 이미지를 그려서
// 실제 ImageTranslator + 페이지 쪽 스크립트(pagetools.img*Fn)를 돌리고, Gemini 만 가짜 답(글자 위치 + 번역)으로 바꾼다.
// 사용: node tools/test_imgtr.js [출력폴더]   → img_before.png / img_after.png / img_tall_before.png / img_tall_after.png / img_compare.png
const path = require('path'), fs = require('fs');
const { chromium } = require('playwright');
const PT = require('../src/main/pagetools');
const I = require('../src/shared/imgtr');
const { ImageTranslator } = require('../src/main/imgtranslate');
const OUT = process.argv[2] || '/tmp/ev_imgtr'; fs.mkdirSync(OUT, { recursive: true });
const bad = [];
const check = (c, m) => { if (!c) bad.push(m); };

// 만화 칸을 그리는 코드(페이지 안에서 돌린다). 글자마다 { text, x,y,w,h } 를 돌려줘서 가짜 Gemini 가 정확한 위치를 안다.
const DRAW = `(function(){
  var W=900,H=620,c=document.createElement('canvas');c.width=W;c.height=H;var x=c.getContext('2d'),T=[];
  var g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#7fb6e8');g.addColorStop(.62,'#cfe6f7');g.addColorStop(.62,'#6d9c5a');g.addColorStop(1,'#42693a');x.fillStyle=g;x.fillRect(0,0,W,H);
  x.fillStyle='#e8c07a';x.beginPath();x.arc(700,150,60,0,7);x.fill();
  function bubble(cx,cy,rx,ry,lines,fs,fill,col){x.fillStyle=fill||'#fff';x.strokeStyle='#222';x.lineWidth=3;x.beginPath();x.ellipse(cx,cy,rx,ry,0,0,7);x.fill();x.stroke();
    x.fillStyle=col||'#111';x.font='bold '+fs+'px Arial';x.textAlign='center';x.textBaseline='middle';var lh=fs*1.25,y0=cy-(lines.length-1)*lh/2,mw=0;
    lines.forEach(function(l,i){x.fillText(l,cx,y0+i*lh);mw=Math.max(mw,x.measureText(l).width)});
    T.push({text:lines.join(' '),x:cx-mw/2,y:y0-fs*.62,w:mw,h:(lines.length-1)*lh+fs*1.25});}
  bubble(230,130,170,80,['I thought you','said you would','be here by noon!'],26);
  bubble(640,300,150,70,["Sorry, the train","was late again."],26);
  bubble(250,430,130,60,['Hmm... really?'],28,'#fff3b0');
  x.fillStyle='#f4d35e';x.fillRect(0,0,W,0);
  x.fillStyle='#fff7c2';x.fillRect(20,540,360,60);x.strokeStyle='#222';x.lineWidth=2;x.strokeRect(20,540,360,60);
  x.fillStyle='#111';x.font='italic 24px Georgia';x.textAlign='left';x.fillText('Meanwhile, at the station…',34,570);var m=x.measureText('Meanwhile, at the station…').width;T.push({text:'Meanwhile, at the station…',x:34,y:556,w:m,h:30});
  x.font='bold 54px Impact, Arial';x.fillStyle='#fff';x.strokeStyle='#000';x.lineWidth=7;x.textAlign='center';x.lineJoin='round';x.strokeText('BOOM!',730,520);x.fillText('BOOM!',730,520);var bw=x.measureText('BOOM!').width;T.push({text:'BOOM!',x:730-bw/2,y:490,w:bw,h:62});
  window.__T=T;return c.toDataURL('image/png');
})()`;
const DRAW_TALL = `(function(){
  var W=800,H=5200,c=document.createElement('canvas');c.width=W;c.height=H;var x=c.getContext('2d'),T=[];
  var cols=['#f6e7e0','#e3eefb','#e9f5e1','#f3e8fa','#fdf2d0','#e0f4f2'];
  for(var i=0;i<6;i++){x.fillStyle=cols[i];x.fillRect(0,i*870,W,870);}
  function bub(cx,cy,lines){var fs=30;x.fillStyle='#fff';x.strokeStyle='#222';x.lineWidth=3;x.beginPath();x.ellipse(cx,cy,230,90,0,0,7);x.fill();x.stroke();
    x.fillStyle='#111';x.font='bold '+fs+'px Arial';x.textAlign='center';x.textBaseline='middle';var lh=38,y0=cy-(lines.length-1)*lh/2,mw=0;
    lines.forEach(function(l,k){x.fillText(l,cx,y0+k*lh);mw=Math.max(mw,x.measureText(l).width)});
    T.push({text:lines.join(' '),x:cx-mw/2,y:y0-20,w:mw,h:(lines.length-1)*lh+40});}
  bub(400,300,['Chapter one begins','on a quiet morning.']);
  bub(300,1100,['The first bubble','near the middle.']);
  bub(500,2050,['This one sits right on','the tile boundary!']);
  bub(300,3400,['Almost there,','keep walking.']);
  bub(500,4900,['The end of','the episode.']);
  window.__T=T;return c.toDataURL('image/png');
})()`;
const KO = { 'I thought you said you would be here by noon!': '정오까지 온다고 했잖아!', 'Sorry, the train was late again.': '미안, 기차가 또 늦었어.', 'Hmm... really?': '흠… 정말?', 'Meanwhile, at the station…': '한편, 역에서…', 'BOOM!': '쾅!',
  'Chapter one begins on a quiet morning.': '1화는 고요한 아침에 시작돼요.', 'The first bubble near the middle.': '중간쯤의 첫 번째 말풍선.', 'This one sits right on the tile boundary!': '이 말풍선은 조각 경계에 딱 걸려 있어요!', 'Almost there, keep walking.': '거의 다 왔어, 계속 걸어.', 'The end of the episode.': '이번 화의 끝.' };

(async () => {
  const br = await chromium.launch();
  const pg = await br.newPage({ viewport: { width: 980, height: 760 }, deviceScaleFactor: 2 });
  const comic = await pg.evaluate(DRAW); const comicT = await pg.evaluate('window.__T');
  const tall = await pg.evaluate(DRAW_TALL); const tallT = await pg.evaluate('window.__T');
  await pg.setContent(`<!doctype html><html lang="en"><meta charset=utf-8><body style="font:16px/1.6 'Segoe UI',sans-serif;margin:0;padding:20px 40px;background:#fafafa;color:#222">
    <h2 style="margin:0 0 6px">Episode 12 — The late train</h2><p style="margin:0 0 14px;color:#666">Swipe through the panels below.</p>
    <img id=a src="${comic}" style="display:block;width:900px;max-width:100%;border-radius:6px">
    <img id=b src="${tall}" style="display:block;width:400px;margin-top:20px;border-radius:6px"></body>`);
  await pg.waitForFunction('document.images[0].complete && document.images[1].complete');

  // 가짜 Gemini: 보낸 조각이 어느 이미지의 몇 번째 조각인지 순서대로 안다(이미지를 한 장씩 번역하므로 겹치지 않는다)
  let current = null, tileNo = 0, sentTiles = 0;
  const loose = (t, padx, pady, W, y0, th) => [Math.max(0, (t.y - pady - y0) / th * 1000), Math.max(0, (t.x - padx) / W * 1000), Math.min(1000, (t.y + t.h + pady - y0) / th * 1000), Math.min(1000, (t.x + t.w + padx) / W * 1000)].map(Math.round);
  const makeClient = () => ({ cancel() {}, stream: async (o) => {
    sentTiles++;
    const plan = I.planTiles(current.W, current.H)[tileNo++], out = [];
    current.T.forEach((t) => { const cy = t.y + t.h / 2; if (cy < plan.y0 || cy > plan.y0 + plan.h) return; out.push({ box: loose(t, 6, 4, current.W, plan.y0, plan.h), text: t.text, tr: KO[t.text], v: 0 }); });
    o.cb.text('```json\n' + JSON.stringify(out) + '\n```'); return { ok: true };
  } });
  const toasts = [];
  const d = { PT, call: PT.call, run: (wc, code) => pg.evaluate(code), toast: (m) => toasts.push(m), changed() {}, makeClient, pickVision: () => ({ key: 'K', model: 'vision' }), fetchImage: async () => null };
  const it = new ImageTranslator(d);

  await pg.screenshot({ path: path.join(OUT, 'img_before.png'), fullPage: true });
  // ① 만화 칸 한 장
  current = { W: 900, H: 620, T: comicT }; tileNo = 0;
  const srcA = await pg.evaluate('document.getElementById("a").currentSrc');
  const r1 = await it.translateOne({ id: 1 }, 'ko', srcA);
  check(r1.applied === 1, '만화 칸 번역 실패: ' + JSON.stringify(r1));
  await pg.waitForTimeout(1200);
  const ov = await pg.evaluate('(function(){var r=document.getElementById("__ev_img_root");return r?Array.prototype.map.call(r.querySelectorAll("span"),function(s){return s.textContent}):[]})()');
  check(ov.length === 5, '덮개 글 ' + ov.length + '개(5개여야 함): ' + ov.join(' | '));
  check(ov.includes('쾅!') && ov.includes('흠… 정말?'), '번역문 누락');
  const flat = await pg.evaluate('(function(){var d=document.querySelectorAll("#__ev_img_root div div");return Array.prototype.map.call(d,function(e){return e.style.backdropFilter?1:0})})()');
  check(flat.length === 5, '덮개 상자 ' + flat.length + '개');   // BOOM! 은 단색에 가까운 풀밭 위라 불투명 덮개가 된다(그림이 복잡한 곳이면 블러)
  // 덮개 상자끼리 겹치지 않는지
  const rects = await pg.evaluate('Array.prototype.map.call(document.querySelectorAll("#__ev_img_root div div"),function(e){var r=e.getBoundingClientRect();return [r.left,r.top,r.right,r.bottom]})');
  let overlap = 0; for (let i = 0; i < rects.length; i++) for (let j = i + 1; j < rects.length; j++) { const a = rects[i], b = rects[j]; if (Math.min(a[2], b[2]) - Math.max(a[0], b[0]) > 1 && Math.min(a[3], b[3]) - Math.max(a[1], b[1]) > 1) overlap++; }
  check(overlap === 0, '덮개끼리 겹침 ' + overlap);
  const has = await it.has({ id: 1 }, srcA); check(has === true, 'has() 가 true 여야 함');
  await pg.screenshot({ path: path.join(OUT, 'img_after.png'), fullPage: true });
  // 번역 해제
  const n0 = await it.clear({ id: 1 }, srcA); check(n0 === 1, '해제한 이미지 수 ' + n0);
  check((await it.has({ id: 1 }, srcA)) === false, '해제 뒤 has() 가 false 여야 함');
  check((await pg.evaluate('document.querySelectorAll("#__ev_img_root div div").length')) === 0, '해제 뒤에도 덮개가 남음');
  // ② 아주 긴 웹툰 이미지: 조각으로 나눠 보내고 경계 글자는 한 번만
  const srcB = await pg.evaluate('document.getElementById("b").currentSrc');
  current = { W: 800, H: 5200, T: tallT }; tileNo = 0; sentTiles = 0;
  const r2 = await it.translateOne({ id: 1 }, 'ko', srcB);
  check(r2.applied === 1, '긴 이미지 번역 실패: ' + JSON.stringify(r2));
  check(sentTiles === I.planTiles(800, 5200).length, '조각 수 ' + sentTiles);
  await pg.waitForTimeout(1200);
  const ov2 = await pg.evaluate('Array.prototype.map.call(document.querySelectorAll("#__ev_img_root span"),function(s){return s.textContent})');
  check(ov2.length === 5, '긴 이미지 덮개 글 ' + ov2.length + '개(5개여야 함, 경계 글자 중복 없이): ' + ov2.join(' | '));
  check(new Set(ov2).size === ov2.length, '경계 글자가 두 번 번역됨');
  await pg.screenshot({ path: path.join(OUT, 'img_tall_after.png'), fullPage: true });
  // ③ 모두 걷기(원문 보기)
  const cleared = await it.clear({ id: 1 }); check(cleared === 5, '전체 해제 개수 ' + cleared);
  await br.close();
  console.log('이미지 번역(진짜 크롬):', bad.length ? '' : '통과'); bad.forEach((b) => console.log('  ', b));
  console.log('토스트:', toasts.join(' / '));
  process.exit(bad.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
