'use strict';
// npm install 뒤에 실행: hls.js(스트리밍 재생)와 ffmpeg(스트리밍 저장을 mp4 로 합칠 때)를 src/ 안으로 복사한다.
// src/ 에 두는 이유: 설치 파일에 확실히 들어가게 하려고. 없어도 앱은 동작한다(스트리밍 재생·mp4 합치기만 빠짐).
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
function copy(from, to) {
  try { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(from, to); console.log('복사:', path.relative(root, to)); return true; } catch (e) { console.log('건너뜀:', path.relative(root, to), '-', e.code || e.message); return false; }
}
copy(path.join(root, 'node_modules', 'hls.js', 'dist', 'hls.min.js'), path.join(root, 'src', 'player', 'vendor', 'hls.min.js'));
try {
  const ff = require('ffmpeg-static');
  if (ff) copy(ff, path.join(root, 'src', 'vendor', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg'));
} catch (e) { console.log('건너뜀: ffmpeg-static 없음'); }
