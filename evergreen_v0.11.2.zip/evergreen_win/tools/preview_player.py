#!/usr/bin/env python3
"""플레이어 화면 미리보기: 진짜 player.html 을 헤드리스 크롬으로 열고(가짜 메인 프로세스), 동작을 눌러 보며 PNG 로 저장한다.
   사용: python3 tools/preview_player.py 영상파일 [출력폴더]"""
import sys, pathlib, json
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
VIDEO = pathlib.Path(sys.argv[1]).resolve()
OUT = pathlib.Path(sys.argv[2] if len(sys.argv) > 2 else "/tmp/ev_player"); OUT.mkdir(parents=True, exist_ok=True)
SRT = "1\n00:00:01,000 --> 00:00:09,000\n안녕하세요, 에버그린 플레이어입니다.\n두 번째 줄 자막\n\n2\n00:00:10,000 --> 00:00:20,000\nHello, this is a subtitle\n"
MOCK = """(function(){var H={};window.__sent=[];window.__fire=function(c,p){(H[c]||[]).forEach(function(f){f(p)})};
window.evergreen={send:function(c,p){window.__sent.push([c,p])},on:function(c,cb){(H[c]=H[c]||[]).push(cb)},
invoke:function(c){return Promise.resolve(c==='pl:subfile'?{name:'예시.srt',text:%s}:null)}};})();""" % json.dumps(SRT)
errors = []
with sync_playwright() as p:
    b = p.chromium.launch(args=["--autoplay-policy=no-user-gesture-required"])
    pg = b.new_page(viewport={"width": 1280, "height": 720}, color_scheme="dark", bypass_csp=True)
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.on("console", lambda m: errors.append("console: " + m.text) if m.type == "error" and "hls.min" not in m.text and "Failed to load resource" not in m.text else None)
    pg.add_init_script(MOCK)
    pg.goto((ROOT / "src/player/player.html").as_uri() + "?mode=player")
    pg.evaluate("window.__fire('pl:init',{mode:'player',url:%s,title:'여행 브이로그 #3 — 제주도 한 바퀴',host:'example.com',subs:[],startAt:0,prefs:{},dark:true,capRight:140})" % json.dumps(VIDEO.as_uri()))
    pg.wait_for_function("window.__player.st.dur>0", timeout=8000)
    pg.mouse.move(600, 300); pg.wait_for_timeout(1500)
    pg.screenshot(path=str(OUT / "1_playing_controls.png"))
    ok = {}
    ok["재생 중"] = pg.evaluate("window.__player.st.playing")
    pg.keyboard.press("ArrowRight"); pg.wait_for_timeout(200)
    ok["→ 5초"] = pg.evaluate("window.__player.st.pos") > 5
    # 자막 파일
    pg.click("#cCc"); pg.wait_for_timeout(400); pg.screenshot(path=str(OUT / "2_subs_panel.png"))
    pg.click("#panel >> text=자막 파일 열기…"); pg.wait_for_timeout(600)
    ok["자막 파일"] = pg.evaluate("window.__player.sub().kind") == "file"
    pg.mouse.move(640, 300); pg.wait_for_timeout(700); pg.screenshot(path=str(OUT / "3_subtitle_shown.png"))
    ok["자막 글자"] = "에버그린" in pg.inner_text("#subMain") or "subtitle" in pg.inner_text("#subMain")
    # 설정
    pg.mouse.move(640, 300); pg.click("#bGear"); pg.wait_for_timeout(400); pg.screenshot(path=str(OUT / "4_settings.png"))
    pg.click("#panel >> text=재생 속도"); pg.wait_for_timeout(300); pg.click("#panel >> text=1.5x"); pg.wait_for_timeout(200)
    ok["속도 1.5x"] = pg.evaluate("window.__player.st.speed") == 1.5
    pg.click("text=취침 타이머") if pg.query_selector("text=취침 타이머") else None
    pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
    pg.click("#bGear"); pg.click("#panel >> text=취침 타이머"); pg.wait_for_timeout(300); pg.screenshot(path=str(OUT / "5_sleep.png"))
    pg.click("text=30분 뒤"); pg.wait_for_timeout(300); print("panel after sleep:", pg.evaluate("[window.__player.sleep.active, document.getElementById('scrim').className, document.getElementById('panel').className]"))
    ok["취침 타이머"] = pg.evaluate("window.__player.sleep.active")
    pg.click("#bGear"); pg.click("#panel >> text=자막"); pg.click("#panel >> text=자막 스타일"); pg.click("#panel >> text=글자 크기"); pg.click("#panel >> text=아주 크게"); pg.wait_for_timeout(300)
    pg.screenshot(path=str(OUT / "6_sub_style.png"))
    pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
    # 재생막대 끌기
    box = pg.query_selector("#seek").bounding_box(); pg.mouse.move(box["x"] + 50, box["y"] + 14); pg.mouse.down(); pg.mouse.move(box["x"] + box["width"] * .6, box["y"] + 14, steps=5)
    pg.screenshot(path=str(OUT / "7_seek_drag.png")); pg.mouse.up(); pg.wait_for_timeout(300)
    ok["막대 이동"] = pg.evaluate("window.__player.st.pos") > 12
    # 일시정지 / 키
    pg.keyboard.press("Space"); pg.wait_for_timeout(300); ok["Space 일시정지"] = not pg.evaluate("window.__player.st.playing")
    pg.keyboard.press("m"); pg.wait_for_timeout(200); ok["m 음소거"] = pg.evaluate("window.__player.st.muted")
    # 두 번 클릭(양옆 10초)
    t0 = pg.evaluate("window.__player.st.pos"); pg.mouse.dblclick(900 + 200, 300); pg.wait_for_timeout(350)
    ok["오른쪽 더블클릭 +10초"] = pg.evaluate("window.__player.st.pos") > t0 + 8
    # 닫기 (아래로 끌기)
    pg.mouse.move(640, 300); pg.mouse.down(); pg.mouse.move(640, 560, steps=8); pg.screenshot(path=str(OUT / "8_swipe_down.png")); pg.mouse.up(); pg.wait_for_timeout(500)
    ok["끌어내려 닫기"] = any(m[0] == "pl:close" for m in pg.evaluate("window.__sent"))
    # 오류 화면
    pg.evaluate("window.__player.showError('이 영상은 재생할 수 없어요','지원하지 않는 형식이거나 주소가 막혔을 수 있어요.','MEDIA_ERR_4')"); pg.wait_for_timeout(300)
    pg.screenshot(path=str(OUT / "9_error.png"))
    # 미러링 모드
    m = b.new_page(viewport={"width": 1280, "height": 720}, color_scheme="dark", bypass_csp=True); m.on("pageerror", lambda e: errors.append("mirror: " + str(e))); m.add_init_script(MOCK)
    m.goto((ROOT / "src/player/player.html").as_uri() + "?mode=mirror")
    m.evaluate("window.__fire('pl:init',{mode:'mirror',url:'',title:'',host:'',prefs:{},dark:true,capRight:0})")
    m.evaluate("window.__fire('pl:mstate',{on:true,pos:312,dur:1480,playing:true,speed:1,buffered:600,volume:.8,muted:false,title:'오늘의 뉴스 - 라이브러리',host:'video.example.com',tracks:[{idx:0,label:'한국어'}],track:-1,cue:'',fit:'contain'})")
    m.add_style_tag(content="body{background:linear-gradient(135deg,#335,#8a6) !important}")
    m.mouse.move(500, 300); m.wait_for_timeout(500); m.screenshot(path=str(OUT / "10_mirror.png"))
    m.click("#bFwd10"); ok["미러링 명령 전달"] = any(x[0] == "pl:cmd" and x[1]["a"] == "seek" for x in m.evaluate("window.__sent"))
    b.close()
for k, v in ok.items(): print(("OK  " if v else "FAIL"), k)
print("JS 오류:", errors or "없음")
