'use strict';
// 자동 스크롤 통합 확인: 진짜 크롬 + 가짜 webContents 로 main/autoscroll.js 의 AutoScroller 를 그대로 돌린다.
//   node tools/test_autoscroll.js     (playwright 필요)
// 확인: 흐름 · 휠로 잠깐 멈춤 · 완전히 멈춤 모드 · Esc · 웹툰 끝 일시정지 → ▶ 이어 가기 → 페이지 끝 · 조작 막대 없이 서서히 정지 · 안쪽 칸 스크롤 · 새 페이지 이동
const { chromium } = require('playwright');
const { AutoScroller } = require('../src/main/autoscroll');
const A = require('../src/shared/autoscroll');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('  ✗ ' + m); } else console.log('  ✓ ' + m); };

const svg = (n) => 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="640" height="700"><rect width="640" height="700" fill="#' + (n % 2 ? 'eef' : 'fee') + '"/><text x="40" y="360" font-size="60">' + n + '</text></svg>');
const webtoon = (cuts = 6) => '<body style="margin:0;font:16px sans-serif"><div style="width:640px;margin:0 auto">' +
  Array.from({ length: cuts }, (_, i) => '<img src="' + svg(i) + '" width="640" height="700" style="display:block">').join('') +
  '</div><div style="height:1400px;background:#fafafa;padding:20px">댓글 영역</div></body>';
const longText = () => '<body style="margin:0">' + '<p style="height:300px;margin:0">문단</p>'.repeat(30) + '</body>';
const inner = () => '<body style="margin:0;overflow:hidden"><div id="v" style="height:100vh;overflow-y:auto">' + '<p style="height:400px;margin:0">칸</p>'.repeat(20) + '</div></body>';

async function rig(html, cfg, vp) {
  const br = await chromium.launch();
  const page = await br.newPage({ viewport: vp || { width: 900, height: 700 } });
  await page.setContent(html); await sleep(150);
  const wc = { isDestroyed: () => false, getZoomFactor: () => 1, getURL: () => 'https://example.test/',
    executeJavaScriptInIsolatedWorld: (_w, [{ code }]) => page.evaluate(code) };
  const store = { d: { autoScroll: cfg }, get(k) { return this.d[k]; }, set(k, v) { this.d[k] = v; } };
  const toasts = []; let pillOn = false, pill = [];
  const tab = { id: 1, view: { webContents: wc } };
  const as = new AutoScroller({ store, toast: (m) => toasts.push(m), changed() {}, allowed: () => true,
    pill: { show: (s) => { pillOn = true; pill.push(s); }, update: (s) => pill.push(s), hide: () => { pillOn = false; }, shown: () => pillOn } });
  return { br, page, as, tab, toasts, pill, y: () => page.evaluate(() => window.pageYOffset), done: () => br.close(), wc };
}

(async () => {
  let r;
  console.log('① 흐르기 · 휠로 잠깐 멈춤 · 이어서 흐름');
  r = await rig(longText(), { speed: 20 });                     // 20단계 = 초당 500
  await r.as.start(r.tab); await sleep(1000);
  let y1 = await r.y(); ok(y1 > 350 && y1 < 650, '1초에 약 500px 내려감 (' + Math.round(y1) + ')');
  await r.page.mouse.move(300, 300); await r.page.mouse.wheel(0, -100); await sleep(250);
  const yh = await r.y(); await sleep(400); const yh2 = await r.y();
  ok(Math.abs(yh2 - yh) < 3, '휠을 굴리면 멈춰 있음 (' + Math.round(yh) + ' → ' + Math.round(yh2) + ')');
  await sleep(1600); ok((await r.y()) > yh2 + 100, '조금 뒤 이어서 흐름');
  ok(r.as.running, '여전히 켜져 있음');
  r.as.stop('x'); await sleep(200); const ys = await r.y(); await sleep(300); ok((await r.y()) === ys, '멈춘 뒤에는 안 움직임'); await r.done();

  console.log('② 만지면 완전히 멈춤 (touch=1) · Esc');
  r = await rig(longText(), { speed: 10, touch: 1 });
  await r.as.start(r.tab); await sleep(500); await r.page.mouse.click(300, 300); await sleep(400);
  ok(!r.as.running, '화면을 누르면 완전히 멈춤'); ok(r.toasts.includes('자동 스크롤을 멈췄어요'), '멈춤 알림');
  await r.done();
  r = await rig(longText(), { speed: 10 });
  await r.as.start(r.tab); await sleep(400); await r.page.keyboard.press('Escape'); await sleep(400);
  ok(!r.as.running, 'Esc 로 멈춤'); await r.done();
  r = await rig(longText(), { speed: 10, touch: 0 });
  await r.as.start(r.tab); await sleep(400); await r.page.mouse.click(300, 300); await sleep(100);
  ok(r.as.running, 'touch=0 이면 눌러도 꺼지지 않음'); const yc = await r.y(); await sleep(250); ok(Math.abs((await r.y()) - yc) < 3, '누른 직후엔 잠깐 쉼'); await sleep(1200); ok((await r.y()) > yc + 20, '곧 이어 흐름'); await r.done();

  console.log('③ 웹툰 끝: 막대가 있으면 일시정지 → ▶ → 페이지 끝에서 끔');
  r = await rig(webtoon(), { speed: 40, pauseAtEnd: true, controls: true });
  await r.as.start(r.tab); let paused = false;
  for (let i = 0; i < 100 && !paused; i++) { await sleep(150); paused = r.as.snapshot().paused; }
  const ye = await r.y();
  ok(paused, '웹툰 마지막 컷 뒤에서 일시정지'); ok(r.toasts.some((t) => /웹툰 끝/.test(t)), '일시정지 알림');
  ok(ye > 4200 - 700 && ye < 4200 + 100, '마지막 컷(4200px) 근처에서 멈춤: y=' + Math.round(ye) + ' (화면 700)');
  ok(r.pill[r.pill.length - 1].paused === true, '조작 막대가 ▶ 로 바뀜');
  await sleep(500); ok(Math.abs((await r.y()) - ye) < 3, '일시정지 중엔 안 움직임');
  r.as.command('pause'); await sleep(1500); ok((await r.y()) > ye + 100, '▶ 누르면 댓글 쪽으로 이어 흐름');
  for (let i = 0; i < 60 && r.as.running; i++) await sleep(200);
  ok(!r.as.running, '페이지 맨 끝에서 꺼짐'); ok(r.toasts.some((t) => /페이지 끝/.test(t)), '끝 알림'); await r.done();

  console.log('④ 막대가 꺼져 있으면 서서히 느려지다 정지 / 끝 멈춤을 끄면 계속 흐름');
  r = await rig(webtoon(), { speed: 40, pauseAtEnd: true, controls: false });
  await r.as.start(r.tab); for (let i = 0; i < 100 && r.as.running; i++) await sleep(150);
  const yf = await r.y(); ok(!r.as.running, '정지함'); ok(yf > 3500 && yf < 4700, '웹툰 끝에서 멈춤(댓글까지 안 감): y=' + Math.round(yf)); await r.done();
  r = await rig(webtoon(), { speed: 40, pauseAtEnd: false, controls: true });
  await r.as.start(r.tab); await sleep(5500);
  ok((await r.y()) > 4600 && !r.as.snapshot().paused, '끝 멈춤이 꺼져 있으면 댓글 영역까지 계속 흐름: y=' + Math.round(await r.y())); r.as.stop(null); await r.done();

  console.log('⑤ 안쪽 칸이 스크롤되는 페이지');
  r = await rig(inner(), { speed: 20 });
  await r.as.start(r.tab); await sleep(1000);
  const yi = await r.page.evaluate(() => document.getElementById('v').scrollTop); ok(yi > 300 && yi < 700, '안쪽 칸이 내려감: ' + Math.round(yi)); r.as.stop(null); await r.done();

  console.log('⑥ 새 페이지로 이동 · 일시정지 중엔 막대 유지 · 스크롤 안 되는 페이지');
  r = await rig(longText(), { speed: 20 });
  await r.as.start(r.tab); await sleep(300); r.as.onNavigate(r.tab); ok(!r.as.running, '흐르는 중 이동하면 멈춤'); await r.done();
  r = await rig(longText(), { speed: 20 });
  await r.as.start(r.tab); await sleep(300); r.as.command('pause'); r.as.onNavigate(r.tab); ok(r.as.running, '일시정지 중 이동하면 막대를 둠'); r.as.stop(null); await r.done();
  r = await rig('<body style="margin:0"><p>짧은 글</p></body>', { speed: 20 });
  await r.as.start(r.tab); for (let i = 0; i < 40 && r.as.running; i++) await sleep(150);
  ok(!r.as.running && r.toasts.some((t) => /스크롤할 수 없어요/.test(t)), '스크롤할 수 없는 페이지는 알리고 끔'); await r.done();

  console.log('⑦ 속도 바꾸기 · 설정 저장');
  r = await rig(longText(), { speed: 6 });
  await r.as.start(r.tab); r.as.command('faster'); r.as.command('faster'); r.as.command('slower');
  ok(r.as.cfg.speed === 7, '막대의 +/- 가 속도 단계를 바꿈 (7)');
  r.as.setCfg({ smart: true }); r.as.command('faster'); ok(r.as.cfg.contentLevel === 16 && r.as.cfg.blankLevel === 41, '스마트에서는 두 단계를 함께 바꿈');
  r.as.stop(null); await r.done();

  console.log('⑧ 스마트: 화면을 읽어 빈 그림이면 빠르게, 글·그림이면 천천히');
  {
    const html = '<body style="margin:0"><div style="height:2200px;background:#fff"></div><div style="height:2200px;background:repeating-linear-gradient(90deg,#000 0 4px,#fff 4px 9px)"></div></body>';
    r = await rig(html, { smart: true, contentLevel: 5, blankLevel: 40, touch: 0 });
    // 진짜 Electron 의 capturePage → NativeImage 대신, 크롬 스크린샷을 160폭 BGRA 로 바꿔 주는 가짜
    r.wc.capturePage = async (rect) => {
      const png = (await r.page.screenshot({ clip: { x: rect.x, y: rect.y, width: rect.width, height: rect.height } })).toString('base64');
      const px = await r.page.evaluate(async ([b64, w]) => {
        const im = new Image(); im.src = 'data:image/png;base64,' + b64; await im.decode();
        const h = Math.max(1, Math.round(w * im.height / im.width)), c = document.createElement('canvas'); c.width = w; c.height = h;
        const g = c.getContext('2d'); g.drawImage(im, 0, 0, w, h); return { w, h, d: Array.from(g.getImageData(0, 0, w, h).data) };
      }, [png, 160]);
      const bgra = Buffer.alloc(px.d.length); for (let i = 0; i < px.d.length; i += 4) { bgra[i] = px.d[i + 2]; bgra[i + 1] = px.d[i + 1]; bgra[i + 2] = px.d[i]; bgra[i + 3] = 255; }
      const img = { isEmpty: () => false, resize: () => img, getSize: () => ({ width: px.w, height: px.h }), toBitmap: () => bgra };
      return img;
    };
    await r.as.start(r.tab); await sleep(2600);
    const lvBlank = r.as.smartLevel; ok(lvBlank > 33, '빈 그림 구간: 단계가 빈 그림 단계(40)로 올라감 → ' + lvBlank.toFixed(1));
    await r.page.evaluate(() => window.scrollTo(0, 2500)); await sleep(1000);
    const lvText = r.as.smartLevel; ok(lvText < 9, '글·그림 구간: 내용 단계(5)로 빠르게 내려옴 → ' + lvText.toFixed(1));
    ok(r.pill.some((p) => p.smart), '조작 막대에 스마트 표시');
    r.as.stop(null); await r.done();
  }

  console.log(fails ? '\n실패 ' + fails + '개' : '\n모두 통과');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
