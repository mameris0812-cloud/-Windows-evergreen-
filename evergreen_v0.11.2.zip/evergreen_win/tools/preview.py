#!/usr/bin/env python3
"""화면 미리보기: 실제 renderer/overlay/newtab 파일을 크롬(헤드리스)으로 열고, 메인 프로세스 대신 가짜 데이터를 넣어 PNG 로 저장한다.
   사용: python3 tools/preview.py [출력폴더]   (playwright 필요)   → 자바스크립트 오류가 있으면 끝에 목록을 보여 준다."""
import json, sys, time, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/ev_shots")
OUT.mkdir(parents=True, exist_ok=True)
NOW = int(time.time() * 1000)
MIN, DAY = 60000, 86400000

def bm(i, url, title, f=0): return {"id": i, "url": url, "title": title, "folderId": f, "fav": ""}
DB = {
  "bookmarks": {"bookmarks": [
      bm(1, "https://www.naver.com", "NAVER"), bm(2, "https://github.com", "GitHub"), bm(3, "https://ko.wikipedia.org/wiki/위키백과", "위키백과, 우리 모두의 백과사전"),
      bm(4, "https://news.ycombinator.com", "Hacker News", 1), bm(5, "https://www.bbc.com/news", "BBC News", 1), bm(6, "https://developer.mozilla.org", "MDN Web Docs", 2)],
    "folders": [{"id": 1, "name": "뉴스"}, {"id": 2, "name": "개발"}]},
  "history": {"now": NOW, "items": [
      {"url": "https://www.google.com/search?q=evergreen", "title": "evergreen - Google 검색", "time": NOW - 4 * MIN, "fav": ""},
      {"url": "https://github.com/anthropics", "title": "Anthropic · GitHub", "time": NOW - 22 * MIN, "fav": ""},
      {"url": "https://www.naver.com", "title": "NAVER", "time": NOW - 3 * 3600000, "fav": ""},
      {"url": "https://ko.wikipedia.org/wiki/위키백과", "title": "위키백과, 우리 모두의 백과사전", "time": NOW - DAY - 5 * 3600000, "fav": ""},
      {"url": "https://developer.mozilla.org/ko/docs/Web", "title": "웹 개발 학습하기 | MDN", "time": NOW - DAY - 6 * 3600000, "fav": ""},
      {"url": "https://www.bbc.com/news", "title": "BBC News", "time": NOW - 4 * DAY, "fav": ""}]},
  "downloads": {"active": [
      {"id": 2, "name": "ubuntu-24.04-desktop-amd64.iso", "total": 6200000000, "received": 2790000000, "speed": 18400000, "paused": False},
      {"id": 3, "name": "report_final.pdf", "total": 0, "received": 1800000, "speed": 0, "paused": True}],
    "done": [{"key": "d:3", "name": "evergreen_win_setup_0.3.0_x64.exe", "path": "x", "size": 84300000, "time": NOW - 2 * 3600000},
             {"key": "d:2", "name": "여행 계획서.xlsx", "path": "x", "size": 52000, "time": NOW - DAY},
             {"key": "d:1", "name": "photo (1).jpg", "path": "x", "size": 2400000, "time": NOW - 3 * DAY}],
    "folders": [{"id": 1, "name": "업무"}], "folderMap": {"d:2": 1}},
  "shortcuts": [{"name": "Google", "url": "https://www.google.com", "glyph": "G"}, {"name": "네이버", "url": "https://www.naver.com", "glyph": "N"},
                {"name": "YouTube", "url": "https://www.youtube.com", "glyph": "▶"}, {"name": "GitHub", "url": "https://github.com", "glyph": ""}],
}
STATE = {"activeWin": 1, "wins": [{"id": 1, "num": 1, "name": "창 1", "active": 11, "tabs": [
    {"id": 10, "title": "evergreen - Google 검색", "url": "https://www.google.com/search?q=evergreen", "favicon": "", "loading": False, "incognito": False, "audible": False, "canBack": True, "canFwd": False, "secure": True, "zoom": 100, "zoomOnly": False, "bookmarked": False},
    {"id": 11, "title": "위키백과, 우리 모두의 백과사전", "url": "https://ko.wikipedia.org/wiki/위키백과", "favicon": "", "loading": False, "incognito": False, "audible": False, "canBack": True, "canFwd": True, "secure": True, "zoom": 120, "zoomOnly": True, "bookmarked": True},
    {"id": 12, "title": "", "url": "", "favicon": "", "loading": False, "incognito": False, "audible": False, "canBack": False, "canFwd": False, "secure": False, "zoom": 100, "zoomOnly": False, "bookmarked": False}]},
  {"id": 2, "num": 2, "name": "업무", "active": 20, "tabs": [{"id": 20, "title": "x", "url": "", "favicon": "", "loading": False, "incognito": False, "audible": False, "canBack": False, "canFwd": False, "secure": False, "zoom": 100, "zoomOnly": False, "bookmarked": False}]}],
  "prefs": {"theme": "system", "engine": "google", "zoom": 100, "bookmarkBar": True},
  "engines": [{"key": "google", "name": "Google"}, {"key": "naver", "name": "네이버"}, {"key": "ddg", "name": "DuckDuckGo"}, {"key": "bing", "name": "Bing"}],
  "dl": {"count": 2, "progress": 0.45},
  "sec": {"summary": "보호 수준 보통 · 오늘 41번 차단", "adBlock": True}}

KIND_COLORS = ["#7E57C2", "#EF5350", "#5C6BC0", "#FF9800", "#26A69A", "#42A5F5", "#D81B60", "#66BB6A"]
KIND_LABELS = ["광고·추적 요청", "광고 팝업·페이지 이동", "트래커 (엄격 모드)", "클릭 가로채기 이동", "자동 다운로드", "뒤로가기 중 자동 이동", "악성 사이트", "보안 연결(HTTPS)로 올림"]
_parts = [[3, 1, 0, 2, 0, 1], [8, 0, 1, 4, 0, 2], [0, 0, 0, 0, 0, 0], [12, 2, 0, 3, 1, 5], [6, 1, 1, 6, 0, 3], [21, 3, 2, 7, 0, 4], [14, 1, 0, 9, 0, 2]]
DB["adstats"] = {"enabled": True, "since": NOW - 40 * DAY, "total": 18342, "today": 213, "session": 96, "requests": 88, "popups": 8, "pageBlocked": 12,
  "top": [["doubleclick.net", 31], ["googlesyndication.com", 22], ["adnxs.com", 11], ["taboola.com", 9], ["criteo.com", 6]], "week": [42, 118, 0, 160, 97, 233, 213],
  "lists": {"hosts": 148211, "rules": 61874, "css": 9320, "updated": NOW - 5 * 3600000, "updating": False, "malware": 9244}}
DB["secstats"] = {"protection": {"score": 6, "max": 8, "level": 1, "levelName": "보통", "off": ["트래커 차단(엄격)", "캡차 건너뛰기(서드파티 쿠키 차단)"]},
  "days": [{"total": sum(x), "parts": x, "dow": d} for x, d in zip(_parts, "토일월화수목금")], "today": 41, "firstSecurity": 2,
  "kinds": [{"k": 2 + i, "label": KIND_LABELS[2 + i], "color": KIND_COLORS[2 + i], "today": _parts[6][i], "week": sum(r[i] for r in _parts)} for i in range(6)],
  "settings": {"adBlock": True, "ytAdBlock": True, "ytAdPrune": True, "strictTrackers": False, "skipCaptcha": False, "malwareWarning": True, "blockAutoDownload": True, "blockBackRedirect": True, "notifyBackBlocked": True, "httpsFirst": True, "blockHijackNav": True}}

MOCK = """(function(){ var H={}, DB=%s;
 window.__sent=[]; window.__fire=function(c,p){(H[c]||[]).forEach(function(f){f(p)})};
 window.evergreen={send:function(c,p){window.__sent.push([c,p])},on:function(c,cb){(H[c]=H[c]||[]).push(cb)},
   invoke:function(c,p){return Promise.resolve(c==='data:get'?DB[p]:null)}};
 if(/newtab\\.html$/.test(location.pathname)) window.evergreenNewTab={go:function(){},shortcuts:function(){return Promise.resolve(DB.shortcuts)},onShortcuts:function(){},menu:function(){},add:function(){},cards:function(){return Promise.resolve({adWeek:1284,secToday:41})},onCards:function(){},openCard:function(){}};
})();""" % json.dumps(DB)

def harness(w, h):
    return f"""<!doctype html><meta charset=utf-8><style>html,body{{margin:0;background:#888}}
#win{{position:relative;width:{w}px;height:{h}px;overflow:hidden;background:var(--b,#fff)}}
iframe{{border:0;position:absolute;background:transparent;color-scheme:normal}}
#web{{position:absolute;left:0;right:0;top:132px;bottom:0;background:#fff;padding:32px 64px;font:15px/1.7 sans-serif;color:#222}}
#web.dark{{background:#16181c;color:#ccc}} #web h1{{font-size:34px;margin:0 0 6px}} #web p{{max-width:760px;color:#666}} #web.dark p{{color:#99a}}</style>
<div id=win><iframe id=chrome src="file://{SRC}/renderer/index.html" style="left:0;top:0;width:{w}px;height:132px"></iframe>
<div id=web><h1>위키백과</h1><p>위키백과는 누구나 자유롭게 쓸 수 있는 인터넷 백과사전입니다. 웹 화면은 네이티브 뷰라서, 팝업·토스트·추천은 그 위의 투명 층에서 그려집니다.</p><p>이 영역은 미리보기용 가짜 웹페이지예요.</p></div>
<iframe id=overlay src="file://{SRC}/overlay/overlay.html" style="left:0;top:0;width:{w}px;height:{h}px;display:none"></iframe>
<iframe id=toast src="file://{SRC}/toast/toast.html" style="display:none"></iframe>
<iframe id=suggest src="file://{SRC}/suggest/suggest.html" style="display:none"></iframe></div>"""

errors = []
def run():
    with sync_playwright() as p:
        br = p.chromium.launch()
        for scheme in ("light", "dark"):
            ctx = br.new_context(viewport={"width": 1280, "height": 780}, color_scheme=scheme, device_scale_factor=1)
            ctx.add_init_script(MOCK)
            page = ctx.new_page()
            page.on("pageerror", lambda e, s=scheme: errors.append(f"[{s}] pageerror: {e}"))
            page.on("console", lambda m, s=scheme: errors.append(f"[{s}] console.{m.type}: {m.text}") if m.type == "error" and "ERR_" not in m.text and "Failed to load resource" not in m.text else None)
            page.route("**/*", lambda r: r.abort() if r.request.url.startswith("http") else r.continue_())
            hp = OUT / f"_h_{scheme}.html"; hp.write_text(harness(1280, 780), encoding="utf-8")
            page.goto(f"file://{hp}")
            if scheme == "dark": page.evaluate("document.getElementById('web').classList.add('dark')")
            time.sleep(0.5)
            fr = {n: next(f for f in page.frames if n in f.url) for n in ("renderer/index", "overlay/overlay", "toast/toast", "suggest/suggest")}
            chrome, ov, toast, sug = fr["renderer/index"], fr["overlay/overlay"], fr["toast/toast"], fr["suggest/suggest"]
            chrome.evaluate("s=>__fire('state',s)", STATE); time.sleep(0.3)
            page.evaluate("document.getElementById('chrome').style.height = document.getElementById('chrome').contentDocument ? '' : ''")
            h = chrome.evaluate("document.getElementById('top').offsetHeight")
            page.evaluate(f"document.getElementById('chrome').style.height='{h}px';document.getElementById('web').style.top='{h}px'")
            def shot(name, clip=None): page.screenshot(path=str(OUT / f"{name}_{scheme}.png"), clip=clip)
            def show_overlay(kind, anchor=None, data=None, left=False):
                page.evaluate("document.getElementById('overlay').style.display='block'")
                ov.evaluate("m=>__fire('overlay:show',m)", {"kind": kind, "anchor": anchor or {"x": 1232, "y": 51, "w": 40, "h": 40}, "left": left, "data": data, "state": STATE})
                time.sleep(0.55)
            def hide_overlay():
                page.evaluate("document.getElementById('overlay').style.display='none'")
                ov.goto(f"file://{SRC}/overlay/overlay.html"); time.sleep(0.4)
            # 1. 기본 화면: 북마크 막대 + 별 + 확대 배지 + 다운로드 단추
            shot("01_browser", {"x": 0, "y": 0, "width": 1280, "height": 300})
            # 2. 추천 + 토스트
            page.evaluate(f"var s=document.getElementById('suggest');s.style.display='block';s.style.left='{12+34+40+40+8-14}px';s.style.top='{h-8}px';s.style.width='700px';s.style.height='260px'")
            sug.evaluate("p=>__fire('suggest:show',p)", {"items": ["https://ko.wikipedia.org/wiki/위키백과", "https://www.wikipedia.org", "위키백과", "위키백과 한국어", "위키 사이트"], "selected": 1, "dark": scheme == "dark"}); time.sleep(0.5)
            sh = sug.evaluate("document.body.scrollHeight"); page.evaluate(f"document.getElementById('suggest').style.height='{sh}px'")
            page.evaluate("var t=document.getElementById('toast');t.style.display='block';t.style.width='600px';t.style.height='80px';t.style.left='0px';t.style.top='300px'")
            toast.evaluate("p=>__fire('toast:show',p)", {"msg": "북마크 3개를 삭제했습니다", "label": "실행 취소"}); time.sleep(0.4)
            sz = [x for x in toast.evaluate("__sent") if x[0] == "toast:size"][-1][1]
            page.evaluate(f"var t=document.getElementById('toast');t.style.display='block';t.style.width='{int(sz['w'])+2}px';t.style.height='{int(sz['h'])+2}px';t.style.left='{(1280-int(sz['w']))//2}px';t.style.top='{700-int(sz['h'])}px'")
            time.sleep(0.4); shot("02_suggest_toast", {"x": 0, "y": 0, "width": 1280, "height": 780})
            page.evaluate("document.getElementById('suggest').style.display='none';document.getElementById('toast').style.display='none'")
            # 3. 메뉴
            show_overlay("menu"); shot("03_menu", {"x": 780, "y": 0, "width": 500, "height": 520}); hide_overlay()
            # 4. 북마크 · 5. 선택 모드 · 6. 방문 기록 · 7. 다운로드
            show_overlay("bookmarks"); time.sleep(0.4); shot("04_bookmarks", {"x": 700, "y": 0, "width": 580, "height": 780})
            ov.click(".lr >> nth=1", button="right"); time.sleep(0.3); ov.click(".lr >> nth=2"); time.sleep(0.3); shot("05_bookmarks_select", {"x": 700, "y": 0, "width": 580, "height": 780})
            ov.press("body", "Escape"); ov.click(".lr >> nth=0 >> .mo"); time.sleep(0.4); shot("05b_bookmark_rowmenu", {"x": 700, "y": 0, "width": 580, "height": 780}); hide_overlay()
            show_overlay("history"); time.sleep(0.4); shot("06_history", {"x": 700, "y": 0, "width": 580, "height": 780})
            ov.click(".dh >> nth=2"); time.sleep(0.6); shot("06b_history_expanded", {"x": 700, "y": 0, "width": 580, "height": 780}); hide_overlay()
            show_overlay("downloads"); time.sleep(0.4); shot("07_downloads", {"x": 700, "y": 0, "width": 580, "height": 780}); hide_overlay()
            # 8. 대화상자
            show_overlay("none"); ov.evaluate("EvDlg.open('bookmark',{id:null,url:'https://ko.wikipedia.org/wiki/위키백과',title:'위키백과, 우리 모두의 백과사전',folderId:2,folders:%s})" % json.dumps(DB["bookmarks"]["folders"])); time.sleep(0.5); shot("08_dialog_bookmark")
            ov.click("[data-b=ok]") if False else None; hide_overlay()
            show_overlay("none"); ov.evaluate("EvDlg.open('zoom',{})"); time.sleep(0.5); shot("09_dialog_zoom"); hide_overlay()
            show_overlay("none"); ov.evaluate("EvDlg.open('shortcut',{index:null,name:'',url:'exa mple'})"); ov.click("[data-b=ok]"); time.sleep(0.4); shot("10_dialog_shortcut_error"); hide_overlay()
            # 12~16. 3단계: 광고 차단 현황 · 보안 현황 · 설정 · https 대체 연결
            show_overlay("none"); ov.evaluate("p=>EvDlg.open('adstats',p)", {"stats": DB["adstats"]}); time.sleep(0.6); shot("12_adstats"); hide_overlay()
            show_overlay("none"); ov.evaluate("p=>EvDlg.open('secstats',p)", {"stats": DB["secstats"]}); time.sleep(0.6); shot("13_secstats"); hide_overlay()
            show_overlay("none"); ov.evaluate("p=>EvDlg.open('secset',p)", {"settings": DB["secstats"]["settings"]}); time.sleep(0.6); shot("14_secset"); hide_overlay()
            show_overlay("none"); ov.evaluate("EvDlg.open('httpfb',{host:'old-site.example',url:'http://old-site.example/',token:'t'})"); time.sleep(0.5); shot("15_httpfb"); hide_overlay()
            # 11. 새 탭
            np = ctx.new_page(); np.on("pageerror", lambda e, s=scheme: errors.append(f"[{s}] newtab pageerror: {e}")); np.route("**/*", lambda r: r.abort() if r.request.url.startswith("http") else r.continue_())
            np.goto(f"file://{SRC}/renderer/newtab.html"); time.sleep(0.5); np.screenshot(path=str(OUT / f"11_newtab_{scheme}.png"))
            np.set_viewport_size({"width": 1280, "height": 900}); time.sleep(0.2); np.screenshot(path=str(OUT / f"16_newtab_cards_{scheme}.png"))
            ctx.close()
        br.close()
try:
    run()
except Exception as ex:
    errors.append('실행 중단: ' + str(ex).splitlines()[0])
print("images:", len(list(OUT.glob("[0-9]*.png"))))
print("JS 오류:", "없음" if not errors else "")
for e in errors: print("  ", e)
