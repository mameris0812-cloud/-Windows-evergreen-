# 안드로이드 AdBlocker.kt / TrackerBlocker.kt / AdScripts.kt 의 목록·스크립트를 윈도우판 파일로 옮긴다.
# 사용: EV_SRC=<안드로이드 .../com/example/evergreen> python3 tools/port_ad_data.py
import os, re, json
SRC = os.environ.get('EV_SRC', '/tmp/ev/app/src/main/java/com/example/evergreen')
OUT = os.path.join(os.path.dirname(__file__), '..', 'src')
rd = lambda n: open(os.path.join(SRC, n), encoding='utf8').read()
ab, tb, sc = rd('AdBlocker.kt'), rd('TrackerBlocker.kt'), rd('AdScripts.kt')

def strings_of(block):
    # 문자열 안의 // (주소)는 남기고, 문자열 밖의 // 주석만 지운다
    clean = re.sub(r'"(?:[^"\\]|\\.)*"|//[^\n]*', lambda m: m.group(0) if m.group(0).startswith('"') else '', block)
    return re.findall(r'"((?:[^"\\]|\\.)*)"', clean)
def unesc(s):
    return s.replace('\\"', '"').replace('\\\\', '\\')
def block(src, name, open_ch='(', close_ch=')'):
    i = src.index(name)
    j = src.index(open_ch, i)
    depth = 0
    for k in range(j, len(src)):
        if src[k] == open_ch: depth += 1
        elif src[k] == close_ch:
            depth -= 1
            if depth == 0: return src[j + 1:k]
    raise SystemExit('block not found: ' + name)

data = {}
for key, name in [('HOST_SOURCES', 'val HOST_SOURCES = listOf'), ('COSMETIC_SOURCES', 'val COSMETIC_SOURCES = listOf'),
                  ('NET_SOURCES', 'val NET_SOURCES = listOf'), ('SECOND_LEVEL', 'val SECOND_LEVEL = setOf'),
                  ('ALLOW', 'val ALLOW: Set<String> = setOf'), ('AD_LABELS', 'val AD_LABELS = setOf'),
                  ('AD_PATHS', 'val AD_PATHS = listOf'), ('BUILTIN', 'val BUILTIN: Set<String> = setOf')]:
    data[key] = [unesc(s) for s in strings_of(block(ab, name))]
sel = [unesc(s) for s in strings_of(block(ab, 'val COSMETIC_SELECTORS = listOf'))]
data['COSMETIC_SELECTORS'] = sel
data['TRACKERS'] = [unesc(s) for s in strings_of(block(tb, 'val TRACKERS: Set<String> = setOf'))]
data['ESSENTIAL'] = [unesc(s) for s in strings_of(block(tb, 'val ESSENTIAL: Set<String> = setOf'))]
# 배너 정규식(코틀린 문자열 → 자바스크립트)
def kt_regex(name):
    b = block(ab, 'val ' + name + ' = Regex')
    parts = [unesc(s).replace('\\\\', '\\') for s in re.findall(r'"((?:[^"\\]|\\.)*)"', b)]
    return ''.join(parts)
data['BANNER_PATH'] = kt_regex('BANNER_PATH')
data['BANNER_VIDEO_PATH'] = kt_regex('BANNER_VIDEO_PATH')
js = "'use strict';\n// 자동 생성: tools/port_ad_data.py (안드로이드 AdBlocker.kt · TrackerBlocker.kt 의 목록)\nmodule.exports = " + json.dumps(data, ensure_ascii=False, indent=1) + ";\n"
open(os.path.join(OUT, 'shared', 'addata.js'), 'w', encoding='utf8').write(js)

# 페이지 안에서 도는 스크립트 (EvMedia 다리는 그대로 두고, 윈도우 preload 가 같은 이름의 다리를 만든다)
def raw_string_after(src, marker):
    i = src.index(marker)
    a = src.index('"""', i) + 3
    b = src.index('"""', a)
    return src[a:b].replace("${'$'}", '$')
cos = raw_string_after(ab, 'val COSMETIC_START_JS: String =')
yt = raw_string_after(ab, 'val YT_AD_START_JS: String =')
vb = raw_string_after(sc, 'val VIDEO_BANNER_JS: String =')
cos = cos.replace('${AdScripts.VIDEO_BANNER_JS}', '/*__VIDEO_BANNER__*/')
# 화면 숨김 CSS 는 페이지 CSP 에 막히지 않도록 preload 가 insertCSS 로 넣는다
cos = re.sub(r" addCss\(`__SEL__\{display:none!important\}`\);\n", '', cos)
cos = re.sub(r" if\(window===window\.top\)\{ try\{ var c=EvMedia\.adcss\(location\.hostname\); if\(c\) addCss\(c\); \}catch\(e\)\{\} \}\n", '', cos)
for name, body in [('cosmetic.js', cos), ('ytad.js', yt), ('videobanner.js', vb)]:
    open(os.path.join(OUT, 'guard', name), 'w', encoding='utf8').write(body.strip() + '\n')
print({k: len(v) for k, v in data.items() if isinstance(v, list)}, len(cos), len(yt), len(vb))
