#!/usr/bin/env python3
"""자동 스크롤 화면 미리보기: 실제 overlay · ascroll · toast · renderer 파일을 헤드리스 크롬으로 열어 PNG 로 저장한다 (가짜 메인 프로세스).
   사용: python3 tools/preview_ascroll.py [출력폴더]   (playwright 필요)"""
import json, sys, time, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/ev_ascroll")
OUT.mkdir(parents=True, exist_ok=True)
W, H = 1180, 760

def tab(i, title, url, zoom=100): return {"id": i, "title": title, "url": url, "favicon": "", "loading": False, "incognito": False, "audible": False, "canBack": True, "canFwd": False, "secure": True, "zoom": zoom, "zoomOnly": False, "bookmarked": False}
def state(cfg, running=False, paused=False):
    return {"activeWin": 1, "wins": [{"id": 1, "num": 1, "name": "창 1", "active": 11, "tabs": [tab(10, "evergreen - Google 검색", "https://www.google.com/search?q=evergreen"), tab(11, "별빛 정원사 1화 - 웹툰", "https://webtoon.example/ep/1")]}],
            "prefs": {"theme": "system", "engine": "google", "zoom": 100, "bookmarkBar": True, "trLang": "ko", "trImages": False},
            "engines": [{"key": "google", "name": "Google"}], "langs": [{"key": "ko", "name": "한국어"}], "dl": {"count": 0, "progress": 0},
            "sec": {"summary": "보호 수준 보통 · 오늘 41번 차단", "adBlock": True}, "version": "0.11.0",
            "autoScroll": {"cfg": cfg, "running": running, "tabId": 11 if running else None, "paused": paused}}
CFG = {"speed": 6, "smart": False, "contentLevel": 15, "blankLevel": 40, "touch": 0, "controls": True, "pauseAtEnd": True}
CFG_SMART = dict(CFG, smart=True, contentLevel=12, blankLevel=38)

MOCK = """(function(){ var H={};
 window.__sent=[]; window.__fire=function(c,p){(H[c]||[]).forEach(function(f){f(p)})};
 window.evergreen={send:function(c,p){window.__sent.push([c,p])},on:function(c,cb){(H[c]=H[c]||[]).push(cb)},invoke:function(c,p){return Promise.resolve(null)}};
})();"""

def cuts():
    pal = [("#FDE2E4", "#E8B4BC"), ("#E2ECE9", "#B5CFC6"), ("#DFE7FD", "#B6C4F0"), ("#FFF1E6", "#F0CDAF")]
    out = ""
    for i, (a, b) in enumerate(pal):
        out += f'<div style="height:330px;background:linear-gradient(160deg,{a},{b});position:relative;border-bottom:1px solid rgba(0,0,0,.05)"><div style="position:absolute;left:{40+i*18}px;top:{50+i*10}px;background:#fff;border-radius:22px;padding:14px 20px;font:600 17px sans-serif;box-shadow:0 2px 0 rgba(0,0,0,.08)">{["어? 이게 뭐지…","정원에 불이 켜져 있어.","…아직 아무도 몰라.","내일 다시 올게요."][i]}</div></div>'
    return out

def harness():
    return f"""<!doctype html><meta charset=utf-8><style>html,body{{margin:0;background:#888}}
#win{{position:relative;width:{W}px;height:{H}px;overflow:hidden}}
iframe{{border:0;position:absolute;background:transparent;color-scheme:normal}}
#web{{position:absolute;left:0;right:0;top:98px;bottom:0;background:#EEF0F3;overflow:hidden}}
#web .col{{width:520px;margin:0 auto;box-shadow:0 0 0 1px rgba(0,0,0,.05)}}
#web.dark{{background:#0E0F12}}</style>
<div id=win><iframe id=chrome src="file://{SRC}/renderer/index.html" style="left:0;top:0;width:{W}px;height:98px"></iframe>
<div id=web><div class=col>{cuts()}</div></div>
<iframe id=overlay src="file://{SRC}/overlay/overlay.html" style="left:0;top:0;width:{W}px;height:{H}px;display:none"></iframe>
<iframe id=pill src="file://{SRC}/ascroll/ascroll.html" style="display:none"></iframe>
<iframe id=toast src="file://{SRC}/toast/toast.html" style="display:none"></iframe></div>"""

errors = []
def run():
    with sync_playwright() as p:
        br = p.chromium.launch()
        for scheme in ("light", "dark"):
            ctx = br.new_context(viewport={"width": W, "height": H}, color_scheme=scheme, device_scale_factor=2)
            ctx.add_init_script(MOCK)
            page = ctx.new_page()
            page.on("pageerror", lambda e, s=scheme: errors.append(f"[{s}] pageerror: {e}"))
            page.on("console", lambda m, s=scheme: errors.append(f"[{s}] console.{m.type}: {m.text}") if m.type == "error" and "Failed to load resource" not in m.text else None)
            page.route("**/*", lambda r: r.abort() if r.request.url.startswith("http") else r.continue_())
            hp = OUT / f"_h_{scheme}.html"; hp.write_text(harness(), encoding="utf-8")
            page.goto(f"file://{hp}")
            if scheme == "dark": page.evaluate("document.getElementById('web').classList.add('dark')")
            time.sleep(0.5)
            fr = {n: next(f for f in page.frames if n in f.url) for n in ("renderer/index", "overlay/overlay", "ascroll/ascroll", "toast/toast")}
            chrome, ov, pill, toast = fr["renderer/index"], fr["overlay/overlay"], fr["ascroll/ascroll"], fr["toast/toast"]
            chrome.evaluate("s=>__fire('state',s)", state(CFG, True)); time.sleep(0.3)
            def shot(name, clip=None): page.screenshot(path=str(OUT / f"{name}_{scheme}.png"), clip=clip)
            def place_pill(s, with_toast=None):
                page.evaluate("document.getElementById('pill').style.display='block';document.getElementById('pill').style.width='600px';document.getElementById('pill').style.height='120px';document.getElementById('pill').style.left='0';document.getElementById('pill').style.top='0'")
                pill.evaluate("s=>__fire('as:state',s)", s); time.sleep(0.45)
                sz = [x for x in pill.evaluate("__sent") if x[0] == "as:size"][-1][1]
                pw, ph = int(sz["w"]), int(sz["h"])
                page.evaluate(f"var e=document.getElementById('pill');e.style.width='{pw}px';e.style.height='{ph}px';e.style.left='{(W-pw)//2}px';e.style.top='{H-ph+2}px'")
                lift = ph - 14
                if with_toast:
                    page.evaluate("var t=document.getElementById('toast');t.style.display='block';t.style.width='600px';t.style.height='80px';t.style.left='0';t.style.top='0'")
                    toast.evaluate("p=>__fire('toast:show',p)", {"msg": with_toast, "label": "", "dark": scheme == "dark"}); time.sleep(0.4)
                    tz = [x for x in toast.evaluate("__sent") if x[0] == "toast:size"][-1][1]
                    page.evaluate(f"var t=document.getElementById('toast');t.style.width='{int(tz['w'])+2}px';t.style.height='{int(tz['h'])+2}px';t.style.left='{(W-int(tz['w']))//2}px';t.style.top='{H-int(tz['h'])-28-lift}px'")
                time.sleep(0.3)
                return pw, ph
            # 1. 웹툰 위의 조작 막대 + 시작 토스트
            pw, ph = place_pill({"level": 6, "smart": False, "paused": False, "min": 1, "max": 50}, "자동 스크롤을 시작했어요")
            shot("01_scene_running", {"x": 0, "y": 0, "width": W, "height": H})
            page.evaluate("document.getElementById('toast').style.display='none'")
            # 2. 막대 세 가지 모양 (확대)
            tiles = []
            for name, s in (("running", {"level": 6, "smart": False, "paused": False, "min": 1, "max": 50}), ("smart", {"level": 27, "smart": True, "paused": False, "min": 1, "max": 50}), ("paused", {"level": 6, "smart": False, "paused": True, "min": 1, "max": 50}), ("max", {"level": 50, "smart": False, "paused": False, "min": 1, "max": 50})):
                pw, ph = place_pill(s)
                x0 = (W - pw) // 2; y0 = H - ph + 2
                page.screenshot(path=str(OUT / f"_pill_{name}_{scheme}.png"), clip={"x": x0, "y": y0, "width": pw, "height": ph}); tiles.append(name)
            page.evaluate("document.getElementById('pill').style.display='none'")
            # 3. 메뉴 (새 줄) — 자동 스크롤 중 / 아닐 때
            for nm, run_ in (("menu_off", False), ("menu_on", True)):
                page.evaluate("document.getElementById('overlay').style.display='block'")
                ov.evaluate("m=>__fire('overlay:show',m)", {"kind": "menu", "anchor": {"x": W - 48, "y": 51, "w": 40, "h": 40}, "left": False, "data": None, "state": state(CFG_SMART if run_ else CFG, run_)}); time.sleep(0.6)
                shot("0" + ("3a_" if not run_ else "3b_") + nm, {"x": W - 340, "y": 40, "width": 340, "height": 720})
                page.evaluate("document.getElementById('overlay').style.display='none'"); ov.goto(f"file://{SRC}/overlay/overlay.html"); time.sleep(0.4)
            # 4. 설정 창: 일반 / 스마트
            for nm, cfg in (("04_settings", CFG), ("05_settings_smart", CFG_SMART), ("06_settings_nobar_noend_touch1", dict(CFG, controls=False, pauseAtEnd=False, touch=1))):
                page.evaluate("document.getElementById('overlay').style.display='block'")
                ov.evaluate("m=>__fire('overlay:show',m)", {"kind": "none", "anchor": {"x": 0, "y": 0, "w": 0, "h": 0}, "left": False, "data": None, "state": state(cfg)}); time.sleep(0.3)
                ov.evaluate("EvDlg.open('ascroll',{})"); time.sleep(0.6)
                shot(nm)
                if nm == "05_settings_smart":
                    ov.evaluate("var r=document.querySelector('input[data-k=blankLevel]');r.value=45;r.dispatchEvent(new Event('input',{bubbles:true}))"); time.sleep(0.3)
                    sent = [x for x in ov.evaluate("__sent") if x[0] == "app:cmd" and x[1]["name"] == "ascroll:set"]
                    assert sent and sent[-1][1]["arg"]["blankLevel"] == 45, sent[-1:]
                page.evaluate("document.getElementById('overlay').style.display='none'"); ov.goto(f"file://{SRC}/overlay/overlay.html"); time.sleep(0.4)
        br.close()
run()
if errors:
    print("오류:"); [print(" ", e) for e in errors]; sys.exit(1)
print("저장:", OUT)
