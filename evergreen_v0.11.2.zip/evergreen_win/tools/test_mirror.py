#!/usr/bin/env python3
"""미러링 페이지 스크립트(src/guard/mirror.js)를 진짜 크롬에서 시험: 영상 찾기 → 화면 채우기 → 명령 → 원래대로 되돌리기"""
import sys, pathlib, json
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
V = pathlib.Path(sys.argv[1]).resolve().as_uri()
JS = (ROOT / "src/guard/mirror.js").read_text(encoding="utf-8")
HTML = f"""<body style="margin:0"><div id=hdr style="height:60px;background:#06c">사이트 머리글</div>
<div id=wrap style="width:480px;height:270px;margin:20px;transform:scale(.9);position:relative;overflow:hidden"><video id=v src="{V}" muted loop autoplay style="width:100%;height:100%"></video></div>
<div id=ad style="position:fixed;right:0;bottom:0;z-index:99999;background:red;width:200px;height:90px">광고</div></body>"""
res = {}
with sync_playwright() as p:
    b = p.chromium.launch(args=["--autoplay-policy=no-user-gesture-required"]); pg = b.new_page(viewport={"width": 1000, "height": 600})
    open("/tmp/mirror_page.html","w",encoding="utf-8").write(HTML); pg.goto("file:///tmp/mirror_page.html"); pg.wait_for_function("document.getElementById('v').readyState>=2")
    before = pg.evaluate("JSON.stringify([document.getElementById('v').getBoundingClientRect(),getComputedStyle(document.getElementById('wrap')).transform,getComputedStyle(document.getElementById('wrap')).overflow,document.getElementById('v').style.position])")
    pg.evaluate(JS)
    res["영상 찾음"] = pg.evaluate("window.__evMir.on()")["ok"]
    r = pg.evaluate("(()=>{var r=document.getElementById('v').getBoundingClientRect();return [r.width,r.height]})()")
    res["화면 가득(1000x600)"] = r == [1000, 600]
    res["광고 가려짐"] = pg.evaluate("getComputedStyle(document.getElementById('ad')).visibility") == "hidden"
    s = pg.evaluate("window.__evMir.state()"); res["상태(길이·재생)"] = s["on"] and s["dur"] > 20 and s["playing"]
    pg.evaluate("window.__evMir.cmd('pause')"); pg.wait_for_timeout(100); res["일시정지"] = not pg.evaluate("window.__evMir.state().playing")
    pg.evaluate("window.__evMir.cmd('seek',12)"); pg.wait_for_timeout(200); res["이동"] = abs(pg.evaluate("window.__evMir.state().pos") - 12) < 1
    pg.evaluate("window.__evMir.cmd('fit','cover')"); res["fit cover"] = pg.evaluate("getComputedStyle(document.getElementById('v')).objectFit") == "cover"
    pg.evaluate("window.__evMir.off()")
    after = pg.evaluate("JSON.stringify([document.getElementById('v').getBoundingClientRect(),getComputedStyle(document.getElementById('wrap')).transform,getComputedStyle(document.getElementById('wrap')).overflow,document.getElementById('v').style.position])")
    res["원래대로"] = before == after and pg.evaluate("getComputedStyle(document.getElementById('ad')).visibility") == "visible"
    res["영상 없는 페이지"] = (lambda q: (q.set_content("<p>없음</p>"), q.evaluate(JS), q.evaluate("window.__evMir.on()")["ok"])[2] is False)(b.new_page())
    b.close()
for k, v in res.items(): print("OK  " if v else "FAIL", k)
sys.exit(0 if all(res.values()) else 1)
