'use strict';
// 안드로이드 GeminiKeyPoolTest 의 핵심을 옮긴 테스트 + 모델 · 자동 선택 · 오류 글 규칙
const test = require('node:test');
const assert = require('node:assert');
const G = require('../src/shared/gemini');

function setup() {
  const clock = { t: 1_000_000 };
  const g = G.create({ now: () => clock.t });
  g.clock = clock;
  return g;
}
const A = 'key-A', B = 'key-B', C = 'key-C';
const perModelBody = (model, retry = '34s') => '{"error":{"code":429,"message":"You exceeded your current quota","status":"RESOURCE_EXHAUSTED","details":[' +
  '{"@type":"type.googleapis.com/google.rpc.QuotaFailure","violations":[{"quotaMetric":"generate_content_requests","quotaId":"GenerateRequestsPerMinutePerProjectPerModel","quotaDimensions":{"model":"' + model + '"}}]}' +
  (retry ? ',{"@type":"type.googleapis.com/google.rpc.RetryInfo","retryDelay":"' + retry + '"}' : '') + ']}}';
const unscoped = (retry) => '{"error":{"code":429,"message":"You exceeded your current quota, please check your plan"' + (retry ? ',"details":[{"retryDelay":"' + retry + '"}]' : '') + '}}';

test('한도 응답 판별: 한도 · 서버 붐빔', () => {
  const { pool } = setup();
  assert.ok(pool.isQuota(perModelBody('x')));
  assert.ok(pool.isQuota('{"retryDelay":"20s"}'));
  assert.ok(pool.isQuota('Quota exceeded: GenerateRequestsPerDayPerProjectPerModel'));
  assert.ok(!pool.isQuota('{"error":{"code":429,"message":"Resource has been exhausted (e.g. check quota)."}}'.replace('quota', 'q')));
  assert.ok(!pool.isQuota(null));
});

test('분당 한도: 알려 준 시간만 이 모델만 쉰다 · 키 전체는 안 쉰다', () => {
  const g = setup(); const m = g.models.lite();
  g.pool.pick([A, B]);
  g.pool.onLimit(A, m, perModelBody(m, '34s'), false);
  const left = g.pool.restingModels()[m];
  assert.ok(left > 33000 && left <= 34000);
  assert.ok(!g.pool.resting(A));
  assert.ok(g.pool.usable(m)); // B 가 있다
  assert.ok(!g.pool.blocked(A, g.models.hydrogen()));
});

test('대기 시간: 없으면 60초 · 너무 짧으면 5초 · 너무 길면 5분 · 소수도 읽는다', () => {
  const g = setup(); const m = g.models.lite();
  g.pool.pick([A]);
  g.pool.onLimit(A, m, perModelBody(m, null), false);
  assert.strictEqual(g.pool.restingModels()[m], 60000);
  g.pool.coolModel = {};
  g.pool.onLimit(A, m, perModelBody(m, '1s'), false);
  assert.strictEqual(g.pool.restingModels()[m], 5000);
  g.pool.coolModel = {};
  g.pool.onLimit(A, m, perModelBody(m, '900s'), false);
  assert.strictEqual(g.pool.restingModels()[m], 300000);
  g.pool.coolModel = {};
  g.pool.onLimit(A, m, perModelBody(m, '12.5s'), false);
  assert.strictEqual(g.pool.restingModels()[m], 12500);
});

test('하루 한도 10분 · 한도 0 은 30분 · 한도 05 나 10 은 한도 0 이 아니다', () => {
  const g = setup(); const m = g.models.hydrogen();
  g.pool.pick([A]);
  g.pool.onLimit(A, m, 'Quota exceeded: GenerateRequestsPerDayPerProjectPerModel', false);
  assert.strictEqual(g.pool.restingModels()[m], 600000);
  g.pool.coolModel = {};
  g.pool.onLimit(A, m, 'quota exceeded, limit: 0, model: ' + m, false);
  assert.strictEqual(g.pool.restingModels()[m], 1800000);
  g.pool.coolModel = {};
  g.pool.onLimit(A, m, 'quota exceeded limit: 05', false);
  assert.ok(g.pool.restingModels()[m] < 1800000);
  g.pool.coolModel = {};
  g.pool.onLimit(A, m, 'quota exceeded limit: 10', false);
  assert.ok(g.pool.restingModels()[m] < 1800000);
});

test('어느 모델 한도인지 몰라도 키 전체는 쉬지 않고 이 모델만 30초', () => {
  const g = setup(); const m = g.models.lite();
  g.pool.pick([A]);
  g.pool.onLimit(A, m, unscoped(), false);
  assert.strictEqual(g.pool.restingModels()[m], 30000);
  assert.ok(!g.pool.resting(A));
  g.pool.coolModel = {};
  g.pool.onLimit(A, m, unscoped('47s'), false);
  assert.strictEqual(g.pool.restingModels()[m], 47000);
  g.pool.coolModel = {};
  g.pool.onLimit(A, m, null, false);
  assert.strictEqual(g.pool.restingModels()[m], 30000);
});

test('키가 거부돼도 키를 쉬게 하지 않고, 모델 권한 403 만 그 모델 10분', () => {
  const g = setup(); const m = g.models.hydrogen();
  g.pool.pick([A, B]);
  g.pool.onLimit(A, m, '{"error":{"message":"API key not valid"}}', true);
  assert.ok(!g.pool.resting(A));
  assert.deepStrictEqual(g.pool.restingModels(), {});
  g.pool.onLimit(A, m, '{"error":{"message":"Permission denied for model"}}', true);
  assert.strictEqual(g.pool.restingModels()[m], 600000);
  assert.ok(g.pool.blocked(A, m) && !g.pool.blocked(B, m));
});

test('키 고르기: 번갈아 · 쉬는 키 건너뜀 · 모두 쉬면 가장 빨리 풀리는 키 · 시간이 지나면 다시', () => {
  const g = setup();
  assert.strictEqual(g.pool.pick([]), '');
  const seq = [g.pool.pick([A, B, C]), g.pool.pick([A, B, C]), g.pool.pick([A, B, C]), g.pool.pick([A, B, C])];
  assert.deepStrictEqual(seq, [A, B, C, A]);
  g.pool.cooldown(B, 60000);
  const seq2 = [g.pool.pick([A, B, C]), g.pool.pick([A, B, C]), g.pool.pick([A, B, C])];
  assert.ok(!seq2.includes(B));
  g.pool.cooldown(A, 30000); g.pool.cooldown(C, 90000);
  assert.strictEqual(g.pool.pick([A, B, C]), A);
  g.clock.t += 61000;
  assert.ok([A, B].includes(g.pool.pick([A, B, C])));
  assert.ok(!g.pool.resting(B));
});

test('다른 키 찾기: 써 본 키 · 이 모델에서 막힌 키 · 쉬는 키는 뺀다', () => {
  const g = setup(); const m = g.models.lite();
  g.pool.pick([A, B, C]);
  assert.strictEqual(g.pool.alternative(new Set([A])), B);
  g.pool.onLimit(B, m, perModelBody(m), false);
  assert.strictEqual(g.pool.alternative(new Set([A]), m), C);
  assert.strictEqual(g.pool.alternative(new Set([A, C]), m), null);
  g.pool.cooldown(C, 5000);
  assert.strictEqual(g.pool.alternative(new Set([A]), ''), B);
  const one = setup(); one.pool.pick([A]);
  assert.strictEqual(one.pool.alternative(new Set([A])), null);
});

test('모델 쓸 수 있나: 키 정보 없음 · 하나라도 쓸 수 있음 · 모두 한도 · 시간이 지나면 다시', () => {
  const g = setup(); const m = g.models.lite(), h = g.models.hydrogen();
  assert.ok(g.pool.usable(m));
  g.pool.pick([A, B]);
  g.pool.onLimit(A, m, perModelBody(m), false);
  assert.ok(g.pool.usable(m));
  g.pool.onLimit(B, m, perModelBody(m), false);
  assert.ok(!g.pool.usable(m) && g.pool.usable(h));
  assert.strictEqual(g.auto.usableOrFallback(m), h);
  g.clock.t += 61000;
  assert.ok(g.pool.usable(m));
  g.pool.cooldown(A, 5000); g.pool.cooldown(B, 5000);
  assert.ok(!g.pool.usable(m) && !g.pool.usable(h));
  assert.strictEqual(g.auto.usableOrFallback(m), m); // 쓸 수 있는 게 없으면 그대로
});

test('forModel: 막힌 키는 막히지 않은 키로, 모두 막혔으면 그대로', () => {
  const g = setup(); const m = g.models.lite();
  g.pool.pick([A, B]);
  g.pool.onLimit(A, m, perModelBody(m), false);
  assert.strictEqual(g.pool.forModel(A, m), B);
  g.pool.onLimit(B, m, perModelBody(m), false);
  assert.strictEqual(g.pool.forModel(A, m), A);
});

test('상태 글: 멀쩡한 키 null · 모델 한도 · 키 휴식(분 올림 · 초) · 거부', () => {
  const g = setup(); const m = g.models.hydrogen();
  g.pool.pick([A]);
  assert.strictEqual(g.pool.statusOf(A), null);
  g.pool.onLimit(A, m, perModelBody(m), false);
  assert.strictEqual(g.pool.statusOf(A), '4 Hydrogen 한도 도달 · 다른 모델은 사용 가능');
  g.pool.cooldown(B, 61000);
  assert.strictEqual(g.pool.statusOf(B), '한도 도달 · 2분 뒤 다시 사용');
  g.pool.cooldown(C, 20000, true);
  assert.strictEqual(g.pool.statusOf(C), '키가 거부됐어요 · 20초 뒤 다시 확인');
  assert.strictEqual(g.pool.restingSummary(), '4 Hydrogen 34초');
});

test('키 바뀜 알림: 몇 번 → 몇 번 · 거부 · 키가 하나면 없음 · 3초에 한 번 · 번호는 항상 바뀜', () => {
  const g = setup(); const ev = [];
  g.pool.onEvent = (e) => ev.push(e);
  g.pool.pick([A, B]);
  g.pool.notifySwitch(A, B, false);
  assert.strictEqual(ev[0].text, '키 1 한도 도달 → 키 2 사용');
  g.pool.notifySwitch(B, A, false);
  assert.strictEqual(ev.length, 1); // 3초 안
  assert.strictEqual(g.pool.currentNo(), 1);
  g.clock.t += 3100;
  g.pool.notifySwitch(A, B, true);
  assert.strictEqual(ev[1].text, '키 1 거부됨 → 키 2 사용');
  const one = setup(); const e1 = []; one.pool.onEvent = (e) => e1.push(e); one.pool.pick([A]); one.pool.notifySwitch(A, A, false);
  assert.strictEqual(e1.length, 0);
});

test('한도 이름 읽기', () => {
  const { pool } = setup();
  assert.strictEqual(pool.quotaName(perModelBody('m')), 'GenerateRequestsPerMinutePerProjectPerModel');
  assert.strictEqual(pool.quotaName('{"quotaMetric":"a.googleapis.com/generate_content_requests"}'), 'generate_content_requests');
  assert.strictEqual(pool.quotaName(null), '');
});

test('검색 쉬기 · 검색 도구를 탓하는 400', () => {
  const g = setup(); const m = g.models.lite();
  assert.ok(!g.search.resting());
  g.search.rest(300000);
  assert.ok(g.search.resting());
  g.clock.t += 300001;
  assert.ok(!g.search.resting());
  assert.ok(g.search.blamesSearch('google_search is not supported'));
  assert.ok(g.search.blamesSearch('Tool use is unsupported for this model'));
  assert.ok(!g.search.blamesSearch('API key not valid. google_search'));
  assert.ok(!g.search.blamesSearch('Unable to submit request because function calling tool'));
  assert.ok(g.search.rejected(400, 'Search Grounding is not supported', m, true));
  assert.ok(g.search.isUnsupported(m));
  const body = {};
  assert.ok(!g.search.apply(body, m, true));
  g.clock.t += 10 * 60 * 1000 + 1;
  assert.ok(g.search.apply(body, m, true));
  assert.deepStrictEqual(body.tools, [{ google_search: {} }]);
  assert.ok(!g.search.rejected(400, 'something else', m, true));
  assert.ok(!g.search.rejected(429, 'google_search', m, true));
});

test('생각 설정: 거부한 모델은 기억', () => {
  const g = setup(); const m = g.models.lite(); const gen = {};
  assert.ok(g.thinking.apply(gen, m, 'minimal', true));
  assert.deepStrictEqual(gen.thinkingConfig, { thinkingLevel: 'minimal', includeThoughts: true });
  assert.ok(g.thinking.rejected(400, 'Thinking level minimal is not supported', m, true));
  assert.ok(!g.thinking.apply({}, m, 'minimal'));
  assert.ok(!g.thinking.rejected(500, 'thinking', m, true));
  assert.ok(!g.thinking.apply({}, m, ''));
});

test('모델 이름 · 계열 이어 쓰기', () => {
  const g = setup();
  assert.strictEqual(G.labelOf('gemini-3.5-flash-lite'), '3.5 Flash-Lite');
  assert.strictEqual(G.labelOf('gemini-4-hydrogen'), '4 Hydrogen');
  assert.strictEqual(g.models.successor('gemini-3.8-flash'), g.models.lite()); // 없앤 Flash
  assert.strictEqual(g.models.successor('gemini-3-flash-lite'), 'gemini-3.5-flash-lite');
  assert.strictEqual(g.models.successor('gemini-3.5-flash-lite'), 'gemini-3.5-flash-lite');
  assert.strictEqual(g.models.successor('something-else'), 'something-else');
  assert.ok(g.models.apply({ LITE: 'gemini-3.6-flash-lite', HYDROGEN: 'gemini-4-hydrogen', JUNK: 'gemini-9' }));
  assert.strictEqual(g.models.lite(), 'gemini-3.6-flash-lite');
  assert.ok(!g.models.apply({ LITE: 'gemini-3.6-flash-lite' }));
  assert.ok(g.models.apply({ LITE: 'not-gemini' })); // 잘못된 값은 기본값으로 돌아가므로 바뀐 것으로 본다
  assert.strictEqual(g.models.lite(), 'gemini-3.5-flash-lite');
});

test('모델 목록으로 칸별 모델 다시 정하기 (종료 예정은 피하고 같은 계열의 더 새 것)', () => {
  const g = setup();
  const avail = { 'gemini-3.5-flash-lite': true, 'gemini-3.6-flash-lite': false, 'gemini-4-hydrogen': false, 'gemini-2-pro': false };
  assert.deepStrictEqual(g.models.resolveAll(avail), { HYDROGEN: 'gemini-4-hydrogen', LITE: 'gemini-3.6-flash-lite' });
  assert.strictEqual(g.models.resolveAll({ 'gemini-4-hydrogen': false }), null); // Flash 계열이 없으면 이상한 목록
  const now = Date.parse('2026-11-21T00:00:00Z');
  assert.ok(G.isEnding({ modelStage: 'DEPRECATED' }, now));
  assert.ok(G.isEnding({ retirementTime: '2026-11-25T00:00:00Z' }, now));
  assert.ok(!G.isEnding({ retirementTime: '2027-03-01T00:00:00Z' }, now));
  assert.ok(!G.isEnding(null, now));
});

test('자동 모델: 맞장구 · 코딩 · 깊은 추론 · 사진 · 링크 · 이어 묻기', () => {
  const g = setup(); const L = g.models.lite(), H = g.models.hydrogen(), au = g.auto;
  assert.strictEqual(au.forChat('고마워!', 3, false, 0), L);
  assert.strictEqual(au.forChat('파이썬으로 정렬 짜 줘', 1, false, 0), H);
  assert.strictEqual(au.forChat('이 함수 버그 있어?', 1, false, 0), H);
  assert.strictEqual(au.forChat('오늘 점심 뭐 먹지', 1, false, 0), L);
  assert.strictEqual(au.forChat('이차방정식 풀이를 단계별로 알려줘', 1, false, 0), H);
  assert.strictEqual(au.forChat('이 사진 뭐야? 방정식 같아', 1, false, 1), L); // 사진은 Flash-Lite
  assert.strictEqual(au.forChat('https://example.com/java 요약해 줘', 1, false, 0), L); // 주소 속 글자는 질문이 아님
  assert.strictEqual(au.forChat('계산이랑 분석 해줘', 1, false, 0), H); // 평범한 낱말 둘
  assert.strictEqual(au.forChat('1+2 와 3*4 는?', 1, false, 0), H); // 계산식 둘
  assert.strictEqual(au.forChat('이 코드 고쳐 줘 ```js\nlet a\n```', 1, false, 0), H);
  assert.strictEqual(au.forChat('그럼 그건?', 4, false, 0), H); // 앞이 Hydrogen 이면 짧은 이어 묻기도
  au.resetChat();
  assert.strictEqual(au.forChat('그럼 그건?', 4, false, 0), L);
  au.noteRule(H, '코딩 질문');
  assert.strictEqual(au.lastReason, '코딩 질문 → 4 Hydrogen');
});

test('없어진 모델은 다른 모델로', () => {
  const g = setup(); const L = g.models.lite(), H = g.models.hydrogen();
  g.auto.markDead(H);
  assert.strictEqual(g.auto.live(H), L);
  assert.deepStrictEqual(g.auto.fallbacks(L), []);
  assert.strictEqual(g.auto.forChat('파이썬 코딩', 1, false, 0), L);
});

test('오류 글', () => {
  const g = setup();
  assert.match(G.describeError(403, '', g.pool), /API 키가 거부/);
  assert.match(G.describeError(429, perModelBody('m'), g.pool), /요청 한도/);
  assert.match(G.describeError(429, '{"error":{"message":"busy"}}', g.pool), /붐벼서/);
  assert.match(G.describeError(503, '', g.pool), /서버에 문제/);
  assert.match(G.describeError(400, '{"error":{"message":"잘못된 요청"}}', g.pool), /\n잘못된 요청/);
  assert.doesNotMatch(G.describeError(400, '{"error":{"message":"bad request"}}', g.pool), /bad request/);
  assert.match(G.networkErrorMessage(new Error('The operation timed out')), /시간 초과/);
  assert.match(G.networkErrorMessage(Object.assign(new Error('fetch failed'), { cause: { code: 'ENOTFOUND' } })), /인터넷/);
  assert.match(G.emptyMessage({ blocked: 'SAFETY' }), /안전 정책/);
  assert.match(G.emptyMessage({ finish: 'MALFORMED_FUNCTION_CALL' }), /도구를 잘못/);
  assert.deepStrictEqual(G.tokensOf({ promptTokenCount: 10, toolUsePromptTokenCount: 5, candidatesTokenCount: 7, thoughtsTokenCount: 3 }), { inTok: 15, outTok: 10 });
});
