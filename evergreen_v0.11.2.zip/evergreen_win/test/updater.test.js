'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { EventEmitter } = require('node:events');
const { UpdateManager, friendlyError } = require('../src/main/updater');

function make(over) {
  const u = new EventEmitter();
  u.calls = 0; u.installed = 0;
  u.checkForUpdates = async () => { u.calls++; u.emit('checking-for-update'); if (u.next) u.next(); };
  u.quitAndInstall = () => { u.installed++; };
  const kv = { autoUpdate: true, updCheckedAt: 0 };
  const toasts = []; let changes = 0; let t = 10 * 24 * 3600 * 1000;
  const m = new UpdateManager(Object.assign({ updater: u, packaged: true, version: '0.7.0', now: () => t,
    store: { get: (k) => kv[k], set: (k, v) => { kv[k] = v; } }, toast: (s) => toasts.push(s), changed: () => changes++ }, over || {}));
  return { u, m, kv, toasts, tick: (ms) => { t += ms; }, changes: () => changes };
}

test('업데이트: 새 버전 → 받는 중 → 준비됨 → 설치', async () => {
  const { u, m, toasts } = make();
  u.next = () => { u.emit('update-available', { version: '0.8.0' }); u.emit('download-progress', { percent: 41.6 }); u.emit('update-downloaded', { version: '0.8.0' }); };
  await m.check(true);
  const s = m.snapshot();
  assert.strictEqual(s.phase, 'ready'); assert.strictEqual(s.version, '0.8.0'); assert.strictEqual(s.percent, 100);
  assert.ok(toasts.some((x) => /v0\.8\.0/.test(x)));
  assert.strictEqual(m.installNow(), true); assert.strictEqual(u.installed, 1);
});

test('업데이트: 진행률은 0~100 으로 맞춘다', async () => {
  const { u, m } = make();
  u.emit('update-available', { version: '1.0.0' });
  u.emit('download-progress', { percent: 41.6 }); assert.strictEqual(m.snapshot().percent, 42);
  u.emit('download-progress', { percent: 250 }); assert.strictEqual(m.snapshot().percent, 100);
  u.emit('download-progress', { percent: -5 }); assert.strictEqual(m.snapshot().percent, 0);
});

test('업데이트: 최신이면 직접 눌렀을 때만 알려 준다', async () => {
  const a = make(); a.u.next = () => a.u.emit('update-not-available');
  await a.m.check(true); assert.strictEqual(a.m.snapshot().phase, 'none'); assert.strictEqual(a.toasts.length, 1);
  assert.strictEqual(a.kv.updCheckedAt, 10 * 24 * 3600 * 1000);
  const b = make(); b.u.next = () => b.u.emit('update-not-available');
  await b.m.check(false); assert.strictEqual(b.toasts.length, 0);
});

test('업데이트: 자동 확인은 하루 한 번, 설정이 꺼져 있으면 안 한다', async () => {
  const { u, m, kv, tick } = make();
  u.next = () => u.emit('update-not-available');
  m.maybeAuto(); await Promise.resolve(); assert.strictEqual(u.calls, 1);
  tick(3600 * 1000); m.maybeAuto(); assert.strictEqual(u.calls, 1);
  tick(24 * 3600 * 1000); m.maybeAuto(); await Promise.resolve(); assert.strictEqual(u.calls, 2);
  kv.autoUpdate = false; tick(48 * 3600 * 1000); m.maybeAuto(); assert.strictEqual(u.calls, 2);
});

test('업데이트: 오류는 쉬운 말로, 확인 중에는 중복 확인 안 함', async () => {
  const { u, m, toasts } = make();
  u.checkForUpdates = async () => { u.emit('checking-for-update'); u.emit('error', new Error('getaddrinfo ENOTFOUND github.com')); };
  await m.check(true);
  assert.strictEqual(m.snapshot().phase, 'error'); assert.match(m.snapshot().error, /인터넷/);
  assert.ok(toasts.some((x) => /인터넷/.test(x)));
  const r = make(); r.m._set({ phase: 'checking' });
  assert.strictEqual(await r.m.check(true), false); assert.strictEqual(r.u.calls, 0);
});

test('업데이트: 개발 실행·라이브러리 없음이면 지원 안 함으로 표시', async () => {
  const a = make({ packaged: false }); assert.strictEqual(a.m.snapshot().supported, false);
  await a.m.check(true); assert.strictEqual(a.u.calls, 0); assert.strictEqual(a.toasts.length, 1);
  const b = make({ updater: null }); assert.strictEqual(b.m.snapshot().supported, false);
  assert.strictEqual(b.m.installNow(), false);
});

test('업데이트: 오류 문구 변환', () => {
  assert.match(friendlyError(new Error('HttpError: 404 Not Found')), /새 버전/);
  assert.match(friendlyError(new Error('rate limit exceeded 403')), /잠시/);
  assert.match(friendlyError(new Error('sha512 checksum mismatch')), /올바르지/);
  assert.strictEqual(friendlyError(null), '알 수 없는 오류');
});
