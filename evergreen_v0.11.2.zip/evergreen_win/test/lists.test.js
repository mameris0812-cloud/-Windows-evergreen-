'use strict';
const test = require('node:test');
const assert = require('node:assert');
const L = require('../src/shared/lists');

const NOW = new Date(2026, 10, 20, 15, 30).getTime(); // 2026-11-20 15:30 (로컬)
const min = (n) => n * 60000;

test('방문 기록: 맨 앞에 올리고 같은 주소는 하나로, 최대 1000개', () => {
  let h = [];
  h = L.addHistory(h, 'https://a.com', 'A', NOW);
  h = L.addHistory(h, 'https://b.com', 'B', NOW + 1);
  h = L.addHistory(h, 'https://a.com', 'A2', NOW + 2);
  assert.deepStrictEqual(h.map((x) => x.url), ['https://a.com', 'https://b.com']);
  assert.strictEqual(h[0].title, 'A2');
  let big = [];
  for (let i = 0; i < 1100; i++) big = L.addHistory(big, 'https://x.com/' + i, 't', NOW + i * 100000);
  assert.strictEqual(big.length, 1000);
  assert.strictEqual(big[0].url, 'https://x.com/1099');
});

test('방문 기록: 1분 안에 같은 주소·제목이 또 끝나면 건너뛴다', () => {
  const h = L.addHistory([], 'https://a.com', 'A', NOW);
  assert.strictEqual(L.addHistory(h, 'https://a.com', 'A', NOW + 30000), h);
  assert.notStrictEqual(L.addHistory(h, 'https://a.com', 'A', NOW + 61000), h);
  assert.notStrictEqual(L.addHistory(h, 'https://a.com', 'B', NOW + 1000), h);
});

test('방문 기록 묶음: 최근 1시간 → 오늘 → 어제 → 날짜 → 날짜 없음', () => {
  const items = [
    { url: 'https://1', title: '', time: NOW - min(10) },
    { url: 'https://2', title: '', time: NOW - min(300) },
    { url: 'https://3', title: '', time: NOW - 24 * 3600000 },
    { url: 'https://4', title: '', time: new Date(2026, 9, 3, 9).getTime() },
    { url: 'https://5', title: '', time: new Date(2025, 11, 25, 9).getTime() },
    { url: 'https://6', title: '', time: 0 },
  ];
  const g = L.groupHistory(items, NOW);
  assert.deepStrictEqual(g.map((x) => x.label), ['최근 1시간', '오늘', '어제', '10월 3일 (토)', '2025년 12월 25일 (목)', '날짜 없음']);
  assert.strictEqual(g[0].day, L.RECENT_DAY);
  assert.strictEqual(g[1].items.length, 2); // 최근 1시간의 기록은 오늘에도 들어 있다
});

test('시각 표시', () => {
  assert.strictEqual(L.timeLabel(new Date(2026, 0, 1, 0, 5).getTime()), '오전 12:05');
  assert.strictEqual(L.timeLabel(new Date(2026, 0, 1, 15, 30).getTime()), '오후 3:30');
  assert.strictEqual(L.timeLabel(0), '');
});

test('북마크: 추가는 맨 앞, 같은 주소는 합친다(끝 / 무시)', () => {
  let r = L.saveBookmark([], 'https://a.com/', 'A', 0);
  r = L.saveBookmark(r.list, 'https://b.com', 'B', 0);
  assert.deepStrictEqual(r.list.map((b) => b.title), ['B', 'A']);
  r = L.saveBookmark(r.list, 'https://a.com', 'A!', 0);
  assert.deepStrictEqual(r.list.map((b) => b.title), ['A!', 'B']);
  assert.ok(L.findBookmark(r.list, 'https://b.com/'));
});

test('북마크: 수정하면 같은 id 를 고치고, 다른 항목과 주소가 겹치면 합친다', () => {
  let r = L.saveBookmark([], 'https://a.com', 'A', 0);
  r = L.saveBookmark(r.list, 'https://b.com', 'B', 0);
  const a = L.findBookmark(r.list, 'https://a.com');
  const r2 = L.saveBookmark(r.list, 'https://b.com', 'A→B', 0, a.id);
  assert.strictEqual(r2.list.length, 1);
  assert.strictEqual(r2.list[0].id, a.id);
});

test('폴더를 지우면 안의 북마크는 폴더 없음으로', () => {
  const f = L.addFolder([], '뉴스');
  const r = L.saveBookmark([], 'https://a.com', 'A', f.folder.id);
  const out = L.removeFolder(f.list, r.list, f.folder.id);
  assert.strictEqual(out.folders.length, 0);
  assert.strictEqual(out.bookmarks[0].folderId, 0);
});

test('주소창 추천: 북마크 2개 먼저, 합쳐서 4개, 중복 없음', () => {
  const bms = [1, 2, 3].map((i) => ({ id: i, url: 'https://news.com/' + i, title: 'news ' + i, folderId: 0 }));
  const hist = [{ url: 'https://news.com/1', title: '', time: 1 }, { url: 'https://daily-news.kr', title: '', time: 2 }, { url: 'https://other.com', title: 'newsletter', time: 3 }, { url: 'https://zzz.com', title: 'z', time: 4 }];
  assert.deepStrictEqual(L.suggestLocal('NEWS', hist, bms), ['https://news.com/1', 'https://news.com/2', 'https://daily-news.kr', 'https://other.com']);
  assert.deepStrictEqual(L.suggestLocal('  ', hist, bms), []);
});

test('북마크 HTML 내보내기 → 가져오기 왕복 (폴더·특수문자 포함)', () => {
  const folders = [{ id: 1, name: '뉴스 & 날씨' }, { id: 2, name: '빈 폴더' }];
  const bms = [
    { id: 1, url: 'https://a.com/?x=1&y=2', title: 'A <b> "q"', folderId: 1 },
    { id: 2, url: 'https://b.com', title: '', folderId: 0 },
  ];
  const html = L.bookmarksToHtml(bms, folders, NOW);
  assert.ok(html.startsWith('<!DOCTYPE NETSCAPE-Bookmark-file-1>'));
  assert.ok(!html.includes('빈 폴더')); // 비어 있는 폴더는 내보내지 않는다
  const p = L.parseBookmarksHtml(html);
  assert.deepStrictEqual(p, [
    { title: 'A <b> "q"', url: 'https://a.com/?x=1&y=2', folder: '뉴스 & 날씨' },
    { title: 'https://b.com', url: 'https://b.com', folder: '' },
  ]);
});

test('북마크 HTML: 크롬 형식(맨 바깥 목록만 폴더 없음, 안쪽은 가장 가까운 이름 있는 폴더), http 아닌 것·중복 제외', () => {
  const html = `<DL><p><DT><H3>북마크바</H3><DL><p>
    <DT><A HREF="https://a.com">A</A>
    <DT><H3>개발</H3><DL><p><DT><H3>JS</H3><DL><p><DT><A HREF="https://js.dev/">MDN &amp; co</A></DL><p></DL><p>
    <DT><A HREF="javascript:alert(1)">bad</A>
    <DT><A HREF="https://a.com/">dup</A>
  </DL><p></DL><p>`;
  const p = L.parseBookmarksHtml(html);
  assert.deepStrictEqual(L.parseBookmarksHtml('<DL><p><DT><A HREF="https://root.com">R</A></DL>'), [{ title: 'R', url: 'https://root.com', folder: '' }]);
  assert.deepStrictEqual(p, [{ title: 'A', url: 'https://a.com', folder: '북마크바' }, { title: 'MDN & co', url: 'https://js.dev/', folder: 'JS' }]);
});

test('가져오기 합치기: 같은 주소는 건너뛰고 폴더는 이름으로 찾거나 만든다', () => {
  const have = L.saveBookmark([], 'https://a.com', 'A', 0).list;
  const m = L.mergeImported(have, [], [
    { title: 'A', url: 'https://a.com/', folder: '' },
    { title: 'B', url: 'https://b.com', folder: '뉴스' },
    { title: 'C', url: 'https://c.com', folder: '뉴스' },
  ]);
  assert.strictEqual(m.added, 2); assert.strictEqual(m.skipped, 1);
  assert.strictEqual(m.folders.length, 1);
  assert.ok(m.bookmarks.filter((b) => b.folderId === m.folders[0].id).length === 2);
});

test('크기·제목 표시', () => {
  assert.strictEqual(L.fmtSize(512), '512 B');
  assert.strictEqual(L.fmtSize(2048), '2 KB');
  assert.strictEqual(L.fmtSize(5 * 1048576), '5.0 MB');
  assert.strictEqual(L.displayTitle('', 'https://www.naver.com/x'), 'naver.com');
  assert.strictEqual(L.displayTitle('  제목 ', 'https://a.com'), '제목');
});

test('받은 파일 이름: 윈도우에서 못 쓰는 글자·예약어 정리, 겹치면 (1) 붙임', () => {
  const { safeName, uniquePath } = require('../src/main/fsutil');
  const fs = require('fs'), os = require('os'), path = require('path');
  assert.strictEqual(safeName('a<b>:c?.txt'), 'a_b__c_.txt');
  assert.strictEqual(safeName('CON.txt'), '_CON.txt');
  assert.strictEqual(safeName('...  '), 'download');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ev-'));
  fs.writeFileSync(path.join(dir, 'a.zip'), 'x');
  fs.writeFileSync(path.join(dir, 'a (1).zip'), 'x');
  assert.strictEqual(path.basename(uniquePath(dir, 'a.zip')), 'a (2).zip');
  assert.strictEqual(path.basename(uniquePath(dir, 'b.zip')), 'b.zip');
});
