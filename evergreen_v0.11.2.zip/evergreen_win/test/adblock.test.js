'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { NetFilter, T, parse, fromResourceType } = require('../src/shared/netfilter');
const { AdEngine, parseHostLine, parseCosmetic, extractHosts } = require('../src/shared/adengine');
const { TrackerBlocker } = require('../src/shared/trackers');
const { SecStats, K } = require('../src/shared/secstats');
const G = require('../src/shared/guard');

test('NetFilter: 도메인·경로·옵션·예외', () => {
  const f = new NetFilter();
  f.load(['||ads.example.com^', '||cdn.x.com/banner/*$image', '||t.example.net^$third-party', '@@||ads.example.com/ok^', '! 주석', 'example.com##.ad']);
  assert.strictEqual(f.shouldBlock('https://ads.example.com/a.js', 'ads.example.com', 'site.com', true, T.SCRIPT), true);
  assert.strictEqual(f.shouldBlock('https://ads.example.com/ok/a.js', 'ads.example.com', 'site.com', true, T.SCRIPT), false, '예외 규칙');
  assert.strictEqual(f.shouldBlock('https://cdn.x.com/banner/1.png', 'cdn.x.com', 'site.com', true, T.IMAGE), true);
  assert.strictEqual(f.shouldBlock('https://cdn.x.com/banner/1.js', 'cdn.x.com', 'site.com', true, T.SCRIPT), false, '종류 옵션');
  assert.strictEqual(f.shouldBlock('https://t.example.net/p', 't.example.net', 'example.net', false, T.XHR), false, '퍼스트파티는 third-party 규칙에 안 걸림');
  assert.strictEqual(f.shouldBlock('https://t.example.net/p', 't.example.net', 'site.com', true, T.XHR), true);
});
test('NetFilter: 지원 안 하는 옵션·정규식·너무 짧은 규칙은 버린다', () => {
  assert.strictEqual(parse('||a.com^$redirect=nooptext'), null);
  assert.strictEqual(parse('/ads\\d+/'), null);
  assert.strictEqual(parse('/ad'), null);
  assert.strictEqual(parse('||a.com^$popup'), null);
  assert.ok(parse('||a.com^$domain=x.com|~y.com'));
});
test('NetFilter: 요청 종류 변환', () => {
  assert.strictEqual(fromResourceType('script'), T.SCRIPT);
  assert.strictEqual(fromResourceType('mainFrame'), T.DOC);
  assert.strictEqual(fromResourceType('webSocket'), T.WS);
});
test('AdEngine: 내장 목록·서브도메인·허용 목록·배너 주소', () => {
  const e = new AdEngine();
  assert.strictEqual(e.shouldBlock('x.doubleclick.net', 'news.com', 'https://x.doubleclick.net/a', T.SCRIPT), true);
  assert.strictEqual(e.shouldBlock('r1.googlevideo.com', 'youtube.com', 'https://r1.googlevideo.com/v', T.MEDIA), false, '허용 목록');
  assert.strictEqual(e.shouldBlock('img.news.com', 'news.com', 'https://img.news.com/banners/a.png', T.IMAGE), true, '같은 사이트 배너');
  assert.strictEqual(e.shouldBlock('img.news.com', 'news.com', 'https://img.news.com/photo/a.png', T.IMAGE), false);
  assert.strictEqual(e.shouldBlock('ads.other.net', 'news.com', 'https://ads.other.net/x', T.ANY), true, 'ads. 이름');
  assert.strictEqual(e.shouldBlock('static.news.com', 'news.com', 'https://static.news.com/a.swf', T.OBJECT), true, '플래시');
  assert.strictEqual(e.isAdHost('a.b.googlesyndication.com'), true);
  assert.strictEqual(e.isAdHost('example.com'), false);
});
test('AdEngine: 목록 줄 읽기', () => {
  assert.strictEqual(parseHostLine('0.0.0.0 ads.foo.com'), 'ads.foo.com');
  assert.strictEqual(parseHostLine('||ads.foo.com^'), 'ads.foo.com');
  assert.strictEqual(parseHostLine('||ads.foo.com/x^'), null);
  assert.strictEqual(parseHostLine('foo.com##.ad'), null);
  assert.strictEqual(parseHostLine('# c'), null);
  assert.deepStrictEqual(parseCosmetic('##.ad-box'), { doms: null, sel: '.ad-box' });
  assert.deepStrictEqual(parseCosmetic('a.com,www.b.com##.x'), { doms: ['a.com', 'b.com'], sel: '.x' });
  assert.strictEqual(parseCosmetic('a.com##.x:has-text(광고)'), null);
  assert.strictEqual(parseCosmetic('~a.com##.x'), null);
  assert.deepStrictEqual([...extractHosts(['||p.net^', '@@||q.net^', '||r.net/x^'], true)], ['p.net']);
});
test('AdEngine: 사이트별 숨김 CSS 는 상위 도메인까지', () => {
  const e = new AdEngine();
  e.setSiteLines(['news.com\t.top-ad', 'a.news.com\t.side']);
  assert.ok(e.topCss('a.news.com').includes('.top-ad{display:none!important}'));
  assert.ok(e.topCss('a.news.com').includes('.side{'));
  assert.ok(!e.topCss('other.com').includes('.top-ad'));
});
test('TrackerBlocker: 트래커만, 같은 사이트·필수 도메인은 통과', () => {
  const t = new TrackerBlocker();
  assert.strictEqual(t.shouldBlock('www.google-analytics.com', 'news.com'), true);
  assert.strictEqual(t.shouldBlock('www.google-analytics.com', 'google-analytics.com'), false);
  assert.strictEqual(t.shouldBlock('www.gstatic.com', 'news.com'), false);
  assert.strictEqual(t.shouldBlock('cdn.news.com', 'news.com'), false);
});
test('SecStats: 7일 기록 · 종류별 · 초기화', () => {
  let now = Date.UTC(2026, 10, 21, 12);
  const s = new SecStats(null, () => now);
  s.add(K.AD, 'x.doubleclick.net'); s.add(K.AD, 'y.doubleclick.net'); s.add(K.POPUP, 'p.com'); s.add(K.TRACKER); s.add(K.HTTPS);
  assert.strictEqual(s.todayTotal(), 2, '보안 합계에는 광고·팝업이 빠진다');
  assert.strictEqual(s.adSummary().today, 3);
  assert.deepStrictEqual(s.adSummary().top[0], ['doubleclick.net', 2]);
  now += 86400000; s.add(K.TRACKER);
  assert.deepStrictEqual(s.week().slice(-2), [2, 1]);
  assert.strictEqual(s.weekTotal(K.TRACKER), 2);
  const saved = JSON.parse(JSON.stringify(s.serialize()));
  const s2 = new SecStats(saved, () => now);
  assert.strictEqual(s2.weekTotal(K.TRACKER), 2); assert.strictEqual(s2.total, 3);
  now += 10 * 86400000; s2.add(K.AD); // 오래된 날은 사라진다
  assert.strictEqual(s2.weekTotal(K.TRACKER), 0);
  s.resetSecurity(); assert.strictEqual(s.weekTotal(K.TRACKER), 0); assert.strictEqual(s.total, 3);
  s.resetAds(); assert.strictEqual(s.total, 0);
});
test('guard: siteKey · 로그인/결제 · https 올리기', () => {
  assert.strictEqual(G.siteKey('m.news.naver.com'), 'naver.com');
  assert.strictEqual(G.siteKey('www.a.co.kr'), 'a.co.kr');
  assert.strictEqual(G.siteKey('foo.github.io'), 'foo.github.io');
  assert.strictEqual(G.siteKey('x.foo.github.io'), 'foo.github.io');
  assert.ok(G.looksLikeSignInOrPay(new URL('https://accounts.google.com/x'), 'accounts.google.com'));
  assert.ok(G.looksLikeSignInOrPay(new URL('https://shop.com/checkout/1'), 'shop.com'));
  assert.ok(!G.looksLikeSignInOrPay(new URL('https://ad.evil.com/x'), 'ad.evil.com'));
  assert.strictEqual(G.upgradeUrl('http://example.com/a?b=1'), 'https://example.com/a?b=1');
  assert.strictEqual(G.upgradeUrl('http://192.168.0.1/'), null);
  assert.strictEqual(G.upgradeUrl('http://nas/'), null);
  assert.strictEqual(G.upgradeUrl('http://example.com/', new Set(['example.com'])), null);
  assert.strictEqual(G.upgradeUrl('https://example.com/'), null);
});
test('guard: 클릭 가로채기 판정', () => {
  const base = { from: 'https://video.com/watch', isRedirect: false, lastHopAt: 0, now: 10000, allowed: new Set() };
  const dest = (u) => new URL(u);
  assert.strictEqual(G.isHijackedNav(Object.assign({}, base, { dest: dest('https://ad.evil.com/x'), tap: { recent: true, onLink: false, href: '' } })), true, '빈 곳을 눌렀는데 다른 사이트');
  assert.strictEqual(G.isHijackedNav(Object.assign({}, base, { dest: dest('https://ad.evil.com/x'), tap: { recent: false } })), false, '누른 적 없음');
  assert.strictEqual(G.isHijackedNav(Object.assign({}, base, { dest: dest('https://video.com/next'), tap: { recent: true, onLink: false } })), false, '같은 사이트');
  assert.strictEqual(G.isHijackedNav(Object.assign({}, base, { dest: dest('https://other.com/a'), tap: { recent: true, onLink: true, href: 'https://other.com/a' } })), false, '링크 그대로');
  assert.strictEqual(G.isHijackedNav(Object.assign({}, base, { dest: dest('https://ad.evil.com/a'), tap: { recent: true, onLink: true, href: 'https://video.com/#' } })), true, '링크와 다른 곳으로');
  assert.strictEqual(G.isHijackedNav(Object.assign({}, base, { dest: dest('https://accounts.google.com/o'), tap: { recent: true, onLink: false } })), false, '로그인');
  assert.strictEqual(G.isHijackedNav(Object.assign({}, base, { dest: dest('https://ad.evil.com/x'), tap: { recent: true, onLink: false }, allowed: new Set(['evil.com']) })), false, '허락한 사이트');
  assert.strictEqual(G.isHijackedNav(Object.assign({}, base, { dest: dest('https://ad.evil.com/x'), isRedirect: true, lastHopAt: 9000, tap: { recent: true, onLink: false } })), false, '직전에 통과한 이동의 리다이렉트');
});
test('guard: 뒤로가기 함정', () => {
  const o = { enabled: true, hasTapSince: false, backAt: 1000, now: 2000, from: 'https://a.com/p', backTarget: 'https://a.com/p/', backLeft: 'https://b.com/x', dest: 'https://trap.com/' };
  assert.strictEqual(G.isBackTrap(o), true);
  assert.strictEqual(G.isBackTrap(Object.assign({}, o, { hasTapSince: true })), false);
  assert.strictEqual(G.isBackTrap(Object.assign({}, o, { now: 6000 })), false);
  assert.strictEqual(G.isBackTrap(Object.assign({}, o, { dest: 'http://www.a.com/p' })), false, '주소 정리');
  assert.strictEqual(G.isBackTrap(Object.assign({}, o, { enabled: false })), false);
});
