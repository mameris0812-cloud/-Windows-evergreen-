'use strict';
// 진짜 로컬 서버(가짜 Gemini)로 스트리밍 · 키/모델 바꿔 보내기 · 이어 쓰기 · 도구 호출 · 검색 거부를 확인한다
const test = require('node:test');
const assert = require('node:assert');
const http = require('http');
const G = require('../src/shared/gemini');
const { GeminiClient } = require('../src/main/gemini-client');
const { Usage } = require('../src/main/usage');
const { ModelSync } = require('../src/main/modelsync');

function sse(chunks) { return chunks.map((c) => 'data: ' + JSON.stringify(c) + '\n\n').join(''); }
const text = (t, extra) => Object.assign({ candidates: [{ content: { parts: [{ text: t }] } }] }, extra);
const fin = (t, reason) => ({ candidates: [{ content: { parts: t ? [{ text: t }] : [] }, finishReason: reason || 'STOP' }], usageMetadata: { promptTokenCount: 11, candidatesTokenCount: 7 } });
const quotaBody = (model) => JSON.stringify({ error: { code: 429, message: 'You exceeded your current quota', details: [{ '@type': 'x.QuotaFailure', violations: [{ quotaId: 'GenerateRequestsPerMinutePerProjectPerModel', quotaDimensions: { model } }] }, { retryDelay: '20s' }] } });

async function withServer(handler, fn) {
  const reqs = [];
  const srv = http.createServer((req, res) => {
    let b = ''; req.on('data', (d) => (b += d));
    req.on('end', () => {
      const m = /models\/([^:]+):stream/.exec(req.url) || [];
      const rq = { model: m[1], key: req.headers['x-goog-api-key'], body: b ? JSON.parse(b) : null, url: req.url };
      reqs.push(rq);
      const out = handler(rq, reqs.length - 1);
      res.writeHead(out.status || 200, { 'Content-Type': out.status && out.status !== 200 ? 'application/json' : 'text/event-stream' });
      res.end(out.body);
    });
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  try { await fn('http://127.0.0.1:' + srv.address().port + '/v1beta', reqs); } finally { srv.close(); }
}
function mk(base, extra) {
  const g = G.create();
  const usage = new Usage(null);
  const modelSync = { refreshIfStale() {}, refreshNow() { return Promise.resolve(false); } }; // 모델 목록 요청은 따로 시험한다
  const c = new GeminiClient(Object.assign({ g, usage, modelSync, base, sleep: () => Promise.resolve() }, extra));
  return { g, c, usage };
}
const hist = (t) => [{ role: 'user', text: t }];

test('스트리밍: 글 조각 · 생각 요약 · 출처 · 토큰 기록 · 요청 모양', async () => {
  await withServer(() => ({ body: sse([
    { candidates: [{ content: { parts: [{ text: '생각 중', thought: true }] } }] },
    text('안녕'), text('하세요'),
    { candidates: [{ content: { parts: [{ text: '!' }] }, finishReason: 'STOP', groundingMetadata: { webSearchQueries: ['날씨'], groundingChunks: [{ web: { uri: 'https://a.com/x', title: 'a.com' } }] } }], usageMetadata: { promptTokenCount: 20, thoughtsTokenCount: 5, candidatesTokenCount: 3 } },
  ]) }), async (base, reqs) => {
    const { g, c, usage } = mk(base);
    g.pool.pick(['K1']);
    let out = '', thought = '', ground = null, ran = 0;
    const r = await c.stream({ key: 'K1', model: g.models.lite(), system: '시스템', history: hist('질문'), search: true, includeThoughts: true,
      cb: { text: (d) => (out += d), thought: (t) => (thought += t), grounding: (q, s) => (ground = { q, s }), searchRan: () => ran++ } });
    assert.deepStrictEqual(r, { ok: true });
    assert.strictEqual(out, '안녕하세요!'); assert.strictEqual(thought, '생각 중');
    assert.deepStrictEqual(ground, { q: ['날씨'], s: [{ title: 'a.com', url: 'https://a.com/x' }] }); assert.strictEqual(ran, 1);
    const b = reqs[0].body;
    assert.strictEqual(reqs[0].key, 'K1');
    assert.deepStrictEqual(b.tools, [{ google_search: {} }]);
    assert.strictEqual(b.systemInstruction.parts[0].text, '시스템');
    assert.deepStrictEqual(b.generationConfig.thinkingConfig, { thinkingLevel: 'minimal', includeThoughts: true });
    assert.strictEqual(b.safetySettings.length, 5);
    assert.strictEqual(usage.today().calls, 1); assert.strictEqual(usage.today().tokIn, 20); assert.strictEqual(usage.today().tokOut, 8);
  });
});

test('사진·글 파일 첨부는 글보다 앞에, 글 파일은 이름 붙인 text 로', async () => {
  await withServer(() => ({ body: sse([fin('ok')]) }), async (base, reqs) => {
    const { g, c } = mk(base);
    await c.stream({ key: 'K', model: g.models.lite(), system: '', history: [{ role: 'user', text: '이거', images: [
      { mime: 'image/jpeg', base64: 'QUJD', name: '사진' }, { mime: 'text/plain', base64: Buffer.from('안녕').toString('base64'), name: 'a.txt' }] }], cb: {} });
    const parts = reqs[0].body.contents[0].parts;
    assert.deepStrictEqual(parts[0], { inlineData: { mimeType: 'image/jpeg', data: 'QUJD' } });
    assert.strictEqual(parts[1].text, '[첨부 파일: a.txt]\n안녕\n[파일 끝]');
    assert.strictEqual(parts[2].text, '이거');
  });
});

test('한도(429)가 찬 키는 다른 키로 같은 요청을 다시 보내고, 키 바뀜을 알린다', async () => {
  await withServer((rq) => (rq.key === 'K1' ? { status: 429, body: quotaBody(rq.model) } : { body: sse([fin('두번째 키')]) }), async (base, reqs) => {
    const { g, c } = mk(base);
    const ev = []; g.pool.onEvent = (e) => ev.push(e.text);
    g.pool.pick(['K1', 'K2']);
    let out = '';
    const r = await c.stream({ key: 'K1', model: g.models.lite(), system: '', history: hist('q'), cb: { text: (d) => (out += d) } });
    assert.ok(r.ok); assert.strictEqual(out, '두번째 키');
    assert.deepStrictEqual(reqs.map((x) => x.key), ['K1', 'K2']);
    assert.deepStrictEqual(ev, ['키 1 한도 도달 → 키 2 사용']);
    assert.ok(g.pool.blocked('K1', g.models.lite())); assert.ok(!g.pool.resting('K1'));
  });
});

test('모든 키가 한도면 다른 모델로 가고, 그것도 안 되면 한도 안내와 쉬는 모델을 알려 준다', async () => {
  await withServer((rq) => ({ status: 429, body: quotaBody(rq.model) }), async (base, reqs) => {
    const { g, c } = mk(base);
    g.pool.pick(['K1', 'K2']);
    const models = [];
    const r = await c.stream({ key: 'K1', model: g.models.lite(), system: '', history: hist('q'), cb: { model: (m) => models.push(m) } });
    assert.strictEqual(r.ok, false);
    assert.match(r.error, /요청 한도를 넘었어요/); assert.match(r.error, /등록한 키 2개가 모두/); assert.match(r.error, /쉬는 모델: /); assert.match(r.error, /한도 종류: GenerateRequestsPerMinute/);
    assert.deepStrictEqual(models, [g.models.hydrogen()]);
    const used = reqs.map((x) => x.model + '@' + x.key);
    assert.deepStrictEqual(used, [g.models.lite() + '@K1', g.models.lite() + '@K2', g.models.hydrogen() + '@K2', g.models.hydrogen() + '@K1']); // 다음 모델은 지금 쓰던 키(K2)부터
  });
});

test('모델이 없어지면(404) 없는 모델로 기억하고 다른 모델로 보낸다', async () => {
  await withServer((rq) => (rq.model === 'gemini-4-hydrogen' ? { status: 404, body: '{"error":{"message":"not found"}}' } : { body: sse([fin('lite 가 답함')]) }), async (base) => {
    const { g, c } = mk(base);
    let out = ''; const models = [];
    const r = await c.stream({ key: 'K', model: g.models.hydrogen(), system: '', history: hist('q'), cb: { text: (d) => (out += d), model: (m) => models.push(m) } });
    assert.ok(r.ok); assert.strictEqual(out, 'lite 가 답함'); assert.deepStrictEqual(models, [g.models.lite()]);
    assert.strictEqual(g.auto.live(g.models.hydrogen()), g.models.lite());
  });
});

test('답이 토큰 한도(MAX_TOKENS)로 잘리면 이어서 쓰게 다시 요청한다', async () => {
  await withServer((rq, i) => ({ body: sse(i === 0 ? [text('앞부분 '), fin('', 'MAX_TOKENS')] : [fin('뒷부분')]) }), async (base, reqs) => {
    const { g, c } = mk(base);
    let out = '';
    const r = await c.stream({ key: 'K', model: g.models.lite(), system: '', history: hist('긴 글'), cb: { text: (d) => (out += d) } });
    assert.ok(r.ok); assert.strictEqual(out, '앞부분 뒷부분');
    const c2 = reqs[1].body.contents;
    assert.strictEqual(c2.length, 3); assert.strictEqual(c2[1].role, 'model'); assert.strictEqual(c2[1].parts[0].text, '앞부분 ');
    assert.match(c2[2].parts[0].text, /이어서 계속 써 줘/);
  });
});

test('검색 도구를 모델이 거부하면 검색 없이 다시 보낸다 (필수 검색이면 다른 모델로)', async () => {
  await withServer((rq) => (rq.body.tools ? { status: 400, body: '{"error":{"message":"google_search is not supported for this model"}}' } : { body: sse([fin('검색 없이')]) }), async (base, reqs) => {
    const { g, c } = mk(base);
    let dropped = '', out = '';
    const r = await c.stream({ key: 'K', model: g.models.lite(), system: '', history: hist('q'), search: true, cb: { text: (d) => (out += d), searchDropped: (m) => (dropped = m) } });
    assert.ok(r.ok); assert.strictEqual(out, '검색 없이'); assert.strictEqual(dropped, g.models.lite());
    assert.ok(!reqs[1].body.tools);
  });
  await withServer((rq) => (rq.body.tools && rq.model === 'gemini-3.5-flash-lite' ? { status: 400, body: '{"error":{"message":"Search Grounding is not supported"}}' } : { body: sse([fin('다른 모델이 검색함')]) }), async (base, reqs) => {
    const { g, c } = mk(base);
    let out = '';
    const r = await c.stream({ key: 'K', model: g.models.lite(), system: '', history: hist('q'), search: true, searchOptional: false, cb: { text: (d) => (out += d) } });
    assert.ok(r.ok); assert.strictEqual(out, '다른 모델이 검색함');
    assert.strictEqual(reqs[1].model, g.models.hydrogen()); assert.ok(reqs[1].body.tools);
  });
});

test('생각 설정을 거부하면 설정 없이 다시 보낸다', async () => {
  await withServer((rq) => (rq.body.generationConfig.thinkingConfig ? { status: 400, body: '{"error":{"message":"Thinking level not supported"}}' } : { body: sse([fin('ok')]) }), async (base, reqs) => {
    const { g, c } = mk(base);
    const r = await c.stream({ key: 'K', model: g.models.lite(), system: '', history: hist('q'), cb: {} });
    assert.ok(r.ok); assert.ok(!reqs[1].body.generationConfig.thinkingConfig);
  });
});

test('빈 응답 · 안전 차단 · 키 거부 안내', async () => {
  await withServer(() => ({ body: sse([{ promptFeedback: { blockReason: 'SAFETY' } }, fin('')]) }), async (base) => {
    const { g, c } = mk(base);
    const r = await c.stream({ key: 'K', model: g.models.lite(), system: '', history: hist('q'), cb: {} });
    assert.match(r.error, /안전 정책/);
  });
  await withServer(() => ({ status: 403, body: '{"error":{"message":"API key not valid"}}' }), async (base) => {
    const { g, c } = mk(base);
    const r = await c.stream({ key: 'K', model: g.models.lite(), system: '', history: hist('q'), cb: {} });
    assert.match(r.error, /API 키가 거부/);
  });
});

test('서버가 붐비면(503) 다른 모델로, 둘 다 안 되면 같은 모델로 잠깐 뒤 다시', async () => {
  let n = 0;
  await withServer((rq) => (++n <= 2 ? { status: 503, body: '{}' } : { body: sse([fin('돌아옴')]) }), async (base, reqs) => {
    const { g, c } = mk(base);
    let out = '';
    const r = await c.stream({ key: 'K', model: g.models.lite(), system: '', history: hist('q'), cb: { text: (d) => (out += d) } });
    assert.ok(r.ok); assert.strictEqual(out, '돌아옴'); assert.strictEqual(reqs.length, 3);
  });
});

test('도구 호출 한 단계: functionCall 과 생각 서명을 parts 에 그대로 담는다', async () => {
  await withServer(() => ({ body: sse([
    { candidates: [{ content: { parts: [{ text: '탭을 닫을게요', thoughtSignature: 'SIG1' }] } }] },
    { candidates: [{ content: { parts: [{ functionCall: { name: 'close_tab', args: { number: 2 } }, thoughtSignature: 'SIG2' }] }, finishReason: 'STOP' }], usageMetadata: { promptTokenCount: 100, candidatesTokenCount: 9 } },
  ]) }), async (base, reqs) => {
    const { g, c } = mk(base);
    let streamed = '';
    const decls = [{ name: 'close_tab', description: 'x', parameters: { type: 'object', properties: {} } }];
    const s = await c.step({ key: 'K', model: g.models.hydrogen(), system: 'sys', contents: [{ role: 'user', parts: [{ text: '2번 탭 닫아' }] }], decls, thoughts: true, allowCalls: true, canSwitchModel: true, cb: { text: (t) => (streamed += t) } });
    assert.strictEqual(s.error, null); assert.strictEqual(streamed, '탭을 닫을게요');
    assert.deepStrictEqual(s.calls, [{ name: 'close_tab', args: { number: 2 }, id: '' }]);
    assert.deepStrictEqual(s.parts[0], { text: '탭을 닫을게요', thoughtSignature: 'SIG1' });
    assert.strictEqual(s.parts[1].thoughtSignature, 'SIG2');
    assert.deepStrictEqual(reqs[0].body.tools, [{ functionDeclarations: decls }]);
    assert.strictEqual(reqs[0].body.toolConfig.functionCallingConfig.mode, 'AUTO');
    assert.strictEqual(reqs[0].body.generationConfig.maxOutputTokens, 16384);
    assert.strictEqual(s.model, g.models.hydrogen());
  });
});

test('도구 단계가 한도로 막히면 다른 키로, 글이 이미 나갔으면 다시 보내지 않는다', async () => {
  await withServer((rq) => (rq.key === 'K1' ? { status: 429, body: quotaBody(rq.model) } : { body: sse([fin('끝')]) }), async (base, reqs) => {
    const { g, c } = mk(base);
    g.pool.pick(['K1', 'K2']);
    const s = await c.step({ key: 'K1', model: g.models.lite(), system: '', contents: [{ role: 'user', parts: [{ text: 'q' }] }], decls: [{ name: 'a', description: 'b', parameters: { type: 'object', properties: {} } }], cb: {} });
    assert.strictEqual(s.error, null); assert.strictEqual(s.key, 'K2'); assert.deepStrictEqual(reqs.map((r) => r.key), ['K1', 'K2']);
  });
});

test('모델 동기화: 목록에서 사라진 모델은 같은 계열의 새 모델로', async () => {
  const srv = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ models: [
      { name: 'models/gemini-3.5-flash-lite', supportedGenerationMethods: ['generateContent'], modelStatus: { modelStage: 'DEPRECATED' } },
      { name: 'models/gemini-3.6-flash-lite', supportedGenerationMethods: ['generateContent'] },
      { name: 'models/gemini-4-hydrogen', supportedGenerationMethods: ['generateContent'] },
      { name: 'models/embedding-001', supportedGenerationMethods: ['embedContent'] }] }));
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  try {
    const g = G.create(); const saved = {};
    const ms = new ModelSync({ g, store: { get: (k) => saved[k], set: (k, v) => { saved[k] = v; } }, base: 'http://127.0.0.1:' + srv.address().port });
    assert.ok(await ms.refreshNow('K'));
    assert.strictEqual(g.models.lite(), 'gemini-3.6-flash-lite');
    assert.strictEqual(saved.aiModelSync.map.LITE, 'gemini-3.6-flash-lite');
    const g2 = G.create(); const ms2 = new ModelSync({ g: g2, store: { get: (k) => saved[k], set() {} }, base: 'http://x' });
    ms2.init(); assert.strictEqual(g2.models.lite(), 'gemini-3.6-flash-lite'); // 저장해 둔 결과를 바로 쓴다
  } finally { srv.close(); }
});
