'use strict';
// 일렉트론 없이 Security(메인 프로세스 쪽 판정)를 가짜 일렉트론으로 돌려 본다: 요청 차단 → 응답 모양, 이동 감시, 다운로드 문
const test = require('node:test');
const assert = require('node:assert');
const Module = require('module');
const os = require('os');
const path = require('path');
const fs = require('fs');

const handlers = {};
const fakeElectron = {
  ipcMain: { on: (c, f) => { handlers[c] = f; }, handle: () => {} },
  webContents: { getAllWebContents: () => [], fromId: () => null },
  net: { fetch: async () => { throw new Error('offline'); } },
};
const orig = Module._load;
Module._load = function (req, ...rest) { return req === 'electron' ? fakeElectron : orig.call(this, req, ...rest); };
const { Security } = require('../src/main/secure');
Module._load = orig;

function make() {
  const store = { d: {}, get(k) { return this.d[k] == null ? null : this.d[k]; }, set(k, v) { this.d[k] = v; } };
  const toasts = []; const log = [];
  const tab = { id: 1, wid: 1, curHost: 'news.com', adBlocked: 0, tapMark: 0, view: { webContents: { getURL: () => 'https://news.com/a' } } };
  const sec = new Security({
    store, userData: fs.mkdtempSync(path.join(os.tmpdir(), 'ev-')),
    tabOf: () => tab, tabById: () => tab, tabByTabId: () => tab,
    toast: (m, a) => toasts.push({ m, a }),
    hooks: { closeTab: () => log.push('close'), openTab: (t, u) => log.push('open ' + u), load: (t, u) => log.push('load ' + u), warn: (t, h, u) => log.push('warn ' + u), leave: () => {}, dialog: (k, p) => log.push('dialog ' + k), goBack: () => log.push('back'), reloadActive: () => log.push('reload'), notify: () => {} },
  });
  const req = (url, resourceType) => { let r; sec._onRequest({ url, resourceType, webContentsId: 7 }, (x) => { r = x; }); return r; };
  return { sec, tab, toasts, log, req };
}

test('하위 요청: 광고는 취소, 평범한 요청은 통과, 통계가 쌓인다', () => {
  const { sec, tab, req } = make();
  assert.deepStrictEqual(req('https://ad.doubleclick.net/x.js', 'script'), { cancel: true });
  assert.deepStrictEqual(req('https://cdn.news.com/app.js', 'script'), {});
  assert.strictEqual(tab.adBlocked, 1);
  assert.strictEqual(sec.stats.adSummary().total, 1);
  sec.set('adBlock', false);
  assert.deepStrictEqual(req('https://ad.doubleclick.net/x.js', 'script'), {});
});
test('유튜브: 구글 광고 서버 요청은 막지 않고 넘기기 쪽으로 처리', () => {
  const { tab, req, sec } = make();
  tab.curHost = 'www.youtube.com';
  assert.deepStrictEqual(req('https://securepubads.g.doubleclick.net/x', 'xhr'), {});
  sec.set('ytAdBlock', false);
  assert.deepStrictEqual(req('https://securepubads.g.doubleclick.net/x', 'xhr'), { cancel: true });
});
test('엄격 트래커는 켰을 때만', () => {
  const { sec, req } = make();
  assert.deepStrictEqual(req('https://api.mixpanel.com/track', 'ping'), {});
  sec.set('strictTrackers', true);
  assert.deepStrictEqual(req('https://api.mixpanel.com/track', 'ping'), { cancel: true });
  assert.strictEqual(sec.stats.today(2), 1);
});
test('HTTPS 우선: http 는 https 로 올리고, 서버가 되돌리면 그대로 둔다', () => {
  const { sec, tab, req } = make();
  assert.deepStrictEqual(req('http://example.com/p?q=1', 'mainFrame'), { redirectURL: 'https://example.com/p?q=1' });
  assert.strictEqual(sec.stats.today(7), 1);
  assert.deepStrictEqual(req('http://example.com/p?q=1', 'mainFrame'), {}, '되돌아온 http 는 통과');
  assert.ok(sec.httpAllowed.has('example.com'));
  assert.deepStrictEqual(req('http://192.168.0.5/', 'mainFrame'), {});
  assert.strictEqual(tab.curHost, '192.168.0.5');
});
test('악성 사이트: 취소 후 경고 화면, 허락하면 통과', () => {
  const { sec, tab, req, log, toasts } = make();
  sec.malware = new Set(['evil-site.example']);
  assert.deepStrictEqual(req('https://www.evil-site.example/', 'mainFrame'), { cancel: true });
  assert.strictEqual(sec.handleFail(tab, -20, 'https://www.evil-site.example/'), true, '오류 화면 대신 경고');
  assert.ok(log.includes('warn https://www.evil-site.example/'));
  assert.strictEqual(sec.stats.today(6), 1);
  sec.malwareOk.add('www.evil-site.example');
  assert.deepStrictEqual(req('https://www.evil-site.example/', 'mainFrame'), {});
  sec.set('malwareWarning', false); sec.malwareOk.clear();
  assert.deepStrictEqual(req('https://www.evil-site.example/', 'mainFrame'), {});
});
test('스크립트 팝업이 광고 서버로 가면 탭을 닫는다', () => {
  const { tab, req, log, sec } = make();
  tab.scriptPopup = true;
  assert.deepStrictEqual(req('https://popads.net/x', 'mainFrame'), { cancel: true });
  assert.strictEqual(sec.handleFail(tab, -20, 'https://popads.net/x'), true);
  return new Promise((r) => setImmediate(r)).then(() => assert.ok(log.includes('close')));
});
test('새 창: 광고 서버 · 클릭 가로채기', () => {
  const { sec, tab, toasts, log } = make();
  assert.strictEqual(sec.checkPopup(tab, 'https://popads.net/x'), true);
  assert.strictEqual(sec.checkPopup(tab, 'https://news.com/other'), false);
  tab.tapAt = Date.now() - 500; tab.tapOnLink = false;
  assert.strictEqual(sec.checkPopup(tab, 'https://totally-other.example/'), true);
  const t = toasts[toasts.length - 1];
  assert.strictEqual(t.a.label, '이동');
  t.a.fn();
  assert.ok(log.includes('open https://totally-other.example/'));
  assert.strictEqual(sec.checkPopup(tab, 'https://totally-other.example/'), false, '허락한 사이트');
});
test('자동 다운로드: 누른 적 없으면 막고, 최근에 눌렀으면 허용', () => {
  const { sec, tab } = make();
  assert.strictEqual(sec.allowDownload({}, 'https://x.com/a.zip'), false);
  tab.tapAt = Date.now() - 1000;
  assert.strictEqual(sec.allowDownload({}, 'https://x.com/a.zip'), true);
  tab.tapAt = 0; tab.userDlAt = Date.now();
  assert.strictEqual(sec.allowDownload({}, 'https://x.com/a.zip'), true);
  sec.set('blockAutoDownload', false); tab.userDlAt = 0;
  assert.strictEqual(sec.allowDownload({}, 'https://x.com/a.zip'), true);
});
test('https 연결 실패 → http 대체 대화상자 → 허락하면 http 로 연다', () => {
  const { sec, tab, log } = make();
  tab.upgradedFrom = 'http://old.example/';
  assert.strictEqual(sec.handleFail(tab, -102, 'https://old.example/'), false);
  assert.ok(log.includes('dialog httpfb'));
  const token = [...sec.fbTokens.keys()][0];
  sec.command('sec:http-continue', { token, yes: true });
  assert.ok(log.includes('load http://old.example/'));
  assert.ok(sec.httpAllowed.has('old.example'));
});
test('설정·보호 수준·요약', () => {
  const { sec } = make();
  assert.strictEqual(sec.protection().level, 1);
  sec.set('strictTrackers', true); sec.set('skipCaptcha', true);
  assert.strictEqual(sec.protection().level, 2);
  sec.set('adBlock', false); sec.set('httpsFirst', false);
  assert.strictEqual(sec.protection().level, 0);
  assert.ok(sec.protection().off.includes('광고 차단'));
  assert.ok(/^보호 수준 /.test(sec.summary()));
  assert.ok(sec.secPayload().kinds.length === 6 && sec.adPayload(3).pageBlocked === 3);
});
test('페이지 초기화 응답: 숨김 CSS · 스크립트 · 설정 반영', () => {
  const { sec } = make();
  const e = {}; handlers['sec:init'](e, { name: '__evtest', host: 'www.youtube.com', href: 'https://www.youtube.com/' });
  assert.ok(e.returnValue.css.includes('display:none'));
  assert.ok(e.returnValue.code.includes('__evtest') && e.returnValue.code.includes('ytAdBlock') && e.returnValue.code.includes('adblock'));
  sec.set('adBlock', false);
  const e2 = {}; handlers['sec:init'](e2, { name: '__x', host: 'news.com', href: 'https://news.com/' });
  assert.strictEqual(e2.returnValue.code, ''); assert.strictEqual(e2.returnValue.css, '');
});
test('페이지 스크립트 문법', () => {
  const { sec } = make();
  const e = {}; handlers['sec:init'](e, { name: '__evtest', host: 'www.youtube.com', href: '' });
  assert.doesNotThrow(() => new Function(e.returnValue.code));
});
