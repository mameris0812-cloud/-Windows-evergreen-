'use strict';
const test = require('node:test');
const assert = require('node:assert');
const G = require('../src/shared/gemini');
const { AgentRunner, buildTools, pickTools } = require('../src/main/agent');

// 가짜 모델: 미리 짠 단계(calls/text)를 차례로 돌려준다
function fakeClient(script) {
  const seen = [];
  return {
    seen, cancel() {},
    async step(o) {
      const s = script.shift() || { text: '끝' };
      seen.push({ contents: JSON.parse(JSON.stringify(o.contents)), decls: o.decls.map((d) => d.name), allowCalls: o.allowCalls, canSwitchModel: o.canSwitchModel, system: o.system });
      if (s.error) return { parts: [], calls: [], finish: '', blocked: '', error: s.error, key: o.key, model: o.model };
      if (s.text && o.cb.text) o.cb.text(s.text);
      const parts = []; if (s.text) parts.push({ text: s.text });
      (s.calls || []).forEach((c) => parts.push({ functionCall: { name: c[0], args: c[1] }, thoughtSignature: 'sig-' + c[0] }));
      return { parts, calls: (s.calls || []).map((c) => ({ name: c[0], args: c[1], id: '' })), finish: 'STOP', blocked: '', error: null, key: o.key, model: o.model };
    },
  };
}
function fakeHost() {
  const log = [];
  const h = new Proxy({ log }, { get: (t, k) => (k in t ? t[k] : (...a) => { log.push([k, ...a]); return k === 'listTabs' ? [{ number: 1, title: 'A', url: 'https://a.com', active: true }, { number: 2, title: 'B', url: 'https://b.com' }] : k === 'elementInfo' ? t.els && t.els[a[0]] : { ok: true }; }) });
  return h;
}
const mk = (script, host, confirm) => {
  const g = G.create(); const client = fakeClient(script); const events = [];
  const r = new AgentRunner({ client, g, host: host || fakeHost(), emit: (e) => events.push(e), confirm });
  return { r, client, events, g };
};
const hist = (q) => [{ role: 'user', text: q }];
const run = (m, q, extra) => m.r.run(Object.assign({ key: 'K', model: m.g.models.hydrogen(), history: hist(q), question: q, system: 'SYS' }, extra));

test('도구를 부르고 결과를 돌려준 뒤 마무리 글로 끝난다 (생각 서명 그대로)', async () => {
  const m = mk([{ calls: [['list_tabs', {}]] }, { calls: [['close_tab', { number: 2 }]], text: '' }, { text: '2번 탭을 닫았어요' }]);
  const res = await run(m, '2번 탭 닫아 줘');
  assert.ok(res.ok); assert.strictEqual(res.text, '2번 탭을 닫았어요');
  const c2 = m.client.seen[1].contents;
  assert.strictEqual(c2[1].role, 'model'); assert.strictEqual(c2[1].parts[0].thoughtSignature, 'sig-list_tabs');
  assert.strictEqual(c2[2].role, 'user'); assert.strictEqual(c2[2].parts[0].functionResponse.name, 'list_tabs');
  assert.strictEqual(c2[2].parts[0].functionResponse.response.tabs.length, 2);
  assert.deepStrictEqual(m.r.host.log.filter((l) => l[0] === 'closeTab'), [['closeTab', 2]]);
  assert.strictEqual(m.client.seen[0].canSwitchModel, true); assert.strictEqual(m.client.seen[1].canSwitchModel, false);
  assert.deepStrictEqual(m.events.filter((e) => e.type === 'tool').map((e) => e.name + ':' + e.status), ['list_tabs:run', 'list_tabs:ok', 'close_tab:run', 'close_tab:ok']);
});

test('위험한 도구는 확인 카드를 거치고, 거절되면 실행하지 않는다', async () => {
  const asked = [];
  const m = mk([{ calls: [['delete_bookmarks', { urls: ['https://x.com'] }]] }, { text: '거절돼서 안 지웠어요' }], null, async (c) => { asked.push(c); return false; });
  const res = await run(m, '북마크 지워 줘');
  assert.ok(res.ok); assert.strictEqual(asked.length, 1); assert.match(asked[0].text, /북마크 1개를 지울까요/);
  assert.ok(!m.r.host.log.some((l) => l[0] === 'deleteBookmarks'));
  assert.match(m.client.seen[1].contents[2].parts[0].functionResponse.response.error, /거절/);
  assert.ok(m.events.some((e) => e.status === 'denied'));
  const ok = mk([{ calls: [['delete_bookmarks', { urls: ['https://x.com'] }]] }, { text: 'ㅇ' }], null, async () => true);
  await run(ok, '북마크 지워 줘'); assert.ok(ok.r.host.log.some((l) => l[0] === 'deleteBookmarks'));
});

test('설정: 보안을 끌 때만 확인, 테마는 바로', async () => {
  const asked = [];
  const m = mk([{ calls: [['change_setting', { name: 'theme', value: 'dark' }], ['change_setting', { name: 'adBlock', value: 'false' }]] }, { text: 'ok' }], null, async (c) => { asked.push(c.text); return true; });
  await run(m, '다크 모드 켜고 광고 차단 꺼 줘');
  assert.deepStrictEqual(asked, ['보안·광고 설정 「adBlock」 을(를) 끌까요?']);
});

test('페이지 버튼: 결제·삭제 같은 이름은 확인, 입력 제출도 확인, 평범한 버튼은 바로', async () => {
  const host = fakeHost(); host.els = { 1: { label: '결제하기', type: 'button' }, 2: { label: '더보기', type: 'button' }, 3: { label: '검색', type: 'text' } };
  const asked = [];
  const m = mk([{ calls: [['click_element', { element: 2 }], ['click_element', { element: 1 }], ['fill_field', { element: 3, text: '날씨', submit: true }]] }, { text: '끝' }], host, async (c) => { asked.push(c.text); return true; });
  await run(m, '버튼 눌러 줘');
  assert.deepStrictEqual(asked, ['이 페이지에서 「결제하기」 을(를) 누를까요?', '입력칸 「검색」 에 글을 넣고 제출할까요?']);
  assert.strictEqual(host.log.filter((l) => l[0] === 'clickElement').length, 2);
});

test('도구 선택: 관련 없는 묶음은 싣지 않고, 안 실은 도구를 불러도 실행한다', async () => {
  const all = buildTools();
  const names = (q) => pickTools(all, q).map((t) => t.name);
  assert.ok(names('탭 닫아 줘').includes('close_tab')); assert.ok(!names('탭 닫아 줘').includes('delete_history')); assert.ok(!names('탭 닫아 줘').includes('set_extension'));
  assert.ok(names('방문 기록 지워 줘').includes('delete_history')); assert.ok(names('확장 꺼 줘').includes('set_extension'));
  const m = mk([{ calls: [['set_extension', { id: 'abc', enabled: false }]] }, { text: '껐어요' }]);
  await run(m, '탭 정리해 줘');
  assert.ok(!m.client.seen[0].decls.includes('set_extension'));
  assert.ok(m.r.host.log.some((l) => l[0] === 'setExtension' && l[1] === 'abc'));
});

test('모르는 도구 · 도구 오류는 모델에게 알려 주고 이어 간다', async () => {
  const host = fakeHost(); host.closeTab = () => { throw new Error('그 번호의 탭이 없어요'); };
  const m = mk([{ calls: [['nope', {}], ['close_tab', { number: 9 }]] }, { text: '못 했어요' }], host);
  const res = await run(m, '탭 닫아');
  assert.ok(res.ok);
  const fr = m.client.seen[1].contents[2].parts;
  assert.match(fr[0].functionResponse.response.error, /없는 도구/); assert.match(fr[1].functionResponse.response.error, /탭이 없어요/);
});

test('단계가 끝나면 도구 없이 마무리하고, 오류는 그대로 알린다', async () => {
  const loop = Array.from({ length: 40 }, () => ({ calls: [['list_tabs', {}]] }));
  const m = mk(loop);
  const res = await run(m, '탭 계속 봐');
  assert.ok(res.ok);
  assert.strictEqual(m.client.seen.length, 17); assert.strictEqual(m.client.seen[16].allowCalls, false); // 16단계 + 마무리 1번
  const e = mk([{ error: '요청 한도를 넘었어요' }]);
  const r2 = await run(e, 'x'); assert.deepStrictEqual([r2.ok, r2.error], [false, '요청 한도를 넘었어요']);
  const empty = mk([{ text: '' }]); const r3 = await run(empty, 'x'); assert.strictEqual(r3.ok, false); assert.match(r3.error, /응답이 비어/);
});

test('큰 결과는 잘라서 보내고, 자율 모드는 더 긴 단계와 안내를 쓴다', async () => {
  const host = fakeHost(); host.readPage = async () => ({ text: 'x'.repeat(50000) });
  const m = mk([{ calls: [['read_page', {}]] }, { text: 'ok' }], host);
  await run(m, '페이지 읽어 줘', { auto: true });
  const resp = m.client.seen[1].contents[2].parts[0].functionResponse.response;
  assert.strictEqual(resp.truncated, true); assert.ok(resp.partial.length <= 14000);
  assert.match(m.client.seen[0].system, /자율 모드/); assert.match(m.client.seen[0].system, /최대 30단계/);
});

test('중지하면 더 부르지 않는다', async () => {
  const m = mk([{ calls: [['list_tabs', {}]] }, { calls: [['list_tabs', {}]] }, { text: 'x' }]);
  const orig = m.client.step; let n = 0;
  m.client.step = async (o) => { const r = await orig.call(m.client, o); if (++n === 1) m.r.cancel(); return r; };
  const res = await run(m, '탭');
  assert.ok(res.cancelled); assert.strictEqual(m.client.seen.length, 1);
});
