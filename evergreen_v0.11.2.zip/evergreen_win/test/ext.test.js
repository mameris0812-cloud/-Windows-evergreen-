'use strict';
const test = require('node:test');
const assert = require('node:assert');
const zlib = require('zlib');
const crypto = require('crypto');
const { readZip } = require('../src/shared/zip');
const Crx = require('../src/shared/crx');
const C = require('../src/shared/extcompat');
const T = require('../src/shared/theme');

// 시험용 zip 만들기 (deflate / 저장 섞어서)
function makeZip(files) {
  const locals = [], cds = []; let off = 0;
  for (const [name, content, store] of files) {
    const nb = Buffer.from(name), data = Buffer.from(content), comp = store ? data : zlib.deflateRawSync(data);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x800, 6); lh.writeUInt16LE(store ? 0 : 8, 8);
    lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nb.length, 26);
    const cd = Buffer.alloc(46); cd.writeUInt32LE(0x02014b50, 0); cd.writeUInt16LE(20, 4); cd.writeUInt16LE(20, 6); cd.writeUInt16LE(0x800, 8); cd.writeUInt16LE(store ? 0 : 8, 10);
    cd.writeUInt32LE(comp.length, 20); cd.writeUInt32LE(data.length, 24); cd.writeUInt16LE(nb.length, 28); cd.writeUInt32LE(off, 42);
    locals.push(lh, nb, comp); cds.push(cd, nb); off += 30 + nb.length + comp.length;
  }
  const cdBuf = Buffer.concat(cds), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cdBuf.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...locals, cdBuf, end]);
}
const varint = (n) => { const o = []; while (n > 127) { o.push((n % 128) | 128); n = Math.floor(n / 128); } o.push(n); return Buffer.from(o); };
const field = (num, buf) => Buffer.concat([varint(num * 8 + 2), varint(buf.length), buf]);

test('zip: 읽기(deflate · 저장 · 한글 이름), 경로 탈출 거부, 깨진 파일 거부', () => {
  const z = readZip(makeZip([['manifest.json', '{"name":"가나다"}'], ['_locales/ko/messages.json', 'x'.repeat(5000)], ['a/', ''], ['raw.txt', 'hello', true], ['한글.txt', '안녕']]));
  assert.deepStrictEqual(z.map((e) => e.name), ['manifest.json', '_locales/ko/messages.json', 'a/', 'raw.txt', '한글.txt']);
  assert.strictEqual(z[0].data().toString(), '{"name":"가나다"}'); assert.strictEqual(z[1].data().length, 5000);
  assert.strictEqual(z[3].data().toString(), 'hello'); assert.strictEqual(z[4].data().toString(), '안녕'); assert.ok(z[2].dir);
  assert.throws(() => readZip(makeZip([['../evil.js', 'x']])), /안전하지/);
  assert.throws(() => readZip(makeZip([['C:/x.js', 'x']])), /안전하지/);
  assert.throws(() => readZip(makeZip([['/abs', 'x']])), /안전하지/);
  assert.throws(() => readZip(Buffer.from('not a zip at all, definitely not')), /zip/);
});

test('crx3: 서명 키로 확장 프로그램 ID 와 공개 키를 구한다 (크롬 방식)', () => {
  const { publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 1024 });
  const der = publicKey.export({ type: 'spki', format: 'der' });
  const id = Crx.idFromKey(der); assert.match(id, /^[a-p]{32}$/);
  const crxId = crypto.createHash('sha256').update(der).digest().subarray(0, 16);
  const other = crypto.generateKeyPairSync('rsa', { modulusLength: 1024 }).publicKey.export({ type: 'spki', format: 'der' });
  const header = Buffer.concat([
    field(2, field(1, other)), field(2, field(1, der)), field(2, field(1, Buffer.alloc(0)).subarray(0, 0)),
    field(10000, field(1, crxId)),
  ]);
  const zip = makeZip([['manifest.json', '{}']]);
  const h = Buffer.alloc(12); h.write('Cr24', 0, 'latin1'); h.writeUInt32LE(3, 4); h.writeUInt32LE(header.length, 8);
  const r = Crx.parseCrx(Buffer.concat([h, header, zip]));
  assert.strictEqual(r.id, id); assert.strictEqual(r.key, der.toString('base64')); assert.ok(r.zip.equals(zip));
  assert.strictEqual(readZip(r.zip)[0].name, 'manifest.json');
});
test('crx2 와 일반 zip', () => {
  const der = crypto.generateKeyPairSync('rsa', { modulusLength: 1024 }).publicKey.export({ type: 'spki', format: 'der' });
  const sig = Buffer.alloc(8, 1), zip = makeZip([['manifest.json', '{}']]), h = Buffer.alloc(16);
  h.write('Cr24', 0, 'latin1'); h.writeUInt32LE(2, 4); h.writeUInt32LE(der.length, 8); h.writeUInt32LE(sig.length, 12);
  const r = Crx.parseCrx(Buffer.concat([h, der, sig, zip]));
  assert.strictEqual(r.id, Crx.idFromKey(der)); assert.ok(r.zip.equals(zip));
  const plain = Crx.parseCrx(zip); assert.strictEqual(plain.id, null); assert.ok(plain.zip.equals(zip));
  assert.throws(() => { const b = Buffer.alloc(32); b.write('Cr24', 0, 'latin1'); b.writeUInt32LE(9, 4); Crx.parseCrx(b); }, /버전/);
});

test('웹스토어 주소·ID 읽기 + 받을 주소', () => {
  const id = 'cjpalhdlnbpafiamejdnhcphjbkeiagm';
  assert.strictEqual(C.parseStoreId(id), id);
  assert.strictEqual(C.parseStoreId('https://chromewebstore.google.com/detail/ublock-origin/' + id + '?hl=ko'), id);
  assert.strictEqual(C.parseStoreId('https://chrome.google.com/webstore/detail/' + id), id);
  assert.strictEqual(C.parseStoreId('https://example.com/detail/' + id), null);
  assert.strictEqual(C.parseStoreId('abc'), null);
  assert.ok(C.storeCrxUrl(id).includes('id%3D' + id + '%26uc'));
});
test('호환성: 막는 것 · 경고만 하는 것 · 통과', () => {
  assert.match(C.manifestIncompat({ manifest_version: 2, app: {} }), /^크롬 앱/);
  assert.ok(C.hardIncompat(C.manifestIncompat({ manifest_version: 3, devtools_page: 'd.html' })));
  assert.match(C.manifestIncompat({ manifest_version: 3, permissions: ['storage', 'nativeMessaging'] }), /nativeMessaging/);
  assert.match(C.manifestIncompat({ manifest_version: 1 }), /manifest_version/);
  const ok = { manifest_version: 3, permissions: ['storage', 'activeTab'] };
  assert.strictEqual(C.manifestIncompat(ok), null); assert.strictEqual(C.manifestWarning(ok), null);
  assert.match(C.manifestWarning({ manifest_version: 3, permissions: ['bookmarks', 'sidePanel', 'history'] }), /북마크 · 사이드 패널 · 방문 기록/);
  assert.strictEqual(C.manifestWarning({ manifest_version: 3, theme: {}, permissions: ['history'] }), null);
});
test('현지화 · 아이콘 고르기', () => {
  assert.strictEqual(C.localize('__MSG_appName__ 확장', { appname: { message: '번역기' } }), '번역기 확장');
  assert.strictEqual(C.localize('__MSG_none__', {}), '');
  assert.strictEqual(C.bestIcon({ 16: 'a.png', 48: 'b.png', 128: 'c.png' }), 'b.png');
  assert.strictEqual(C.bestIcon({ 16: 'a.png', 32: 'b.png' }), 'b.png');
  assert.strictEqual(C.bestIcon({}), null);
});
test('테마: 색 옮기기 · 읽히는 글자색 · 색 없으면 null', () => {
  const dark = T.themeVars({ theme: { colors: { frame: [20, 24, 30], toolbar: [30, 34, 42], tab_text: [10, 10, 10], omnibox_background: [45, 50, 60], button_background: [255, 120, 0] } } });
  assert.strictEqual(dark.dark, true);
  assert.strictEqual(dark.vars['--bg'], '#14181e'); assert.strictEqual(dark.vars['--surface'], '#1e222a'); assert.strictEqual(dark.vars['--pill'], '#2d323c');
  assert.strictEqual(dark.vars['--text'], '#ffffff'); // 어두운 바탕에 어두운 글자색을 원해도 읽히게 바꾼다
  assert.strictEqual(dark.vars['--accent'], '#ff7800');
  const light = T.themeVars({ theme: { colors: { toolbar: [250, 250, 245], toolbar_text: [40, 40, 40] } } });
  assert.strictEqual(light.dark, false); assert.strictEqual(light.vars['--text'], '#282828');
  assert.strictEqual(T.themeVars({ theme: { images: { theme_frame: 'a.png' } } }), null);
  assert.strictEqual(T.themeVars({ theme: { colors: { frame: [1, 2] } } }), null);
});

// ───────── 설치 관리자 (가짜 electron / 가짜 세션) ─────────
function loadMgr() {
  const Module = require('module'), orig = Module._load;
  Module._load = function (req, ...a) { return req === 'electron' ? { WebContentsView: class {}, ipcMain: { handle() {} }, dialog: {} } : orig.call(this, req, ...a); };
  try { return require('../src/main/extensions').ExtManager; } finally { Module._load = orig; }
}
function mkMgr() {
  const fs = require('fs'), os = require('os'), path = require('path');
  const ExtManager = loadMgr(), dir = fs.mkdtempSync(path.join(os.tmpdir(), 'evext-')), kv = {}, loaded = [], log = { toasts: [], changed: 0 };
  const api = { loadExtension: async (p) => { if (/broken/.test(fs.readFileSync(path.join(p, 'manifest.json'), 'utf8'))) throw new Error('Manifest 오류'); const e = { id: 'real' + loaded.length, path: p }; loaded.push(p); return e; }, removeExtension: async () => {} };
  const m = new ExtManager({ userData: dir, ses: () => ({ extensions: api }), toast: (t) => log.toasts.push(t), openTab() {}, win: () => null, store: { get: (k) => kv[k] == null ? null : kv[k], set: (k, v) => { kv[k] = v; } }, chromeH: () => 80, changed: () => { log.changed++; }, raise() {} });
  return { m, dir, kv, loaded, log, fs, path };
}
const mkCrx3 = (files, manifestObj) => {
  const { publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 1024 }), der = publicKey.export({ type: 'spki', format: 'der' });
  const header = Buffer.concat([field(2, field(1, der)), field(10000, field(1, crypto.createHash('sha256').update(der).digest().subarray(0, 16)))]);
  const h = Buffer.alloc(12); h.write('Cr24', 0, 'latin1'); h.writeUInt32LE(3, 4); h.writeUInt32LE(header.length, 8);
  return { buf: Buffer.concat([h, header, makeZip([['manifest.json', JSON.stringify(manifestObj)], ...files])]), id: Crx.idFromKey(der), der };
};

test('설치: crx3 → 크롬과 같은 id 폴더, key 넣기, 현지화 이름·아이콘, 다시 설치하면 교체(업데이트)', async () => {
  const { m, dir, loaded, fs, path } = mkMgr();
  const png = Buffer.from('89504e470d0a1a0a', 'hex');
  const c = mkCrx3([['icon48.png', png], ['_locales/ko/messages.json', JSON.stringify({ appName: { message: '밝은 번역기' } })], ['popup.html', '<p>hi</p>']],
    { manifest_version: 3, name: '__MSG_appName__', version: '1.2', default_locale: 'ko', icons: { 48: 'icon48.png' }, action: { default_popup: 'popup.html' }, permissions: ['storage', 'bookmarks'] });
  const info = await m.installBuffer(c.buf, { storeId: c.id });
  assert.strictEqual(info.id, c.id); assert.strictEqual(info.name, '밝은 번역기'); assert.strictEqual(info.version, '1.2');
  assert.strictEqual(info.source, '웹스토어'); assert.ok(info.popup); assert.match(info.icon, /^data:image\/png;base64,/); assert.match(info.warning, /북마크/); assert.strictEqual(info.eid, 'real0');
  assert.strictEqual(JSON.parse(fs.readFileSync(path.join(dir, 'extensions', c.id, 'manifest.json'), 'utf8')).key, c.der.toString('base64'));
  assert.strictEqual(loaded.length, 1);
  // 같은 확장을 다시 설치 = 교체
  const c2 = { ...c }; const again = await m.installBuffer(c.buf, { storeId: c.id });
  assert.strictEqual(m.list().length, 1); assert.strictEqual(loaded.length, 2); assert.strictEqual(again.id, c.id);
  // 다시 켤 때(앱 재시작)도 불러온다
  const m2 = new (loadMgr())({ userData: dir, ses: () => ({ extensions: { loadExtension: async (p) => { loaded.push('re:' + p); return { id: 'x' }; }, removeExtension: async () => {} } }), toast() {}, openTab() {}, win: () => null, store: { get: () => null, set() {} }, chromeH: () => 0, changed() {}, raise() {} });
  await m2.init(); assert.ok(loaded.some((x) => String(x).startsWith('re:')));
});
test('설치: 막아야 할 확장 · 깨진 파일 · 불러오기 실패는 이유를 알려 준다', async () => {
  const { m, log } = mkMgr();
  await assert.rejects(() => m.installBuffer(makeZip([['manifest.json', JSON.stringify({ manifest_version: 3, name: 'n', permissions: ['nativeMessaging'] })]])), /nativeMessaging/);
  await assert.rejects(() => m.installBuffer(makeZip([['a.txt', 'x']])), /manifest\.json/);
  await assert.rejects(() => m.installBuffer(makeZip([['manifest.json', '{oops']])), /읽지 못했어요/);
  await assert.rejects(() => m.installBuffer(makeZip([['manifest.json', JSON.stringify({ manifest_version: 3, name: 'broken' })]])), /불러오지 못했어요: Manifest 오류/);
  assert.strictEqual(m.list().length, 1); assert.ok(m.list()[0].error); // 폴더는 남겨 두고 오류를 표시 → 사용자가 지울 수 있다
  const z = await m.installStore('nope'); assert.strictEqual(z.ok, false); assert.match(z.error, /32자/);
});
test('끄기 · 켜기 · 삭제, 테마는 불러오지 않고 색만 쓴다', async () => {
  const { m, kv, loaded, fs, path, dir } = mkMgr();
  const a = await m.installBuffer(makeZip([['manifest.json', JSON.stringify({ manifest_version: 3, name: '도구', version: '1' })]]));
  assert.ok(a.id.startsWith('local-')); assert.strictEqual(loaded.length, 1);
  await m.setEnabled(a.id, false); assert.strictEqual(m.list()[0].enabled, false);
  await m.setEnabled(a.id, true); assert.strictEqual(loaded.length, 2); assert.strictEqual(m.list()[0].enabled, true);
  const t = await m.installBuffer(makeZip([['manifest.json', JSON.stringify({ manifest_version: 3, name: '밤하늘', version: '1', theme: { colors: { frame: [10, 12, 30], toolbar: [20, 24, 50] } } })]]));
  assert.ok(t.theme); assert.strictEqual(loaded.length, 2); assert.strictEqual(m.activeTheme(), null);
  assert.strictEqual(m.setTheme(t.id).ok, true); assert.strictEqual(kv.extTheme, t.id); assert.strictEqual(m.activeTheme().vars['--bg'], '#0a0c1e');
  assert.strictEqual(m.list().find((x) => x.id === t.id).active, true);
  assert.strictEqual(m.setTheme(a.id).ok, false); // 테마가 아닌 것은 거부
  await m.remove(t.id); assert.strictEqual(kv.extTheme, null); assert.ok(!fs.existsSync(path.join(dir, 'extensions', t.id)));
  await m.remove(a.id); assert.strictEqual(m.list().length, 0);
  const imgOnly = await m.installBuffer(makeZip([['manifest.json', JSON.stringify({ manifest_version: 3, name: '그림테마', version: '1', theme: { images: { theme_frame: 'f.png' } } })]]));
  assert.strictEqual(m.setTheme(imgOnly.id).ok, false);
});

test('아이콘 파일: icon() 함수와 확장 프로그램 아이콘이 들어 있다 (생성 도구가 함수를 지우면 앱 화면이 통째로 깨진다)', () => {
  global.window = {}; delete require.cache[require.resolve('../src/renderer/icons.js')];
  require('../src/renderer/icons.js');
  assert.strictEqual(typeof window.icon, 'function'); assert.ok(window.EV_ICONS.extension); assert.match(window.icon('extension', 24), /<svg/);
  delete global.window;
});
