'use strict';
const test = require('node:test');
const assert = require('node:assert');
const T = require('../src/shared/translate');
const { PageTranslator } = require('../src/main/pagetranslate');
const PT = require('../src/main/pagetools');

test('번역: 이미 목표 언어이거나 글자가 없는 글은 건너뛴다', () => {
  assert.ok(T.skip('안녕하세요 반갑습니다', 'ko'));
  assert.ok(!T.skip('Hello world', 'ko'));
  assert.ok(T.skip('12,345 ©', 'ko')); assert.ok(T.skip('a', 'ko'));
  assert.ok(!T.skip('안녕하세요', 'en'));
});
test('번역: 묶음은 글자 수·개수 한도를 지키고 순서를 유지한다', () => {
  const items = Array.from({ length: 100 }, (_, i) => ({ i, t: 'x'.repeat(100) }));
  const bs = T.batches(items, 2800, 40);
  assert.ok(bs.every((b) => b.length <= 40 && b.reduce((n, x) => n + x.t.length, 0) <= 2800));
  assert.deepStrictEqual(bs.flat().map((x) => x.i), items.map((x) => x.i));
  assert.strictEqual(T.batches([{ i: 0, t: 'y'.repeat(5000) }]).length, 1); // 너무 긴 글 하나도 보낸다
});
test('번역: 답 읽기 — 코드펜스·앞뒤 글 허용, 개수가 다르면 null', () => {
  assert.deepStrictEqual(T.parse('```json\n["가","나"]\n```', 2), ['가', '나']);
  assert.deepStrictEqual(T.parse('결과: ["a", 1, null]', 3), ['a', '1', '']);
  assert.strictEqual(T.parse('["a"]', 2), null); assert.strictEqual(T.parse('nope', 1), null); assert.strictEqual(T.parse('[broken', 1), null);
});
test('번역: 언어 순환 · 요청 글에 목표 언어', () => {
  assert.strictEqual(T.nextLang('ko'), 'en'); assert.strictEqual(T.nextLang('zh'), 'ko'); assert.strictEqual(T.nextLang('??'), 'en');
  assert.match(T.system('ja'), /Japanese/);
});

// ── PageTranslator (가짜 페이지 · 가짜 Gemini) ──
function rig(nodes, reply) {
  const applied = []; const toasts = []; let restored = 0, changes = 0; const calls = [];
  const wc = { id: 7 };
  const d = {
    PT, call: (fn, ...a) => ({ fn: fn.name, a }),
    run: async (_wc, code) => {
      if (code.fn === 'trCollectFn') return nodes;
      if (code.fn === 'trApplyFn') { applied.push(...code.a[0]); return code.a[0].length; }
      if (code.fn === 'trRestoreFn') { restored++; return 1; }
      return null;
    },
    toast: (m, a) => toasts.push([m, a]), changed: () => changes++, pick: () => ({ key: 'K', model: 'm' }),
    makeClient: () => ({ cancel() {}, stream: async (o) => { calls.push(JSON.parse(o.history[0].text)); const out = reply(JSON.parse(o.history[0].text)); if (out instanceof Error) return { ok: false, error: out.message }; o.cb.text(out); return { ok: true }; } }),
  };
  return { tr: new PageTranslator(d), wc, applied, toasts, calls, get restored() { return restored; }, get changes() { return changes; } };
}
const enc = (arr) => JSON.stringify(arr.map((t) => t.toUpperCase()));

test('페이지 번역: 같은 글은 한 번만 보내고 모든 노드에 적용한다', async () => {
  const r = rig([{ i: 0, t: 'Hello' }, { i: 1, t: 'World' }, { i: 2, t: 'Hello' }, { i: 3, t: '안녕하세요 여러분' }], enc);
  assert.strictEqual(await r.tr.translate(r.wc, 'ko'), 'done');
  assert.deepStrictEqual(r.calls, [['Hello', 'World']]);
  assert.deepStrictEqual(r.applied.sort((a, b) => a[0] - b[0]), [[0, 'HELLO'], [1, 'WORLD'], [2, 'HELLO']]);
  assert.strictEqual(r.tr.status(7), 'done');
  assert.ok(r.toasts.some((t) => /번역했어요/.test(t[0]) && t[1] && t[1].name === 'page:translate'));
});
test('페이지 번역: 답 개수가 틀리면 반으로 나눠 다시 보낸다', async () => {
  const r = rig([{ i: 0, t: 'a1' }, { i: 1, t: 'b2' }, { i: 2, t: 'c3' }, { i: 3, t: 'd4' }], (arr) => (arr.length > 2 ? '["only one"]' : enc(arr)));
  assert.strictEqual(await r.tr.translate(r.wc, 'ko'), 'done');
  assert.deepStrictEqual(r.calls.map((c) => c.length), [4, 2, 2]);
  assert.strictEqual(r.applied.length, 4);
});
test('페이지 번역: 한 줄까지 줄여도 안 맞으면 그 줄은 원문 그대로', async () => {
  const r = rig([{ i: 0, t: 'only' }], () => '[]');
  assert.strictEqual(await r.tr.translate(r.wc, 'ko'), 'done');
  assert.deepStrictEqual(r.applied, [[0, 'only']]);
});
test('페이지 번역: 키가 없거나 오류면 안내하고 아무것도 바꾸지 않는다', async () => {
  const a = rig([{ i: 0, t: 'Hi there' }], enc); a.tr.d.pick = () => null;
  assert.strictEqual(await a.tr.translate(a.wc, 'ko'), 'idle'); assert.match(a.toasts[0][0], /API 키/); assert.strictEqual(a.applied.length, 0);
  const b = rig([{ i: 0, t: 'Hi there' }], () => new Error('한도 초과'));
  assert.strictEqual(await b.tr.translate(b.wc, 'ko'), 'idle'); assert.ok(b.toasts.some((t) => /한도 초과/.test(t[0]))); assert.strictEqual(b.tr.status(7), 'idle');
});
test('페이지 번역: 번역할 글이 없으면 알려 준다', async () => {
  const r = rig([{ i: 0, t: '이미 한국어 문장' }], enc);
  assert.strictEqual(await r.tr.translate(r.wc, 'ko'), 'idle'); assert.ok(r.toasts.some((t) => /번역할 글이 없어요/.test(t[0])));
});
test('페이지 번역: 토글 — 번역됨이면 원문 복원, 이동하면 상태 잊기', async () => {
  const r = rig([{ i: 0, t: 'Hello' }], enc);
  await r.tr.toggle(r.wc, 'ko'); assert.strictEqual(r.tr.status(7), 'done');
  assert.strictEqual(await r.tr.toggle(r.wc, 'ko'), 'idle'); assert.strictEqual(r.restored, 1); assert.strictEqual(r.tr.status(7), 'idle');
  await r.tr.toggle(r.wc, 'ko'); r.tr.forget(7); assert.strictEqual(r.tr.status(7), 'idle');
});
