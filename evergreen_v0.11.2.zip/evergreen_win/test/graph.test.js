'use strict';
const test = require('node:test');
const assert = require('node:assert');
const Gr = require('../src/shared/graph');

test('수식: 곱셈 생략 · 거듭제곱 · 함수 · 상수 · 읽지 못하는 식', () => {
  const f = (s) => Gr.parseExpr(s);
  assert.strictEqual(f('2x+1')(3), 7);
  assert.strictEqual(f('x^2-2x-3')(1), -4);
  assert.strictEqual(f('2(x+1)')(2), 6);
  assert.strictEqual(f('x(x-1)')(3), 6);
  assert.ok(Math.abs(f('sinx')(Math.PI / 2) - 1) < 1e-12);
  assert.ok(Math.abs(f('3sin(x)')(Math.PI / 2) - 3) < 1e-12);
  assert.strictEqual(f('-x^2')(3), -9);
  assert.ok(Math.abs(f('2π')(0) - 2 * Math.PI) < 1e-12);
  assert.strictEqual(f('x²')(4), 16);
  assert.strictEqual(f('log(100)')(0), 2);
  assert.strictEqual(f('foo(x)'), null);
  assert.strictEqual(f('(x+1'), null);
  assert.strictEqual(f(''), null);
});

test('읽기: 키 · 범위 · 함수 접두 · 선 · 막대 · 점 · 보조선 · 틀린 줄은 건너뜀', () => {
  const g = Gr.parse('title: 이차함수\nx: -3..5\ny: -10 ~ 10\nfn: f(x) = x^2-2x-3 | f(x)\nline: 매출 | 1:3, 2:5, 3:4\nline: 3, 5, 4\nbar: 판매 | 1월:30, 2월:45\npoint: 1, -4, 꼭짓점\nhline: 0\nvline: 2\nxlabel: 가로\nfn: ???\n이상한 줄\nfoo: bar');
  assert.strictEqual(g.title, '이차함수'); assert.deepStrictEqual([g.xMin, g.xMax, g.yMin, g.yMax], [-3, 5, -10, 10]);
  assert.strictEqual(g.fns.length, 1); assert.strictEqual(g.fns[0].label, 'f(x)'); assert.strictEqual(g.fns[0].expr(1), -4);
  assert.deepStrictEqual(g.lines[0].xs, [1, 2, 3]); assert.deepStrictEqual(g.lines[1].xs, [1, 2, 3]); // y 만 쓰면 x 는 1,2,3…
  assert.deepStrictEqual(g.bars[0].cats, ['1월', '2월']); assert.deepStrictEqual(g.points[0], { x: 1, y: -4, label: '꼭짓점' });
  assert.deepStrictEqual(g.hLines, [0]); assert.deepStrictEqual(g.vLines, [2]); assert.strictEqual(g.xLabel, '가로'); assert.ok(!g.isEmpty);
  assert.ok(Gr.parse('title: 아직').isEmpty);
});

test('범위 · 눈금', () => {
  assert.strictEqual(Gr.niceStep(10, 5), 2); assert.strictEqual(Gr.niceStep(0, 5), 1);
  assert.strictEqual(Gr.fmt(3), '3'); assert.strictEqual(Gr.fmt(0.12345678), '0.1235'); assert.strictEqual(Gr.fmt(1e-15), '0');
  const b = Gr.autoRange(Gr.parse('fn: 1/x'));
  assert.ok(b.yMax < 50 && b.yMin > -50, '점근선에서 튀는 값은 범위에서 버린다');
  const bars = Gr.autoRange(Gr.parse('bar: a | x:5, y:9'));
  assert.strictEqual(bars.yMin, 0);
  const one = Gr.autoRange(Gr.parse('line: 2:3'));
  assert.ok(one.xMax - one.xMin > 1);
});

test('SVG: 제목 · 범례 · 곡선 · 막대 · 점 · 색 변수, 비어 있어도 깨지지 않는다', () => {
  const r = Gr.render(Gr.parse('title: T\nfn: x^2 | a\nfn: x | b\npoint: 1,1,P'), { width: 360 });
  assert.match(r.svg, /^<svg[\s\S]*<\/svg>$/); assert.match(r.svg, /class="ln"/); assert.match(r.svg, /class="pt"/); assert.match(r.svg, /var\(--text\)/);
  const b = Gr.render(Gr.parse('bar: A | x:1, y:2\nbar: B | x:2, y:3'), { width: 300 });
  assert.match(b.svg, /class="bar"/); assert.ok(!/NaN/.test(b.svg) && !/NaN/.test(r.svg));
  const l = Gr.render(Gr.parse('line: s | 1:3, 2:5, 3:4, 4:8'), { width: 340 });
  assert.match(l.svg, /<path d="M[^"]*C/); assert.ok(!/NaN|Infinity/.test(l.svg));
  assert.doesNotThrow(() => Gr.render(Gr.parse('x'), { width: 100 }));
});

test('값 보기: 함수 · 꺾은선(가까운 점) · 막대(칸)', () => {
  const f = Gr.render(Gr.parse('fn: 2x | g\nx: 0..10'), { width: 400 });
  const h = Gr.hover(f.meta, f.meta.px(5));
  assert.strictEqual(h.head, 'x = 5'); assert.strictEqual(h.rows[0].text, 'g  10');
  const l = Gr.render(Gr.parse('line: 매출 | 1:3, 2:5, 3:4'), { width: 400 });
  const h2 = Gr.hover(l.meta, l.meta.px(2.1));
  assert.strictEqual(h2.head, 'x = 2'); assert.strictEqual(h2.rows[0].text, '매출  5');
  const b = Gr.render(Gr.parse('bar: 판매 | 1월:30, 2월:45'), { width: 400 });
  const h3 = Gr.hover(b.meta, b.meta.plot.right - 5);
  assert.strictEqual(h3.head, '2월'); assert.strictEqual(h3.rows[0].text, '판매  45');
  assert.strictEqual(Gr.hover(b.meta, 0), null);
  assert.ok(Gr.isExtremum('극 댓값'));
});
