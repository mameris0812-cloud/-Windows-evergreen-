'use strict';
const test = require('node:test');
const assert = require('node:assert');
const I = require('../src/shared/imgtr');
const PT = require('../src/main/pagetools');
const { ImageTranslator } = require('../src/main/imgtranslate');
const { PageTranslator } = require('../src/main/pagetranslate');

test('이미지 번역: 조각 나누기 — 작은 이미지는 읽지 않고, 보통 이미지는 통째로, 긴 이미지는 겹쳐서 나눈다', () => {
  assert.deepStrictEqual(I.planTiles(60, 500), []);
  assert.deepStrictEqual(I.planTiles(800, 30), []);
  assert.deepStrictEqual(I.planTiles(800, 2500), [{ y0: 0, h: 2500, keepEnd: 2500, last: true }]);
  const t = I.planTiles(800, 6000);
  assert.strictEqual(t[0].y0, 0); assert.strictEqual(t[0].h, 2200); assert.strictEqual(t[0].keepEnd, 2000); assert.strictEqual(t[1].y0, 2000);
  assert.ok(t[t.length - 1].last && t[t.length - 1].y0 + t[t.length - 1].h === 6000);
  assert.ok(t.slice(0, -1).every((x) => !x.last));
  assert.strictEqual(I.planTiles(800, 90000).length, I.LIM.MAX_TILES);   // 아주 긴 이미지의 끝은 건너뜀
});
test('이미지 번역: 답 읽기 — 코드펜스 허용, 잘못된 상자·빈 번역은 버린다, 깨진 답은 null', () => {
  const ok = I.parse('```json\n[{"box":[10,20,110,220],"text":"Hi","tr":"안녕","v":0},{"box":[0,0,1,1],"text":"x","tr":"y"},{"box":[1,2,3],"tr":"z"},{"box":[5,5,50,50],"text":"a","tr":" "},{"box":[900,900,1200,1100],"text":"b","tr":"비","v":1}]\n```');
  assert.strictEqual(ok.length, 2);
  assert.deepStrictEqual(ok[0].box, [10, 20, 110, 220]);
  assert.deepStrictEqual(ok[1].box, [900, 900, 1000, 1000]);   // 0~1000 으로 맞춘다
  assert.strictEqual(ok[1].v, 1);
  assert.strictEqual(I.parse('nope'), null); assert.strictEqual(I.parse('[broken'), null); assert.deepStrictEqual(I.parse('[]'), []);
});
test('이미지 번역: 상자를 원본 좌표로 — 다음 조각이 맡는 글자와 이미 목표 언어인 글은 거른다', () => {
  const tile = { y0: 2000, h: 2200, keepEnd: 4000, last: false };
  const items = [
    { box: [0, 100, 100, 400], text: 'Hello there', tr: '안녕하세요', v: 0 },       // 위쪽: 남김
    { box: [900, 100, 990, 400], text: 'Late line', tr: '늦은 글', v: 0 },          // 중심이 keepEnd(=y 4000) 아래 → 다음 조각 몫
    { box: [300, 100, 400, 400], text: '이미 한국어 문장', tr: '이미 한국어 문장', v: 0 },
    { box: [500, 100, 503, 400], text: 'tiny', tr: '작음', v: 0 },             // 높이 8px 미만
    { box: [600, 100, 700, 400], text: 'Written by Huma Raza', tr: '후마 라자(Huma Raza) 글', v: 0 },
  ];
  const b = I.toBlocks(items, tile, 1000, 'ko');
  assert.strictEqual(b.length, 2);
  assert.deepStrictEqual([b[0].x, b[0].y, b[0].w, b[0].h], [100, 2000, 300, 220]);
  assert.strictEqual(b[1].t, '후마 라자 글');                    // 번역기가 덧붙인 영문 괄호는 지운다
  assert.strictEqual(I.toBlocks(items.slice(1, 2), { y0: 2000, h: 2200, keepEnd: 4200, last: true }, 1000, 'ko').length, 1); // 마지막 조각은 끝까지
});
test('이미지 번역: 요청 글에 목표 언어, 한자·가나가 있으면 cjk', () => {
  assert.match(I.system('ja'), /Japanese/); assert.match(I.system('ko'), /Korean/);
  const b = I.toBlocks([{ box: [0, 0, 100, 100], text: 'ありがとう', tr: '고마워', v: 1 }], { y0: 0, h: 1000, keepEnd: 1000, last: true }, 800, 'ko');
  assert.strictEqual(b[0].cjk, true); assert.strictEqual(b[0].v, 1);
  assert.strictEqual(I.sameKey('https://a/b.png#x'), 'https://a/b.png');
});
test('이미지 번역: 페이지 쪽 함수는 서로 밖의 것을 쓰지 않는다(문자열로 옮겨 실행되므로)', () => {
  ['imgCollectFn', 'imgLoadFn', 'imgTileFn', 'imgBusyFn', 'imgApplyFn', 'imgCoverFn'].forEach((n) => {
    assert.strictEqual(typeof PT[n], 'function', n);
    const code = PT.call(PT[n], 1, 2);
    assert.doesNotThrow(() => new Function('return ' + code.replace(/\.apply\(null,.*$/s, '')), n);   // 문법만 확인
    assert.ok(!/require\(|PT\.|module\./.test(PT[n].toString()), n + ' 에 바깥 참조');
  });
});

// ── 흐름: 가짜 페이지·가짜 Gemini ──
function fakeEnv(opts) {
  opts = opts || {};
  const calls = []; const toasts = [];
  const page = {
    imgCollectFn: () => ({ lang: 'en', items: opts.items || [{ k: 0, u: 'https://x/a.png' }, { k: 1, u: 'https://x/b.png' }] }),
    imgLoadFn: (k, data) => (opts.need && !data ? { need: true } : { w: 800, h: opts.h || 1200 }),
    imgTileFn: () => 'QUJD', imgBusyFn: () => 1, imgApplyFn: (tok, k, w, h, blocks) => { calls.push({ k, w, h, blocks }); return blocks.length; },
    imgCoverFn: () => 0,
  };
  const names = Object.keys(page);
  const PTfake = {}; names.forEach((n) => { PTfake[n] = { __n: n }; });
  const d = {
    PT: PTfake, call: (fn, ...a) => ({ n: fn.__n, a }),
    run: async (wc, code) => { if (typeof code === 'string') return 'TOKEN'; return page[code.n](...code.a); },
    toast: (m) => toasts.push(m), changed() {},
    pickVision: () => (opts.noKey ? null : { key: 'K', model: 'vision' }),
    fetchImage: async () => ({ buf: Buffer.from('x'), mime: 'image/png' }),
    makeClient: () => ({ cancel() {}, stream: async (o) => {
      assert.ok(o.json); assert.strictEqual(o.history[0].images[0].mime, 'image/jpeg');
      o.cb.text(opts.answer || JSON.stringify([{ box: [100, 100, 200, 500], text: 'Hello', tr: '안녕', v: 0 }]));
      return { ok: true };
    } }),
  };
  return { d, calls, toasts };
}
const WC = { id: 7 };

test('이미지 번역 흐름: 모든 이미지를 읽어 덮개를 올린다', async () => {
  const { d, calls } = fakeEnv(); const it = new ImageTranslator(d);
  const r = await it.translateAll(WC, 'ko');
  assert.strictEqual(r.total, 2); assert.strictEqual(r.applied, 2); assert.strictEqual(calls.length, 2);
  assert.deepStrictEqual([calls[0].blocks[0].x, calls[0].blocks[0].y, calls[0].blocks[0].w, calls[0].blocks[0].h], [80, 120, 320, 120]);
  assert.ok(!it.busy(7));
});
test('이미지 번역 흐름: 페이지에서 못 읽으면 앱이 받아서 넘긴다 · 긴 이미지는 조각마다 보낸다', async () => {
  const { d, calls } = fakeEnv({ need: true, h: 6000, items: [{ k: 0, u: 'https://x/long.webp' }] });
  let sent = 0; const mk = d.makeClient; d.makeClient = () => { const c = mk(); const s = c.stream; c.stream = (o) => { sent++; return s(o); }; return c; };
  const r = await new ImageTranslator(d).translateAll(WC, 'ko');
  assert.strictEqual(r.applied, 1); assert.ok(sent >= 3, '조각 ' + sent);
});
test('이미지 번역 흐름: 키가 없으면 안내하고, 한 장만 번역할 때 이미지를 못 찾으면 알려 준다', async () => {
  const a = fakeEnv({ noKey: true }); const r = await new ImageTranslator(a.d).translateOne(WC, 'ko', 'https://x/a.png');
  assert.strictEqual(r.applied, 0); assert.ok(a.toasts.some((m) => /API 키/.test(m)));
  const b = fakeEnv(); await new ImageTranslator(b.d).translateOne(WC, 'ko', 'https://x/zzz.png');
  assert.ok(b.toasts.some((m) => /찾지 못했어요/.test(m)));
  const c = fakeEnv(); const r2 = await new ImageTranslator(c.d).translateOne(WC, 'ko', 'https://x/b.png#frag');
  assert.strictEqual(r2.applied, 1); assert.strictEqual(c.calls[0].k, 1); assert.ok(c.toasts.some((m) => /번역했어요/.test(m)));
});
test('이미지 번역 흐름: 깨진 답은 한 번 다시 묻고, 그래도 안 되면 그 이미지는 건너뛴다', async () => {
  const { d, calls } = fakeEnv({ answer: 'sorry I cannot', items: [{ k: 0, u: 'https://x/a.png' }] });
  let n = 0; const mk = d.makeClient; d.makeClient = () => { n++; return mk(); };
  const r = await new ImageTranslator(d).translateAll(WC, 'ko');
  assert.strictEqual(n, 2); assert.strictEqual(calls.length, 0); assert.strictEqual(r.applied, 0); assert.ok(r.error);
});

test('페이지 번역 + 이미지: 설정을 켜면 글 번역 뒤에 이미지도 번역하고, 원문 보기가 이미지 덮개도 걷는다', async () => {
  const log = [];
  const images = { translateAll: async () => { log.push('img'); return { applied: 2, error: '' }; }, clear: async () => { log.push('clear'); }, cancel() {}, forget() {} };
  const run = async (wc, code) => (code.n === 'trCollectFn' ? [{ i: 0, t: 'Hello world', y: 0 }] : code.n === 'trApplyFn' ? 1 : 0);
  const d = { images, imagesOn: () => true, run, call: (fn, ...a) => ({ n: fn.__n, a }), PT: { trCollectFn: { __n: 'trCollectFn' }, trApplyFn: { __n: 'trApplyFn' }, trRestoreFn: { __n: 'trRestoreFn' } },
    toast() {}, changed() {}, pick: () => ({ key: 'K', model: 'm' }),
    makeClient: () => ({ cancel() {}, stream: async (o) => { o.cb.text('["안녕 세상"]'); return { ok: true }; } }) };
  const p = new PageTranslator(d);
  assert.strictEqual(await p.toggle({ id: 1 }, 'ko'), 'done'); assert.deepStrictEqual(log, ['img']);
  assert.strictEqual(await p.toggle({ id: 1 }, 'ko'), 'idle'); assert.deepStrictEqual(log, ['img', 'clear']);
  d.imagesOn = () => false; log.length = 0;
  assert.strictEqual(await p.toggle({ id: 1 }, 'ko'), 'done'); assert.deepStrictEqual(log, []);
});
