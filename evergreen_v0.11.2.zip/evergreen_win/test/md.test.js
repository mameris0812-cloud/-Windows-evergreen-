'use strict';
const test = require('node:test');
const assert = require('node:assert');
const Md = require('../src/shared/md');
const M = require('../src/shared/mathtex');
const r = (s, o) => Md.render(s, o);

test('서식: 굵게 · 기울임 · 취소선 · 코드 · 링크(안전한 주소만) · 이스케이프', () => {
  assert.strictEqual(r('**굵게** 그리고 *기울임* ~~취소~~ `a<b`'), '<p><strong>굵게</strong> 그리고 <em>기울임</em> <del>취소</del> <code>a&lt;b</code></p>');
  assert.match(r('[구글](https://google.com) [나쁨](javascript:alert(1))'), /<a href="https:\/\/google.com" data-url="https:\/\/google.com">구글<\/a> 나쁨/);
  assert.doesNotMatch(r('<script>alert(1)</script> <img src=x onerror=1>'), /<script|<img/);
  assert.match(r('주소는 https://a.com/x?y=1&z=2 입니다.'), /<a href="https:\/\/a.com\/x\?y=1&amp;z=2"[^>]*>https:\/\/a.com\/x\?y=1&amp;z=2<\/a> 입니다/);
  assert.doesNotMatch(r('코드 `**x**` 안'), /<strong>/);
});

test('제목 · 목록(중첩 · 번호 · 체크) · 인용 · 구분선', () => {
  assert.match(r('# 제목\n## 둘'), /<h2>제목<\/h2><h3>둘<\/h3>/);
  assert.strictEqual(r('- a\n- b\n  - c\n- d'), '<ul><li>a</li><li>b<ul><li>c</li></ul></li><li>d</li></ul>');
  assert.strictEqual(r('1. 하나\n2. 둘'), '<ol><li>하나</li><li>둘</li></ol>');
  assert.match(r('3. x'), /<ol start="3">/);
  assert.match(r('- [x] 끝\n- [ ] 전'), /<input type="checkbox" disabled checked> 끝[\s\S]*<input type="checkbox" disabled> 전/);
  assert.match(r('> 인용\n> 둘째'), /<blockquote><p>인용<br>둘째<\/p><\/blockquote>/);
  assert.match(r('위\n\n---\n\n아래'), /<hr>/);
});

test('표: 머리 · 정렬 · 모자란 칸 · 이스케이프한 |', () => {
  const h = r('| 이름 | 값 |\n|:--|--:|\n| a | 1 |\n| b |');
  assert.match(h, /<th style="text-align:left">이름<\/th><th style="text-align:right">값<\/th>/);
  assert.match(h, /<td style="text-align:right">1<\/td>/); assert.match(h, /<td style="text-align:right"><\/td>/);
  assert.match(r('|a|b|\n|-|-|\n|x\\|y|z|'), /<td>x\|y<\/td>/);
});

test('코드 블록: 복사 단추 · 열려 있는 블록(받는 중) · graph 자리', () => {
  assert.match(r('```js\nlet a = 1 < 2;\n```'), /<div class="code"><div class="code-h"><span>js<\/span><button class="copy" type="button">복사<\/button><\/div><pre><code>let a = 1 &lt; 2;<\/code><\/pre><\/div>/);
  assert.match(r('```py\nprint(1)', { streaming: true }), /<code>print\(1\)<\/code>/);
  assert.match(r('```graph\ntitle: T\nfn: x^2\n```'), /<div class="graph" data-src="title: T\nfn: x\^2"><\/div>/);
  assert.match(r('```graph\nfn: x', { streaming: true }), /data-open="1"/);
});

test('수식: 인라인 · 블록 · 달러 금액은 수식이 아님 · 틀린 식은 원문', () => {
  assert.match(r('값 $x^2$ 입니다'), /<span class="math"><math[^>]*><msup>/);
  assert.match(r('$$\n\\frac{a}{b}\n$$'), /<div class="math-block"><math[^>]*display="block"><mfrac>/);
  assert.match(r('$$a+b$$'), /math-block/);
  assert.doesNotMatch(r('가격은 $5 에서 $10 까지'), /<math/);
  assert.match(r('\\(a_1\\) 와 \\[b\\]'), /<msub>/);
  assert.match(r('$\\notacommand$'), /\$\\notacommand\$/);
  assert.strictEqual(M.plain('$\\alpha^2$'), 'α²');
});

test('받는 중: 커서 · 사진 표시 [[사진1]] 는 지움', () => {
  assert.match(r('안녕', { streaming: true }), /<span class="cursor"><\/span><\/p>$/);
  assert.doesNotMatch(r('[[사진1]] 이 사진은'), /사진1/);
  assert.strictEqual(r(''), '');
});
