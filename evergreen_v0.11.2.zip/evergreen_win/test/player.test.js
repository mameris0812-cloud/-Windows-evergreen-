'use strict';
const test = require('node:test');
const assert = require('node:assert');
const http = require('http');
const crypto = require('crypto');
const Sub = require('../src/shared/subtitle');
const Sleep = require('../src/shared/sleep');
const Hls = require('../src/shared/hls');
const dl = require('../src/main/hlsdl');

// ───────── 자막 ─────────
test('자막: VTT · SRT 시간 읽기, 태그 제거, 겹치는 줄 이어 붙이기', () => {
  const cues = Sub.parse('\uFEFFWEBVTT\r\n\r\n00:00:01.000 --> 00:00:03.500\r\nHello <b>world</b> &amp; you\r\n\r\n1\r\n00:00:03,000 --> 00:00:05,000\r\nTwo\r\nlines\r\n\r\n00:05.0 --> 00:04.0\r\n뒤집힌 시간');
  assert.deepStrictEqual(cues.map((c) => [c.start, c.end, c.text]), [[1, 3.5, 'Hello world & you'], [3, 5, 'Two\nlines']]);
  assert.strictEqual(Sub.textAt(cues, 0.5), '');
  assert.strictEqual(Sub.textAt(cues, 2), 'Hello world & you');
  assert.strictEqual(Sub.textAt(cues, 3.2), 'Hello world & you\nTwo\nlines'); // 겹침
  assert.strictEqual(Sub.textAt(cues, 4), 'Two\nlines');
  assert.strictEqual(Sub.textAt(cues, 9), '');
});
test('자막: ASS 는 Format 줄 순서와 쉼표 든 글을, TTML 은 begin/end/dur 를 읽는다', () => {
  const ass = '[Script Info]\nTitle: x\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n' +
    'Dialogue: 0,0:00:01.50,0:00:03.00,Default,,0,0,0,,{\\i1}안녕, 세상{\\i0}\\N둘째 줄\n' +
    'Dialogue: 0,0:01:00.00,0:01:02.25,Default,,0,0,0,,다음\\h글';
  const a = Sub.parse(ass);
  assert.deepStrictEqual(a.map((c) => [c.start, c.end, c.text]), [[1.5, 3, '안녕, 세상\n둘째 줄'], [60, 62.25, '다음 글']]);
  const ttml = '<?xml version="1.0"?><tt xmlns="http://www.w3.org/ns/ttml"><body><div>' +
    '<p begin="00:00:02.000" end="00:00:04.000">첫째<br/>둘째</p><p begin="5s" dur="2s">초 단위</p><p begin="9000ms" end="10000ms">밀리초</p><p end="3s">begin 없음</p></div></body></tt>';
  const t = Sub.parse(ttml);
  assert.deepStrictEqual(t.map((c) => [c.start, c.end, c.text]), [[2, 4, '첫째\n둘째'], [5, 7, '초 단위'], [9, 10, '밀리초']]);
});

// ───────── 취침 타이머 ─────────
test('취침 타이머: 남은 시간 표시, 취소, 끝나면 한 번만 부른다', () => {
  let now = 1000, fired = 0, cb = null, cleared = 0;
  const timers = { set: (f) => { cb = f; return 7; }, clear: () => { cleared++; cb = null; } };
  const s = Sleep.SleepTimer(() => { fired++; }, () => now, timers);
  assert.strictEqual(s.active, false); assert.strictEqual(s.valueLabel(), '끔');
  s.start(30);
  assert.strictEqual(s.active, true); assert.strictEqual(s.valueLabel(), '30분 남음');
  now += 10 * 60000 + 1; // 19분 59.999초 남음 → 올림해서 20분
  assert.strictEqual(s.valueLabel(), '20분 남음');
  now += 19 * 60000 + 59000; // 0.999초 남음 → 1분
  assert.strictEqual(s.valueLabel(), '1분 남음');
  s.start(60); assert.strictEqual(cleared, 1); assert.strictEqual(s.valueLabel(), '1시간 남음');
  s.cancel(); assert.strictEqual(s.active, false); assert.strictEqual(cb, null);
  s.start(10); const f = cb; f();
  assert.strictEqual(fired, 1); assert.strictEqual(s.active, false);
  assert.deepStrictEqual([Sleep.label(10), Sleep.label(60), Sleep.label(90), Sleep.label(120)], ['10분', '1시간', '1시간 30분', '2시간']);
});

// ───────── HLS 목록 ─────────
test('HLS: 주소로 종류 짐작', () => {
  assert.ok(Hls.looksLikeHls('https://a.com/x/index.m3u8?token=1'));
  assert.ok(Hls.looksLikeHls('https://a.com/play', 'application/vnd.apple.mpegurl'));
  assert.ok(!Hls.looksLikeHls('https://a.com/video.mp4'));
});
test('HLS: 마스터 목록은 화면 크기가 있는 것 중 가장 높은 대역폭 + 소리 줄기', () => {
  const m = '#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud",NAME="ko",DEFAULT=YES,URI="audio/ko.m3u8"\n' +
    '#EXT-X-STREAM-INF:BANDWIDTH=9000000,CODECS="mp4a.40.2"\naudioonly.m3u8\n' +
    '#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=640x360,AUDIO="aud"\nv360.m3u8\n' +
    '#EXT-X-STREAM-INF:BANDWIDTH=2400000,RESOLUTION=1280x720,AUDIO="aud"\nhttps://cdn.example.com/v720.m3u8\n';
  const v = Hls.pickVariant(m, 'https://a.com/p/master.m3u8');
  assert.strictEqual(v.url, 'https://cdn.example.com/v720.m3u8');
  assert.strictEqual(v.audioGroup, 'aud');
  assert.strictEqual(Hls.findAudio(m, 'https://a.com/p/master.m3u8', 'aud'), 'https://a.com/p/audio/ko.m3u8');
});
test('HLS: 조각 목록 — 키 · IV · 번호 · byterange · fMP4 초기화 조각', () => {
  const t = '#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:7\n#EXT-X-KEY:METHOD=AES-128,URI="k.bin",IV=0x000102030405060708090a0b0c0d0e0f\n#EXTINF:4,\na.ts\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:4,\nb.ts\n#EXT-X-ENDLIST\n';
  const s = Hls.parseMedia(t, 'https://a.com/v/list.m3u8');
  assert.strictEqual(s.segs.length, 2); assert.strictEqual(s.rawExt, 'ts'); assert.strictEqual(s.fmp4, false);
  assert.strictEqual(s.segs[0].key.uri, 'https://a.com/v/k.bin'); assert.deepStrictEqual(s.segs[0].key.iv.slice(0, 3), [0, 1, 2]);
  assert.strictEqual(s.segs[1].key, null); assert.deepStrictEqual(s.segs.map((x) => x.seq), [7, 8]);
  const f = Hls.parseMedia('#EXTM3U\n#EXT-X-MAP:URI="init.mp4",BYTERANGE="720@0"\n#EXT-X-BYTERANGE:1000@720\nm.mp4\n#EXT-X-BYTERANGE:500\nm.mp4\n', 'https://a.com/f.m3u8');
  assert.ok(f.fmp4); assert.strictEqual(f.rawExt, 'mp4');
  assert.deepStrictEqual([f.init.rangeStart, f.init.rangeLen], [0, 720]);
  assert.deepStrictEqual(f.segs.map((x) => [x.rangeStart, x.rangeLen]), [[720, 1000], [1720, 500]]); // 시작 없는 범위는 직전 끝에서 이어진다
  assert.throws(() => Hls.parseMedia('#EXTM3U\n#EXT-X-KEY:METHOD=SAMPLE-AES,URI="k"\na.ts\n', 'https://a.com/l.m3u8'), /SAMPLE-AES/);
  assert.throws(() => Hls.parseMedia('#EXTM3U\n#EXT-X-ENDLIST\n', 'https://a.com/l.m3u8'), /조각/);
  assert.throws(() => Hls.parseMedia('#EXTM3U\nhttp://evil.com/a.ts\n', 'https://a.com/l.m3u8'), /http/); // https 목록이 http 조각을 가리키면 차단
  assert.deepStrictEqual(Hls.seqIv(258).slice(12), [0, 0, 1, 2]);
});

// ───────── HLS 받기 (진짜 서버) ─────────
function aesEnc(buf, key, iv) { const c = crypto.createCipheriv('aes-128-cbc', key, iv); return Buffer.concat([c.update(buf), c.final()]); }
function serve(handler) {
  return new Promise((res) => { const s = http.createServer(handler).listen(0, '127.0.0.1', () => res({ s, base: 'http://127.0.0.1:' + s.address().port })); });
}
const ctxOf = (extra) => Object.assign({ headers: () => ({}), cancelled: () => false, onBytes() {}, onSegment() {}, retryMs: 5 }, extra);

test('HLS 받기: 마스터 → 영상 · 소리, AES-128 풀기(IV 없으면 번호), 순서대로 이어 붙이기, 머리글 전달', async () => {
  const key = crypto.randomBytes(16), plain = [], seen = [];
  for (let i = 0; i < 9; i++) plain.push(crypto.randomBytes(300 + i * 11));
  const iv = (seq) => { const b = Buffer.alloc(16); b.writeUInt32BE(seq, 12); return b; };
  const audioPlain = [Buffer.from('AUDIO-1'), Buffer.from('AUDIO-2')];
  const { s, base } = await serve((req, res) => {
    seen.push([req.url, req.headers.referer, req.headers.cookie]);
    const u = req.url.split('?')[0];
    if (u === '/m.m3u8') return res.end('#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="a",DEFAULT=YES,URI="a.m3u8"\n#EXT-X-STREAM-INF:BANDWIDTH=1000,RESOLUTION=2x2,AUDIO="a"\nv.m3u8\n');
    if (u === '/v.m3u8') return res.end('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-KEY:METHOD=AES-128,URI="key"\n' + plain.map((_, i) => '#EXTINF:1,\ns' + i + '.ts\n').join('') + '#EXT-X-ENDLIST\n');
    if (u === '/a.m3u8') return res.end('#EXTM3U\n#EXTINF:1,\nA0.aac\n#EXTINF:1,\nA1.aac\n');
    if (u === '/key') return res.end(key);
    let m = /^\/s(\d)\.ts$/.exec(u);
    if (m) { const i = Number(m[1]); const d = aesEnc(plain[i], key, iv(i)); return setTimeout(() => res.end(d), (9 - i) * 8); } // 뒤쪽 조각이 먼저 도착해도 순서는 지킨다
    m = /^\/A(\d)\.aac$/.exec(u);
    if (m) return res.end(audioPlain[Number(m[1])]);
    res.statusCode = 404; res.end();
  });
  try {
    let bytes = 0, segs = 0;
    const ctx = ctxOf({ headers: () => ({ Referer: 'https://page.example/', Cookie: 'sid=1' }), onBytes: (n) => { bytes += n; }, onSegment: () => { segs++; } });
    const p = await dl.plan(ctx, base + '/m.m3u8');
    assert.strictEqual(p.video.segs.length, 9); assert.strictEqual(p.audio.rawExt, 'aac');
    const out = [];
    await dl.download(ctx, p.video, (b) => { out.push(b); });
    assert.ok(Buffer.concat(out).equals(Buffer.concat(plain)));
    assert.strictEqual(segs, 9); assert.ok(bytes > 0);
    const aout = []; await dl.download(ctx, p.audio, (b) => { aout.push(b); });
    assert.strictEqual(Buffer.concat(aout).toString(), 'AUDIO-1AUDIO-2');
    assert.ok(seen.every((x) => x[1] === 'https://page.example/' && x[2] === 'sid=1'));
  } finally { s.close(); }
});
test('HLS 받기: 404 는 다시 시도하지 않고, 5xx 는 다시 시도하고, 취소하면 멈춘다', async () => {
  let hits404 = 0, hits500 = 0;
  const { s, base } = await serve((req, res) => {
    if (req.url === '/gone') { hits404++; res.statusCode = 404; return res.end(); }
    if (req.url === '/flaky') { hits500++; if (hits500 < 3) { res.statusCode = 503; return res.end(); } return res.end('ok'); }
    res.end('x');
  });
  try {
    await assert.rejects(() => dl.fetchBytes(ctxOf(), base + '/gone'), /404/);
    assert.strictEqual(hits404, 1);
    assert.strictEqual((await dl.fetchBytes(ctxOf(), base + '/flaky')).toString(), 'ok');
    assert.strictEqual(hits500, 3);
    await assert.rejects(() => dl.fetchBytes(ctxOf({ cancelled: () => true }), base + '/x'), /cancelled/);
  } finally { s.close(); }
});

// ───────── 페이지 스크립트 · 화면 파일 ─────────
test('플레이어 스크립트·화면 파일 문법과 연결', () => {
  const fs = require('fs'), path = require('path');
  const root = path.join(__dirname, '..', 'src');
  for (const f of ['guard/mirror.js', 'player/player.js', 'player/preload.js', 'main/player.js', 'overlay/overlay-player.js', 'overlay/overlay-ext.js', 'main/extensions.js', 'shared/theme.js']) new Function('require', 'module', fs.readFileSync(path.join(root, f), 'utf8'));
  const html = fs.readFileSync(path.join(root, 'player/player.html'), 'utf8');
  for (const m of html.matchAll(/<script src="([^"]+)"/g)) if (!/vendor\/hls/.test(m[1])) assert.ok(fs.existsSync(path.join(root, 'player', m[1])), m[1]);
  const cl = require('../src/shared/changelog').ENTRIES;
  assert.strictEqual(cl[0].version, require('../package.json').version); // 버전을 올리면 업데이트 로그도 함께
});

// ───────── 받기 작업 → 파일 (ffmpeg 가 있으면 mp4 로 합치기까지) ─────────
test('HLS 저장 작업: 진짜 ffmpeg 로 만든 스트림을 받아 mp4 로 합친다', async (t) => {
  const { spawnSync } = require('child_process'), fs = require('fs'), os = require('os'), path = require('path');
  if (spawnSync('ffmpeg', ['-version']).status !== 0) return t.skip('ffmpeg 없음');
  const Module = require('module');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'evhls-'));
  const r = spawnSync('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'testsrc=size=160x90:rate=10', '-f', 'lavfi', '-i', 'sine=frequency=440', '-t', '6', '-c:v', 'libx264', '-g', '10', '-c:a', 'aac', '-f', 'hls', '-hls_time', '2', '-hls_playlist_type', 'vod', '-hls_segment_filename', path.join(dir, 's%d.ts'), path.join(dir, 'v.m3u8')]);
  assert.strictEqual(r.status, 0);
  const { s, base } = await serve((req, res) => { const f = path.join(dir, req.url.slice(1).split('?')[0]); if (fs.existsSync(f)) res.end(fs.readFileSync(f)); else { res.statusCode = 404; res.end(); } });
  try {
    // electron 없이 불러오려고 가짜 electron 을 끼운다
    const orig = Module._load; Module._load = function (req, ...a) { return req === 'electron' ? { WebContentsView: class {}, ipcMain: {}, session: {}, dialog: {}, app: {} } : orig.call(this, req, ...a); };
    const P = require('../src/main/player'); Module._load = orig;
    const out = fs.mkdtempSync(path.join(os.tmpdir(), 'evout-'));
    let segs = 0;
    const ctl = { signal: undefined, cancelled: () => false, bytes() {}, segment() { segs++; }, setSegments() {}, phase() {} };
    const res = await P.runHlsJob(ctl, out, { url: base + '/v.m3u8', title: '테스트: 영상?', headers: () => ({}) });
    assert.ok(segs >= 3);
    if (P.ffmpegPath()) assert.ok(res.path.endsWith('.mp4')); else assert.ok(res.path.endsWith('.ts'));
    assert.ok(fs.statSync(res.path).size > 1000);
    assert.ok(!/[:?]/.test(res.name)); // 파일 이름에 못 쓰는 글자는 정리
  } finally { s.close(); }
});
