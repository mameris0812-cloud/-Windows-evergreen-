'use strict';
const test = require('node:test');
const assert = require('node:assert');
const U = require('../src/main/urlutil');

test('주소는 https 를 붙이고, 로컬/IP 는 http', () => {
  assert.strictEqual(U.resolveInput('example.com'), 'https://example.com');
  assert.strictEqual(U.resolveInput('naver.com/path?q=1'), 'https://naver.com/path?q=1');
  assert.strictEqual(U.resolveInput('localhost:3000'), 'http://localhost:3000');
  assert.strictEqual(U.resolveInput('192.168.0.1:8080/x'), 'http://192.168.0.1:8080/x');
  assert.strictEqual(U.resolveInput('https://a.b/c'), 'https://a.b/c');
});
test('그 밖의 글은 검색 엔진으로', () => {
  assert.strictEqual(U.resolveInput('날씨', 'google'), 'https://www.google.com/search?q=' + encodeURIComponent('날씨'));
  assert.strictEqual(U.resolveInput('hello world', 'naver'), 'https://search.naver.com/search.naver?query=hello%20world');
  assert.strictEqual(U.resolveInput('a.b c', 'ddg'), 'https://duckduckgo.com/?q=' + encodeURIComponent('a.b c'));
});
test('빠른 검색 단축어', () => {
  assert.strictEqual(U.resolveInput('yt 노래'), 'https://www.youtube.com/results?search_query=' + encodeURIComponent('노래'));
  assert.strictEqual(U.resolveInput('n 날씨'), 'https://search.naver.com/search.naver?query=' + encodeURIComponent('날씨'));
  assert.strictEqual(U.resolveInput('map 서울역'), 'https://www.google.com/maps/search/' + encodeURIComponent('서울역'));
});
test('빈 입력은 새 탭', () => { assert.strictEqual(U.resolveInput('  '), U.NEWTAB); });
test('주소 줄여 보이기', () => {
  assert.strictEqual(U.displayUrl('https://www.example.com/'), 'example.com');
  assert.strictEqual(U.displayUrl('https://a.com/b?c=1'), 'a.com/b?c=1');
  assert.strictEqual(U.displayUrl(''), '');
});
test('오류 안내와 다음 번호 주소', () => {
  assert.strictEqual(U.describeError(-106).title, '인터넷에 연결되어 있지 않아요');
  assert.strictEqual(U.describeError(-105).title, '웹사이트를 찾을 수 없어요');
  assert.deepStrictEqual(U.nextNumbered('https://a.com/ch/009'), { url: 'https://a.com/ch/010', label: '다음 (010)' });
  assert.strictEqual(U.nextNumbered('https://a.com/'), null);
});
