'use strict';
// 안드로이드 AgentRoutingTest 를 그대로 옮긴 것
const test = require('node:test');
const assert = require('node:assert');
const R = require('../src/shared/routing');
const yes = (list) => list.forEach((q) => assert.ok(R.useAgent(q), q));
const no = (list) => list.forEach((q) => assert.ok(!R.useAgent(q), q));
test('앱 조작 말은 에이전트로', () => yes(['탭 다 닫아 줘', '구글 열어봐', '새 창으로 옮겨 줘', '시크릿 탭 열어 줘', '다크 모드 켜줘', '글자 크기 키워 줘', '광고 차단 꺼 줘', '북마크 폴더 정리해 줘', '웹스토어에서 확장 설치해 줘', '페이지 확대해 줘', '맨 아래로 스크롤해 줘', '시작 페이지 바꿔 줘']));
test('사진 낱말이 있어도 앱 조작이 분명하면 에이전트로', () => yes(['이 이미지 다운로드해 줘', '사진 있는 탭 닫아 줘', '이 그림 북마크해 줘']));
test('사진을 읽어야 하는 말과 잡담은 일반 채팅으로', () => no(['이 사진 뭐야?', '이 그래프 설명해 줘', '안녕', '고마워']));
test('웹 페이지 조작 말', () => yes(['로그인 버튼 눌러 줘', '장바구니에 담아 줘', '좋아요 눌러줘', '검색창에 날씨 입력해 줘', '더보기 펼쳐 줘', '팝업 닫아 줘', '영상 재생해 줘']));
test('이어 말하기', () => {
  assert.ok(R.isFollowUp('응 그걸로 해', true)); assert.ok(R.isFollowUp('두 번째 걸로', true));
  assert.ok(!R.isFollowUp('응 그걸로 해', false)); assert.ok(!R.isFollowUp('고마워', true)); assert.ok(!R.isFollowUp('이 사진 뭐야?', true)); assert.ok(!R.isFollowUp('a'.repeat(41), true));
});
test('미디어 · 확장 · 테마 말', () => { yes(['일시정지해 줘', '다음 곡으로 넘겨 줘', '10초 뒤로 감아 줘', '볼륨 줄여 줘', '광고 차단 확장 팝업 열어 줘', '파란 테마로 꾸며 줘', '미러링 켜 줘']); });
test('일반 질문은 도구 없이', () => no(['오늘 뭐 먹을까', '이 글 정리해 줘', '목표를 세우는 법 알려 줘', '노래 가사 뜻이 뭐야?', '음악 추천해 주세요']));
test('자율 모드 낱말', () => { assert.ok(R.wantsAuto('알아서 끝까지 해 줘')); assert.ok(!R.wantsAuto('탭 닫아')); });
