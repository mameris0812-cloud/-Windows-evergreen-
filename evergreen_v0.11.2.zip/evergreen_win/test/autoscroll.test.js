'use strict';
// 자동 스크롤의 순수 규칙 (안드로이드 AutoScroller 와 같은 값 · 같은 식)
const test = require('node:test');
const assert = require('node:assert');
const A = require('../src/shared/autoscroll');

test('설정 정리: 빠진 값은 기본값, 범위 밖은 끌어들임', () => {
  assert.deepStrictEqual(A.normalize(null), { speed: 6, smart: false, contentLevel: 15, blankLevel: 40, touch: 0, controls: true, pauseAtEnd: true });
  const n = A.normalize({ speed: 999, contentLevel: -3, blankLevel: '7', touch: 5, controls: false, pauseAtEnd: 0, smart: 'yes' });
  assert.strictEqual(n.speed, 50); assert.strictEqual(n.contentLevel, 1); assert.strictEqual(n.blankLevel, 7);
  assert.strictEqual(n.touch, 0); assert.strictEqual(n.controls, false); assert.strictEqual(n.pauseAtEnd, true); assert.strictEqual(n.smart, false);
  assert.strictEqual(A.normalize({ touch: 1, smart: true }).touch, 1);
  assert.strictEqual(A.normalize({ speed: 'abc' }).speed, 6);
});

test('속도: 1단계 = 초당 25, 50단계 = 1250, 화면 한 장 걸리는 시간', () => {
  assert.strictEqual(A.dipPerSecond(1), 25); assert.strictEqual(A.dipPerSecond(50), 1250); assert.strictEqual(A.dipPerSecond(999), 1250); assert.strictEqual(A.dipPerSecond(0), 25);
  assert.strictEqual(A.screenSeconds(10, 750), 3);
  assert.strictEqual(A.secondsLabel(3), '3.0초'); assert.strictEqual(A.secondsLabel(0.64), '0.6초'); assert.strictEqual(A.secondsLabel(30.4), '30초');
});

test('스마트: 빈 줄 비율 → 목표 단계 (35% 이하 내용, 85% 이상 빈 그림, 사이는 부드럽게)', () => {
  assert.strictEqual(A.smartTarget(0, 15, 40), 15); assert.strictEqual(A.smartTarget(0.35, 15, 40), 15);
  assert.strictEqual(A.smartTarget(0.85, 15, 40), 40); assert.strictEqual(A.smartTarget(1, 15, 40), 40);
  assert.ok(Math.abs(A.smartTarget(0.6, 15, 40) - 27.5) < 1e-9); // 가운데
  assert.strictEqual(A.smartTarget(1, 30, 10), 30); // 빈 그림 단계가 더 낮게 들어와도 내용 단계 밑으로 가지 않는다
});

test('스마트: 내용이 나타날 땐 빨리 줄고, 빈 그림에선 느긋하게 올라간다', () => {
  const down = 40 - A.smartFollow(40, 15, 0.1, 15, 40); // 줄어든 양
  const up = A.smartFollow(15, 40, 0.1, 15, 40) - 15;   // 늘어난 양
  assert.ok(down > up * 2, down + ' vs ' + up);
  let v = 15; for (let i = 0; i < 100; i++) v = A.smartFollow(v, 40, 0.05, 15, 40);
  assert.ok(v > 39.9 && v <= 40);
});

function img(w, h, fn, bgra) { const px = new Uint8Array(w * h * 4); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const c = fn(x, y), o = (y * w + x) * 4; px[o] = c[bgra ? 2 : 0]; px[o + 1] = c[1]; px[o + 2] = c[bgra ? 0 : 2]; px[o + 3] = 255; } return px; }
test('빈 줄 비율: 한 색 · 여백+한 색+여백은 빈 줄, 글·그림은 아님', () => {
  const W = 160, H = 80;
  assert.strictEqual(A.blankFraction(img(W, H, () => [255, 255, 255]), W, H, false), 1);
  assert.strictEqual(A.blankFraction(img(W, H, () => [0, 0, 0]), W, H, true), 1);
  assert.strictEqual(A.blankFraction(img(W, H, (x) => (x > 30 && x < 130 ? [20, 20, 20] : [255, 255, 255])), W, H, false), 1); // 검은 그림 + 흰 여백
  assert.strictEqual(A.blankFraction(img(W, H, (x, y) => ((x * 7 + y * 13) % 50 > 25 ? [250, 250, 250] : [10, 10, 10])), W, H, false), 0); // 글자 같은 잔무늬
  const half = img(W, H, (x, y) => (y < 40 ? [255, 255, 255] : (x % 6 < 3 ? [0, 0, 0] : [255, 255, 255])), false);
  assert.strictEqual(A.blankFraction(half, W, H, false), 0.5);
  assert.strictEqual(A.blankFraction(new Uint8Array(0), 0, 0, true), 0);
});

test('BGRA 와 RGBA 는 순서만 다르고 같은 결과', () => {
  const f = (x, y) => [(x * 3) % 256, (y * 5) % 256, (x + y) % 256];
  assert.strictEqual(A.blankFraction(img(64, 32, f, true), 64, 32, true), A.blankFraction(img(64, 32, f, false), 64, 32, false));
});

test('페이지 안 스크립트는 문법이 맞다', () => {
  assert.doesNotThrow(() => new Function(A.DRIVER_JS));
  assert.doesNotThrow(() => new Function('return ' + A.END_PROBE_JS));
  assert.doesNotThrow(() => new Function(A.STOP_JS));
});
