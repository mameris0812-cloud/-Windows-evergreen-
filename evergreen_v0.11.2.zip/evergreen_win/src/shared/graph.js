'use strict';
// AI 답변 속 ```graph 코드 블록을 읽어 SVG 로 그린다. 안드로이드 GraphSpec.kt(읽기) · GraphView.kt(그리기)와 같은 규칙.
//   title: 제목   xlabel: 가로축 이름   ylabel: 세로축 이름   x: -5..5   y: -10..10 (생략하면 자동)
//   fn: x^2 - 2x + 1 | f(x)   line: 이름 | 1:3, 2:5   bar: 이름 | 1월:30, 2월:45   point: 2, 3, 꼭짓점   hline: 0   vline: 2
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvGraph = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  // ───────── 수식 (한 변수 x) ─────────
  var FUNCS = { asin: Math.asin, acos: Math.acos, atan: Math.atan, sqrt: Math.sqrt, sin: Math.sin, cos: Math.cos, tan: Math.tan, abs: Math.abs, ln: Math.log, log: Math.log10, exp: Math.exp };
  // 긴 이름부터 맞춰 본다 ("sinx" → sin + x, "exp" 가 e 보다 먼저)
  var NAMES = ['asin', 'acos', 'atan', 'sqrt', 'sin', 'cos', 'tan', 'abs', 'exp', 'log', 'ln', 'pi', 'x', 'e'];
  function Parser(s) { this.s = s; this.i = 0; }
  Parser.prototype.peek = function () { return this.i < this.s.length ? this.s[this.i] : ''; };
  Parser.prototype.parseAll = function () { var e = this.expr(); if (this.i < this.s.length) throw new Error('남은 글자'); return e; };
  Parser.prototype.expr = function () {
    var l = this.term();
    for (;;) {
      var c = this.peek();
      if (c === '+') { this.i++; l = (function (a, r) { return function (x) { return a(x) + r(x); }; })(l, this.term()); }
      else if (c === '-') { this.i++; l = (function (a, r) { return function (x) { return a(x) - r(x); }; })(l, this.term()); }
      else return l;
    }
  };
  function startsFactor(c) { return c !== '' && (/[A-Za-z]/.test(c) || /[0-9]/.test(c) || c === '(' || c === '.'); }
  Parser.prototype.term = function () {
    var l = this.unary();
    for (;;) {
      var c = this.peek();
      if (c === '*') { this.i++; l = (function (a, r) { return function (x) { return a(x) * r(x); }; })(l, this.unary()); }
      else if (c === '/') { this.i++; l = (function (a, r) { return function (x) { return a(x) / r(x); }; })(l, this.unary()); }
      else if (startsFactor(c)) { l = (function (a, r) { return function (x) { return a(x) * r(x); }; })(l, this.power()); } // 곱셈 기호 생략: 2x, 2(x+1), x(x-1), 3sinx
      else return l;
    }
  };
  Parser.prototype.unary = function () {
    var c = this.peek();
    if (c === '-') { this.i++; var u = this.unary(); return function (x) { return -u(x); }; }
    if (c === '+') { this.i++; return this.unary(); }
    return this.power();
  };
  Parser.prototype.power = function () {
    var base = this.atom();
    if (this.peek() === '^') { this.i++; var ex = this.unary(); return function (x) { return Math.pow(base(x), ex(x)); }; }
    return base;
  };
  Parser.prototype.atom = function () {
    var c = this.peek(), s = this.s;
    if (c === '(') {
      this.i++; var e = this.expr();
      if (this.peek() !== ')') throw new Error('괄호');
      this.i++; return e;
    }
    if (/[0-9.]/.test(c) && c !== '') {
      var st = this.i;
      while (this.i < s.length && /[0-9.]/.test(s[this.i])) this.i++;
      var v = parseFloat(s.slice(st, this.i));
      if (isNaN(v)) throw new Error('숫자');
      return function () { return v; };
    }
    if (/[A-Za-z]/.test(c) && c !== '') {
      var j = this.i;
      while (j < s.length && /[A-Za-z]/.test(s[j])) j++;
      var run = s.slice(this.i, j), name = null;
      for (var k = 0; k < NAMES.length; k++) if (run.indexOf(NAMES[k]) === 0) { name = NAMES[k]; break; }
      if (!name) throw new Error('모르는 이름');
      this.i += name.length;
      if (name === 'x') return function (x) { return x; };
      if (name === 'e') return function () { return Math.E; };
      if (name === 'pi') return function () { return Math.PI; };
      var f = FUNCS[name], arg = this.peek() === '(' ? this.atom() : this.power();
      return function (x) { return f(arg(x)); };
    }
    throw new Error('읽을 수 없는 글자');
  };
  // 읽지 못하는 식은 null
  function parseExpr(src) {
    try {
      var s = String(src).trim().replace(/−/g, '-').replace(/–/g, '-').replace(/×/g, '*').replace(/·/g, '*').replace(/⋅/g, '*').replace(/\\cdot/g, '*')
        .replace(/÷/g, '/').replace(/\*\*/g, '^').replace(/²/g, '^2').replace(/³/g, '^3').replace(/π/g, 'pi').replace(/√/g, 'sqrt').replace(/\s+/g, '').toLowerCase();
      if (!s || s.length > 200) return null;
      return new Parser(s).parseAll();
    } catch (e) { return null; }
  }
  function num(s) { var f = parseExpr(String(s).trim()); if (!f) return null; var v = f(0); return isNaN(v) || !isFinite(v) ? null : v; }
  // 「-5..5」 「-5, 5」 「-5 ~ 5」 → [-5, 5]
  function range(v) {
    var parts = v.split(/\.\.|~|,|에서| to /).map(function (x) { return x.trim(); }).filter(Boolean);
    if (parts.length !== 2) return null;
    var a = num(parts[0]), b = num(parts[1]);
    if (a == null || b == null) return null;
    return a < b ? [a, b] : b < a ? [b, a] : null;
  }
  var FN_PREFIX = /^[A-Za-z]\w*\s*(\(\s*x\s*\))?\s*=\s*/;
  function parse(src) {
    var g = { title: '', xLabel: '', yLabel: '', xMin: null, xMax: null, yMin: null, yMax: null, fns: [], lines: [], bars: [], points: [], hLines: [], vLines: [] };
    String(src).split('\n').forEach(function (raw) {
      var line = raw.trim(), c = line.indexOf(':');
      if (!line || c <= 0) return;
      var key = line.slice(0, c).trim().toLowerCase(), value = line.slice(c + 1).trim();
      if (!value) return;
      try {
        var bar = value.indexOf('|'), label, data;
        if (key === 'title' || key === '제목') g.title = value;
        else if (key === 'xlabel' || key === 'x축') g.xLabel = value;
        else if (key === 'ylabel' || key === 'y축') g.yLabel = value;
        else if (key === 'x' || key === 'xrange') { var rx = range(value); if (rx) { g.xMin = rx[0]; g.xMax = rx[1]; } }
        else if (key === 'y' || key === 'yrange') { var ry = range(value); if (ry) { g.yMin = ry[0]; g.yMax = ry[1]; } }
        else if (key === 'fn' || key === 'f' || key === 'function' || key === '함수') {
          var body = (bar >= 0 ? value.slice(0, bar) : value).trim().replace(FN_PREFIX, '');
          label = bar >= 0 ? value.slice(bar + 1).trim() : '';
          var e = parseExpr(body);
          if (e) g.fns.push({ label: label || body, expr: e });
        } else if (key === 'line' || key === '선') {
          label = bar >= 0 ? value.slice(0, bar).trim() : '';
          data = (bar >= 0 ? value.slice(bar + 1) : value).split(',').map(function (x) { return x.trim(); }).filter(Boolean);
          var xs = [], ys = [];
          data.forEach(function (d, i) {
            var p = d.split(':');
            if (p.length >= 2) { var x = num(p[0]), y = num(p[1]); if (x != null && y != null) { xs.push(x); ys.push(y); } }
            else { var y2 = num(d); if (y2 != null) { xs.push(i + 1); ys.push(y2); } }
          });
          if (xs.length) g.lines.push({ label: label, xs: xs, ys: ys });
        } else if (key === 'bar' || key === '막대') {
          label = bar >= 0 ? value.slice(0, bar).trim() : '';
          data = (bar >= 0 ? value.slice(bar + 1) : value).split(',').map(function (x) { return x.trim(); }).filter(Boolean);
          var cats = [], vals = [];
          data.forEach(function (d) {
            var k = d.lastIndexOf(':'); if (k <= 0) return;
            var y = num(d.slice(k + 1)); if (y == null) return;
            cats.push(d.slice(0, k).trim()); vals.push(y);
          });
          if (cats.length) g.bars.push({ label: label, cats: cats, values: vals });
        } else if (key === 'point' || key === '점') {
          var p2 = value.split(',').map(function (x) { return x.trim(); });
          if (p2.length >= 2) { var px = num(p2[0]), py = num(p2[1]); if (px != null && py != null) g.points.push({ x: px, y: py, label: p2.slice(2).join(', ') }); }
        } else if (key === 'hline') { var h = num(value); if (h != null) g.hLines.push(h); }
        else if (key === 'vline') { var v = num(value); if (v != null) g.vLines.push(v); }
      } catch (err) { /* 한 줄이 틀려도 나머지는 그린다 */ }
    });
    g.isEmpty = !g.fns.length && !g.lines.length && !g.bars.length && !g.points.length;
    return g;
  }

  // ───────── 범위 · 눈금 ─────────
  function niceStep(rng, target) {
    var raw = rng / Math.max(1, target);
    if (!(raw > 0) || !isFinite(raw)) return 1;
    var mag = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / mag;
    return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * mag;
  }
  function fmt(v) {
    if (Math.abs(v) < 1e-12) return '0';
    if (Math.abs(v - Math.round(v)) < 1e-9 * Math.max(1, Math.abs(v)) && Math.abs(v) < 1e9) return String(Math.round(v));
    return String(parseFloat(v.toFixed(4)));
  }
  function autoRange(g) {
    var hasBars = g.bars.length > 0, xMin = g.xMin, xMax = g.xMax, i;
    if (xMin == null || xMax == null) {
      var xs = [];
      g.lines.forEach(function (s) { s.xs.forEach(function (x) { xs.push(x); }); });
      g.points.forEach(function (p) { xs.push(p.x); });
      g.vLines.forEach(function (x) { xs.push(x); });
      if (xs.length && !g.fns.length) {
        var lo = Math.min.apply(null, xs), hi = Math.max.apply(null, xs);
        if (hi - lo < 1e-9) { lo -= 1; hi += 1; }
        var pad = (hi - lo) * 0.06; xMin = lo - pad; xMax = hi + pad;
      } else if (xs.length) { xMin = Math.min(-6, Math.min.apply(null, xs)); xMax = Math.max(6, Math.max.apply(null, xs)); }
      else { xMin = -6; xMax = 6; }
    }
    var yMin = g.yMin, yMax = g.yMax;
    if (yMin == null || yMax == null) {
      var ys = [];
      g.fns.forEach(function (f) { for (var k = 0; k <= 240; k++) { var v = f.expr(xMin + (xMax - xMin) * k / 240); if (!isNaN(v) && isFinite(v)) ys.push(v); } });
      // 점근선처럼 튀는 값은 범위를 정할 때 버린다 (tan · 1/x 등)
      if (ys.length > 20) {
        var mags = ys.map(Math.abs).sort(function (a, b) { return a - b; });
        var limit = Math.max(mags[Math.floor(mags.length * 9 / 10)] * 3, 1);
        ys = ys.filter(function (v) { return Math.abs(v) <= limit; });
      }
      g.lines.forEach(function (s) { s.ys.forEach(function (y) { ys.push(y); }); });
      g.bars.forEach(function (b) { b.values.forEach(function (y) { ys.push(y); }); });
      g.points.forEach(function (p) { ys.push(p.y); });
      g.hLines.forEach(function (y) { ys.push(y); });
      var lo2 = ys.length ? Math.min.apply(null, ys) : -1, hi2 = ys.length ? Math.max.apply(null, ys) : 1;
      if (hasBars) { lo2 = Math.min(lo2, 0); hi2 = Math.max(hi2, 0); }
      if (hi2 - lo2 < 1e-9) { lo2 -= 1; hi2 += 1; }
      var pad2 = (hi2 - lo2) * 0.08;
      yMin = hasBars && lo2 >= 0 ? 0 : lo2 - pad2; yMax = hi2 + pad2;
    }
    return { xMin: xMin, xMax: xMax, yMin: yMin, yMax: yMax };
  }

  var PALETTE = ['var(--accent, #2FA35B)', '#1A73E8', '#E8710A', '#9334E6', '#D93025', '#00897B'];
  function color(i) { return PALETTE[i % PALETTE.length]; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function r1(v) { return Math.round(v * 10) / 10; }
  function ell(s, maxChars) { s = String(s); return s.length > maxChars ? s.slice(0, Math.max(1, maxChars - 1)) + '…' : s; }

  // 점들을 부드러운 곡선으로 잇는다 (단조 3차 보간: 점 사이에서 출렁이지 않고 점을 그대로 지난다). SVG 경로 조각을 돌려준다
  function smooth(px, py, move) {
    var n = px.length, d = move === false ? '' : 'M' + r1(px[0]) + ' ' + r1(py[0]);
    if (n < 2) return d;
    if (n === 2) return d + 'L' + r1(px[1]) + ' ' + r1(py[1]);
    var dx = [], sl = [], m = [], i;
    for (i = 0; i < n - 1; i++) { dx.push(px[i + 1] - px[i]); sl.push(dx[i] === 0 ? 0 : (py[i + 1] - py[i]) / dx[i]); }
    m[0] = sl[0]; m[n - 1] = sl[n - 2];
    for (i = 1; i < n - 1; i++) m[i] = sl[i - 1] * sl[i] <= 0 ? 0 : (sl[i - 1] + sl[i]) / 2;
    for (i = 0; i < n - 1; i++) {
      if (sl[i] === 0) { m[i] = 0; m[i + 1] = 0; continue; }
      var a = m[i] / sl[i], b = m[i + 1] / sl[i], s = a * a + b * b;
      if (s > 9) { var t = 3 / Math.sqrt(s); m[i] = t * a * sl[i]; m[i + 1] = t * b * sl[i]; }
    }
    for (i = 0; i < n - 1; i++) {
      var h = dx[i] / 3;
      d += 'C' + r1(px[i] + h) + ' ' + r1(py[i] + m[i] * h) + ' ' + r1(px[i + 1] - h) + ' ' + r1(py[i + 1] - m[i + 1] * h) + ' ' + r1(px[i + 1]) + ' ' + r1(py[i + 1]);
    }
    return d;
  }

  function legendNames(g) {
    var names = [], ci = 0;
    g.bars.forEach(function (b) { if (b.label.trim()) names.push({ name: b.label, color: color(ci) }); ci++; });
    g.fns.forEach(function (f) { if (f.label.trim()) names.push({ name: f.label, color: color(ci) }); ci++; });
    g.lines.forEach(function (s) { if (s.label.trim()) names.push({ name: s.label, color: color(ci) }); ci++; });
    return names.length && (names.length > 1 || !g.title.trim()) ? names : [];
  }
  function isExtremum(label) { var t = String(label).replace(/ /g, ''); return ['극댓값', '극솟값', '극대값', '극소값', '극대', '극소'].indexOf(t) >= 0; }

  // spec(parse 결과) → { svg, meta }.  width: 화면 폭(px). 색은 CSS 변수(--text · --muted · --line · --surface)를 쓴다
  function render(g, o) {
    var W = Math.max(220, Math.round((o && o.width) || 360)), uid = (o && o.uid) || 'g';
    var box = autoRange(g), hasBars = g.bars.length > 0, mathAxes = g.fns.length > 0;
    var tick = 11, cy = 10, out = [], title = '', legend = '';
    if (g.title.trim()) { title = '<text x="12" y="' + (cy + 14) + '" class="gt" font-size="14" font-weight="700" fill="var(--text)">' + esc(ell(g.title, Math.floor((W - 20) / 8))) + '</text>'; cy += 22; }
    var names = legendNames(g), legH = 0;
    if (names.length) {
      var x = 12, row = 0, rowH = 18, maxW = W - 24;
      names.forEach(function (n) {
        var label = ell(n.name, Math.floor(maxW * 0.6 / 6.2)), itemW = 13 + label.length * 6.4;
        if (x > 12 && x + itemW > 12 + maxW) { x = 12; row++; }
        var mid = cy + row * rowH + rowH / 2;
        legend += '<circle cx="' + (x + 4) + '" cy="' + mid + '" r="4" fill="' + n.color + '"/><text x="' + (x + 13) + '" y="' + (mid + 3.7) + '" font-size="10.5" fill="var(--text)">' + esc(label) + '</text>';
        x += itemW + 14;
      });
      legH = (row + 1) * rowH; cy += legH;
    }
    var yl = '';
    if (g.yLabel.trim()) { yl = '<text x="12" y="' + (cy + 10.5) + '" font-size="10.5" fill="var(--muted)">' + esc(ell(g.yLabel, Math.floor((W - 20) / 6))) + '</text>'; cy += 14; }
    var H = Math.round(Math.min(420, Math.max(190, W * 0.68))) + (title ? 22 : 0) + legH + (g.yLabel.trim() ? 14 : 0);
    // 눈금 글자 폭으로 왼쪽 여백을 정한다
    var yStep = niceStep(box.yMax - box.yMin, 5), yTicks = [], yt = Math.ceil(box.yMin / yStep) * yStep, guard = 0;
    while (yt <= box.yMax + yStep * 1e-6 && guard++ < 40) { yTicks.push(yt); yt += yStep; }
    var tickW = yTicks.reduce(function (m, v) { return Math.max(m, fmt(v).length * 6.4); }, 0);
    var top = cy + 4, left = 10 + (mathAxes ? 6 : tickW + 6), right = 14, bottom = 10 + tick + 6 + (g.xLabel.trim() ? 14 : 0);
    var plot = { left: left, top: top, right: W - right, bottom: H - bottom };
    plot.w = plot.right - plot.left; plot.h = plot.bottom - plot.top;
    var meta = { W: W, H: H, plot: plot, box: box, bars: hasBars, g: g };
    if (plot.w < 40 || plot.h < 40) return { svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="100%"></svg>', meta: meta };
    function PX(v) { return plot.left + (v - box.xMin) / (box.xMax - box.xMin) * plot.w; }
    function PY(v) { return plot.bottom - (v - box.yMin) / (box.yMax - box.yMin) * plot.h; }
    meta.px = PX; meta.py = PY;
    var zeroY = box.yMin <= 0 && box.yMax >= 0, zeroX = box.xMin <= 0 && box.xMax >= 0;
    var ayPos = zeroY ? PY(0) : plot.bottom, axPos = zeroX ? PX(0) : plot.left, origin = mathAxes && zeroX && zeroY;
    // 격자 + 눈금 글자
    yTicks.forEach(function (v) {
      var y = r1(PY(v));
      out.push('<line x1="' + plot.left + '" x2="' + plot.right + '" y1="' + y + '" y2="' + y + '" stroke="var(--line)" stroke-width="1"/>');
      if (!(origin && Math.abs(v) < yStep * 1e-6)) out.push('<text x="' + r1((mathAxes ? axPos : plot.left) - 5) + '" y="' + r1(y + tick * 0.35) + '" text-anchor="end" font-size="' + tick + '" fill="var(--muted)">' + fmt(v) + '</text>');
    });
    if (!hasBars) {
      var xStep = niceStep(box.xMax - box.xMin, 6), xt = Math.ceil(box.xMin / xStep) * xStep; guard = 0;
      while (xt <= box.xMax + xStep * 1e-6 && guard++ < 40) {
        var xx = r1(PX(xt));
        out.push('<line x1="' + xx + '" x2="' + xx + '" y1="' + plot.top + '" y2="' + plot.bottom + '" stroke="var(--line)" stroke-opacity=".55" stroke-width="1"/>');
        if (!(origin && Math.abs(xt) < xStep * 1e-6)) out.push('<text x="' + xx + '" y="' + r1((mathAxes ? ayPos : plot.bottom) + tick + 4) + '" text-anchor="middle" font-size="' + tick + '" fill="var(--muted)">' + fmt(xt) + '</text>');
        xt += xStep;
      }
    }
    if (origin) out.push('<text x="' + r1(axPos - 5) + '" y="' + r1(ayPos + tick + 4) + '" text-anchor="end" font-size="' + tick + '" fill="var(--muted)">0</text>');
    // 좌표축 (0 이 범위 안에 있을 때만 가운데를 지난다)
    var ax = '';
    if (zeroY) ax += '<line x1="' + plot.left + '" x2="' + plot.right + '" y1="' + r1(PY(0)) + '" y2="' + r1(PY(0)) + '"/>';
    if (!hasBars && zeroX) ax += '<line x1="' + r1(PX(0)) + '" x2="' + r1(PX(0)) + '" y1="' + plot.top + '" y2="' + plot.bottom + '"/>';
    if (!mathAxes) ax += '<line x1="' + plot.left + '" x2="' + plot.right + '" y1="' + plot.bottom + '" y2="' + plot.bottom + '"/>';
    if (!hasBars && !mathAxes) ax += '<line x1="' + plot.left + '" x2="' + plot.left + '" y1="' + plot.top + '" y2="' + plot.bottom + '"/>';
    out.push('<g stroke="var(--muted)" stroke-width="1.2" fill="none">' + ax + '</g>');
    // 축 끝 화살표와 x · y 이름 (막대 그래프에는 없다)
    if (!hasBars) {
      var tipX = plot.right + 5, tipY = plot.top - 5, ah = 8, aw = 3.6;
      out.push('<g stroke="var(--muted)" stroke-width="1.2" fill="none"><line x1="' + (mathAxes ? plot.left : plot.right) + '" x2="' + (tipX - 1) + '" y1="' + r1(ayPos) + '" y2="' + r1(ayPos) + '"/><line x1="' + r1(axPos) + '" x2="' + r1(axPos) + '" y1="' + (mathAxes ? plot.bottom : plot.top) + '" y2="' + (tipY + 1) + '"/></g>' +
        '<path fill="var(--muted)" d="M' + tipX + ' ' + r1(ayPos) + 'L' + (tipX - ah) + ' ' + r1(ayPos - aw) + 'L' + (tipX - ah) + ' ' + r1(ayPos + aw) + 'Z"/>' +
        '<path fill="var(--muted)" d="M' + r1(axPos) + ' ' + tipY + 'L' + r1(axPos - aw) + ' ' + (tipY + ah) + 'L' + r1(axPos + aw) + ' ' + (tipY + ah) + 'Z"/>');
      if (!g.xLabel.trim()) out.push('<text x="' + (plot.right - 3) + '" y="' + r1(ayPos - 7) + '" text-anchor="end" font-size="11" font-style="italic" font-family="serif" fill="var(--muted)">x</text>');
      if (!g.yLabel.trim()) out.push('<text x="' + r1(axPos + 8) + '" y="' + (plot.top + 11) + '" font-size="11" font-style="italic" font-family="serif" fill="var(--muted)">y</text>');
    }
    if (g.xLabel.trim()) out.push('<text x="' + r1((plot.left + plot.right) / 2) + '" y="' + (H - 8) + '" text-anchor="middle" font-size="10.5" fill="var(--muted)">' + esc(ell(g.xLabel, Math.floor(plot.w / 6))) + '</text>');
    // 그래프 영역 안에서만 그린다
    out.push('<clipPath id="' + uid + 'c"><rect x="' + (plot.left - 1) + '" y="' + (plot.top - 1) + '" width="' + (plot.w + 2) + '" height="' + (plot.h + 2) + '"/></clipPath><g clip-path="url(#' + uid + 'c)">');
    var ci = 0;
    if (g.hLines.length || g.vLines.length) {
      out.push('<g stroke="var(--muted)" stroke-width="1.2" stroke-dasharray="5 4">' + g.hLines.map(function (v) { return '<line x1="' + plot.left + '" x2="' + plot.right + '" y1="' + r1(PY(v)) + '" y2="' + r1(PY(v)) + '"/>'; }).join('') +
        g.vLines.map(function (v) { return '<line y1="' + plot.top + '" y2="' + plot.bottom + '" x1="' + r1(PX(v)) + '" x2="' + r1(PX(v)) + '"/>'; }).join('') + '</g>');
    }
    if (hasBars) { // 막대: 데이터 쪽 모서리만 둥글게, 너무 두껍지 않게
      var cats = g.bars[0].cats, n = cats.length, sets = g.bars.length, slot = plot.w / n, bw = Math.min(slot * 0.72 / sets, 26), zero = PY(0);
      var widest = 0; g.bars.forEach(function (b) { b.values.forEach(function (v) { widest = Math.max(widest, fmt(v).length * 6.2); }); });
      var showVals = widest <= bw + 8 || n * sets <= 6;
      for (var c = 0; c < n; c++) {
        var cx = plot.left + slot * (c + 0.5);
        out.push('</g><text x="' + r1(cx) + '" y="' + r1(plot.bottom + tick + 4) + '" text-anchor="middle" font-size="10.5" fill="var(--muted)">' + esc(ell(cats[c], Math.max(2, Math.floor((slot - 2) / 6.2)))) + '</text><g clip-path="url(#' + uid + 'c)">');
        for (var k = 0; k < sets; k++) {
          var b = g.bars[k]; if (c >= b.values.length) continue;
          var x0 = cx - bw * sets / 2 + bw * k, y = PY(b.values[c]), up = b.values[c] >= 0;
          var rx0 = x0 + 1, rx1 = x0 + bw - 1, ry0 = Math.min(y, zero), ry1 = Math.max(y, zero), rr = Math.max(0, Math.min(8, (rx1 - rx0) / 2, (ry1 - ry0) / 2));
          var d = up
            ? 'M' + r1(rx0) + ' ' + r1(ry1) + 'V' + r1(ry0 + rr) + 'Q' + r1(rx0) + ' ' + r1(ry0) + ' ' + r1(rx0 + rr) + ' ' + r1(ry0) + 'H' + r1(rx1 - rr) + 'Q' + r1(rx1) + ' ' + r1(ry0) + ' ' + r1(rx1) + ' ' + r1(ry0 + rr) + 'V' + r1(ry1) + 'Z'
            : 'M' + r1(rx0) + ' ' + r1(ry0) + 'V' + r1(ry1 - rr) + 'Q' + r1(rx0) + ' ' + r1(ry1) + ' ' + r1(rx0 + rr) + ' ' + r1(ry1) + 'H' + r1(rx1 - rr) + 'Q' + r1(rx1) + ' ' + r1(ry1) + ' ' + r1(rx1) + ' ' + r1(ry1 - rr) + 'V' + r1(ry0) + 'Z';
          out.push('<path class="bar" d="' + d + '" fill="' + color(k) + '"/>');
          if (showVals) out.push('<text x="' + r1(x0 + bw / 2) + '" y="' + r1(up ? y - 4 : y + 12.5) + '" text-anchor="middle" font-size="10.5" fill="var(--text)">' + fmt(b.values[c]) + '</text>');
        }
      }
      ci = sets;
    }
    g.fns.forEach(function (f) { // 함수: 점근선에서 위아래로 크게 튀면 선을 잇지 않는다
      var d = '', n2 = Math.min(700, Math.max(120, Math.floor(plot.w / 2))), open = false, prevY = 0;
      for (var k2 = 0; k2 <= n2; k2++) {
        var xv = box.xMin + (box.xMax - box.xMin) * k2 / n2, v = f.expr(xv);
        if (isNaN(v) || !isFinite(v)) { open = false; continue; }
        var sx = PX(xv), sy = PY(v);
        if (open && Math.abs(sy - prevY) > plot.h) open = false;
        d += (open ? 'L' : 'M') + r1(sx) + ' ' + r1(sy); open = true; prevY = sy;
      }
      out.push('<path class="ln" d="' + d + '" fill="none" stroke="' + color(ci) + '" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" pathLength="1"/>');
      ci++;
    });
    var lineBase = ci;
    g.lines.forEach(function (s) { // 꺾은선: 하나뿐이면 아래를 옅게 채우고, 점에는 바탕색 테두리
      var col = color(ci), sx = s.xs.map(PX), sy = s.ys.map(PY);
      if (g.lines.length === 1 && !hasBars && !g.fns.length && s.xs.length > 1)
        out.push('<path d="M' + r1(sx[0]) + ' ' + r1(plot.bottom) + smooth(sx, sy, false).replace(/^/, 'L' + r1(sx[0]) + ' ' + r1(sy[0])) + 'L' + r1(sx[sx.length - 1]) + ' ' + r1(plot.bottom) + 'Z" fill="' + col + '" fill-opacity=".15"/>');
      out.push('<path class="ln" d="' + smooth(sx, sy) + '" fill="none" stroke="' + col + '" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" pathLength="1"/>');
      if (s.xs.length <= 40) s.xs.forEach(function (_x, k3) { out.push('<circle cx="' + r1(sx[k3]) + '" cy="' + r1(sy[k3]) + '" r="4.6" fill="var(--surface)"/><circle cx="' + r1(sx[k3]) + '" cy="' + r1(sy[k3]) + '" r="3.2" fill="' + col + '"/>'); });
      ci++;
    });
    meta.lineBase = lineBase;
    var ptStart = ci;
    g.points.forEach(function (m, pi) { // 점: 평소엔 점만. 위에 가져가면 축으로 내리는 점선 · 축 위 값 알약 · 이름이 나타난다
      out.push('<g class="pt" data-i="' + pi + '"><circle class="pt-halo" cx="' + r1(PX(m.x)) + '" cy="' + r1(PY(m.y)) + '" r="5.6" fill="var(--surface)"/><circle class="pt-dot" cx="' + r1(PX(m.x)) + '" cy="' + r1(PY(m.y)) + '" r="4.2" fill="' + color(ptStart) + '"/></g>');
    });
    meta.ptColor = color(ptStart); meta.axPos = axPos; meta.ayPos = ayPos; meta.zeroX = zeroX; meta.zeroY = zeroY;
    out.push('</g>');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" class="graph-svg" viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="' + esc(g.title || '그래프') + '" font-family="inherit">' + title + legend + yl + out.join('') + '<g class="hover"></g></svg>';
    return { svg: svg, meta: meta };
  }

  // 가로 위치(svg 좌표) x 의 값을 알려 주는 말풍선 내용. { anchor, head, rows:[{color, text}], dots:[{x,y,color}], slot } 또는 null
  function hover(meta, x) {
    var g = meta.g, p = meta.plot, box = meta.box, rows = [], dots = [], head = '', anchor = x;
    if (x < p.left || x > p.right) return null;
    if (meta.bars && g.bars[0].cats.length) {
      var n = g.bars[0].cats.length, slot = p.w / n, c = Math.max(0, Math.min(n - 1, Math.floor((x - p.left) / slot)));
      head = g.bars[0].cats[c];
      g.bars.forEach(function (b, k) { if (c < b.values.length) rows.push({ color: color(k), text: (b.label ? b.label + '  ' : '') + fmt(b.values[c]) }); });
      return { anchor: p.left + slot * (c + 0.5), head: head, rows: rows, dots: [], slot: { x: p.left + slot * c, w: slot } };
    }
    if (g.lines.some(function (s) { return s.xs.length; })) {
      var bestX = null, bestD = 1e18;
      g.lines.forEach(function (s) { s.xs.forEach(function (xv) { var d = Math.abs(meta.px(xv) - x); if (d < bestD) { bestD = d; bestX = xv; } }); });
      anchor = meta.px(bestX); head = 'x = ' + fmt(bestX);
      g.lines.forEach(function (s, j) {
        var k = -1; for (var i = 0; i < s.xs.length; i++) if (Math.abs(s.xs[i] - bestX) < 1e-9) { k = i; break; }
        if (k >= 0) { dots.push({ x: anchor, y: meta.py(s.ys[k]), color: color(meta.lineBase + j) }); rows.push({ color: color(meta.lineBase + j), text: (s.label ? s.label + '  ' : '') + fmt(s.ys[k]) }); }
      });
      return { anchor: anchor, head: head, rows: rows, dots: dots };
    }
    if (g.fns.length) {
      var xv2 = box.xMin + (x - p.left) / p.w * (box.xMax - box.xMin);
      head = 'x = ' + fmt(xv2);
      g.fns.forEach(function (f, j) { var v = f.expr(xv2); if (!isNaN(v) && isFinite(v)) { dots.push({ x: x, y: meta.py(v), color: color(j) }); rows.push({ color: color(j), text: (f.label ? f.label + '  ' : '') + fmt(v) }); } });
      return { anchor: x, head: head, rows: rows, dots: dots };
    }
    return null;
  }
  return { parse: parse, parseExpr: parseExpr, render: render, hover: hover, autoRange: autoRange, niceStep: niceStep, fmt: fmt, isExtremum: isExtremum, smooth: smooth, PALETTE: PALETTE };
});
