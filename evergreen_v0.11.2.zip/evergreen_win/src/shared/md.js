'use strict';
// AI 답변(마크다운) → 안전한 HTML. 굵게 · 기울임 · 취소선 · 제목 · 글머리표/번호(중첩) · 인용 · 표 · 코드 블록(복사 단추) · 링크 ·
// 수식($…$ → MathML) · ```graph 블록(그래프 자리)을 읽는다. 받는 중인 글(코드 블록이 아직 안 닫힘 등)도 깨지지 않게 그린다.
// 사용자 글은 항상 이스케이프하고, 링크는 http(s)/mailto 만 허용한다.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./mathtex'));
  else root.EvMd = factory(root.EvMath);
})(typeof self !== 'undefined' ? self : this, function (Math_) {
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var SAFE_URL = /^(https?:\/\/|mailto:)/i;

  // 한 줄 안의 서식. 수식과 코드는 먼저 떼어 두었다가 마지막에 되돌린다
  function inline(text, stash) {
    var s = String(text);
    s = s.replace(/`([^`\n]+)`/g, function (_m, c) { stash.push('<code>' + esc(c) + '</code>'); return '\u0001' + (stash.length - 1) + '\u0001'; });
    if (Math_) s = Math_.replaceAll(s, function (tex, display, m) {
      var ml = Math_.toMathML(tex, false);
      if (!ml) return m;
      stash.push('<span class="math">' + ml + '</span>'); return '\u0001' + (stash.length - 1) + '\u0001';
    });
    s = s.replace(/\[\[사진\d+\]\]/g, '');
    s = esc(s);
    s = s.replace(/\[([^\]\n]+)\]\(([^)\s]+)\)/g, function (m, label, url) {
      var u = url.replace(/&amp;/g, '&');
      return SAFE_URL.test(u) ? '<a href="' + esc(u) + '" data-url="' + esc(u) + '">' + label + '</a>' : label;
    });
    s = s.replace(/(^|[\s(])(https?:\/\/[^\s<)]+[^\s<).,;:!?])/g, function (_m, pre, url) { var u = url.replace(/&amp;/g, '&'); return pre + '<a href="' + esc(u) + '" data-url="' + esc(u) + '">' + url + '</a>'; });
    s = s.replace(/\*\*\*([^*\n]+?)\*\*\*/g, '<strong><em>$1</em></strong>').replace(/\*\*([^*\n]+?)\*\*/g, '<strong>$1</strong>').replace(/__([^_\n]+?)__/g, '<strong>$1</strong>')
      .replace(/(^|[^*\w])\*([^*\s][^*\n]*?)\*(?!\w)/g, '$1<em>$2</em>').replace(/~~([^~\n]+?)~~/g, '<del>$1</del>');
    return s.replace(/\u0001(\d+)\u0001/g, function (_m, i) { return stash[+i]; });
  }

  function isTableSep(l) { return /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/.test(l) && l.indexOf('|') >= 0; }
  function cells(l) { var t = l.trim().replace(/^\|/, '').replace(/\|$/, ''); return t.split(/(?<!\\)\|/).map(function (c) { return c.replace(/\\\|/g, '|').trim(); }); }

  // opts: { streaming: boolean }  → HTML 문자열
  function render(src, opts) {
    var lines = String(src || '').replace(/\r\n?/g, '\n').split('\n'), out = [], i = 0, stash = [];
    var streaming = !!(opts && opts.streaming);
    function para(buf) { if (buf.length) out.push('<p>' + inline(buf.join('\n'), stash).replace(/\n/g, '<br>') + '</p>'); }
    var buf = [];
    // 목록: 들여쓰기로 중첩
    function list(start) {
      var m0 = /^(\s*)([-*+]|\d+[.)])\s+/.exec(lines[start]), base = m0[1].length, ordered = /\d/.test(m0[2]), html = '', j = start;
      var startNum = ordered ? parseInt(m0[2], 10) : 1;
      html += ordered ? '<ol' + (startNum !== 1 ? ' start="' + startNum + '"' : '') + '>' : '<ul>';
      while (j < lines.length) {
        var m = /^(\s*)([-*+]|\d+[.)])\s+(.*)$/.exec(lines[j]);
        if (!m || m[1].length < base) break;
        if (m[1].length > base) { var sub = list(j); html = html.replace(/<\/li>$/, '') + sub.html + '</li>'; j = sub.next; continue; }
        if (/\d/.test(m[2]) !== ordered) break;
        var body = m[3], task = /^\[( |x|X)\]\s+(.*)$/.exec(body);
        var item = task ? '<input type="checkbox" disabled' + (task[1] !== ' ' ? ' checked' : '') + '> ' + inline(task[2], stash) : inline(body, stash);
        j++;
        // 이어지는 들여쓴 줄은 같은 항목의 글
        while (j < lines.length && /^\s{2,}\S/.test(lines[j]) && !/^(\s*)([-*+]|\d+[.)])\s+/.test(lines[j])) { item += '<br>' + inline(lines[j].trim(), stash); j++; }
        html += '<li>' + item + '</li>';
      }
      return { html: html + (ordered ? '</ol>' : '</ul>'), next: j };
    }
    while (i < lines.length) {
      var l = lines[i], m;
      if ((m = /^\s*(```+|~~~+)\s*([\w+#.-]*)\s*$/.exec(l))) { // 코드 블록
        para(buf); buf = [];
        var fence = m[1], lang = (m[2] || '').toLowerCase(), body = [], closed = false; i++;
        while (i < lines.length) { if (new RegExp('^\\s*' + fence[0] + '{' + fence.length + ',}\\s*$').test(lines[i])) { closed = true; i++; break; } body.push(lines[i]); i++; }
        var code = body.join('\n');
        if (lang === 'graph') out.push('<div class="graph" data-src="' + esc(code) + '"' + (closed || !streaming ? '' : ' data-open="1"') + '></div>');
        else out.push('<div class="code"><div class="code-h"><span>' + esc(lang || '코드') + '</span><button class="copy" type="button">복사</button></div><pre><code>' + esc(code) + '</code></pre></div>');
        continue;
      }
      if ((m = /^\s*\$\$\s*$/.exec(l)) || (m = /^\s*\\\[\s*$/.exec(l))) { // 여러 줄 수식 블록
        var close = /\$/.test(m[0]) ? /^\s*\$\$\s*$/ : /^\s*\\\]\s*$/, j2 = i + 1, tex = [];
        while (j2 < lines.length && !close.test(lines[j2])) { tex.push(lines[j2]); j2++; }
        if (j2 < lines.length || !streaming) {
          para(buf); buf = [];
          var ml = Math_ && Math_.toMathML(tex.join('\n'), true);
          out.push(ml ? '<div class="math-block">' + ml + '</div>' : '<pre class="math-raw">' + esc(tex.join('\n')) + '</pre>');
          i = j2 + 1; continue;
        }
      }
      if (/^\s*$/.test(l)) { para(buf); buf = []; i++; continue; }
      if ((m = /^\s*\$\$(.+)\$\$\s*$/.exec(l))) { para(buf); buf = []; var ml2 = Math_ && Math_.toMathML(m[1], true); out.push(ml2 ? '<div class="math-block">' + ml2 + '</div>' : '<p>' + esc(l) + '</p>'); i++; continue; }
      if ((m = /^(#{1,6})\s+(.*?)\s*#*\s*$/.exec(l))) { para(buf); buf = []; var lv = Math.min(6, m[1].length + 1); out.push('<h' + lv + '>' + inline(m[2], stash) + '</h' + lv + '>'); i++; continue; }
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(l) && !/^\s*[-*]\s+\S/.test(l)) { para(buf); buf = []; out.push('<hr>'); i++; continue; }
      if (/^\s*>/.test(l)) { // 인용
        para(buf); buf = []; var q = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) { q.push(lines[i].replace(/^\s*>\s?/, '')); i++; }
        out.push('<blockquote>' + render(q.join('\n'), opts) + '</blockquote>'); continue;
      }
      if (l.indexOf('|') >= 0 && i + 1 < lines.length && isTableSep(lines[i + 1])) { // 표
        para(buf); buf = [];
        var head = cells(l), aligns = cells(lines[i + 1]).map(function (c) { return /^:-+:$/.test(c) ? 'center' : /-:$/.test(c) ? 'right' : /^:-/.test(c) ? 'left' : ''; }), rows = []; i += 2;
        while (i < lines.length && lines[i].indexOf('|') >= 0 && !/^\s*$/.test(lines[i])) { rows.push(cells(lines[i])); i++; }
        var al = function (k) { return aligns[k] ? ' style="text-align:' + aligns[k] + '"' : ''; };
        out.push('<div class="table-wrap"><table><thead><tr>' + head.map(function (c, k) { return '<th' + al(k) + '>' + inline(c, stash) + '</th>'; }).join('') + '</tr></thead><tbody>' +
          rows.map(function (r) { return '<tr>' + head.map(function (_c, k) { return '<td' + al(k) + '>' + inline(r[k] == null ? '' : r[k], stash) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>');
        continue;
      }
      if (/^\s*([-*+]|\d+[.)])\s+/.test(l)) { para(buf); buf = []; var r = list(i); out.push(r.html); i = r.next; continue; }
      buf.push(l); i++;
    }
    para(buf);
    var html = out.join('');
    if (streaming) html = html.replace(/(<\/(?:p|li|h\d|code|pre|div|blockquote|table|ul|ol)>)?$/, function (m) { return '<span class="cursor"></span>' + (m || ''); });
    return html;
  }
  return { render: render, inline: function (t) { return inline(t, []); }, esc: esc };
});
