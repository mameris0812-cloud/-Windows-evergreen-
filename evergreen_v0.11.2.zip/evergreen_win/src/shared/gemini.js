'use strict';
// 6단계(AI 어시스턴트): Gemini 호출의 순수 규칙. 안드로이드 Gemini.kt / ModelSync.kt / GeminiSafety.kt 를 그대로 옮겼다.
//  - Models: 칸(LITE · HYDROGEN)마다 쓰는 모델과, 종료돼서 바뀐 모델 이어 쓰기(successor)
//  - KeyPool: API 키를 돌려 쓰고, 한도(429)·거부(401/403)가 난 키/모델만 잠시 쉬게 한다
//  - Auto: 질문만 보고 점수로 모델을 고른다 (요청을 더 보내지 않는다)
//  - Thinking · SearchGate: 생각 설정 / 구글 검색 연결을 모델이 거부하면 기억해 두고 빼고 다시 보낸다
// 시계(now)를 주입할 수 있어서 시간이 걸리는 규칙도 테스트로 확인한다.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvGemini = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var DEFAULT_IDS = { LITE: 'gemini-3.5-flash-lite', HYDROGEN: 'gemini-4-hydrogen' };
  var FAMILY = {
    LITE: /^gemini-(\d+(?:\.\d+)*)-flash-lite$/,
    HYDROGEN: /^gemini-(\d+(?:\.\d+)*)-hydrogen$/,
  };
  var OLD_FLASH = /^gemini-\d+(?:\.\d+)*-flash$/;

  // ───────── 모델 ─────────
  function Models() { this.ids = Object.assign({}, DEFAULT_IDS); }
  Models.prototype.idOf = function (slot) { return this.ids[slot] || DEFAULT_IDS[slot]; };
  Models.prototype.lite = function () { return this.idOf('LITE'); };
  Models.prototype.hydrogen = function () { return this.idOf('HYDROGEN'); };
  Models.prototype.all = function () { return [this.lite(), this.hydrogen()]; };
  Models.prototype.baseKey = function () { return Object.keys(DEFAULT_IDS).map(function (k) { return DEFAULT_IDS[k]; }).join(','); };
  Models.prototype.currentMap = function () { return Object.assign({}, this.ids); };
  // map(칸 → 모델 이름)을 적용한다. 바뀐 게 있으면 true
  Models.prototype.apply = function (map) {
    var next = Object.assign({}, DEFAULT_IDS);
    Object.keys(map || {}).forEach(function (k) { if (k in DEFAULT_IDS && typeof map[k] === 'string' && map[k].indexOf('gemini-') === 0) next[k] = map[k]; });
    var changed = JSON.stringify(next) !== JSON.stringify(this.ids);
    this.ids = next;
    return changed;
  };
  // "gemini-3.5-flash-lite" → "3.5 Flash-Lite", "gemini-4-hydrogen" → "4 Hydrogen"
  function labelOf(id) {
    var parts = String(id).replace(/^gemini-/, '').split('-').filter(Boolean);
    if (!parts.length) return String(id);
    var rest = parts.slice(1).map(function (w) { return w.charAt(0).toUpperCase() + w.slice(1); }).join(' ');
    return (parts[0] + ' ' + rest).trim().replace('Flash Lite', 'Flash-Lite');
  }
  function versionOf(id, re) {
    var m = re.exec(id);
    if (!m) return null;
    var out = [];
    var xs = m[1].split('.');
    for (var i = 0; i < xs.length; i++) { var n = parseInt(xs[i], 10); if (isNaN(n)) return null; out.push(n); }
    return out;
  }
  function cmpVer(a, b) {
    var n = Math.max(a.length, b.length);
    for (var i = 0; i < n; i++) { var x = a[i] || 0, y = b[i] || 0; if (x !== y) return x < y ? -1 : 1; }
    return 0;
  }
  Models.prototype.byId = function (id) { return { id: id, label: labelOf(id) }; };
  // id 가 지금 쓰는 모델이 아니면(종료돼서 이미 다른 모델로 바뀐 뒤 옛 이름이 남은 경우) 같은 계열에서 이어 쓸 모델
  Models.prototype.successor = function (id) {
    if (this.all().indexOf(id) >= 0) return id;
    if (OLD_FLASH.test(id)) return this.lite();
    var re = null;
    Object.keys(FAMILY).forEach(function (k) { if (!re && FAMILY[k].test(id)) re = FAMILY[k]; });
    if (!re) return id;
    var v = versionOf(id, re);
    if (!v) return id;
    var self = this;
    var slots = Object.keys(FAMILY).filter(function (k) { return FAMILY[k].source === re.source; }).map(function (k) { return self.idOf(k); })
      .filter(function (x, i, a) { return a.indexOf(x) === i; })
      .sort(function (a, b) { return cmpVer(versionOf(a, re) || [0], versionOf(b, re) || [0]); });
    if (!slots.length) return id;
    var newer = slots.filter(function (s) { return cmpVer(versionOf(s, re) || [0], v) > 0; });
    return newer.length ? newer[0] : slots[slots.length - 1];
  };
  // 구글 모델 목록(avail: id → 종료 예정 여부)에서 칸별 모델을 다시 정한다. 목록이 이상해 보이면(Flash 계열이 하나도 없음) null
  Models.prototype.resolveAll = function (avail) {
    var ids = Object.keys(avail || {});
    if (!ids.some(function (i) { return FAMILY.LITE.test(i); })) return null;
    var ok = ids.filter(function (i) { return !avail[i]; });
    var result = {}, taken = {}, self = this;
    ['HYDROGEN', 'LITE'].forEach(function (slot) {
      var cur = self.idOf(slot), re = FAMILY[slot], pick;
      if (ok.indexOf(cur) >= 0) pick = cur;
      else {
        var curV = versionOf(cur, re) || [0];
        var cands = ok.map(function (id) { var v = versionOf(id, re); return v ? { id: id, v: v } : null; }).filter(Boolean).sort(function (a, b) { return cmpVer(a.v, b.v); });
        if (!cands.length) pick = cur;
        else {
          var newer = cands.filter(function (c) { return cmpVer(c.v, curV) > 0; });
          var free = newer.filter(function (c) { return !taken[c.id]; })[0];
          pick = free ? free.id : (newer.length ? newer[newer.length - 1].id : cands[cands.length - 1].id);
        }
      }
      result[slot] = pick; taken[pick] = true;
    });
    return result;
  };
  // 모델 상태가 종료됨·종료 예정이거나 종료 시각이 일주일 안이면 true
  function isEnding(st, nowMs) {
    if (!st) return false;
    var stage = String(st.modelStage || '').toUpperCase();
    if (stage.indexOf('DEPRECAT') >= 0 || stage.indexOf('RETIRE') >= 0) return true;
    var rt = String(st.retirementTime || '');
    if (rt.length >= 19) { var d = Date.parse(rt.slice(0, 19) + 'Z'); if (!isNaN(d)) return d < nowMs + 7 * 86400000; }
    return false;
  }

  // ───────── 안전 필터 ─────────
  var SAFETY_CATEGORIES = ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT', 'HARM_CATEGORY_CIVIC_INTEGRITY'];
  function safetySettings() { return SAFETY_CATEGORIES.map(function (c) { return { category: c, threshold: 'BLOCK_NONE' }; }); }

  // ───────── 키 풀 ─────────
  function KeyPool(opts) {
    this.now = (opts && opts.now) || Date.now;
    this.models = (opts && opts.models) || new Models();
    this.cool = {}; this.rejected = {}; this.coolModel = {};
    this.known = []; this.lastUsed = ''; this.counter = 0; this.lastEventAt = 0;
    this.onEvent = null;
  }
  KeyPool.prototype.used = function (key) { this.lastUsed = key; };
  KeyPool.prototype.count = function () { return this.known.length; };
  KeyPool.prototype.currentNo = function () { return this.known.indexOf(this.lastUsed) + 1; };
  // 한도·거부로 from 대신 to 로 바꿨을 때 알린다. 여러 요청이 동시에 바꿔도 알림이 쏟아지지 않게 3초에 한 번만
  KeyPool.prototype.notifySwitch = function (from, to, bad) {
    this.lastUsed = to;
    if (this.known.length < 2) return;
    var t = this.now();
    if (t - this.lastEventAt < 3000) return;
    this.lastEventAt = t;
    if (this.onEvent) {
      var f = this.known.indexOf(from) + 1, n = this.known.indexOf(to) + 1;
      this.onEvent({ from: f, to: n, total: this.known.length, bad: !!bad, text: bad ? '키 ' + f + ' 거부됨 → 키 ' + n + ' 사용' : '키 ' + f + ' 한도 도달 → 키 ' + n + ' 사용' });
    }
  };
  function remainText(ms) { var sec = Math.floor((ms + 999) / 1000); return sec < 60 ? sec + '초' : Math.floor((sec + 59) / 60) + '분'; }
  KeyPool.prototype.remainText = remainText;
  // 설정 화면 표시용: 이 키가 지금 못 쓰는 이유와 풀리기까지 남은 시간. 바로 쓸 수 있으면 null
  KeyPool.prototype.statusOf = function (key) {
    var t = this.now(), until = this.cool[key] || 0, self = this;
    if (until > t) {
      var left = remainText(until - t);
      return this.rejected[key] ? '키가 거부됐어요 · ' + left + ' 뒤 다시 확인' : '한도 도달 · ' + left + ' 뒤 다시 사용';
    }
    var names = Object.keys(this.coolModel).filter(function (k) { return k.indexOf(key + '|') === 0 && self.coolModel[k] > t; })
      .map(function (k) { return labelOf(k.slice(k.indexOf('|') + 1)); }).filter(function (x, i, a) { return a.indexOf(x) === i; });
    if (names.length) return names.join(', ') + ' 한도 도달 · 다른 모델은 사용 가능';
    return null;
  };
  // 429 응답이 정말 내 사용량 한도인지 (어느 한도인지 알려 주는 말이 있어야 한도. 없는 429 는 서버가 붐빌 때도 온다)
  KeyPool.prototype.isQuota = function (body) {
    var low = String(body || '').toLowerCase();
    return ['quotafailure', 'quota_metric', 'quotametric', 'quotaid', 'quota_id', 'retrydelay', 'exceeded your current quota', 'per minute', 'per day', 'perminute', 'perday']
      .some(function (w) { return low.indexOf(w) >= 0; });
  };
  // 이번에 쓸 키: 쉬는 중이 아닌 키를 번갈아 (모두 쉬면 가장 빨리 풀리는 키)
  KeyPool.prototype.pick = function (keys) {
    this.known = keys.slice();
    if (!keys.length) return '';
    var t = this.now(), self = this;
    var ok = keys.filter(function (k) { return (self.cool[k] || 0) <= t; });
    if (ok.length) return ok[(this.counter++) % ok.length];
    return keys.slice().sort(function (a, b) { return (self.cool[a] || 0) - (self.cool[b] || 0); })[0];
  };
  KeyPool.prototype.cooldown = function (key, ms, bad) { this.cool[key] = this.now() + ms; this.rejected[key] = !!bad; };
  KeyPool.prototype.blocked = function (key, model) {
    var t = this.now();
    return (this.cool[key] || 0) > t || (this.coolModel[key + '|' + model] || 0) > t;
  };
  KeyPool.prototype.retryDelayMs = function (body) {
    var m = /retryDelay\W+(\d+(?:\.\d+)?)s/.exec(body);
    return m ? Math.floor(parseFloat(m[1]) * 1000) : 0;
  };
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  // 429 · 키 거부 응답을 받았을 때 호출한다.
  //  - 키가 거부된 경우: 키를 쉬게 하지 않는다 (이번 요청에서만 다른 키로 바꿔 보낸다). 모델만 막힌 403 은 그 (키, 모델) 짝만 10분
  //  - 한도 0 · 하루 한도: (키, 모델) 짝을 오래(30분 / 10분) 쉬게 한다
  //  - 이 모델만의 분당 한도: 응답이 알려 준 시간(없으면 60초)만. 그 밖의 한도도 키 전체는 쉬게 하지 않는다 (없으면 30초)
  KeyPool.prototype.onLimit = function (key, model, body, badKey) {
    var pair = key + '|' + model, t = this.now();
    if (badKey) {
      var bl = String(body || '').toLowerCase();
      if (bl.indexOf('model') >= 0 && (bl.indexOf('permission') >= 0 || bl.indexOf('not found') >= 0 || bl.indexOf('not supported') >= 0 || bl.indexOf('not available') >= 0)) this.coolModel[pair] = t + 600000;
      return;
    }
    var b = String(body || ''), low = b.toLowerCase();
    var zero = (/limit\W{0,4}0\b/.test(low) || /limit_value\W+0\b/.test(low)) && !/limit\W{0,4}0\d/.test(low);
    var daily = low.indexOf('perday') >= 0 || low.indexOf('per_day') >= 0 || low.indexOf('per day') >= 0;
    var perModel = low.indexOf('permodel') >= 0 || low.indexOf('per_model') >= 0 || (low.indexOf('quotadimensions') >= 0 && /"model"\s*:/.test(low)) ||
      low.indexOf('"model":"' + model + '"') >= 0 || low.indexOf(String(model).toLowerCase()) >= 0;
    var wait = this.retryDelayMs(b);
    if (zero || daily) this.coolModel[pair] = t + Math.max(wait, zero ? 1800000 : 600000);
    else if (perModel) this.coolModel[pair] = t + clamp(wait > 0 ? wait : 60000, 5000, 300000);
    else this.coolModel[pair] = t + clamp(wait > 0 ? wait : 30000, 5000, 300000);
  };
  // 모델별로 남은 시간 중 가장 짧은 것
  KeyPool.prototype.restingModels = function () {
    var t = this.now(), out = {}, self = this;
    Object.keys(this.coolModel).forEach(function (k) {
      var until = self.coolModel[k]; if (until <= t) return;
      var m = k.slice(k.indexOf('|') + 1), left = until - t;
      if (out[m] == null || left < out[m]) out[m] = left;
    });
    return out;
  };
  KeyPool.prototype.restingSummary = function () {
    var m = this.restingModels(), self = this;
    return Object.keys(m).map(function (k) { return labelOf(k) + ' ' + remainText(m[k]); }).join(' · ');
  };
  KeyPool.prototype.usable = function (model) {
    var self = this;
    return !this.known.length || this.known.some(function (k) { return !self.blocked(k, model); });
  };
  KeyPool.prototype.anyUsable = function (model) { var self = this; return this.known.some(function (k) { return !self.blocked(k, model); }); };
  KeyPool.prototype.quotaName = function (body) {
    var b = String(body || '');
    var m = /"quotaId"\s*:\s*"([^"]+)"/.exec(b);
    if (m && m[1].trim()) return m[1];
    var q = /"quotaMetric"\s*:\s*"([^"]+)"/.exec(b);
    return q ? q[1].split('/').pop() : '';
  };
  KeyPool.prototype.forModel = function (key, model) {
    if (!this.blocked(key, model)) return key;
    var self = this;
    return this.known.filter(function (k) { return !self.blocked(k, model); })[0] || key;
  };
  KeyPool.prototype.resting = function (key) { return (this.cool[key] || 0) > this.now(); };
  KeyPool.prototype.alternative = function (exclude, model) {
    var t = this.now(), self = this;
    var ex = exclude instanceof Set ? exclude : new Set(exclude || []);
    return this.known.filter(function (k) { return !ex.has(k) && (self.cool[k] || 0) <= t && (!model || (self.coolModel[k + '|' + model] || 0) <= t); })[0] || null;
  };

  // ───────── 자동 모델 ─────────
  var CODE_STRONG = ['코딩', '디버그', '디버깅', '리팩터', '컴파일', '스택트레이스', '스택 트레이스', 'stack trace', '정규식', '정규표현식', '프로그래밍', '파이썬', '자바스크립트', '코틀린', '타입스크립트', 'regex', 'kotlin', 'python', 'javascript', 'typescript', 'java', 'sql', 'html', 'css', 'json', 'c++', 'git'];
  var CODE_WEAK = ['코드', '함수', '버그', '프로그램', '스크립트', '알고리즘', '쿼리', '변수', '라이브러리', 'api', 'github', '깃허브', '에이전트', 'agent', '자동화', '워크플로'];
  var CODE_ACTION = ['짜 ', '짜줘', '짜 줘', '작성', '구현', '만들어', '고쳐', '고치', '수정', '리팩', '최적화', '추가해', '돌아가', '실행'];
  var CODE_SHAPE = /(```|=>|\bfun\s+\w+\(|\bdef\s+\w+\(|\bfunction\s*\w*\(|\bimport\s+[\w.]+|\bclass\s+\w+|#include|<\/?[a-z][a-z0-9]*>|\w+\([^)\n]*\)\s*\{|Exception|Traceback|NullPointer)/i;
  var HEAVY_STRONG = ['증명', '추론', '단계별', '논리적', '방정식', '미분', '적분', '확률', 'step by step'];
  var HEAVY_WEAK = ['분석', '비교', '자세히', '왜', '원인', '계산', '표로', '장단점', '차이', '이유', '전략', '설계', '보고서', '에세이', '논문'];
  var MATH_RE = /\d+(\.\d+)?\s*[+\-*/^×÷=]\s*\d+/g;
  var EXPLAIN_VERBS = ['요약', '번역', '설명', '정리', '교정', '첨삭', '해석', '풀이'];
  var ACK_RE = /^(고마워|고맙|감사|ㅇㅋ|ㅇㅇ|ok|okay|네|넵|응|아니|아냐|좋아|알겠|굿|ㅋ+|ㅎ+|thanks|thx|thank you)[\s!.~?ㅋㅎ]*$/i;
  var URL_RE = /(https?:\/\/|www\.)\S+/gi;
  function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function hasWord(lower, w) {
    if (/^[\x00-\x7f]+$/.test(w)) return new RegExp('(?<![a-z0-9])' + escRe(w) + 's?(?![a-z0-9+#])').test(lower);
    return lower.indexOf(w) >= 0;
  }
  function Auto(pool, models) {
    this.pool = pool; this.models = models; this.dead = new Set(); this.lastChat = null; this.lastReason = '';
  }
  Auto.prototype.translateModel = function () { return this.models.lite(); };
  Auto.prototype.visionModel = function () { return this.models.lite(); };
  Auto.prototype.markDead = function (m) { this.dead.add(m); };
  Auto.prototype.resetChat = function () { this.lastChat = null; };
  Auto.prototype.label = function (m) { return labelOf(m); };
  Auto.prototype.live = function (model) {
    var m = this.models.successor(model);
    if (!this.dead.has(m)) return m;
    return this.fallbacks(m)[0] || m;
  };
  Auto.prototype.fallbacks = function (model) {
    var L = this.models.lite(), H = this.models.hydrogen();
    var order = model === H ? [L] : model === L ? [H] : [L, H];
    var dead = this.dead;
    return order.filter(function (x) { return !dead.has(x); });
  };
  Auto.prototype.usableOrFallback = function (model) {
    if (this.pool.usable(model)) return model;
    var self = this;
    return this.fallbacks(model).filter(function (m) { return self.pool.usable(m); })[0] || model;
  };
  Auto.prototype.noteRule = function (model, why) { this.lastReason = why ? why + ' → ' + labelOf(model) : '낱말·길이 규칙으로 ' + labelOf(model) + ' 선택'; };
  Auto.prototype.noteChat = function (id) { this.lastChat = this.live(id); };
  Auto.prototype._remember = function (id) { var m = this.live(id); this.lastChat = m; return m; };
  // 채팅 질문 하나에 쓸 모델. 위에서부터 먼저 맞는 것:
  //  1 감사·맞장구 → Flash-Lite  2 코딩 → Hydrogen  3 사진 → Flash-Lite, 깊은 추론 → Hydrogen
  //  4 링크 · 페이지 글 · 긴 대화 · 긴 질문 · 설명류 → Flash-Lite(이어 묻기는 앞 모델 그대로)  5 나머지 → Flash-Lite
  Auto.prototype.forChat = function (question, turns, hasPageText, imageCount) {
    var L = this.models.lite(), H = this.models.hydrogen();
    var raw = String(question || '').trim();
    var hasUrl = new RegExp(URL_RE.source, 'i').test(raw);
    var q = raw.replace(URL_RE, ' ').trim(), lower = q.toLowerCase();
    if (imageCount === 0 && q.length <= 15 && !hasUrl && ACK_RE.test(q)) return this._remember(L);
    var strong = CODE_STRONG.filter(function (w) { return hasWord(lower, w); }).length;
    var weak = CODE_WEAK.filter(function (w) { return hasWord(lower, w); }).length;
    var action = CODE_ACTION.some(function (w) { return lower.indexOf(w) >= 0; });
    if (CODE_SHAPE.test(q) || strong >= 1 || weak >= 2 || (weak >= 1 && action)) return this._remember(H);
    var heavyStrong = HEAVY_STRONG.some(function (w) { return lower.indexOf(w) >= 0; });
    var heavyWeak = HEAVY_WEAK.filter(function (w) { return lower.indexOf(w) >= 0; }).length;
    var maths = (q.match(MATH_RE) || []).length;
    var qm = (q.match(/[?？]/g) || []).length;
    var heavy = heavyStrong || heavyWeak >= 2 || q.length > 400 || maths >= 2 || qm >= 3 || q.split('\n').length >= 6;
    if (imageCount > 0) return this._remember(L);
    if (heavy) return this._remember(H);
    var explain = EXPLAIN_VERBS.some(function (w) { return lower.indexOf(w) >= 0; }) && q.length > 50;
    var prev = this.lastChat;
    var shortFollowUp = q.length <= 30 && turns > 2 && prev != null;
    var mid = hasUrl || hasPageText || turns > 6 || q.length > 120 || explain;
    if (mid) return this._remember(shortFollowUp && prev === H ? prev : L);
    if (shortFollowUp) return this._remember(prev);
    return this._remember(L);
  };

  // ───────── 생각 · 검색 ─────────
  function Thinking() { this.unsupported = new Set(); }
  Thinking.prototype.apply = function (gen, model, level, includeThoughts) {
    if (!level || this.unsupported.has(model)) return false;
    var cfg = { thinkingLevel: level };
    if (includeThoughts) cfg.includeThoughts = true;
    gen.thinkingConfig = cfg;
    return true;
  };
  // 400 오류가 생각 설정 때문이면 그 모델을 기억하고 true (같은 요청을 설정 없이 다시 보내면 된다)
  Thinking.prototype.rejected = function (code, body, model, applied) {
    if (!applied || code !== 400 || body == null) return false;
    var low = String(body).toLowerCase();
    if (!(low.indexOf('thinking') >= 0 || low.indexOf('thought') >= 0 || low.indexOf('reasoning') >= 0 || low.indexOf('minimal') >= 0)) return false;
    this.unsupported.add(model);
    return true;
  };
  function SearchGate(now) { this.now = now || Date.now; this.unsupported = {}; this.restUntil = 0; }
  SearchGate.UNSUPPORTED_MS = 10 * 60 * 1000;
  SearchGate.prototype.resting = function () { return this.now() < this.restUntil; };
  SearchGate.prototype.rest = function (ms) { this.restUntil = this.now() + ms; };
  SearchGate.prototype.clearRest = function () { this.restUntil = 0; };
  SearchGate.prototype.isUnsupported = function (model) {
    var until = this.unsupported[model];
    if (!until) return false;
    if (this.now() >= until) { delete this.unsupported[model]; return false; }
    return true;
  };
  SearchGate.prototype.clearUnsupported = function () { this.unsupported = {}; };
  SearchGate.prototype.apply = function (body, model, on) {
    if (!on || this.isUnsupported(model)) return false;
    body.tools = [{ google_search: {} }];
    return true;
  };
  // 400 오류 본문이 검색 도구를 탓하는 글인지 (API 키 오류는 검색 탓이 아니다)
  SearchGate.prototype.blamesSearch = function (body) {
    var b = String(body).toLowerCase();
    if (b.indexOf('api key') >= 0 || b.indexOf('api_key') >= 0) return false;
    if (b.indexOf('google_search') >= 0 || b.indexOf('googlesearch') >= 0 || b.indexOf('grounding') >= 0 || b.indexOf('search as a tool') >= 0) return true;
    return b.indexOf('tool') >= 0 && (b.indexOf('not supported') >= 0 || b.indexOf('unsupported') >= 0 || b.indexOf('not enabled') >= 0 || b.indexOf('not allowed') >= 0);
  };
  SearchGate.prototype.rejected = function (code, body, model, applied) {
    if (!applied || code !== 400 || body == null) return false;
    if (!this.blamesSearch(body)) return false;
    this.unsupported[model] = this.now() + SearchGate.UNSUPPORTED_MS;
    return true;
  };

  // ───────── 오류 글 ─────────
  function networkErrorMessage(e) {
    var m = String((e && e.message) || '');
    var code = e && (e.code || (e.cause && e.cause.code)) || '';
    if (/timeout|timed out|ETIMEDOUT|UND_ERR_(HEADERS|BODY|CONNECT)_TIMEOUT/i.test(m + ' ' + code)) return 'AI의 응답이 너무 오래 걸려서 끊었어요 (시간 초과). 잠시 뒤 다시 시도해 주세요';
    if (/ENOTFOUND|ECONNREFUSED|ENETUNREACH|EAI_AGAIN|ECONNRESET|fetch failed|net::ERR_(INTERNET_DISCONNECTED|NAME_NOT_RESOLVED|CONNECTION)/i.test(m + ' ' + code)) return '인터넷에 연결할 수 없어요. 연결을 확인해 주세요';
    return '네트워크 오류: ' + (m || (e && e.name) || 'unknown');
  }
  function googleMessage(body) {
    try { var o = JSON.parse(body || ''); return o && o.error && o.error.message ? String(o.error.message) : null; } catch (e) { return null; }
  }
  function describeError(code, body, pool) {
    var msg = googleMessage(body);
    var quota = pool ? pool.isQuota(body) : new KeyPool().isQuota(body);
    var head;
    if (code === 400) head = '요청이 올바르지 않거나 API 키가 잘못되었어요';
    else if (code === 401 || code === 403) head = 'API 키가 거부되었어요. 키와 사용 권한을 확인해 주세요';
    else if (code === 404) head = '모델을 찾을 수 없어요';
    else if (code === 429) head = quota ? '요청 한도를 넘었어요. 잠시 후 다시 시도해 주세요' : 'Gemini 서버가 지금 붐벼서 요청을 처리하지 못했어요. 한도 문제는 아니에요. 잠시 후 다시 시도해 주세요 (429)';
    else if (code >= 500 && code <= 599) head = 'Gemini 서버에 문제가 있어요. 잠시 후 다시 시도해 주세요';
    else head = '오류가 났어요 (' + code + ')';
    // 구글이 주는 설명은 영어라서 한글이 든 것만 덧붙인다
    return !msg || !/[가-힣]/.test(msg) ? head : head + '\n' + msg;
  }
  function searchRejectedMessage(model, body) {
    var g = googleMessage(body);
    return '이 모델(' + labelOf(model) + ')은 웹 검색을 받지 못했어요' + (g ? '\n구글 응답: ' + g.slice(0, 200) : '');
  }
  function emptyMessage(step) {
    if (step.blocked) return '요청이 안전 정책에 의해 차단되었어요 (' + step.blocked + ')';
    if (step.finish === 'MALFORMED_FUNCTION_CALL') return 'AI가 도구를 잘못 불러서 멈췄어요. 다시 시도해 주세요';
    if (step.finish && step.finish !== 'STOP') return '응답이 비어 있어요 (' + step.finish + ')';
    return '응답이 비어 있어요';
  }
  // 응답의 usageMetadata 에서 토큰 수 (보낸 쪽 = 질문 + 도구 설명, 받은 쪽 = 답 + 생각)
  function tokensOf(meta) {
    if (!meta) return { inTok: 0, outTok: 0 };
    return { inTok: (meta.promptTokenCount | 0) + (meta.toolUsePromptTokenCount | 0), outTok: (meta.candidatesTokenCount | 0) + (meta.thoughtsTokenCount | 0) };
  }

  function create(opts) {
    var now = (opts && opts.now) || Date.now;
    var models = new Models();
    var pool = new KeyPool({ now: now, models: models });
    return { models: models, pool: pool, auto: new Auto(pool, models), thinking: new Thinking(), search: new SearchGate(now) };
  }
  return { create: create, Models: Models, KeyPool: KeyPool, Auto: Auto, Thinking: Thinking, SearchGate: SearchGate, labelOf: labelOf, versionOf: versionOf, cmpVer: cmpVer,
    FAMILY: FAMILY, DEFAULT_IDS: DEFAULT_IDS, isEnding: isEnding, safetySettings: safetySettings, networkErrorMessage: networkErrorMessage,
    describeError: describeError, searchRejectedMessage: searchRejectedMessage, emptyMessage: emptyMessage, tokensOf: tokensOf, remainText: remainText };
});
