'use strict';
// 크롬 테마(manifest.theme.colors) → 앱 색 변수. 이미지(theme_frame 등)는 쓰지 않고 색만 옮긴다.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvTheme = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  function rgb(v) {
    if (!Array.isArray(v) || v.length < 3) return null;
    var a = [0, 1, 2].map(function (i) { var n = Number(v[i]); return isFinite(n) ? Math.max(0, Math.min(255, Math.round(n))) : null; });
    return a.indexOf(null) >= 0 ? null : a;
  }
  var hex = function (c) { return '#' + c.map(function (n) { return (n < 16 ? '0' : '') + n.toString(16); }).join(''); };
  var lum = function (c) { var f = function (n) { n /= 255; return n <= 0.03928 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
  var mix = function (a, b, t) { return a.map(function (x, i) { return Math.round(x * (1 - t) + b[i] * t); }); };
  // 배경 위에서 읽히는 글자색: 원하는 색이 대비가 모자라면 흑/백으로
  function readable(bg, want) {
    var L = lum(bg), contrast = function (c) { var l = lum(c); return (Math.max(L, l) + 0.05) / (Math.min(L, l) + 0.05); };
    if (want && contrast(want) >= 3.5) return want;
    return contrast([255, 255, 255]) >= contrast([20, 20, 20]) ? [255, 255, 255] : [20, 20, 20];
  }
  // → { vars: { '--bg': '#...' ... }, dark: bool } 또는 색이 하나도 없으면 null
  function themeVars(manifest) {
    var th = manifest && manifest.theme, c = th && th.colors;
    if (!c || typeof c !== 'object') return null;
    var frame = rgb(c.frame) || rgb(c.frame_inactive), toolbar = rgb(c.toolbar), omni = rgb(c.omnibox_background), ntp = rgb(c.ntp_background);
    if (!frame && !toolbar && !omni) return null;
    var bg = frame || toolbar || omni, surface = toolbar || frame || omni;
    var dark = lum(surface) < 0.35;
    var text = readable(surface, rgb(c.toolbar_text) || rgb(c.bookmark_text) || rgb(c.tab_text));
    var white = [255, 255, 255], black = [0, 0, 0];
    var pill = omni || mix(surface, dark ? white : black, 0.08);
    var vars = {
      '--bg': hex(bg), '--surface': hex(surface), '--pill': hex(pill), '--pill-high': hex(mix(pill, dark ? white : black, 0.08)),
      '--line': hex(mix(surface, dark ? white : black, 0.14)), '--text': hex(text), '--muted': hex(mix(text, surface, 0.38)),
      '--hover': 'rgba(' + (dark ? '255,255,255' : '0,0,0') + ',.10)',
    };
    var accent = rgb(c.button_background) || rgb(c.ntp_link) || rgb(c.ntp_header);
    if (accent) { vars['--accent'] = hex(accent); vars['--accent-soft'] = hex(mix(surface, accent, 0.18)); vars['--on-accent-soft'] = hex(readable(mix(surface, accent, 0.18), null)); }
    if (ntp) vars['--ntp'] = hex(ntp);
    return { vars: vars, dark: dark };
  }
  function apply(theme, el) {
    var st = (el || document.documentElement).style, KEYS = ['--bg', '--surface', '--pill', '--pill-high', '--line', '--text', '--muted', '--hover', '--accent', '--accent-soft', '--on-accent-soft', '--ntp'];
    KEYS.forEach(function (k) { st.removeProperty(k); });
    if (theme && theme.vars) Object.keys(theme.vars).forEach(function (k) { st.setProperty(k, theme.vars[k]); });
  }
  return { themeVars: themeVars, apply: apply };
});
