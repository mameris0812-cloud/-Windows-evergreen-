'use strict';
// AI 답변 속 수학식( $…$ · $$…$$ · \(…\) · \[…\] )을 MathML 로 바꾼다 (크로미엄이 그대로 그려 준다).
// 그리스 문자 · 연산 기호 · 위/아래 첨자 · 분수 · 제곱근 · 윗줄 · 벡터 · 행렬/연립식(cases)·합/극한/적분을 읽고,
// 알 수 없는 식이 나오면 원문 그대로 둔다(식 하나가 깨져도 답변 전체는 멀쩡하게).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvMath = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var GREEK = { alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', epsilon: 'ε', varepsilon: 'ε', zeta: 'ζ', eta: 'η', theta: 'θ', vartheta: 'ϑ', iota: 'ι', kappa: 'κ', lambda: 'λ', mu: 'μ', nu: 'ν', xi: 'ξ', omicron: 'ο', pi: 'π', varpi: 'ϖ', rho: 'ρ', varrho: 'ϱ', sigma: 'σ', varsigma: 'ς', tau: 'τ', upsilon: 'υ', phi: 'φ', varphi: 'φ', chi: 'χ', psi: 'ψ', omega: 'ω' };
  var SYM = { Gamma: 'Γ', Delta: 'Δ', Theta: 'Θ', Lambda: 'Λ', Xi: 'Ξ', Pi: 'Π', Sigma: 'Σ', Upsilon: 'Υ', Phi: 'Φ', Psi: 'Ψ', Omega: 'Ω',
    times: '×', div: '÷', cdot: '·', pm: '±', mp: '∓', circ: '∘', ast: '∗', star: '⋆', bullet: '•', oplus: '⊕', otimes: '⊗', odot: '⊙', setminus: '∖',
    leq: '≤', le: '≤', leqslant: '≤', geq: '≥', ge: '≥', geqslant: '≥', neq: '≠', ne: '≠', approx: '≈', equiv: '≡', sim: '∼', simeq: '≃', cong: '≅', propto: '∝', ll: '≪', gg: '≫',
    in: '∈', notin: '∉', ni: '∋', subset: '⊂', supset: '⊃', subseteq: '⊆', supseteq: '⊇', cup: '∪', cap: '∩', emptyset: '∅', varnothing: '∅',
    forall: '∀', exists: '∃', nexists: '∄', neg: '¬', lnot: '¬', land: '∧', wedge: '∧', lor: '∨', vee: '∨', infty: '∞', partial: '∂', nabla: '∇',
    to: '→', rightarrow: '→', leftarrow: '←', leftrightarrow: '↔', Rightarrow: '⇒', Leftarrow: '⇐', Leftrightarrow: '⇔', iff: '⇔', implies: '⟹', mapsto: '↦', uparrow: '↑', downarrow: '↓',
    ldots: '…', cdots: '⋯', vdots: '⋮', ddots: '⋱', dots: '…', angle: '∠', triangle: '△', perp: '⊥', parallel: '∥', degree: '°', prime: '′', hbar: 'ℏ', ell: 'ℓ', Re: 'ℜ', Im: 'ℑ', aleph: 'ℵ',
    therefore: '∴', because: '∵', mid: '∣', lvert: '|', rvert: '|', lVert: '‖', rVert: '‖', Vert: '‖', vert: '|', langle: '⟨', rangle: '⟩', lfloor: '⌊', rfloor: '⌋', lceil: '⌈', rceil: '⌉',
    lbrace: '{', rbrace: '}', backslash: '\\', quad: ' ', qquad: '  ', ',': ' ', ';': ' ', ':': ' ', '!': '', '%': '%', '&': '&', '$': '$', '#': '#', '_': '_', '{': '{', '}': '}', ' ': ' ' };
  var FUNCS = ['sin', 'cos', 'tan', 'cot', 'sec', 'csc', 'arcsin', 'arccos', 'arctan', 'sinh', 'cosh', 'tanh', 'log', 'ln', 'lg', 'exp', 'det', 'dim', 'ker', 'gcd', 'lcm', 'max', 'min', 'sup', 'inf', 'lim', 'liminf', 'limsup', 'Pr', 'arg', 'deg', 'mod'];
  var BIG = { sum: '∑', prod: '∏', coprod: '∐', int: '∫', iint: '∬', iiint: '∭', oint: '∮', bigcup: '⋃', bigcap: '⋂', bigoplus: '⨁', bigotimes: '⨂' };
  var ACCENT = { overline: '‾', bar: '¯', hat: '^', widehat: '^', tilde: '~', widetilde: '~', vec: '→', dot: '˙', ddot: '¨', overrightarrow: '→' };
  var OPEN = '([{⟨⌊⌈|‖', CLOSE = ')]}⟩⌋⌉|‖';
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }

  function tokenize(src) {
    var t = [], i = 0, n = src.length;
    while (i < n) {
      var c = src[i];
      if (c === '\\') {
        var j = i + 1;
        if (j < n && /[A-Za-z]/.test(src[j])) { while (j < n && /[A-Za-z]/.test(src[j])) j++; t.push({ k: 'cmd', v: src.slice(i + 1, j) }); }
        else if (j < n) { t.push({ k: 'cmd', v: src[j] }); j++; }
        else j = n;
        i = j;
      } else if (/\s/.test(c)) i++;
      else { t.push({ k: c === '{' ? 'lb' : c === '}' ? 'rb' : 'ch', v: c }); i++; }
    }
    return t;
  }
  function P(tokens) { this.t = tokens; this.i = 0; }
  P.prototype.peek = function () { return this.t[this.i]; };
  P.prototype.next = function () { return this.t[this.i++]; };
  // 식 하나(원자) 읽기: 중괄호 묶음 · 명령 · 글자 하나
  P.prototype.group = function () {
    var tk = this.next();
    if (!tk) throw new Error('끝');
    if (tk.k === 'lb') { var inner = this.seq(function (x) { return x.k === 'rb'; }); if (!this.next()) throw new Error('중괄호'); return inner; }
    this.i--; return this.atom();
  };
  P.prototype.text = function () { // \text{...} 속 글자를 그대로
    var tk = this.next();
    if (!tk || tk.k !== 'lb') throw new Error('text');
    var d = 1, s = '';
    for (;;) { var x = this.next(); if (!x) throw new Error('text 끝'); if (x.k === 'lb') d++; else if (x.k === 'rb') { d--; if (!d) break; } s += x.k === 'cmd' ? (SYM[x.v] || '') : x.v; }
    return s;
  };
  P.prototype.seq = function (stop) {
    var out = [];
    while (this.i < this.t.length && !stop(this.t[this.i])) {
      var a = this.script(); if (a !== null) out.push(a);
    }
    return out.length === 1 ? out[0] : '<mrow>' + out.join('') + '</mrow>';
  };
  // 원자 + 뒤따르는 ^ _ (합·극한·적분은 위아래 한도)
  P.prototype.script = function () {
    var base = this.atom(), sub = null, sup = null, isBig = this.lastBig;
    for (;;) {
      var tk = this.peek();
      if (tk && tk.k === 'ch' && tk.v === '^') { this.next(); sup = this.group(); }
      else if (tk && tk.k === 'ch' && tk.v === '_') { this.next(); sub = this.group(); }
      else if (tk && tk.k === 'ch' && tk.v === "'") { this.next(); sup = '<mo>′</mo>'; }
      else break;
    }
    var limits = this.lastLimits; this.lastBig = false; this.lastLimits = false;
    if (sub === null && sup === null) return base;
    if (limits || isBig) {
      var tag = limits ? (sub !== null && sup !== null ? 'munderover' : sub !== null ? 'munder' : 'mover') : (sub !== null && sup !== null ? 'msubsup' : sub !== null ? 'msub' : 'msup');
      return '<' + tag + '>' + base + (sub !== null ? sub : '') + (sup !== null ? sup : '') + '</' + tag + '>';
    }
    return sub !== null && sup !== null ? '<msubsup>' + base + sub + sup + '</msubsup>' : sub !== null ? '<msub>' + base + sub + '</msub>' : '<msup>' + base + sup + '</msup>';
  };
  function mi(s) { return '<mi>' + esc(s) + '</mi>'; }
  function mo(s) { return '<mo>' + esc(s) + '</mo>'; }
  P.prototype.atom = function () {
    var tk = this.next();
    if (!tk) throw new Error('끝');
    this.lastBig = false; this.lastLimits = false;
    if (tk.k === 'lb') { this.i--; return this.group(); }
    if (tk.k === 'rb') throw new Error('닫는 중괄호');
    if (tk.k === 'ch') {
      var c = tk.v;
      if (/[0-9.]/.test(c)) { var s = c; while (this.peek() && this.peek().k === 'ch' && /[0-9.]/.test(this.peek().v)) s += this.next().v; return '<mn>' + s + '</mn>'; }
      if (/[A-Za-z]/.test(c)) return mi(c);
      if (c === '^' || c === '_') throw new Error('첨자 앞에 식이 없어요');
      if (c === '(' || c === '[') { // 괄호 묶음 전체가 위/아래 첨자의 밑이 되게 한다: (x-1)^2
        var closer = c === '(' ? ')' : ']', save = this.i, depth = 0, j = this.i;
        for (; j < this.t.length; j++) { var q = this.t[j]; if (q.k === 'ch' && (q.v === '(' || q.v === '[')) depth++; else if (q.k === 'ch' && (q.v === ')' || q.v === ']')) { if (depth === 0) break; depth--; } else if (q.k === 'cmd' && q.v === 'right') break; }
        if (j < this.t.length && this.t[j].k === 'ch' && this.t[j].v === closer) {
          var inner = this.seq(function (x) { return x.k === 'ch' && x.v === closer; }); this.next();
          return '<mrow><mo lspace="0" rspace="0">' + c + '</mo>' + inner + '<mo lspace="0" rspace="0">' + closer + '</mo></mrow>';
        }
        this.i = save;
        return '<mo lspace="0" rspace="0">' + c + '</mo>';
      }
      if (c === ')' || c === ']') return '<mo lspace="0" rspace="0">' + c + '</mo>';
      if (c === ',' || c === ';') return '<mo lspace="0" rspace="0.33em">' + c + '</mo>';
      if ('+-=<>/*:!?|~'.indexOf(c) >= 0) return mo(c === '-' ? '−' : c === '*' ? '∗' : c === '~' ? ' ' : c);
      return /[가-힣]/.test(c) ? '<mtext>' + esc(c) + '</mtext>' : mo(c);
    }
    var v = tk.v;
    if (v === 'frac' || v === 'dfrac' || v === 'tfrac') { var a = this.group(), b = this.group(); return '<mfrac>' + a + b + '</mfrac>'; }
    if (v === 'binom') { var n1 = this.group(), k1 = this.group(); return mo('(') + '<mfrac linethickness="0">' + n1 + k1 + '</mfrac>' + mo(')'); }
    if (v === 'sqrt') {
      var nx = this.peek();
      if (nx && nx.k === 'ch' && nx.v === '[') { this.next(); var idx = this.seq(function (x) { return x.k === 'ch' && x.v === ']'; }); this.next(); return '<mroot>' + this.group() + idx + '</mroot>'; }
      return '<msqrt>' + this.group() + '</msqrt>';
    }
    if (v === 'text' || v === 'mathrm' || v === 'textrm' || v === 'mbox' || v === 'operatorname') { var tx = this.text(); return v === 'operatorname' ? '<mi mathvariant="normal">' + esc(tx) + '</mi>' : '<mtext>' + esc(tx).replace(/ /g, '&#160;') + '</mtext>'; }
    if (v === 'mathbf' || v === 'boldsymbol' || v === 'bm') return '<mstyle mathvariant="bold">' + this.group() + '</mstyle>';
    if (v === 'mathbb') { var bb = this.text(); return '<mi>' + esc(bb.replace(/[A-Z]/g, function (ch) { return { R: 'ℝ', N: 'ℕ', Z: 'ℤ', Q: 'ℚ', C: 'ℂ', P: 'ℙ', E: '𝔼' }[ch] || ch; })) + '</mi>'; }
    if (v === 'mathcal' || v === 'mathit' || v === 'mathsf' || v === 'mathscr') return this.group();
    if (ACCENT[v]) { var body = this.group(); return '<mover accent="true">' + body + mo(ACCENT[v]) + '</mover>'; }
    if (v === 'underline') return '<munder>' + this.group() + mo('_') + '</munder>';
    if (v === 'overbrace' || v === 'underbrace') { var bd = this.group(); return (v === 'overbrace' ? '<mover>' : '<munder>') + bd + mo(v === 'overbrace' ? '⏞' : '⏟') + (v === 'overbrace' ? '</mover>' : '</munder>'); }
    if (v === 'left') { var d1 = this.delim(); var inner = this.seq(function (x) { return x.k === 'cmd' && x.v === 'right'; }); this.next(); var d2 = this.delim(); return '<mrow>' + (d1 ? '<mo fence="true" stretchy="true">' + esc(d1) + '</mo>' : '') + inner + (d2 ? '<mo fence="true" stretchy="true">' + esc(d2) + '</mo>' : '') + '</mrow>'; }
    if (v === 'right') throw new Error('right');
    if (v === 'bigl' || v === 'Bigl' || v === 'biggl' || v === 'bigr' || v === 'Bigr' || v === 'biggr' || v === 'big' || v === 'Big') { var d = this.delim(); return d ? mo(d) : ''; }
    if (v === 'begin') return this.env();
    if (v === 'end') throw new Error('end');
    if (v === 'limits' || v === 'nolimits' || v === 'displaystyle' || v === 'textstyle' || v === 'scriptstyle' || v === 'nonumber' || v === 'label') return '';
    if (v === 'not') { var nxt = this.atom(); return '<mrow>' + nxt + mo('̸') + '</mrow>'; }
    if (GREEK[v]) return mi(GREEK[v]);
    if (BIG[v]) { this.lastBig = true; this.lastLimits = (v === 'sum' || v === 'prod' || v === 'coprod' || v.indexOf('big') === 0); return '<mo largeop="true">' + BIG[v] + '</mo>'; }
    if (v === 'lim' || v === 'liminf' || v === 'limsup' || v === 'max' || v === 'min' || v === 'sup' || v === 'inf') { this.lastLimits = true; return '<mi mathvariant="normal">' + v + '</mi>'; }
    if (FUNCS.indexOf(v) >= 0) return '<mi mathvariant="normal">' + v + '</mi><mo>&#8289;</mo>';
    if (v in SYM) { var s2 = SYM[v]; return /^[A-ZΑ-Ω]$/.test(s2) ? mi(s2) : s2 === ' ' || s2 === '  ' ? '<mspace width="' + (s2.length * 0.5) + 'em"/>' : s2 === '' ? '' : mo(s2); }
    throw new Error('모르는 명령 ' + v);
  };
  P.prototype.delim = function () {
    var tk = this.next(); if (!tk) throw new Error('구분 기호');
    if (tk.k === 'ch') return tk.v === '.' ? '' : tk.v;
    if (tk.k === 'cmd') return tk.v in SYM ? SYM[tk.v] : (function () { throw new Error('구분 기호'); })();
    throw new Error('구분 기호');
  };
  // \begin{환경} … \end{환경}: 행렬 · 연립식 · 정렬
  P.prototype.env = function () {
    var name = this.text(), rows = [[]], cell = [];
    var self = this, end = false;
    function flushCell() { rows[rows.length - 1].push(cell.length === 1 ? cell[0] : '<mrow>' + cell.join('') + '</mrow>'); cell = []; }
    while (this.i < this.t.length) {
      var tk = this.peek();
      if (tk.k === 'cmd' && tk.v === 'end') { this.next(); this.text(); end = true; break; }
      if (tk.k === 'cmd' && tk.v === '\\') { this.next(); flushCell(); rows.push([]); continue; }
      if (tk.k === 'ch' && tk.v === '&') { this.next(); flushCell(); continue; }
      cell.push(self.script());
    }
    if (!end) throw new Error('end 없음');
    flushCell();
    if (rows.length > 1 && rows[rows.length - 1].length === 1 && rows[rows.length - 1][0] === '<mrow></mrow>') rows.pop();
    var table = '<mtable' + (/^(aligned|align|split|eqnarray)\*?$/.test(name) ? ' columnalign="right left" columnspacing="0"' : name === 'cases' ? ' columnalign="left left"' : '') + '>' + rows.map(function (r) { return '<mtr>' + r.map(function (c) { return '<mtd>' + c + '</mtd>'; }).join('') + '</mtr>'; }).join('') + '</mtable>';
    var pair = { pmatrix: '()', bmatrix: '[]', Bmatrix: '{}', vmatrix: '||', Vmatrix: '‖‖', cases: '{.' }[name];
    if (!pair) return table;
    return '<mrow>' + mo(pair[0]).replace('<mo>', '<mo fence="true" stretchy="true">') + table + (pair[1] === '.' ? '' : mo(pair[1]).replace('<mo>', '<mo fence="true" stretchy="true">')) + '</mrow>';
  };
  // tex(달러 기호 · 괄호 빼고 식만) → <math>…</math>. 읽지 못하면 null
  function toMathML(tex, display) {
    try {
      var p = new P(tokenize(String(tex).trim()));
      var out = p.seq(function () { return false; });
      return '<math xmlns="http://www.w3.org/1998/Math/MathML"' + (display ? ' display="block"' : '') + '>' + out + '</math>';
    } catch (e) { return null; }
  }
  // 글 속 수식 찾기: 1=$$…$$  2=\[…\]  3=\(…\)  4=$…$  (달러 금액 "$5 … $10" 은 수식으로 보지 않는다)
  var MATH_RE = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|(?<![\\$])\$(?![\s$])([^$\n]+?)(?<![\s\\])\$(?!\d)/g;
  function newRe() { return new RegExp(MATH_RE.source, 'g'); }
  // 글(이미 HTML 이스케이프 전의 원문) → 수식 자리표시자 목록. replace(text, fn) 에 쓴다
  function replaceAll(text, fn) {
    return String(text).replace(newRe(), function (m, a, b, c, d) {
      var tex = a != null ? a : b != null ? b : c != null ? c : d, display = a != null || b != null;
      return fn(tex, display, m);
    });
  }
  // 한 줄 글(대화 기록 제목 등) 속 수식을 보이는 기호로 (MathML 이 아니라 글자만)
  function plain(text) {
    return replaceAll(text, function (tex, _d, m) {
      var s = String(tex).replace(/\\(?:left|right|displaystyle)\b/g, '').replace(/\\frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g, '($1)/($2)').replace(/\\sqrt\s*\{([^{}]*)\}/g, '√($1)')
        .replace(/\\([A-Za-z]+)/g, function (x, n) { return GREEK[n] || SYM[n] || (BIG[n]) || n; }).replace(/[{}]/g, '').replace(/\^2/g, '²').replace(/\^3/g, '³').replace(/\s+/g, ' ').trim();
      return s || m;
    });
  }
  return { toMathML: toMathML, replaceAll: replaceAll, plain: plain };
});
