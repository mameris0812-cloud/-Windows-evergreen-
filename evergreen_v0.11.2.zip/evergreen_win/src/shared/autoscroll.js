'use strict';
// 자동 스크롤의 순수 규칙 (안드로이드 AutoScroller / Prefs 와 같은 값·같은 식).
// 메인(main/autoscroll.js) · 설정 화면(overlay/overlay-scroll.js) · 조작 막대(ascroll/) · 테스트가 함께 쓴다.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvAutoScroll = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var MIN_LEVEL = 1, MAX_LEVEL = 50, DEFAULT_LEVEL = 6, DEFAULT_CONTENT_LEVEL = 15, DEFAULT_BLANK_LEVEL = 40;
  var DEFAULTS = {
    speed: DEFAULT_LEVEL,           // 일반 속도 단계
    smart: false,                   // 스마트 자동 스크롤
    contentLevel: DEFAULT_CONTENT_LEVEL, // 스마트: 내용(글·그림)이 보일 때
    blankLevel: DEFAULT_BLANK_LEVEL,     // 스마트: 빈 그림이 보일 때
    touch: 0,                       // 0 = 만지는 동안만 멈췄다가 이어서, 1 = 완전히 멈춤
    controls: true,                 // 화면 아래 조작 막대
    pauseAtEnd: true,               // 웹툰 끝에서 멈춤
  };
  var TUNING = {
    SMART_SAMPLE_MS: 120,   // 화면을 훑어 보는 간격
    SMART_FLAT_RANGE: 14,   // 한 줄 안의 밝기 차이가 이 이하면 '한 색'
    SMART_EDGE: 24,         // 이웃 칸의 밝기 차이가 이 값을 넘으면 경계
    SMART_TAU_DOWN: 0.12,   // 내용이 나타날 땐 빠르게 줄이고
    SMART_TAU_UP: 0.45,     // 빈 그림에선 느긋하게 올린다 (초)
    RESUME_DELAY_MS: 500,   // 손을 떼고 이만큼 지나 다시 흐른다
    WHEEL_HOLD_MS: 900,     // 휠을 굴린 뒤 이만큼 쉰다
    END_FADE_MS: 900,       // 조작 막대 없이 웹툰 끝에서 서서히 느려지다 멈추는 시간
    END_HOLD_MS: 1500,      // 페이지 맨 아래에 닿은 채 이만큼 지나면 멈춘다
    END_PROBE_MS: 400,      // 웹툰 끝 확인 간격
    END_NEAR_PX: 12,        // 마지막 컷 아래 끝까지 이 이내면 끝
    END_REARM_PX: 300,      // 끝에서 이만큼 넘게 떨어지면 다시 감지
    END_EXTRA_PX: 310,      // 끝을 확인한 뒤 이만큼 더 내려가서 멈춘다
  };

  function clampLevel(v, def) {
    var n = Math.round(Number(v));
    if (!isFinite(n)) n = def == null ? DEFAULT_LEVEL : def;
    return Math.max(MIN_LEVEL, Math.min(MAX_LEVEL, n));
  }
  // 저장된 값(빠진 것 · 엉뚱한 것 섞임)을 안전한 설정으로
  function normalize(o) {
    o = o && typeof o === 'object' ? o : {};
    var out = {
      speed: clampLevel(o.speed, DEFAULTS.speed),
      smart: o.smart === true,
      contentLevel: clampLevel(o.contentLevel, DEFAULTS.contentLevel),
      blankLevel: clampLevel(o.blankLevel, DEFAULTS.blankLevel),
      touch: o.touch === 1 ? 1 : 0,
      controls: o.controls !== false,
      pauseAtEnd: o.pauseAtEnd !== false,
    };
    return out;
  }
  // 1단계 = 초당 25 화면 점(dip). 50단계 = 1250
  function dipPerSecond(level) { return 25 * Math.max(MIN_LEVEL, Math.min(MAX_LEVEL, Number(level) || MIN_LEVEL)); }
  // 화면 한 장(높이 h dip)을 내려가는 데 걸리는 시간(초)
  function screenSeconds(level, h) { return h / dipPerSecond(level); }
  function secondsLabel(sec) { return sec >= 10 ? String(Math.round(sec)) + '초' : (Math.round(sec * 10) / 10).toFixed(1) + '초'; }

  // 스마트: 빈 줄 비율(0~1) → 목표 단계. 35% 이하는 내용, 85% 이상은 빈 그림, 사이는 부드럽게
  function smartTarget(frac, contentLevel, blankLevel) {
    var c = contentLevel, b = Math.max(blankLevel, contentLevel);
    var x = Math.max(0, Math.min(1, (frac - 0.35) / 0.5));
    var t = x * x * (3 - 2 * x);
    return c + (b - c) * t;
  }
  // 이번 프레임의 단계: 목표를 향해 지수적으로 따라간다 (줄어들 땐 빠르게, 늘어날 땐 느긋하게)
  function smartFollow(cur, target, dt, contentLevel, blankLevel) {
    var tau = target < cur ? TUNING.SMART_TAU_DOWN : TUNING.SMART_TAU_UP;
    var next = cur + (target - cur) * (1 - Math.exp(-dt / tau));
    return Math.max(contentLevel, Math.min(Math.max(blankLevel, contentLevel), next));
  }

  // 화면 가운데 띠를 작게 줄인 그림(픽셀 배열 · 줄 순서 B,G,R,A 또는 R,G,B,A)에서 '빈 줄' 의 비율.
  // 빈 줄 = 줄 안에서 색이 크게 바뀌는 곳이 2번 이하이고, 그 사이 구간이 각각 거의 한 색인 줄.
  function blankFraction(px, w, h, bgra) {
    if (!(w > 0 && h > 0)) return 0;
    var ri = bgra ? 2 : 0, bi = bgra ? 0 : 2, blank = 0;
    for (var y = 0; y < h; y++) {
      var o = y * w * 4, edges = 0, flat = true, prev = 0, mn = 255, mx = 0;
      for (var x = 0; x < w; x++) {
        var p = o + x * 4;
        var l = (px[p + ri] * 299 + px[p + 1] * 587 + px[p + bi] * 114) / 1000;
        if (x > 0 && Math.abs(l - prev) > TUNING.SMART_EDGE) {
          if (mx - mn > TUNING.SMART_FLAT_RANGE) flat = false;
          edges++; mn = 255; mx = 0;
          if (edges > 2) break;
        }
        if (l < mn) mn = l;
        if (l > mx) mx = l;
        prev = l;
      }
      if (mx - mn > TUNING.SMART_FLAT_RANGE) flat = false;
      if (edges <= 2 && flat) blank++;
    }
    return blank / h;
  }

  // 웹툰 끝 감지(페이지 안에서 돈다): 폭 60%↑ 그림(img·canvas, 없으면 배경그림 요소)을 세로로 이어진 덩어리로 묶어
  // 가장 큰 덩어리(컷 3장↑ 또는 화면 3배↑)를 웹툰 본문으로 보고 '본문 아래 끝 − 화면 아래 끝'(CSS px)을 돌려준다.
  // 아직 불러오는 중인 그림이 아래에 있으면 '9999', 웹툰이 아니면 빈 문자열. (안드로이드 END_PROBE_JS 그대로)
  var END_PROBE_JS =
    '(function(){try{\n' +
    'var W=innerWidth,H=innerHeight,sy=scrollY,TW=Math.min(W*0.6,480),L=[],P=[],i,r,c,m;\n' +
    'function ok(e){c=getComputedStyle(e);return !(c.position==\'fixed\'||c.display==\'none\'||c.visibility==\'hidden\')}\n' +
    'var I=document.images;\n' +
    'for(i=0;i<I.length;i++){m=I[i];if(!ok(m))continue;r=m.getBoundingClientRect();\n' +
    'if((!m.complete||m.naturalWidth==0)&&(r.width>=TW||m.getAttribute(\'data-src\')||m.getAttribute(\'data-original\')||m.loading==\'lazy\'))P.push(r.top+sy);\n' +
    'if(r.width>=TW&&r.height>=40)L.push([r.top+sy,r.bottom+sy])}\n' +
    'var C=document.querySelectorAll(\'canvas\');\n' +
    'for(i=0;i<C.length;i++){m=C[i];if(!ok(m))continue;r=m.getBoundingClientRect();if(r.width>=TW&&r.height>=40)L.push([r.top+sy,r.bottom+sy])}\n' +
    'function best(){L.sort(function(a,b){return a[0]-b[0]});\n' +
    'var bb=-1,bn=0,bh=-1,t=0,n=0,e=-1;\n' +
    'for(var k=0;k<L.length;k++){var a=L[k];\n' +
    'if(n>0&&a[0]-e>250){if(t>bh){bh=t;bb=e;bn=n}t=0;n=0;e=-1}\n' +
    't+=a[1]-(e<0?a[0]:Math.max(a[0],e));n++;if(a[1]>e)e=a[1]}\n' +
    'if(n>0&&t>bh){bh=t;bb=e;bn=n}\n' +
    'return(bn>=3||bh>=H*3)?bb:-1}\n' +
    'var b=best();\n' +
    'if(b<0){var E=document.querySelectorAll(\'div,figure,section,li,a\'),lim=Math.min(E.length,1500);\n' +
    'for(i=0;i<lim;i++){m=E[i];r=m.getBoundingClientRect();if(r.width<TW||r.height<40)continue;\n' +
    'c=getComputedStyle(m);if(c.backgroundImage!=\'none\'&&c.visibility!=\'hidden\'&&c.position!=\'fixed\')L.push([r.top+sy,r.bottom+sy])}\n' +
    'b=best()}\n' +
    'if(b<0)return \'\';\n' +
    'var pend=0;for(i=0;i<P.length;i++){if(P[i]>sy+H*0.5&&P[i]<=b+400)pend++}\n' +
    'return pend>0?\'9999\':String(Math.round(b-(sy+H)))\n' +
    '}catch(e){return \'\'}})()\n';

  // 페이지 안에서 매 화면 프레임마다 부드럽게 내려가는 운전자. 메인이 speed(CSS px/초)·run 만 바꾼다.
  // 창이 안 움직이는 페이지(안쪽 칸이 스크롤되는 뷰어)는 가장 큰 스크롤 칸을 대신 굴린다.
  var DRIVER_JS =
    '(function(){\n' +
    'if(window.__evAS&&window.__evAS.alive){return window.__evAS.reset()}\n' +
    'var S=window.__evAS={alive:true,run:false,speed:0,carry:0,last:0,moved:false,el:null,raf:0,tn:0,esc:0,down:0,downAt:0,holdUntil:0,lastTop:null};\n' +
    'var WHEEL=' + TUNING.WHEEL_HOLD_MS + ',RESUME=' + TUNING.RESUME_DELAY_MS + ';\n' +
    'function root(){return document.scrollingElement||document.documentElement}\n' +
    'function room(e){return e.scrollHeight-e.clientHeight}\n' +
    'function pick(){var r=root();if(room(r)>8)return r;\n' +
    'var best=null,bh=0,A=document.querySelectorAll(\'div,main,section,article\'),n=Math.min(A.length,2500);\n' +
    'for(var i=0;i<n;i++){var e=A[i];if(e.clientHeight<innerHeight*0.5||e.clientWidth<innerWidth*0.4)continue;\n' +
    'var o=getComputedStyle(e).overflowY;if((o==\'auto\'||o==\'scroll\')&&room(e)>bh){bh=room(e);best=e}}\n' +
    'return best||r}\n' +
    'function top(e){return e===root()?(window.pageYOffset||e.scrollTop):e.scrollTop}\n' +
    'function hold(ms){S.holdUntil=Math.max(S.holdUntil,performance.now()+ms)}\n' +
    // 사용자의 손길: 휠 · 클릭(누르는 동안) · 이동 키. 진짜 입력(isTrusted)만 본다
    'var O={capture:true,passive:true};\n' +
    'function dn(){return S.down>0&&performance.now()-S.downAt<15000}\n' +
    'function up(e){if(!e.isTrusted)return;if(e.button===0||e.type==\'pointercancel\')S.down=Math.max(0,S.down-1);hold(RESUME)}\n' +
    'addEventListener(\'wheel\',function(e){if(e.isTrusted){S.tn++;hold(WHEEL)}},O);\n' +
    'addEventListener(\'pointerdown\',function(e){if(!e.isTrusted)return;S.tn++;if(e.button===0){S.down++;S.downAt=performance.now()}},O);\n' +
    'addEventListener(\'pointerup\',up,O);addEventListener(\'pointercancel\',up,O);\n' +
    'addEventListener(\'blur\',function(){S.down=0},O);\n' +
    'addEventListener(\'keydown\',function(e){if(!e.isTrusted)return;\n' +
    'if(e.key==\'Escape\'){S.esc++;return}\n' +
    'if(/^(ArrowUp|ArrowDown|PageUp|PageDown|Home|End| )$/.test(e.key)&&!/^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement||{}).tagName||\'\')){S.tn++;hold(WHEEL)}},O);\n' +
    'function step(t){S.raf=requestAnimationFrame(step);\n' +
    'var dt=S.last?Math.min(0.05,(t-S.last)/1000):0;S.last=t;\n' +
    'var e=S.el;if(!e||!e.isConnected||(room(e)<=0&&e!==root()))e=S.el=pick();\n' +
    'var cur=top(e);\n' +
    // 우리가 굴린 게 아닌 움직임(스크롤바 끌기 등)은 손길로 본다
    'if(S.lastTop!==null&&Math.abs(cur-S.lastTop)>1.5)hold(WHEEL);\n' +
    'S.lastTop=cur;\n' +
    'if(!S.run||S.speed<=0||dn()||t<S.holdUntil){S.carry=0;return}\n' +
    'S.carry+=S.speed*dt;var dy=Math.floor(S.carry);if(dy<1)return;S.carry-=dy;\n' +
    'if(e===root())window.scrollBy({top:dy,left:0,behavior:\'instant\'});else e.scrollTo({top:e.scrollTop+dy,behavior:\'instant\'});\n' +
    'var nt=top(e);if(nt!==cur)S.moved=true;S.lastTop=nt}\n' +
    'S.reset=function(){S.run=false;S.speed=0;S.carry=0;S.last=0;S.moved=false;S.lastTop=null;S.el=pick();return 1};\n' +
    'S.set=function(run,speed){S.run=!!run;S.speed=+speed||0;if(!S.run){S.carry=0;S.last=0}};\n' +
    // 현재 위치 · 맨 아래까지 남은 거리(CSS px) · 화면 크기 · 만진 횟수
    'S.state=function(){var e=S.el||(S.el=pick());var r=e===root();\n' +
    'return JSON.stringify({y:top(e),remain:room(e)-top(e),max:room(e),w:r?innerWidth:e.clientWidth,h:r?innerHeight:e.clientHeight,\n' +
    'moved:S.moved,tn:S.tn,esc:S.esc,touching:dn(),hold:Math.max(0,S.holdUntil-performance.now())})};\n' +
    'S.stop=function(){S.alive=false;S.run=false;cancelAnimationFrame(S.raf)};\n' +
    'S.el=pick();S.raf=requestAnimationFrame(step);return 1;\n' +
    '})()';
  var STOP_JS = '(function(){try{if(window.__evAS){window.__evAS.stop();window.__evAS=null}}catch(e){}})()';

  return {
    MIN_LEVEL: MIN_LEVEL, MAX_LEVEL: MAX_LEVEL, DEFAULT_LEVEL: DEFAULT_LEVEL, DEFAULT_CONTENT_LEVEL: DEFAULT_CONTENT_LEVEL, DEFAULT_BLANK_LEVEL: DEFAULT_BLANK_LEVEL,
    DEFAULTS: DEFAULTS, TUNING: TUNING, clampLevel: clampLevel, normalize: normalize,
    dipPerSecond: dipPerSecond, screenSeconds: screenSeconds, secondsLabel: secondsLabel,
    smartTarget: smartTarget, smartFollow: smartFollow, blankFraction: blankFraction,
    END_PROBE_JS: END_PROBE_JS, DRIVER_JS: DRIVER_JS, STOP_JS: STOP_JS,
  };
});
