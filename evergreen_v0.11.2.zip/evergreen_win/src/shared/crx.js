'use strict';
// .crx(CRX2 · CRX3) 에서 zip 을 꺼내고, 크롬이 쓰는 확장 프로그램 ID 를 구한다.
const crypto = require('crypto');

const idFromBytes = (b16) => Array.from(b16).map((x) => String.fromCharCode(97 + (x >> 4)) + String.fromCharCode(97 + (x & 15))).join('');
const idFromKey = (der) => idFromBytes(crypto.createHash('sha256').update(der).digest().subarray(0, 16));

// 아주 작은 protobuf 읽기: [{ field, wire, value(Buffer|number) }]
function pb(buf) {
  const out = []; let p = 0;
  const varint = () => { let r = 0, s = 0, b; do { b = buf[p++]; r += (b & 0x7f) * Math.pow(2, s); s += 7; } while (b & 0x80 && p < buf.length); return r; };
  while (p < buf.length) {
    const tag = varint(), field = Math.floor(tag / 8), wire = tag & 7;
    if (wire === 0) out.push({ field, wire, value: varint() });
    else if (wire === 2) { const l = varint(); out.push({ field, wire, value: buf.subarray(p, p + l) }); p += l; }
    else if (wire === 1) { out.push({ field, wire, value: buf.subarray(p, p + 8) }); p += 8; }
    else if (wire === 5) { out.push({ field, wire, value: buf.subarray(p, p + 4) }); p += 4; }
    else throw new Error('crx 머리 형식을 읽지 못했어요');
  }
  return out;
}
const isCrx = (b) => b.length > 16 && b.toString('latin1', 0, 4) === 'Cr24';

// → { zip: Buffer, id: 'a-p 32자' | null, key: base64 | null }
function parseCrx(buf) {
  if (!isCrx(buf)) return { zip: buf, id: null, key: null };
  const ver = buf.readUInt32LE(4);
  if (ver === 2) {
    const kl = buf.readUInt32LE(8), sl = buf.readUInt32LE(12), key = buf.subarray(16, 16 + kl);
    return { zip: buf.subarray(16 + kl + sl), id: idFromKey(key), key: key.toString('base64') };
  }
  if (ver === 3) {
    const hl = buf.readUInt32LE(8), header = buf.subarray(12, 12 + hl), zip = buf.subarray(12 + hl);
    const fields = pb(header); let crxId = null; const keys = [];
    for (const f of fields) {
      if ((f.field === 2 || f.field === 3) && f.wire === 2) for (const g of pb(f.value)) if (g.field === 1 && g.wire === 2) keys.push(g.value);
      if (f.field === 10000 && f.wire === 2) for (const g of pb(f.value)) if (g.field === 1 && g.wire === 2) crxId = g.value;
    }
    const id = crxId ? idFromBytes(crxId) : null;
    const key = keys.find((k) => idFromKey(k) === id) || null;   // 서명 키 중 ID 와 맞는 것이 확장 프로그램의 공개 키
    return { zip, id, key: key ? key.toString('base64') : null };
  }
  throw new Error('지원하지 않는 crx 버전(' + ver + ')');
}
module.exports = { parseCrx, isCrx, idFromKey, idFromBytes };
