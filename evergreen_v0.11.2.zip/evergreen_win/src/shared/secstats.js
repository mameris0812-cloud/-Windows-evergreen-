'use strict';
// 차단 통계 (안드로이드 SecurityStats.kt + AdBlocker 의 통계 부분).
// - 종류별로 하루 단위 건수를 최근 7일치 모아 둔다 (보안 현황)
// - 광고 차단 현황: 전체 · 오늘 · 이번 실행 · 종류별 · 가장 많이 막은 사이트 · 최근 7일
// 저장소(JSON 으로 직렬화되는 객체)와 시계는 밖에서 넣어 준다 → 테스트 가능.
const { registrable } = require('./adengine');

const K = { AD: 0, POPUP: 1, TRACKER: 2, HIJACK: 3, AUTO_DL: 4, BACK: 5, MALWARE: 6, HTTPS: 7 };
const KINDS = 8;
/** 보안 현황에 들어가는 첫 종류 (AD·POPUP 은 광고 차단 현황 몫이라 보안 합계에서 뺀다) */
const FIRST_SECURITY = K.TRACKER;
const DAYS = 7;

class SecStats {
  /** @param saved 저장해 둔 값 { counts, total, since } 또는 null */
  constructor(saved, now) {
    this.now = now || (() => Date.now());
    this.counts = {};
    this.total = 0; // 광고 차단 전체 건수(평생)
    this.since = this.now();
    this.session = 0; this.requests = 0; this.popups = 0;
    this.hostStats = new Map();
    this.listeners = new Set();
    this.dirty = 0;
    if (saved && typeof saved === 'object') {
      Object.assign(this.counts, saved.counts || {});
      this.total = Number(saved.total) || 0;
      if (saved.since > 0) this.since = saved.since;
    }
    this._trim();
  }
  dayKey(t) {
    const ms = t == null ? this.now() : t;
    return Math.floor((ms - new Date(ms).getTimezoneOffset() * 60000) / 86400000);
  }
  _key(day, kind) { return 'd' + day + '_' + kind; }
  _trim() {
    const oldest = this.dayKey() - (DAYS - 1);
    for (const k of Object.keys(this.counts)) {
      const day = Number(k.replace(/^d/, '').split('_')[0]);
      if (!Number.isFinite(day) || day < oldest) delete this.counts[k];
    }
  }
  onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  _emit() { for (const fn of this.listeners) { try { fn(); } catch (e) { /* 듣는 쪽 오류는 무시 */ } } }

  /** 한 건 기록. host 는 광고 차단 현황의 '가장 많이 막은 곳' 용(광고·팝업만) */
  add(kind, host) {
    const key = this._key(this.dayKey(), kind);
    this.counts[key] = (this.counts[key] || 0) + 1;
    if (kind === K.AD || kind === K.POPUP) {
      this.total++; this.session++;
      if (kind === K.POPUP) this.popups++; else this.requests++;
      if (host) {
        const site = registrable(String(host).toLowerCase());
        this.hostStats.set(site, (this.hostStats.get(site) || 0) + 1);
        if (this.hostStats.size > 600) for (const [h, n] of this.hostStats) if (n <= 1) this.hostStats.delete(h);
      }
    }
    this.dirty++;
    this._emit();
  }
  count(day, kind) { return this.counts[this._key(day, kind)] || 0; }
  today(kind) { return this.count(this.dayKey(), kind); }
  dayTotal(day) { let s = 0; for (let k = FIRST_SECURITY; k < KINDS; k++) s += this.count(day, k); return s; }
  todayTotal() { return this.dayTotal(this.dayKey()); }
  weekTotal(kind) { const t = this.dayKey(); let s = 0; for (let i = 0; i < DAYS; i++) s += this.count(t - i, kind); return s; }
  /** 보안 합계: 오늘을 마지막으로 하는 최근 7일 (오래된 날 → 오늘) */
  week() { const t = this.dayKey(); return Array.from({ length: DAYS }, (_, i) => this.dayTotal(t - (DAYS - 1 - i))); }
  /** 지정한 종류만 합친 최근 7일 */
  weekOf(kinds) { const t = this.dayKey(); return Array.from({ length: DAYS }, (_, i) => kinds.reduce((s, k) => s + this.count(t - (DAYS - 1 - i), k), 0)); }
  top(n) { return [...this.hostStats.entries()].sort((a, b) => b[1] - a[1]).slice(0, n || 8); }
  /** 광고 차단 현황 한 장 */
  adSummary() {
    return { total: this.total, today: this.today(K.AD) + this.today(K.POPUP), session: this.session, requests: this.requests,
      popups: this.popups, since: this.since, top: this.top(8), week: this.weekOf([K.AD, K.POPUP]) };
  }
  resetAds() {
    for (const k of Object.keys(this.counts)) { const kind = Number(k.split('_')[1]); if (kind === K.AD || kind === K.POPUP) delete this.counts[k]; }
    this.total = 0; this.session = 0; this.requests = 0; this.popups = 0; this.hostStats.clear(); this.since = this.now();
    this.dirty++; this._emit();
  }
  /** 보안 기록만 지운다 (광고 차단 기록은 그대로) */
  resetSecurity() {
    for (const k of Object.keys(this.counts)) { const kind = Number(k.split('_')[1]); if (kind >= FIRST_SECURITY) delete this.counts[k]; }
    this.dirty++; this._emit();
  }
  serialize() { this._trim(); this.dirty = 0; return { counts: this.counts, total: this.total, since: this.since }; }
}

module.exports = { SecStats, K, KINDS, FIRST_SECURITY, DAYS };
