'use strict';
// 트래커 차단기 (엄격 모드, 안드로이드 TrackerBlocker.kt).
// - 웹사이트 동작에 필요한 도메인(로그인·결제·캡차 등)은 허용 목록으로 항상 통과
// - 그 외 알려진 트래킹 도메인으로 가는 "서드파티 하위 요청"은 모두 차단
// - 페이지와 같은 사이트(퍼스트파티) 요청은 건드리지 않음
const D = require('./addata');
const { registrable, matchesSet } = require('./adengine');

const ESSENTIAL = new Set(D.ESSENTIAL);
const TRACKERS = new Set(D.TRACKERS);

class TrackerBlocker {
  constructor() { this.blockedCount = 0; this.verdicts = new Map(); }
  shouldBlock(requestHost, pageHost) {
    if (!requestHost) return false;
    // 요청마다 목록을 뒤지지 않도록 (요청 호스트, 페이지 호스트) 조합별 결과를 기억한다
    const key = pageHost == null ? requestHost : requestHost + '|' + pageHost;
    const memo = this.verdicts.get(key);
    if (memo !== undefined) return memo;
    const req = requestHost.toLowerCase();
    let r;
    if (pageHost != null && registrable(req) === registrable(String(pageHost).toLowerCase())) r = false;
    else if (matchesSet(req, ESSENTIAL)) r = false;
    else r = matchesSet(req, TRACKERS);
    if (this.verdicts.size > 6000) this.verdicts.clear();
    this.verdicts.set(key, r);
    return r;
  }
}
module.exports = { TrackerBlocker, ESSENTIAL, TRACKERS };
