'use strict';
// 웹스토어 주소 읽기, 호환성 판별, 현지화 이름. 안드로이드 ExtensionManager 의 규칙에 윈도우(Electron) 쪽 제한을 더했다.
const ID_RE = /^[a-p]{32}$/;
const STORE_RE = /^https?:\/\/(?:chromewebstore\.google\.com|chrome\.google\.com\/webstore)\/detail\/.*?([a-p]{32})(?:[/?#].*)?$/i;
const STORE_CHROME_VERSION = '130.0.0.0';   // electron 33 의 크로미엄

function parseStoreId(input) {
  const t = String(input || '').trim();
  if (ID_RE.test(t)) return t;
  const m = STORE_RE.exec(t);
  return m ? m[1].toLowerCase() : null;
}
function storeCrxUrl(id) {
  return 'https://clients2.google.com/service/update2/crx?response=redirect&os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=stable&prodversion=' +
    STORE_CHROME_VERSION + '&acceptformat=crx2,crx3&x=' + encodeURIComponent('id=' + id + '&uc');
}
// 설치해도 쓸모가 없는 종류 (막는다)
const HARD_PERMS = new Set(['nativeMessaging', 'debugger', 'tabCapture', 'desktopCapture', 'vpnProvider']);
// 앱 화면(탭 · 북마크 · 기록…)을 직접 만지는 권한이라 윈도우판에서는 일부 기능이 안 될 수 있는 것 (경고만 하고 설치는 허용)
const SOFT_PERMS = { sidePanel: '사이드 패널', bookmarks: '북마크', history: '방문 기록', downloads: '다운로드 관리', topSites: '자주 가는 사이트', sessions: '세션', tabGroups: '탭 그룹',
  identity: '구글 로그인', notifications: '알림', offscreen: '오프스크린 문서', proxy: '프록시 설정', commands: '단축키', contextMenus: '우클릭 메뉴', declarativeNetRequest: '요청 차단 규칙', declarativeNetRequestWithHostAccess: '요청 차단 규칙', webNavigation: '탐색 감지', tabs: '탭 조작' };

function hardIncompat(reason) { return !!reason && (reason.startsWith('크롬 앱') || reason.startsWith('개발자 도구') || reason.startsWith('Chrome 확장')); }
function permList(m) { return [].concat(Array.isArray(m.permissions) ? m.permissions : [], m.manifest_version === 2 && Array.isArray(m.optional_permissions) ? [] : []).filter((p) => typeof p === 'string'); }
// 막아야 하면 이유 문자열, 아니면 null
function manifestIncompat(m) {
  if (!m || typeof m !== 'object') return '확장 프로그램 설명 파일(manifest.json)을 읽지 못했어요';
  if (m.app) return '크롬 앱은 지원하지 않아요';
  if (m.devtools_page) return '개발자 도구 확장은 지원하지 않아요';
  if (![2, 3].includes(m.manifest_version)) return 'manifest_version 2 또는 3 이 아니에요';
  for (const p of permList(m)) if (HARD_PERMS.has(p)) return "'" + p + "' 권한을 지원하지 않아요";
  return null;
}
// 설치는 되지만 일부가 안 될 수 있는 것 → 사람이 읽는 글 (없으면 null)
function manifestWarning(m) {
  if (!m || m.theme) return null;
  const hit = [];
  for (const p of permList(m)) if (SOFT_PERMS[p] && hit.indexOf(SOFT_PERMS[p]) < 0) hit.push(SOFT_PERMS[p]);
  if (m.side_panel && hit.indexOf('사이드 패널') < 0) hit.push('사이드 패널');
  if (m.chrome_url_overrides) hit.push('새 탭/기록 페이지 바꾸기');
  return hit.length ? '일부 기능이 동작하지 않을 수 있어요: ' + hit.slice(0, 6).join(' · ') : null;
}
// __MSG_이름__ → 현지화 파일의 글 (messages: { 이름: { message } })
function localize(s, messages) {
  return String(s == null ? '' : s).replace(/__MSG_([A-Za-z0-9_@]+)__/g, (_m, k) => {
    const e = messages && (messages[k] || messages[k.toLowerCase()]);
    return e && typeof e.message === 'string' ? e.message : '';
  });
}
function bestIcon(icons, want) {
  if (!icons || typeof icons !== 'object') return null;
  const sizes = Object.keys(icons).map(Number).filter((n) => n > 0).sort((a, b) => a - b);
  if (!sizes.length) return null;
  const pick = sizes.find((n) => n >= (want || 48)) || sizes[sizes.length - 1];
  return icons[String(pick)] || null;
}
module.exports = { parseStoreId, storeCrxUrl, manifestIncompat, manifestWarning, hardIncompat, localize, bestIcon, STORE_CHROME_VERSION };
