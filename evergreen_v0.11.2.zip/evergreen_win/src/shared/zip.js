'use strict';
// 의존성 없는 zip 읽기(저장·deflate 만). 확장 프로그램 압축 풀기용. 경로 탈출(../, 절대경로)과 압축 폭탄은 막는다.
const zlib = require('zlib');
const MAX_FILES = 6000, MAX_TOTAL = 400 * 1024 * 1024;

function safeName(n) {
  const s = String(n).replace(/\\/g, '/');
  if (!s || s.startsWith('/') || /^[a-zA-Z]:/.test(s) || s.split('/').some((p) => p === '..')) return null;
  return s;
}
// 반환: [{ name, dir, data() }]
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65535); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('zip 파일이 아니에요');
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  if (count > MAX_FILES) throw new Error('파일이 너무 많아요');
  const out = []; let total = 0;
  for (let i = 0; i < count; i++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip 목록이 손상됐어요');
    const flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), lho = buf.readUInt32LE(p + 42);
    const raw = buf.toString((flags & 0x800) ? 'utf8' : 'utf8', p + 46, p + 46 + nlen);
    p += 46 + nlen + elen + clen;
    const name = safeName(raw);
    if (name == null) throw new Error('안전하지 않은 파일 경로가 들어 있어요: ' + raw);
    total += usize;
    if (total > MAX_TOTAL) throw new Error('압축을 풀면 너무 커요');
    const dir = name.endsWith('/');
    out.push({ name, dir, size: usize, data: () => {
      if (dir) return Buffer.alloc(0);
      if (buf.readUInt32LE(lho) !== 0x04034b50) throw new Error('zip 항목이 손상됐어요: ' + name);
      const start = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
      const comp = buf.subarray(start, start + csize);
      const d = method === 0 ? comp : method === 8 ? zlib.inflateRawSync(comp) : null;
      if (!d) throw new Error('지원하지 않는 압축 방식(' + method + '): ' + name);
      if (d.length !== usize) throw new Error('크기가 맞지 않아요: ' + name);
      return d;
    } });
  }
  return out;
}
module.exports = { readZip, safeName };
