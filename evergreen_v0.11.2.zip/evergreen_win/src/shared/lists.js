'use strict';
// 북마크 · 방문 기록 · 폴더 · 추천 · 북마크 HTML 가져오기/내보내기의 순수 로직.
// 안드로이드 Prefs.kt / HistoryActivity.kt / ListUi.kt / BookmarkPorter.kt 와 같은 규칙.
// 메인 프로세스(require)와 화면(<script>)이 함께 쓴다.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvLists = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var HISTORY_MAX = 1000;          // 남겨 두는 방문 기록 수
  var HISTORY_REPEAT_MS = 60000;   // 같은 주소·제목이 이 시간 안에 또 끝나면 다시 쓰지 않는다
  var RECENT_MS = 3600000;         // '최근 1시간'
  var RECENT_DAY = -2;             // '최근 1시간' 줄의 day 값
  var MAX_IMPORT = 1000;
  var WEEK = ['일', '월', '화', '수', '목', '금', '토'];

  // ───────── 공통 ─────────
  function sameUrl(a, b) { return String(a).replace(/\/+$/, '') === String(b).replace(/\/+$/, ''); }
  function newId(ids) { var m = 0; for (var i = 0; i < ids.length; i++) if (ids[i] > m) m = ids[i]; return m + 1; }
  function hostOf(url) { try { return new URL(url).hostname.toLowerCase().replace(/^www\./, '') || null; } catch (e) { return null; } }
  function displayTitle(title, url) { var t = String(title || '').trim(); return t || hostOf(url) || url; }
  function shortUrl(u) { return u ? String(u).replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/$/, '') : ''; }
  function fmtSize(n) {
    if (n >= 1073741824) return (n / 1073741824).toFixed(2) + ' GB';
    if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
    if (n >= 1024) return Math.round(n / 1024) + ' KB';
    return n + ' B';
  }
  function normalizeUrl(raw) { var s = String(raw || '').trim(); return /^https?:\/\//i.test(s) ? s : 'https://' + s; }

  // ───────── 방문 기록 ─────────
  // items: [{url, title, time}] 최근 방문이 앞. 새 배열을 돌려주고, 건너뛰면 같은 배열을 돌려준다.
  function addHistory(items, url, title, now) {
    var t = title || '';
    var head = items[0];
    if (head && head.url === url && head.title === t && now - head.time >= 0 && now - head.time <= HISTORY_REPEAT_MS) return items;
    var out = [{ url: url, title: t, time: now }];
    for (var i = 0; i < items.length && out.length < HISTORY_MAX; i++) {
      if (items[i].url === url) continue;
      out.push(items[i]);
    }
    return out;
  }
  function removeHistory(items, urls) { var s = new Set(urls); return items.filter(function (h) { return !s.has(h.url); }); }

  function startOfDay(t) { var d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); }
  // 오늘 / 어제 / 11월 3일 (화) — 올해가 아니면 연도도 붙인다
  function dayLabel(day, now) {
    var today = startOfDay(now);
    if (day === today) return '오늘';
    if (day === startOfDay(today - 1)) return '어제';
    var d = new Date(day), y = new Date(today).getFullYear();
    var s = (d.getMonth() + 1) + '월 ' + d.getDate() + '일 (' + WEEK[d.getDay()] + ')';
    return d.getFullYear() === y ? s : d.getFullYear() + '년 ' + s;
  }
  // 오전 3:05 / 오후 12:30
  function timeLabel(t) {
    if (!t || t <= 0) return '';
    var d = new Date(t), h = d.getHours(), m = d.getMinutes();
    return (h < 12 ? '오전 ' : '오후 ') + (h % 12 === 0 ? 12 : h % 12) + ':' + (m < 10 ? '0' : '') + m;
  }
  // 최근 1시간 + 날짜별 묶음. 반환: [{ day, label, items }] (최근 1시간 → 최신 날짜 → … → 날짜 없음)
  function groupHistory(items, now) {
    var all = items.slice().sort(function (a, b) { return b.time - a.time; });
    var groups = [];
    var cutoff = now - RECENT_MS;
    var recent = all.filter(function (h) { return h.time > 0 && h.time >= cutoff; });
    if (recent.length) groups.push({ day: RECENT_DAY, label: '최근 1시간', items: recent });
    var map = new Map();
    all.forEach(function (h) {
      var day = h.time > 0 ? startOfDay(h.time) : 0;
      if (!map.has(day)) map.set(day, []);
      map.get(day).push(h);
    });
    map.forEach(function (list, day) { groups.push({ day: day, label: day === 0 ? '날짜 없음' : dayLabel(day, now), items: list }); });
    return groups;
  }

  // ───────── 북마크 · 폴더 ─────────
  // bookmarks: [{id, url, title, folderId}] 최근에 추가한 것이 앞. folders: [{id, name}]
  function findBookmark(list, url) { for (var i = 0; i < list.length; i++) if (sameUrl(list[i].url, url)) return list[i]; return null; }
  // id 가 같은 북마크가 있으면 고치고, 없으면 맨 앞에 추가한다. 같은 주소가 다른 항목으로 있으면 하나로 합친다.
  function saveBookmark(list, url, title, folderId, existingId) {
    var id = existingId != null ? existingId : newId(list.map(function (b) { return b.id; }));
    var b = { id: id, url: url, title: title, folderId: folderId || 0 };
    var out;
    if (existingId != null && list.some(function (x) { return x.id === existingId; })) {
      out = list.filter(function (x) { return x.id === id || !sameUrl(x.url, url); }).map(function (x) { return x.id === id ? b : x; });
    } else {
      out = [b].concat(list.filter(function (x) { return !sameUrl(x.url, url); }));
    }
    return { list: out, bookmark: b };
  }
  function addFolder(folders, name) { var f = { id: newId(folders.map(function (x) { return x.id; })), name: name }; return { list: folders.concat([f]), folder: f }; }
  // 폴더를 지우면 안의 북마크는 폴더 없음(0)으로
  function removeFolder(folders, bookmarks, id) {
    return { folders: folders.filter(function (f) { return f.id !== id; }),
      bookmarks: bookmarks.map(function (b) { return b.folderId === id ? Object.assign({}, b, { folderId: 0 }) : b; }) };
  }

  // ───────── 주소창 추천 (북마크 2개 먼저 → 방문 기록, 합쳐서 4개) ─────────
  function suggestLocal(q, history, bookmarks) {
    var s = String(q || '').trim().toLowerCase();
    if (!s) return [];
    var has = function (x) { return String(x || '').toLowerCase().indexOf(s) >= 0; };
    var marks = bookmarks.filter(function (b) { return has(b.url) || has(b.title); }).map(function (b) { return b.url; }).slice(0, 2);
    var hist = history.filter(function (h) { return has(h.url) || has(h.title); }).map(function (h) { return h.url; });
    var seen = new Set(), out = [];
    marks.concat(hist).forEach(function (u) { if (!seen.has(u) && out.length < 4) { seen.add(u); out.push(u); } });
    return out;
  }

  // ───────── 북마크 HTML (Netscape Bookmark File) ─────────
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function bookmarksToHtml(bookmarks, folders, nowMs) {
    var sec = Math.floor(nowMs / 1000);
    var sb = '<!DOCTYPE NETSCAPE-Bookmark-file-1>\n' +
      '<!-- This is an automatically generated file. It will be read and overwritten. DO NOT EDIT! -->\n' +
      '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n';
    var item = function (b, ind) { return ind + '<DT><A HREF="' + esc(b.url) + '" ADD_DATE="' + sec + '">' + esc(b.title || b.url) + '</A>\n'; };
    var known = new Set(folders.map(function (f) { return f.id; }));
    folders.forEach(function (f) {
      var inside = bookmarks.filter(function (b) { return b.folderId === f.id; });
      if (!inside.length) return;
      sb += '    <DT><H3 ADD_DATE="' + sec + '">' + esc(f.name) + '</H3>\n    <DL><p>\n';
      inside.forEach(function (b) { sb += item(b, '        '); });
      sb += '    </DL><p>\n';
    });
    bookmarks.filter(function (b) { return !b.folderId || !known.has(b.folderId); }).forEach(function (b) { sb += item(b, '    '); });
    return sb + '</DL><p>\n';
  }
  function decode(s) {
    return s.replace(/&(#x[0-9a-fA-F]+|#\d+|amp|lt|gt|quot|apos|nbsp);/g, function (m, e) {
      if (e === 'amp') return '&'; if (e === 'lt') return '<'; if (e === 'gt') return '>';
      if (e === 'quot') return '"'; if (e === 'apos') return "'"; if (e === 'nbsp') return ' ';
      var code = e.charAt(1) === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return code > 0 && code <= 0x10FFFF ? String.fromCodePoint(code) : m;
    });
  }
  function clean(s, max) { return decode(s.replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim().slice(0, max); }
  // http(s) 북마크만 순서대로. 같은 주소는 한 번만. 폴더는 한 단계(가장 가까운 이름 있는 폴더).
  function parseBookmarksHtml(html) {
    var out = [], seen = new Set(), stack = [], pending = null, m;
    var TOKEN = /<h3\b[^>]*>([\s\S]*?)<\/h3\s*>|<a\b([^>]*)>([\s\S]*?)<\/a\s*>|<\/?dl\b[^>]*>/gi;
    while ((m = TOKEN.exec(html))) {
      var v = m[0].toLowerCase();
      if (v.indexOf('<h3') === 0) pending = clean(m[1], 30);
      else if (v.indexOf('</dl') === 0) { if (stack.length) stack.pop(); }
      else if (v.indexOf('<dl') === 0) { stack.push(pending || ''); pending = null; }
      else {
        var hm = /\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/i.exec(m[2] || '');
        if (!hm) continue;
        var href = decode(hm[1] || hm[2] || '').trim();
        if (!/^https?:\/\//i.test(href) || href.length > 2000) continue;
        var key = href.replace(/\/+$/, '');
        if (seen.has(key)) continue;
        seen.add(key);
        var title = clean(m[3], 200) || href;
        var folder = '';
        for (var i = stack.length - 1; i >= 1; i--) if (stack[i]) { folder = stack[i]; break; }
        out.push({ title: title, url: href, folder: folder });
      }
    }
    return out;
  }
  // 가져온 목록을 기존 북마크에 합친다 (같은 주소는 건너뜀, 폴더는 이름으로 찾고 없으면 만든다). 앞에서부터 MAX_IMPORT 개.
  function mergeImported(bookmarks, folders, parsed) {
    var bms = bookmarks.slice(), fs = folders.slice(), added = 0, skipped = 0;
    var byName = new Map(fs.map(function (f) { return [f.name, f.id]; }));
    parsed.slice(0, MAX_IMPORT).forEach(function (p) {
      if (bms.some(function (b) { return sameUrl(b.url, p.url); })) { skipped++; return; }
      var fid = 0;
      if (p.folder) {
        if (!byName.has(p.folder)) { var r = addFolder(fs, p.folder); fs = r.list; byName.set(p.folder, r.folder.id); }
        fid = byName.get(p.folder);
      }
      bms.unshift({ id: newId(bms.map(function (b) { return b.id; })), url: p.url, title: p.title, folderId: fid });
      added++;
    });
    return { bookmarks: bms, folders: fs, added: added, skipped: skipped, truncated: parsed.length > MAX_IMPORT };
  }

  return { HISTORY_MAX: HISTORY_MAX, HISTORY_REPEAT_MS: HISTORY_REPEAT_MS, RECENT_DAY: RECENT_DAY, MAX_IMPORT: MAX_IMPORT,
    sameUrl: sameUrl, newId: newId, hostOf: hostOf, displayTitle: displayTitle, shortUrl: shortUrl, fmtSize: fmtSize, normalizeUrl: normalizeUrl,
    addHistory: addHistory, removeHistory: removeHistory, startOfDay: startOfDay, dayLabel: dayLabel, timeLabel: timeLabel, groupHistory: groupHistory,
    findBookmark: findBookmark, saveBookmark: saveBookmark, addFolder: addFolder, removeFolder: removeFolder,
    suggestLocal: suggestLocal, bookmarksToHtml: bookmarksToHtml, parseBookmarksHtml: parseBookmarksHtml, mergeImported: mergeImported };
});
