'use strict';
// HLS(m3u8) 목록 읽기: 안드로이드 HlsDownload.kt 의 목록 해석을 그대로 옮긴 순수 로직(받기는 main/hlsdl.js).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvHls = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var FMP4_EXTS = ['m4s', 'mp4', 'm4v', 'm4a', 'cmfv', 'cmfa', 'cmfm', 'fmp4'];

  function extOf(url) {
    var p = String(url).split('#')[0].split('?')[0];
    var d = p.lastIndexOf('.');
    if (d < 0 || p.length - d > 8) return null;
    return p.slice(d + 1).toLowerCase();
  }
  function isHlsMime(mime) { return String(mime || '').toLowerCase().indexOf('mpegurl') >= 0; }
  // 주소나 서버가 알려 준 종류만 보고 HLS 인지 짐작한다
  function looksLikeHls(url, mime) {
    if (mime && isHlsMime(mime)) return true;
    if (!url) return false;
    var p = String(url).toLowerCase().split('#')[0].split('?')[0];
    return /\.m3u8?$/.test(p);
  }

  function attrs(s) {
    var m = {}, re = /([A-Z0-9-]+)=("[^"]*"|[^,]*)/g, r;
    while ((r = re.exec(s))) m[r[1]] = r[2].trim().replace(/^"|"$/g, '');
    return m;
  }
  function resolve(base, ref) {
    var r = String(ref).trim(), out;
    try { out = new URL(r, base).href; } catch (e) { throw new Error('잘못된 주소: ' + r); }
    // 보안 연결(https) 목록이 비보안(http) 조각을 가리키면 따라가지 않는다 (일반 다운로드와 같은 기준)
    if (/^https:\/\//i.test(base) && /^http:\/\//i.test(out)) throw new Error('보안 연결(https)에서 비보안(http)으로 이동해 차단했습니다');
    return out;
  }

  function Stream(segs, init) {
    this.segs = segs; this.init = init;
    var first = segs.length ? extOf(segs[0].url) : null;
    this.fmp4 = !!init || FMP4_EXTS.indexOf(first) >= 0;
    this.rawExt = this.fmp4 ? 'mp4' : (first === 'aac' || first === 'mp3' || first === 'ac3' ? first : 'ts');
  }

  // 화면 크기 정보가 있는(=영상이 있는) 것 중 가장 높은 대역폭
  function pickVariant(text, base) {
    var lines = text.split('\n'), all = [];
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i].trim();
      if (l.indexOf('#EXT-X-STREAM-INF:') !== 0) continue;
      var a = attrs(l.slice(l.indexOf(':') + 1)), j = i + 1;
      while (j < lines.length && (!lines[j].trim() || lines[j].trim().charAt(0) === '#')) j++;
      if (j < lines.length) {
        var bw = parseInt(a.BANDWIDTH || a['AVERAGE-BANDWIDTH'] || '0', 10) || 0;
        all.push({ url: resolve(base, lines[j]), bw: bw, hasRes: 'RESOLUTION' in a, audio: a.AUDIO || null, res: a.RESOLUTION || '' });
        i = j;
      }
    }
    if (!all.length) return null;
    var pool = all.filter(function (v) { return v.hasRes; });
    if (!pool.length) pool = all;
    var best = pool[0];
    pool.forEach(function (v) { if (v.bw > best.bw) best = v; });
    return { url: best.url, audioGroup: best.audio, all: all };
  }
  function findAudio(text, base, group) {
    var first = null, lines = text.split('\n');
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i].trim();
      if (l.indexOf('#EXT-X-MEDIA:') !== 0) continue;
      var a = attrs(l.slice(l.indexOf(':') + 1));
      if (a.TYPE !== 'AUDIO' || a['GROUP-ID'] !== group || !a.URI) continue;
      var u = resolve(base, a.URI);
      if (a.DEFAULT === 'YES') return u;
      if (first == null) first = u;
    }
    return first;
  }
  // 16바이트 IV(0x… 16진수) → Buffer 모양의 배열. 비었거나 너무 길면 null
  function parseHex(s) {
    var h = s.replace(/^0x/i, '');
    if (!h || h.length > 32 || /[^0-9a-f]/i.test(h)) return null;
    h = ('00000000000000000000000000000000' + h).slice(-32);
    var out = [];
    for (var i = 0; i < 16; i++) out.push(parseInt(h.substr(i * 2, 2), 16));
    return out;
  }
  // "길이@시작" → [시작, 길이]. 시작이 없으면 prevEnd 에서 이어진다.
  function parseRange(s, prevEnd) {
    var len = parseInt(s.split('@')[0].trim(), 10);
    if (isNaN(len)) return null;
    var off = prevEnd;
    if (s.indexOf('@') >= 0) { off = parseInt(s.split('@')[1].trim(), 10); if (isNaN(off)) return null; }
    return [off, len];
  }

  function parseMedia(text, base) {
    var segs = [], init = null, key = null, seq = 0, pending = null, prevEnd = 0, prevUrl = '';
    text.split('\n').forEach(function (raw) {
      var l = raw.trim();
      if (!l) return;
      if (l.charAt(0) === '#') {
        var body = l.slice(l.indexOf(':') + 1);
        if (l.indexOf('#EXT-X-MEDIA-SEQUENCE:') === 0) seq = parseInt(body.trim(), 10) || 0;
        else if (l.indexOf('#EXT-X-KEY:') === 0) {
          var a = attrs(body), method = (a.METHOD || 'NONE').toUpperCase();
          if (method === 'NONE') key = null;
          else if (method === 'AES-128') {
            if (!a.URI) throw new Error('암호화 키 주소가 없어요');
            key = { uri: resolve(base, a.URI), iv: a.IV ? parseHex(a.IV) : null };
          } else throw new Error('암호화(' + method + ')된 영상은 저장할 수 없어요');
        } else if (l.indexOf('#EXT-X-MAP:') === 0) {
          var m = attrs(body);
          if (m.URI) { var r = m.BYTERANGE ? parseRange(m.BYTERANGE, 0) : null; init = { url: resolve(base, m.URI), rangeStart: r ? r[0] : 0, rangeLen: r ? r[1] : -1 }; }
        } else if (l.indexOf('#EXT-X-BYTERANGE:') === 0) pending = parseRange(body.trim(), -1);
        return;
      }
      var url = resolve(base, l), rs = -1, rl = -1;
      if (pending) { rs = pending[0] >= 0 ? pending[0] : (url === prevUrl ? prevEnd : 0); rl = pending[1]; prevEnd = rs + rl; }
      pending = null; prevUrl = url;
      segs.push({ url: url, rangeStart: rs, rangeLen: rl, key: key, seq: seq });
      seq++;
    });
    if (!segs.length) throw new Error('영상 조각을 찾지 못했어요');
    return new Stream(segs, init);
  }

  // 마스터 목록이면 변형 하나(+소리 줄기)를 골라야 한다. fetchText(url) 로 목록을 가져온다.
  async function plan(fetchText, url) {
    var text = await fetchText(url);
    if (text.trim().indexOf('#EXTM3U') !== 0) throw new Error('HLS 목록이 아닙니다');
    if (text.indexOf('#EXT-X-STREAM-INF') < 0) return { video: parseMedia(text, url), audio: null };
    var v = pickVariant(text, url);
    if (!v) throw new Error('재생 목록에서 영상을 찾지 못했어요');
    var video = parseMedia(await fetchText(v.url), v.url), audio = null;
    if (v.audioGroup) {
      var au = findAudio(text, url, v.audioGroup);
      if (au && au !== v.url) audio = parseMedia(await fetchText(au), au);
    }
    return { video: video, audio: audio };
  }
  // 조각 번호를 IV 로 (EXT-X-KEY 에 IV 가 없을 때)
  function seqIv(seq) {
    var iv = new Array(16).fill(0), n = BigInt(seq);
    for (var i = 0; i < 8; i++) iv[15 - i] = Number((n >> BigInt(8 * i)) & 0xffn);
    return iv;
  }
  return { looksLikeHls: looksLikeHls, isHlsMime: isHlsMime, parseMedia: parseMedia, pickVariant: pickVariant, findAudio: findAudio, plan: plan, seqIv: seqIv, resolve: resolve, extOf: extOf };
});
