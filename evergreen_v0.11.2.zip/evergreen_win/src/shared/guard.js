'use strict';
// 보안 판정 규칙: 클릭 가로채기 · HTTPS 올리기 · 뒤로가기 자동 이동 (안드로이드 MainActivity 의 같은 이름 함수들).
// 일렉트론·화면에 의존하지 않는 순수 함수라서 테스트한다.

/** 서브도메인마다 주인이 다른 호스팅 도메인: 광고·사기 페이지가 이런 곳의 서브도메인으로 자주 열린다 */
const SHARED_HOST_SUFFIXES = [
  'github.io', 'gitlab.io', 'blogspot.com', 'blogspot.kr', 'tistory.com', 'netlify.app', 'vercel.app',
  'pages.dev', 'workers.dev', 'r2.dev', 'web.app', 'firebaseapp.com', 'herokuapp.com', 'onrender.com',
  'azurewebsites.net', 'appspot.com', 'glitch.me', 'repl.co', 'replit.app', 'fly.dev', 'surge.sh',
  'wixsite.com', 'weebly.com', 'notion.site', 'carrd.co', 'webflow.io', 'myshopify.com', 'wordpress.com',
  'cloudfront.net', 'amazonaws.com', 'trycloudflare.com', 'ngrok-free.app', 'duckdns.org', 'ddns.net',
  'hopto.org', '000webhostapp.com', 'infinityfreeapp.com', 'rf.gd',
];
const TWO_LEVEL = new Set(['co', 'com', 'or', 'ne', 'go', 'ac', 're', 'pe', 'ed', 'gov', 'org', 'net', 'edu', 'ltd', 'sch', 'hs', 'ms', 'es']);
const SIGNIN_PAY_FIRST_LABELS = new Set(['accounts', 'account', 'login', 'auth', 'sso', 'id', 'nid', 'signin', 'oauth', 'passport', 'pay', 'payment', 'payments', 'pg', 'checkout']);
const PAY_BRAND_LABELS = ['paypal', 'inicis', 'nicepay', 'danal', 'tosspay', 'kakaopay', 'naverpay', 'payco', 'samsungpay', 'applepay', 'iamport', 'portone', 'kcp'];
const SIGNIN_PAY_PATH = /(?:^|\/)(?:oauth2?|authorize|signin|sign-in|sign_in|login|logon|sso|passport|checkout|payments?|sharer?|intent\/tweet|intent\/post)(?:\/|\.|$)/;

/** 호스트의 '사이트 단위' 키 (m.a.com / www.a.com → a.com, b.co.kr 같은 2단계 도메인도 처리) */
function siteKey(host) {
  const h = String(host).toLowerCase().replace(/\.+$/, '');
  const parts = h.split('.');
  if (parts.length <= 2) return h;
  for (const suffix of SHARED_HOST_SUFFIXES) {
    if (h.endsWith('.' + suffix)) {
      const n = suffix.split('.').length + 1;
      return parts.slice(-Math.min(n, parts.length)).join('.');
    }
  }
  const second = parts[parts.length - 2];
  const twoLevel = parts[parts.length - 1].length === 2 && TWO_LEVEL.has(second);
  return parts.slice(-(twoLevel ? 3 : 2)).join('.');
}

/** 로그인·결제처럼 다른 사이트로 가는 것이 정상인 주소 (글자 일부만 닮은 주소가 아니라 주소의 칸·길 단위로 본다) */
function looksLikeSignInOrPay(url, host) {
  const h = String(host).toLowerCase().replace(/\.+$/, '');
  const labels = h.split('.');
  if (SIGNIN_PAY_FIRST_LABELS.has(labels[0])) return true;
  if (h.includes('oauth')) return true;
  if (labels.some((l) => PAY_BRAND_LABELS.some((b) => l === b || l.startsWith(b) || l.endsWith(b)))) return true;
  if (h === 'appleid.apple.com' || h === 'login.microsoftonline.com' || h === 'live.com' || h.endsWith('.live.com')) return true;
  return SIGNIN_PAY_PATH.test((url.pathname || '').toLowerCase());
}

/**
 * 사용자가 링크가 아닌 곳(빈 곳·버튼 모양 덮개)을 눌렀는데 곧바로 다른 사이트로 가려는지.
 * - 링크를 누른 경우, 서버 리다이렉트, 같은 사이트 안 이동, 로그인·결제 주소, 허락받은 사이트는 통과
 * @param o { dest: URL, from: 이동을 시작한 주소, isRedirect, lastHopAt, now, allowed: Set, tap: { recent, onLink, href }, popupFirst }
 */
function isHijackedNav(o) {
  const now = o.now;
  // 방금 확인하고 통과시킨 이동이 곧바로 이어 보내는 서버 리다이렉트(링크 → 추적 주소 → 도착 주소)는 통과
  if (o.isRedirect && o.lastHopAt && now - o.lastHopAt < 2000) return false;
  const destHost = o.dest && o.dest.hostname && o.dest.hostname.toLowerCase();
  if (!destHost) return false;
  if (!o.from || !/^https?:/i.test(o.from)) return false;
  let fromHost;
  try { fromHost = new URL(o.from).hostname.toLowerCase(); } catch (e) { return false; }
  const destKey = siteKey(destHost);
  if (destKey === siteKey(fromHost) || (o.allowed && o.allowed.has(destKey))) return false;
  if (looksLikeSignInOrPay(o.dest, destHost)) return false;
  const tap = o.tap;
  if (!tap || !tap.recent) return false;
  // 링크가 아닌 곳(빈 곳·버튼 모양 덮개·javascript: 링크)을 눌렀는데 다른 사이트로 간다
  if (!tap.onLink) return true;
  // 링크를 눌렀어도, 그 링크가 가리키는 사이트와 다른 사이트로 가면 가로챈 것이다 (링크 주소를 모르면 통과)
  let linkKey = null;
  try { linkKey = siteKey(new URL(tap.href).hostname); } catch (e) { return false; }
  return linkKey !== destKey;
}

/** 이 시간(ms) 안에 일어나는 눌림이 있었는지 보는 창: 일반 2.5초, 서버 리다이렉트 4초, 팝업 5초 */
const TAP_WINDOW = { normal: 2500, redirect: 4000, popup: 5000 };

/** http 주소를 https 로 올린다. 올리지 않을 주소(내부망·IP·단일 이름·이미 허락한 사이트)면 null */
function upgradeUrl(url, httpAllowed) {
  if (!/^http:\/\//i.test(url)) return null;
  let host;
  try { host = new URL(url).hostname.toLowerCase(); } catch (e) { return null; }
  const internal = !host.includes('.') || host === 'localhost' || /\.(local|lan|internal|home)$/.test(host) ||
    /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(':') || host.startsWith('[');
  if (internal || (httpAllowed && httpAllowed.has(host))) return null;
  return 'https://' + url.replace(/^http:\/\//i, '');
}

/** 같은 문서인가: 주소 정리(http→https, www 붙이기, 끝 슬래시, # 뒤)만 다른 경우 */
function sameDoc(a, b) {
  if (!a || !b) return false;
  const norm = (u) => {
    try {
      const x = new URL(u);
      return x.hostname.toLowerCase().replace(/^www\./, '') + (x.pathname.replace(/\/+$/, '') || '') + x.search;
    } catch (e) { return String(u); }
  };
  return norm(a) === norm(b);
}

/** 뒤로가기 함정: 뒤로가기 직후 사용자 동작 없이 페이지가 스스로 다른 곳으로 보내려는지 (안드로이드와 같은 조건) */
const BACK_GUARD_MS = 4000;
function isBackTrap(o) {
  // o: { enabled, hasTapSince, backAt, now, from, backTarget, backLeft, dest }
  if (!o.enabled || !o.backAt || o.now - o.backAt >= BACK_GUARD_MS || o.hasTapSince) return false;
  if (!o.from) return false;
  if (!(sameDoc(o.from, o.backTarget) || sameDoc(o.from, o.backLeft))) return false;
  return !sameDoc(o.dest, o.backTarget) && !sameDoc(o.dest, o.from);
}

module.exports = { siteKey, looksLikeSignInOrPay, isHijackedNav, upgradeUrl, sameDoc, isBackTrap, TAP_WINDOW, BACK_GUARD_MS };
