'use strict';
// 이미지 속 글자 번역의 순수 규칙: 긴 이미지 나누기 · Gemini 비전 요청 글 · 답 읽기 · 덩어리 걸러내기.
// 안드로이드 ImageOcr(ML Kit)가 하던 '글자 찾기'를 윈도우에서는 Gemini 비전이 대신하고, 나머지 규칙은 그대로 옮겼다.
// (Gemini · 화면은 건드리지 않는다)
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./translate'));
  else root.EvImgTr = factory(root.EvTranslate);
})(typeof self !== 'undefined' ? self : this, function (T) {
  // 안드로이드 ImageOcr · PageTranslator 의 값
  var LIM = {
    MAX_IMAGES: 40,      // 한 페이지에서 번역하는 이미지 수(화면에 보이는 것부터)
    WORKERS: 2,          // 동시에 처리하는 이미지 수
    MIN_W: 80, MIN_H: 40,// 이보다 작은 이미지는 읽지 않는다
    TILE_H: 2200,        // 긴 이미지를 나눌 때: 조각 높이
    TILE_STEP: 2000,     // 조각이 맡는 높이(나머지 200px 은 경계 글자를 온전히 읽으려는 겹침)
    MAX_TILES: 14,       // 한 이미지에서 읽는 조각 수 한계
    SEND_W: 1280,        // Gemini 로 보낼 때 가로가 이만큼(px)을 넘지 않게 줄인다
    MAX_BYTES: 15 * 1024 * 1024,
  };

  // 이미지 크기 → 읽을 조각들. 조각은 원본 px 기준 { y0, h, keepEnd, last }. 다음 조각이 맡는 글자(중심이 keepEnd 아래)는 이 조각에서 버린다.
  function planTiles(w, h) {
    if (!(w >= LIM.MIN_W) || !(h >= LIM.MIN_H)) return [];
    if (h <= LIM.TILE_H + 400) return [{ y0: 0, h: h, keepEnd: h, last: true }];
    var out = [], top = 0;
    while (top < h && out.length < LIM.MAX_TILES) {
      var bottom = Math.min(h, top + LIM.TILE_H), last = bottom >= h;
      out.push({ y0: top, h: bottom - top, keepEnd: last ? h : top + LIM.TILE_STEP, last: last });
      if (last) break;
      top += LIM.TILE_STEP;
    }
    return out;
  }

  function system(langKey) {
    var L = T.lang(langKey), en = L.en;
    return 'You find and translate the text inside one image (comic, manga and webtoon speech bubbles, captions, sound effects, signs, screenshots, posters). ' +
      'Find every text region and return ONLY a JSON array, in natural reading order (top to bottom; for vertical Japanese/Chinese text right to left; speech bubbles in the order they are read). ' +
      'Each item is {"box":[ymin,xmin,ymax,xmax],"text":"original","tr":"translation","v":0}. ' +
      '"box" is four integers from 0 to 1000 relative to this image (0,0 = top-left, 1000,1000 = bottom-right): a tight rectangle around ALL the text of ONE speech bubble, caption, sign or separate line (never one box for the whole page, and do not split a single bubble into several items). ' +
      '"text" is exactly what is written. "tr" is its translation into natural ' + en + '. "v" is 1 if the original is written vertically, otherwise 0. ' +
      'Neighbouring bubbles are usually one conversation: keep the speakers\' tone and context consistent and keep character names consistent (transliterate names into the ' + en + ' writing system). ' +
      'Keep each translation short and natural, as spoken in a speech bubble, so it fits the bubble. Translate sound effects into ' + en + ' onomatopoeia. Do not add explanations or notes. ' +
      'Translate EVERYTHING that is real text, including titles, credits, signs and brand names, and never repeat the original in parentheses. Keep only universal abbreviations such as TV, OK or CD as they are. ' +
      'Skip text that is already ' + en + ', page numbers, and anything that is not real text (logo fragments, noise, textures, random letters). ' +
      'If the image has no text to translate, return [].';
  }
  function user() { return 'Find and translate the text in this image.'; }

  // 답에서 JSON 배열을 꺼내 올바른 항목만 돌려준다. 깨진 답이면 null.
  function parse(text) {
    var s = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    var a = s.indexOf('['), b = s.lastIndexOf(']');
    if (a < 0 || b < a) return null;
    var arr; try { arr = JSON.parse(s.slice(a, b + 1)); } catch (e) { return null; }
    if (!Array.isArray(arr)) return null;
    var out = [];
    arr.forEach(function (o) {
      if (!o || !Array.isArray(o.box) || o.box.length !== 4) return;
      var bx = o.box.map(function (n) { n = Number(n); return isFinite(n) ? Math.max(0, Math.min(1000, n)) : NaN; });
      if (bx.some(isNaN)) return;
      if (bx[2] - bx[0] < 3 || bx[3] - bx[1] < 3) return;
      var tr = typeof o.tr === 'string' ? o.tr.trim() : '', tx = typeof o.text === 'string' ? o.text.trim() : '';
      if (!tr) return;
      out.push({ box: bx, text: tx, tr: tr, v: o.v === 1 || o.v === true || o.v === '1' ? 1 : 0 });
    });
    return out;
  }

  // 번역기가 원문을 괄호로 덧붙이는 것(「아르빌레(Arbhylle Artiaga)의 그림」)을 걷어 낸다. 한글이 있을 때만, 영문 두 글자 이상인 괄호만
  var LATIN_PAREN = /\s*[(（][A-Za-z][A-Za-z0-9 .,'’&\-]+[)）]/g;
  function tidy(t) {
    t = String(t || '').trim();
    if (!/[가-힣]/.test(t)) return t;
    return t.replace(LATIN_PAREN, '').trim();
  }
  var CJK = /[぀-ヿ㐀-鿿]/;

  // 조각 하나의 답(parse 결과) → 원본 이미지 좌표(px)의 덩어리들. tile: planTiles 의 조각, w: 원본 가로, tileW/tileH: 보낸 조각의 원본 기준 크기
  function toBlocks(items, tile, w, langKey) {
    var out = [];
    (items || []).forEach(function (it) {
      var y1 = tile.y0 + it.box[0] / 1000 * tile.h, y2 = tile.y0 + it.box[2] / 1000 * tile.h;
      var x1 = it.box[1] / 1000 * w, x2 = it.box[3] / 1000 * w;
      var cy = (y1 + y2) / 2;
      if (!tile.last && cy >= tile.keepEnd) return;            // 다음 조각에서 읽는 글자
      if (y2 - y1 < 8) return;
      var tr = tidy(it.tr);
      if (!tr || tr === it.text) return;
      if (it.text && T.skip(it.text, langKey)) return;          // 이미 목표 언어
      out.push({ x: Math.round(x1), y: Math.round(y1), w: Math.max(1, Math.round(x2 - x1)), h: Math.max(1, Math.round(y2 - y1)), t: tr, o: it.text, v: it.v, cjk: CJK.test(it.text || '') });
    });
    return out;
  }

  // 같은 이미지 주소인지 비교하는 값: # 뒤를 뺀 것
  function sameKey(u) { return String(u || '').split('#')[0]; }

  return { LIM: LIM, planTiles: planTiles, system: system, user: user, parse: parse, tidy: tidy, toBlocks: toBlocks, sameKey: sameKey };
});
