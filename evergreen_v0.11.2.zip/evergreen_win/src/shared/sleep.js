'use strict';
// 취침 타이머: 정한 시간이 지나면 onFire 를 부른다 (플레이어가 거기서 재생을 멈춘다). 안드로이드 SleepTimer.kt 와 같다.
// 내장 플레이어와 미러링 플레이어가 하나를 같이 쓴다(메인 프로세스에 하나만 둔다).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvSleep = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var OPTIONS = [10, 15, 30, 45, 60, 90, 120];
  function label(min) {
    if (min < 60) return min + '분';
    if (min % 60 === 0) return (min / 60) + '시간';
    return Math.floor(min / 60) + '시간 ' + (min % 60) + '분';
  }
  // now: 시계 함수(테스트에서 바꿔 끼운다), timers: { set, clear }
  function SleepTimer(onFire, now, timers) {
    var clock = now || function () { return Date.now(); };
    // 브라우저에서 setTimeout 을 객체 메서드로 부르면 'Illegal invocation' 이라, 감싸서 쓴다
    var T = timers || { set: function (f, ms) { return setTimeout(f, ms); }, clear: function (h) { clearTimeout(h); } };
    var endAt = 0, h = null;
    function fire() { endAt = 0; h = null; onFire(); }
    return {
      get active() { return endAt > 0; },
      start: function (minutes) { this.cancel(); endAt = clock() + minutes * 60000; h = T.set(fire, minutes * 60000); },
      cancel: function () { if (h != null) T.clear(h); h = null; endAt = 0; },
      remainingMs: function () { return endAt > 0 ? Math.max(0, endAt - clock()) : 0; },
      // 설정 줄에 보여 줄 값: 끄면 "끔", 켜 있으면 남은 시간
      valueLabel: function () {
        if (endAt <= 0) return '끔';
        var m = Math.floor((Math.max(0, endAt - clock()) + 59999) / 60000);
        return label(Math.max(1, m)) + ' 남음';
      },
    };
  }
  return { SleepTimer: SleepTimer, OPTIONS: OPTIONS, label: label };
});
