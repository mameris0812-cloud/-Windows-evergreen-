'use strict';
// Adblock Plus / uBlock Origin / AdGuard 문법의 네트워크 필터 엔진 (안드로이드 NetFilter.kt 를 그대로 옮김).
// EasyList · EasyPrivacy · uBlock Origin · AdGuard · List-KR 같은 오픈소스 목록의 규칙을 그대로 읽어서 쓴다.
//
// 지원하는 문법
//  - `||example.com^`(도메인 시작), `|`(주소 처음/끝), `*`(아무 글자), `^`(구분자)
//  - `@@` 예외 규칙, `$important`
//  - 옵션: third-party / ~third-party, domain=a.com|~b.com, 요청 종류(script, image, stylesheet, xmlhttprequest,
//    subdocument, media, font, ping, websocket, other, object 와 그 반대 ~종류)
//  지원하지 않는 옵션(redirect, removeparam, csp, popup, 정규식 규칙 등)이 붙은 규칙은 잘못 막지 않도록 통째로 버린다.
//
// 속도: 규칙마다 가장 긴 영숫자 조각(토큰)을 뽑아 해시 색인에 넣고, 요청 주소의 조각들만 찾아본다 (uBlock/Brave 방식).
// 이 파일은 일렉트론에 의존하지 않는다 (테스트 가능).

const T = {
  DOC: 1, SCRIPT: 1 << 1, IMAGE: 1 << 2, CSS: 1 << 3, XHR: 1 << 4, SUBDOC: 1 << 5, MEDIA: 1 << 6,
  FONT: 1 << 7, PING: 1 << 8, WS: 1 << 9, OTHER: 1 << 10, OBJECT: 1 << 11,
};
T.ALL = T.SCRIPT | T.IMAGE | T.CSS | T.XHR | T.SUBDOC | T.MEDIA | T.FONT | T.PING | T.WS | T.OTHER | T.OBJECT;
/** 종류를 알 수 없을 때: 이 세 가지 중 하나로 본다 */
T.ANY = T.SCRIPT | T.XHR | T.OTHER;

const MAX_URL = 2000;
const MIN_TOKEN = 3;

const isAlnum = (c) => (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
/** 광고 필터에서 '^' 가 가리키는 구분자: 영문·숫자·_ - . % 를 뺀 모든 글자 */
const isSeparator = (c) => !((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c === '_' || c === '-' || c === '.' || c === '%');

class Rule {
  constructor(o) { Object.assign(this, o); }
  /** `||host^` 처럼 도메인 전체만 막는 단순 규칙인지 (호스트 목록으로 처리 가능) */
  get isPureHost() {
    return this.hostAnchor && !this.endAnchor && this.types === 0 && this.third === 0 && !this.domainsIn &&
      !this.domainsEx && !this.important && this.pattern.length > 1 && this.pattern.endsWith('^') &&
      this.pattern.indexOf('^') === this.pattern.length - 1 && !/[\/*?:]/.test(this.pattern);
  }
  get host() { return this.pattern.replace(/\^$/, ''); }
}

/** 규칙을 색인할 토큰: 양옆이 주소 조각 경계로 확실한 영숫자 덩어리 중 가장 긴 것 */
function tokenOf(r) {
  const p = r.pattern;
  let best = null;
  let i = 0;
  while (i < p.length) {
    if (isAlnum(p[i])) {
      let j = i + 1;
      while (j < p.length && isAlnum(p[j])) j++;
      const leftOk = i === 0 ? (r.hostAnchor || r.startAnchor) : p[i - 1] !== '*';
      const rightOk = j === p.length ? r.endAnchor : p[j] !== '*';
      if (leftOk && rightOk && j - i >= MIN_TOKEN && (best === null || j - i > best.length)) best = p.substring(i, j);
      i = j;
    } else i++;
  }
  return best;
}

class Index {
  constructor() { this.map = new Map(); this.noToken = []; this.size = 0; }
  add(r) {
    this.size++;
    const t = tokenOf(r);
    if (t === null) this.noToken.push(r);
    else { const l = this.map.get(t); if (l) l.push(r); else this.map.set(t, [r]); }
  }
}

/** 줄 하나를 규칙으로. 주석·화면 숨김 규칙·지원하지 않는 문법이면 null */
function parse(line) {
  let s = String(line).trim();
  if (s.length < 3) return null;
  const c0 = s[0];
  if (c0 === '!' || c0 === '[' || c0 === '#') return null;
  if (s.includes('##') || s.includes('#@#') || s.includes('#?#') || s.includes('#$#') || s.includes('#%#') ||
    s.includes('#@$#') || s.includes('#@?#') || s.includes('+js(')) return null;

  let exception = false;
  if (s.startsWith('@@')) { exception = true; s = s.substring(2); }

  let opts = null;
  const d = s.lastIndexOf('$');
  if (d >= 0) {
    const cand = s.substring(d + 1);
    if (cand.length && /^[\p{L}\p{N}~_,=|.\-*:]+$/u.test(cand)) { opts = cand; s = s.substring(0, d); }
  }
  // 정규식 규칙(/.../)은 지원하지 않는다
  if (s.length > 2 && s.startsWith('/') && s.endsWith('/')) return null;

  let host = false; let start = false; let end = false;
  if (s.startsWith('||')) { host = true; s = s.substring(2); } else if (s.startsWith('|')) { start = true; s = s.substring(1); }
  if (s.endsWith('|')) { end = true; s = s.substring(0, s.length - 1); }
  if (!s.length || s === '*') return null;
  const pattern = s.toLowerCase();
  if ((pattern.match(/\*/g) || []).length > 4) return null;
  // 너무 짧고 막연한 규칙(예: "/ad")은 멀쩡한 주소를 막을 수 있어 버린다
  if (!host && pattern.length < 6) return null;
  if (/[ \t]/.test(pattern)) return null;

  let types = 0; let negTypes = 0; let third = 0; let important = false;
  let din = null; let dex = null;
  if (opts !== null) {
    for (const o of opts.split(',')) {
      if (!o) continue;
      const neg = o.startsWith('~');
      const body = neg ? o.substring(1) : o;
      const name = body.split('=')[0].toLowerCase();
      const setType = (bit) => { if (neg) negTypes |= bit; else types |= bit; };
      switch (name) {
        case 'third-party': case '3p': third = neg ? 2 : 1; break;
        case 'first-party': case '1p': third = neg ? 1 : 2; break;
        case 'important': important = true; break;
        case 'match-case': break;
        case 'script': setType(T.SCRIPT); break;
        case 'image': setType(T.IMAGE); break;
        case 'stylesheet': case 'css': setType(T.CSS); break;
        case 'xmlhttprequest': case 'xhr': setType(T.XHR); break;
        case 'subdocument': case 'frame': setType(T.SUBDOC); break;
        case 'media': setType(T.MEDIA); break;
        case 'font': setType(T.FONT); break;
        case 'ping': setType(T.PING); break;
        case 'websocket': setType(T.WS); break;
        case 'other': setType(T.OTHER); break;
        case 'object': case 'object-subrequest': setType(T.OBJECT); break;
        case 'domain': case 'from': {
          if (neg || !o.includes('=')) return null;
          for (const dm of body.substring(body.indexOf('=') + 1).split('|')) {
            const x = dm.trim().toLowerCase();
            const ex = x.startsWith('~');
            const n2 = ex ? x.substring(1) : x;
            if (!n2 || n2.includes('*') || n2.includes('/') || n2.includes(' ')) return null;
            if (ex) (dex = dex || []).push(n2); else (din = din || []).push(n2);
          }
          break;
        }
        // 그 밖의 옵션(redirect, removeparam, csp, popup, document, all, badfilter ...)은 지원하지 않는다
        default: return null;
      }
    }
  }
  if (types === 0 && negTypes !== 0) types = T.ALL & ~negTypes;
  else if (types !== 0) types = types & ~negTypes;
  if (types === 0 && negTypes !== 0) return null;

  const r = new Rule({ pattern, hostAnchor: host, startAnchor: start, endAnchor: end, types, third, domainsIn: din, domainsEx: dex, important, exception });
  // 색인할 토큰이 없는 규칙은 요청마다 모두 검사하게 되므로, 충분히 구체적일 때만 둔다
  if (tokenOf(r) === null && pattern.length < 8) return null;
  return r;
}

/** 주소·Accept 헤더로 요청 종류를 짐작한다 (일렉트론은 resourceType 을 알려 주므로 보조용) */
function inferType(url, accept, isMainFrame, hasRange) {
  if (isMainFrame) return T.DOC;
  const q = url.search(/[?#]/);
  const path = q >= 0 ? url.substring(0, q) : url;
  const dot = path.lastIndexOf('.');
  const slash = path.lastIndexOf('/');
  if (dot > slash && path.length - dot <= 6) {
    switch (path.substring(dot + 1).toLowerCase()) {
      case 'js': case 'mjs': return T.SCRIPT;
      case 'css': return T.CSS;
      case 'png': case 'jpg': case 'jpeg': case 'gif': case 'webp': case 'svg': case 'ico': case 'avif': case 'bmp': return T.IMAGE;
      case 'swf': return T.OBJECT;
      case 'woff': case 'woff2': case 'ttf': case 'otf': case 'eot': return T.FONT;
      case 'mp4': case 'webm': case 'm4v': case 'mp3': case 'm4a': case 'ogg': case 'ogv': case 'mov': case 'ts':
      case 'm3u8': case 'mpd': case 'm4s': case 'flv': case 'mkv': case 'avi': case 'wmv': case '3gp': case 'f4v': case 'aac': case 'wav': return T.MEDIA;
      case 'html': case 'htm': return T.SUBDOC;
      default: break;
    }
  }
  const a = String(accept || '').toLowerCase();
  if (a.includes('text/css')) return T.CSS;
  if (a.startsWith('image/')) return T.IMAGE;
  if (a.includes('text/html')) return T.SUBDOC;
  if (a.startsWith('video/') || a.startsWith('audio/')) return T.MEDIA;
  if (hasRange) return T.MEDIA;
  return T.ANY;
}

/** 일렉트론 webRequest 의 resourceType → 요청 종류 */
function fromResourceType(rt) {
  switch (rt) {
    case 'mainFrame': return T.DOC;
    case 'subFrame': return T.SUBDOC;
    case 'stylesheet': return T.CSS;
    case 'script': return T.SCRIPT;
    case 'image': return T.IMAGE;
    case 'font': return T.FONT;
    case 'object': return T.OBJECT;
    case 'xhr': return T.XHR;
    case 'ping': case 'cspReport': return T.PING;
    case 'media': return T.MEDIA;
    case 'webSocket': return T.WS;
    default: return T.OTHER;
  }
}

class NetFilter {
  constructor() { this.blocks = new Index(); this.excepts = new Index(); }
  /** 차단 규칙 + 예외 규칙 수 */
  get size() { return this.blocks.size + this.excepts.size; }

  /** 규칙 줄들로 색인을 새로 만들어 한 번에 바꿔 끼운다 */
  load(lines) {
    const b = new Index(); const e = new Index();
    for (const line of lines) {
      const r = parse(line);
      if (!r) continue;
      if (r.exception) e.add(r); else b.add(r);
    }
    this.blocks = b; this.excepts = e;
  }

  /** load 와 같지만 규칙이 많을 때 일렉트론 메인 스레드가 멈추지 않도록 2만 줄마다 쉰다 */
  async loadAsync(lines) {
    const b = new Index(); const e = new Index();
    let n = 0;
    for (const line of lines) {
      const r = parse(line);
      if (r) { if (r.exception) e.add(r); else b.add(r); }
      if (++n % 20000 === 0) await new Promise((res) => setImmediate(res));
    }
    this.blocks = b; this.excepts = e;
  }

  /** 이 요청을 막아야 하는지 (예외 규칙이 풀어 주면 false) */
  shouldBlock(url, host, pageHost, third, type) {
    const u = this._prepare(url);
    const hs = hostStart(u); const he = hostEnd(u, hs);
    const hit = this._find(this.blocks, u, hs, he, pageHost, third, type);
    if (!hit) return false;
    if (hit.important) return true;
    return this._find(this.excepts, u, hs, he, pageHost, third, type) === null;
  }

  /** 예외 규칙(@@)에 걸리는지: 목록에 오른 도메인을 사이트가 동작하도록 풀어 줄 때 쓴다 */
  isException(url, host, pageHost, third, type) {
    if (this.excepts.size === 0) return false;
    const u = this._prepare(url);
    const hs = hostStart(u);
    return this._find(this.excepts, u, hs, hostEnd(u, hs), pageHost, third, type) !== null;
  }

  _prepare(url) { return (url.length > MAX_URL ? url.substring(0, MAX_URL) : url).toLowerCase(); }

  _find(ix, u, hs, he, pageHost, third, type) {
    if (ix.size === 0) return null;
    const n = u.length;
    let i = 0;
    while (i < n) {
      if (isAlnum(u[i])) {
        let j = i + 1;
        while (j < n && isAlnum(u[j])) j++;
        if (j - i >= MIN_TOKEN) {
          const list = ix.map.get(u.substring(i, j));
          if (list) for (const r of list) if (matches(r, u, hs, he, pageHost, third, type)) return r;
        }
        i = j;
      } else i++;
    }
    for (const r of ix.noToken) if (matches(r, u, hs, he, pageHost, third, type)) return r;
    return null;
  }
}

function hostStart(u) { const i = u.indexOf('://'); return i < 0 ? 0 : i + 3; }
function hostEnd(u, start) {
  let i = start;
  while (i < u.length) { const c = u[i]; if (c === '/' || c === '?' || c === '#') break; i++; }
  return i;
}

function inDomains(host, list) {
  for (const d of list) {
    if (host === d) return true;
    if (host.length > d.length && host.endsWith(d) && host[host.length - d.length - 1] === '.') return true;
  }
  return false;
}

function matches(r, u, hs, he, pageHost, third, type) {
  if (r.types === 0) { if (type === T.DOC) return false; } else if ((r.types & type) === 0) return false;
  if (r.third === 1 && !third) return false;
  if (r.third === 2 && third) return false;
  if (r.domainsIn) { if (pageHost == null || !inDomains(pageHost, r.domainsIn)) return false; }
  if (r.domainsEx && pageHost != null && inDomains(pageHost, r.domainsEx)) return false;

  const p = r.pattern;
  if (r.hostAnchor) {
    for (let i = hs; i < he; i++) {
      if (i === hs || u[i - 1] === '.') { if (matchAt(p, 0, u, i, r.endAnchor)) return true; }
    }
    return false;
  }
  if (r.startAnchor) return matchAt(p, 0, u, 0, r.endAnchor);
  const c0 = p[0];
  const any = c0 === '*' || c0 === '^';
  for (let i = 0; i <= u.length; i++) {
    if (any || (i < u.length && u[i] === c0)) { if (matchAt(p, 0, u, i, r.endAnchor)) return true; }
  }
  return false;
}

/** 패턴 p(pStart 부터)가 주소 u(uStart 부터)와 맞는지. '*' 는 되돌아가며 시도하고 '^' 는 구분자 한 글자(또는 주소 끝). */
function matchAt(p, pStart, u, uStart, endAnchor) {
  let pi = pStart; let ui = uStart;
  while (pi < p.length) {
    const c = p[pi];
    if (c === '*') {
      while (pi < p.length && p[pi] === '*') pi++;
      if (pi === p.length) return true;
      const next = p[pi];
      for (let k = ui; k <= u.length; k++) {
        if (next === '^' || (k < u.length && u[k] === next)) { if (matchAt(p, pi, u, k, endAnchor)) return true; }
      }
      return false;
    }
    if (c === '^') {
      if (ui === u.length) { pi++; continue; }
      if (!isSeparator(u[ui])) return false;
      ui++; pi++;
      continue;
    }
    if (ui >= u.length || u[ui] !== c) return false;
    ui++; pi++;
  }
  return !endAnchor || ui === u.length;
}

module.exports = { NetFilter, Rule, T, parse, inferType, fromResourceType };
