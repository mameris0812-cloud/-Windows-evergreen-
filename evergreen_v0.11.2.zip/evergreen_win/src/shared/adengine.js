'use strict';
// 광고 차단 엔진 (안드로이드 AdBlocker.kt 의 판정 부분). 파일·네트워크·일렉트론에 의존하지 않아 테스트할 수 있다.
// - 내장 목록 + 내려받은 오픈소스 목록의 도메인 (서브도메인도 함께 차단: x.doubleclick.net → doubleclick.net)
// - 주소 규칙(||host/path^, 와일드카드, $third-party, $domain=, @@ 예외 ...): NetFilter 엔진이 처리
// - 화면 광고 영역 숨김(CSS) 규칙
const D = require('./addata');
const { NetFilter, T, parse: parseNet } = require('./netfilter');

const BUILTIN = new Set(D.BUILTIN);
const ALLOW = new Set(D.ALLOW);
const AD_LABELS = new Set(D.AD_LABELS);
const SECOND_LEVEL = new Set(D.SECOND_LEVEL);
const BANNER_PATH = new RegExp(D.BANNER_PATH);
const BANNER_VIDEO_PATH = new RegExp(D.BANNER_VIDEO_PATH);
const HOST_REGEX = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/;
/** 주소 규칙 엔진에 올리는 규칙 수 상한 (메모리) */
const MAX_NET_RULES = 160000;

// 호스트만 보고 내린 판단 (안드로이드와 같은 값)
const V_BLOCK = 1; const V_THIRD = 2; const V_FORCE = 8; const V_ALLOW = 16;

/** 화면에서 광고 영역을 숨기는 CSS (네트워크 차단을 빠져나간 요소용) */
const COSMETIC_CSS = D.COSMETIC_SELECTORS.join(',') + '{display:none!important}';

function registrable(host) {
  const parts = host.split('.');
  if (parts.length <= 2) return host;
  const last2 = parts.slice(-2).join('.');
  return SECOND_LEVEL.has(last2) ? parts.slice(-3).join('.') : last2;
}

/** host 와 그 상위 도메인이 set 에 있는지 (TLD 단독은 검사하지 않음) */
function matchesSet(host, set) {
  if (!set || set.size === 0) return false;
  let h = host;
  for (;;) {
    if (set.has(h)) return true;
    const dot = h.indexOf('.');
    if (dot < 0) return false;
    h = h.substring(dot + 1);
    if (!h.includes('.')) return false;
  }
}

function pathOf(url) {
  const q = url.search(/[?#]/);
  return (q >= 0 ? url.substring(0, q) : url).toLowerCase();
}
const isWeb = (u) => u.startsWith('http://') || u.startsWith('https://');
function hostOfUrl(url) { try { return new URL(url).hostname.toLowerCase(); } catch (e) { return null; } }

// ── 목록 줄 읽기 ──
/** hosts 형식("0.0.0.0 example.com") / 한 줄에 도메인 하나 / 광고 필터의 "||example.com^" 모두 받는다. */
function parseHostLine(raw) {
  let line = String(raw).trim().toLowerCase();
  if (!line || line[0] === '#' || line[0] === '!' || line[0] === '[') return null;
  if (line.startsWith('@@')) return null;
  // 광고 영역 숨김 규칙(예: "example.com##.ad")을 사이트 전체 차단으로 오해하지 않게
  if (line.includes('##') || line.includes('#@#') || line.includes('#?#') || line.includes('#$#') || line.includes('#%#')) return null;
  if (line.startsWith('||')) {
    line = line.substring(2);
    const end = line.search(/[\^\/$*]/);
    if (end < 0) return null;
    // 도메인 전체를 막는 규칙(예: ||ads.example.com^)만 사용. 경로가 있거나 옵션이 붙으면 건너뜀
    const rest = line.substring(end);
    if (!(rest === '^' || rest === '^$third-party' || rest === '^$important')) return null;
    line = line.substring(0, end);
  } else {
    line = line.split('#')[0].trim();
    line = line.substring(line.lastIndexOf(' ') + 1);
    line = line.substring(line.lastIndexOf('\t') + 1);
  }
  return HOST_REGEX.test(line) && line !== 'localhost' && !line.endsWith('.local') ? line : null;
}

function cleanSelector(raw) {
  const sel = String(raw).trim();
  if (!sel || sel.length > 160) return null;
  // 확장 문법(:has-text, :-abp-*, :contains, :xpath, :matches-css, +js ...)은 브라우저 CSS 로 쓸 수 없다
  if (sel.includes(':-abp') || sel.includes(':has-text') || sel.includes(':contains') || sel.includes(':xpath') ||
    sel.includes(':matches') || sel.includes(':upward') || sel.includes(':style') || sel.includes(':remove') ||
    sel.includes('-ext-') || sel.includes('+js(') || sel.includes(':nth-ancestor') || sel.includes(':watch-attr') ||
    sel.includes("'") || sel.includes('{') || sel.includes('}') || sel.includes('\\')) return null;
  return sel;
}

/**
 * 광고 영역 숨김 규칙 한 줄을 읽는다. 결과: { doms: 적용할 사이트들 또는 null(=모든 사이트), sel } 또는 null.
 * "##.ad-banner" 는 모든 사이트, "a.com,b.com##.ad" 는 그 사이트에서만. 제외(~) 조건이나 확장 문법은 버린다.
 */
function parseCosmetic(raw) {
  const idx = raw.indexOf('##');
  if (idx < 0) return null;
  const sel = cleanSelector(raw.substring(idx + 2));
  if (!sel) return null;
  const domPart = raw.substring(0, idx).trim();
  if (!domPart) return { doms: null, sel };
  const doms = domPart.toLowerCase().split(',').map((x) => x.trim().replace(/^www\./, ''));
  if (doms.some((x) => x.startsWith('~') || !HOST_REGEX.test(x))) return null;
  return { doms, sel };
}

const buildCss = (sels) => sels.map((s) => String(s).trim()).filter(Boolean).map((s) => s + '{display:none!important}').join('');

class AdEngine {
  constructor() {
    this.hosts = new Set();
    this.cssRules = '';
    this.siteRules = new Map(); // 도메인 → 선택자 목록
    this.net = new NetFilter();
    this.genericCssCount = 0;
    this.siteCssCount = 0;
    this.verdicts = new Map();
  }
  get hostRuleCount() { return this.hosts.size + BUILTIN.size; }
  get pathRuleCount() { return this.net.size; }

  // ── 목록 올리기 ──
  setHosts(set) { this.hosts = set; this.verdicts.clear(); }
  setGenericCss(selectors) { this.cssRules = buildCss(selectors); this.genericCssCount = selectors.length; }
  /** 저장 줄: "도메인,도메인<TAB>선택자" */
  setSiteLines(lines) {
    const map = new Map();
    let n = 0;
    for (const line of lines) {
      const tab = line.indexOf('\t');
      if (tab <= 0) continue;
      const sel = line.substring(tab + 1);
      for (const d of line.substring(0, tab).split(',')) { const l = map.get(d); if (l) l.push(sel); else map.set(d, [sel]); n++; }
    }
    this.siteRules = map; this.siteCssCount = n;
  }
  setNetLines(lines) { this.net.load(lines); this.verdicts.clear(); }
  async setNetLinesAsync(lines) { await this.net.loadAsync(lines); this.verdicts.clear(); }

  // ── 판정 ──
  /** 이미 "허용" 으로 판정해 둔 호스트인지 (목록을 뒤지지 않고 기억해 둔 결과만 본다) */
  quickAllow(host, pageHost) {
    if (!host) return false;
    return this.verdicts.get(pageHost == null ? host : host + '|' + pageHost) === V_ALLOW;
  }

  _hostVerdict(h, pageHost) {
    if (matchesSet(h, BUILTIN)) return V_FORCE;
    if (matchesSet(h, ALLOW)) return V_ALLOW;
    const thirdParty = pageHost == null || registrable(h) !== registrable(String(pageHost).toLowerCase());
    const third = thirdParty ? V_THIRD : 0;
    if (matchesSet(h, this.hosts)) return V_BLOCK | third;
    if (thirdParty) {
      const first = h.split('.')[0];
      if (AD_LABELS.has(first) && (h.match(/\./g) || []).length >= 2) return V_BLOCK | third;
    }
    return third;
  }

  /**
   * 하위 요청 한 건을 막아야 하는지.
   * 1) 내장 목록 / 내려받은 목록의 도메인 (서브도메인 포함)
   * 2) 다른 사이트에서 오는 요청 중 ads.xxx / adserver.xxx 같은 광고용 호스트 이름
   * 3) 광고 스크립트로 잘 알려진 주소 패턴
   * @param type NetFilter 의 T.* (모르면 T.ANY)
   */
  shouldBlock(host, pageHost, url, type) {
    if (!host) return false;
    if (type === undefined) type = T.ANY;
    const key = pageHost == null ? host : host + '|' + pageHost;
    let v = this.verdicts.get(key);
    if (v === undefined) {
      v = this._hostVerdict(host.toLowerCase(), pageHost);
      if (this.verdicts.size > 6000) this.verdicts.clear();
      this.verdicts.set(key, v);
    }
    if (v === V_ALLOW) return false;
    const h = host.toLowerCase();
    const ph = pageHost == null ? null : String(pageHost).toLowerCase();
    if (v === 0) {
      // 같은 사이트에서 직접 내려주는 배너 이미지/플래시는 이미지·플래시 요청만 따로 검사한다
      if (url == null || !isWeb(url)) return false;
      return this._firstPartyAsset(url, h, ph, type);
    }
    if (v & V_FORCE) return true;
    const listed = (v & V_BLOCK) !== 0;
    if (url == null) return listed;
    const third = (v & V_THIRD) !== 0;
    const web = isWeb(url);
    // 목록에 오른 도메인이라도 uBlock 'unbreak' 같은 예외 규칙이 풀어 주면 통과시킨다
    if (listed) return !(web && this.net.isException(url, h, ph, third, type));
    if (third) { const lu = url.toLowerCase(); for (const p of D.AD_PATHS) if (lu.includes(p)) return true; }
    if (web && pathOf(url).endsWith('.swf')) return true;
    if (web && this._isBannerAsset(url, type)) return true;
    return web && this.net.shouldBlock(url, h, ph, third, type);
  }

  /** 주소 모양이 배너 광고(이미지·플래시·영상)인지. 영상 배너(mp4/webm 등)도 여기서 잡는다 */
  _isBannerAsset(url, type) {
    const path = pathOf(url);
    if ((type & (T.IMAGE | T.OBJECT)) !== 0 && BANNER_PATH.test(path)) return true;
    if ((type & T.MEDIA) !== 0 && BANNER_VIDEO_PATH.test(path)) return true;
    return false;
  }

  _firstPartyAsset(url, h, ph, type) {
    if (pathOf(url).endsWith('.swf')) return true;
    if ((type & (T.IMAGE | T.OBJECT | T.MEDIA)) === 0) return false;
    if (this._isBannerAsset(url, type)) return true;
    return this.net.shouldBlock(url, h, ph, false, type);
  }

  /** 목록에 올라 있는 광고 서버인지 (이름 모양만 보고 짐작하는 규칙은 제외: 페이지 이동을 막을 때 쓰므로 엄격하게) */
  isAdHost(host) {
    if (!host) return false;
    const h = host.toLowerCase();
    if (matchesSet(h, BUILTIN)) return true;
    if (matchesSet(h, ALLOW)) return false;
    return matchesSet(h, this.hosts);
  }

  /** 이 주소가 광고인지 (페이지 안 스크립트가 팝업/링크를 열려 할 때 확인용) */
  isAdUrl(url) {
    if (!url) return false;
    const host = hostOfUrl(url);
    if (!host) return false;
    return this.isAdHost(host) || this.shouldBlock(host, null, url);
  }

  /** 이 주소가 광고 영상 배너인지 (페이지 스크립트가 <video> 를 검사할 때) */
  isAdVideoUrl(url, pageHost) {
    if (!url || !isWeb(url)) return false;
    const host = hostOfUrl(url);
    return !!host && this.shouldBlock(host, pageHost, url, T.MEDIA);
  }

  /** 지금 보는 사이트(와 그 상위 도메인)에만 해당하는 광고 영역 숨김 CSS */
  _siteCss(host) {
    if (!host || this.siteRules.size === 0) return '';
    let h = host.toLowerCase().replace(/^www\./, '');
    let out = '';
    for (;;) {
      const r = this.siteRules.get(h);
      if (r) out += buildCss(r);
      const dot = h.indexOf('.');
      if (dot < 0) break;
      h = h.substring(dot + 1);
      if (!h.includes('.')) break;
    }
    return out;
  }
  /** 첫 화면 프레임에 넣는 숨김 CSS: 기본 선택자 + 내려받은 일반 규칙 + 이 사이트 규칙 */
  topCss(host) { return COSMETIC_CSS + this.cssRules + this._siteCss(host); }
}

/** 내려받은 목록 파일 한 벌(줄 배열)에서 도메인 / 숨김 규칙 / 주소 규칙을 뽑는다 (안드로이드 update() 와 같은 걸러내기) */
function extractHosts(lines, includePureNetHosts) {
  const out = new Set();
  let n = 0;
  for (const raw of lines) {
    if (includePureNetHosts) {
      const r = parseNet(raw);
      if (r && !r.exception && r.isPureHost && HOST_REGEX.test(r.host)) out.add(r.host);
      continue;
    }
    const h = parseHostLine(raw);
    if (!h) continue;
    out.add(h);
    if (++n >= 250000) break;
  }
  return out;
}

module.exports = {
  AdEngine, BUILTIN, ALLOW, COSMETIC_CSS, MAX_NET_RULES, HOST_REGEX, V_ALLOW,
  registrable, matchesSet, parseHostLine, parseCosmetic, cleanSelector, buildCss, extractHosts, hostOfUrl,
};
