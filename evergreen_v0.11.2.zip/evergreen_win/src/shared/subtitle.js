'use strict';
// 자막 파일(VTT · SRT · ASS/SSA · TTML)을 읽어 시간별 글 목록으로 만든다. 안드로이드 SubtitleFile.kt 와 같은 규칙.
// 플레이어 화면(<script>)과 테스트(require)가 함께 쓴다.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvSubtitle = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var TAGS = /<[^>]+>/g;
  var TIME = /(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{1,3})/;

  function clean(s) {
    return s.replace(TAGS, '')
      .replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
      .split('\n').map(function (l) { return l.trim(); }).join('\n').trim();
  }
  function sec(m) {
    var h = m[1] ? parseInt(m[1], 10) : 0, mi = parseInt(m[2], 10), s = parseInt(m[3], 10);
    var ms = parseInt((m[4] + '00').slice(0, 3), 10);
    return h * 3600 + mi * 60 + s + ms / 1000;
  }
  function parseVttSrt(raw) {
    var out = [];
    raw.split(/\n{2,}/).forEach(function (block) {
      var lines = block.split('\n');
      var ai = -1;
      for (var i = 0; i < lines.length; i++) if (lines[i].indexOf('-->') >= 0) { ai = i; break; }
      if (ai < 0) return;
      var parts = lines[ai].split('-->');
      if (parts.length < 2) return;
      var a = TIME.exec(parts[0]), b = TIME.exec(parts[1]);
      if (!a || !b) return;
      var text = clean(lines.slice(ai + 1).join('\n'));
      if (text) out.push({ start: sec(a), end: sec(b), text: text });
    });
    return out;
  }
  function assTime(s) {
    var m = /(\d+):(\d{1,2}):(\d{1,2})[.:](\d{1,3})/.exec(s.trim());
    if (!m) return null;
    return parseInt(m[1], 10) * 3600 + parseInt(m[2], 10) * 60 + parseInt(m[3], 10) + parseFloat('0.' + m[4]);
  }
  // 앞에서 limit 칸까지만 쉼표로 자르고 나머지는 마지막 칸에 그대로 둔다 (코틀린 split(limit) 과 같다)
  function splitLimit(s, sep, limit) {
    var out = [], from = 0;
    while (out.length < limit - 1) {
      var i = s.indexOf(sep, from);
      if (i < 0) break;
      out.push(s.slice(from, i)); from = i + 1;
    }
    out.push(s.slice(from));
    return out;
  }
  function parseAss(raw) {
    var out = [], iStart = 1, iEnd = 2, iText = 9, cols = 10, inEvents = false;
    raw.split('\n').forEach(function (line) {
      var t = line.trim();
      if (t.charAt(0) === '[') { inEvents = t.toLowerCase() === '[events]'; return; }
      if (!inEvents) return;
      var low = t.toLowerCase();
      if (low.indexOf('format:') === 0) {
        var names = t.slice(t.indexOf(':') + 1).split(',').map(function (x) { return x.trim().toLowerCase(); });
        cols = names.length;
        var a = names.indexOf('start'), b = names.indexOf('end'), c = names.indexOf('text');
        if (a >= 0) iStart = a; if (b >= 0) iEnd = b; if (c >= 0) iText = c;
      } else if (low.indexOf('dialogue:') === 0) {
        var f = splitLimit(t.slice(t.indexOf(':') + 1), ',', cols);
        if (f.length <= iText) return;
        var s = assTime(f[iStart]), e = assTime(f[iEnd]);
        if (s == null || e == null) return;
        var text = f[iText].replace(/\{[^}]*\}/g, '').replace(/\\N/g, '\n').replace(/\\n/g, '\n').replace(/\\h/g, ' ').trim();
        if (text) out.push({ start: s, end: e, text: text });
      }
    });
    return out;
  }
  function ttmlTime(s) {
    var v = s.trim(), m;
    if ((m = /^(\d+(?:\.\d+)?)s$/.exec(v))) return parseFloat(m[1]);
    if ((m = /^(\d+(?:\.\d+)?)ms$/.exec(v))) return parseFloat(m[1]) / 1000;
    m = /^(\d+):(\d{2}):(\d{2})(?:[.,](\d+))?$/.exec(v);
    if (!m) return null;
    return parseInt(m[1], 10) * 3600 + parseInt(m[2], 10) * 60 + parseInt(m[3], 10) + (m[4] ? parseFloat('0.' + m[4]) : 0);
  }
  function attr(attrs, name) { var m = new RegExp('\\b' + name + '="([^"]+)"').exec(attrs); return m ? m[1] : null; }
  function parseTtml(raw) {
    var out = [], re = /<p\b([^>]*)>([\s\S]*?)<\/p>/gi, m;
    while ((m = re.exec(raw))) {
      var bs = attr(m[1], 'begin'); if (bs == null) continue;
      var b = ttmlTime(bs); if (b == null) continue;
      var es = attr(m[1], 'end'), ds = attr(m[1], 'dur');
      var e = es != null ? ttmlTime(es) : null, dur = ds != null ? ttmlTime(ds) : null;
      if (e == null) { if (dur == null) continue; e = b + dur; }
      var text = clean(m[2].replace(/<br\s*\/?>/gi, '\n'));
      if (text) out.push({ start: b, end: e, text: text });
    }
    return out;
  }

  function parse(rawIn) {
    var raw = String(rawIn || '').replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    var list;
    if (/\[Events\]/i.test(raw)) list = parseAss(raw);
    else if (/<tt[\s>]/i.test(raw.slice(0, 2000))) list = parseTtml(raw);
    else list = parseVttSrt(raw);
    return list.filter(function (c) { return c.text.trim() && c.end > c.start; }).sort(function (a, b) { return a.start - b.start; });
  }

  // t 초에 보여 줄 글 (겹치는 자막은 줄바꿈으로 이어 붙인다). 없으면 빈 글
  function textAt(cues, t) {
    if (!cues.length) return '';
    var lo = 0, hi = cues.length - 1, idx = -1;
    while (lo <= hi) {
      var mid = (lo + hi) >>> 1;
      if (cues[mid].start <= t) { idx = mid; lo = mid + 1; } else hi = mid - 1;
    }
    if (idx < 0) return '';
    var hit = [], i = idx, steps = 0;
    while (i >= 0 && steps < 8) { if (cues[i].end > t) hit.unshift(cues[i].text); i--; steps++; }
    return hit.join('\n');
  }
  return { parse: parse, textAt: textAt };
});
