'use strict';
// 페이지 번역의 순수 규칙: 번역할 글 묶기 · 요청 글 · 답 읽기. (Gemini · 화면은 건드리지 않는다)
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvTranslate = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var LANGS = [
    { key: 'ko', name: '한국어', en: 'Korean', re: /[\uAC00-\uD7A3]/g },
    { key: 'en', name: '영어', en: 'English', re: /[A-Za-z]/g },
    { key: 'ja', name: '일본어', en: 'Japanese', re: /[\u3040-\u30FF]/g },
    { key: 'zh', name: '중국어(간체)', en: 'Simplified Chinese', re: /[\u4E00-\u9FFF]/g },
  ];
  function lang(key) { return LANGS.filter(function (l) { return l.key === key; })[0] || LANGS[0]; }
  function nextLang(key) { var i = LANGS.map(function (l) { return l.key; }).indexOf(lang(key).key); return LANGS[(i + 1) % LANGS.length].key; }

  // 이미 목표 언어인 글(글자의 절반 넘게 목표 언어)은 보내지 않는다. 숫자 · 기호뿐인 글도 건너뛴다.
  function skip(text, key) {
    var t = String(text || '').trim();
    if (t.length < 2) return true;
    var base = t.replace(/[\s\d\p{P}\p{S}]/gu, '').length;   // 글자(숫자·기호·공백 뺀 것)
    if (!base) return true;
    var m = t.match(lang(key).re);
    return !!m && m.length / base > 0.5;
  }

  // items: [{ i, t }] → 묶음들 [{ items }] (글자 수 · 개수 한도)
  function batches(items, maxChars, maxItems) {
    maxChars = maxChars || 2800; maxItems = maxItems || 40;
    var out = [], cur = [], n = 0;
    items.forEach(function (it) {
      var len = it.t.length;
      if (cur.length && (n + len > maxChars || cur.length >= maxItems)) { out.push(cur); cur = []; n = 0; }
      cur.push(it); n += len;
    });
    if (cur.length) out.push(cur);
    return out;
  }

  function system(key) {
    var L = lang(key);
    return 'You are a translation engine inside a web browser. Translate every string of the JSON array the user sends into ' + L.en + '. ' +
      'Return ONLY a JSON array of strings with exactly the same number of elements in the same order. ' +
      'Keep numbers, URLs, code, brand and product names, and leading/trailing spaces as they are. Do not merge, split, add or explain anything. ' +
      'If a string is already in ' + L.en + ' or cannot be translated, return it unchanged.';
  }
  function user(batch) { return JSON.stringify(batch.map(function (x) { return x.t; })); }

  // 답에서 JSON 배열을 꺼낸다. 개수가 다르면 null (호출한 쪽이 더 작게 나눠 다시 보낸다)
  function parse(text, n) {
    var s = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    var a = s.indexOf('['), b = s.lastIndexOf(']');
    if (a < 0 || b < a) return null;
    var arr; try { arr = JSON.parse(s.slice(a, b + 1)); } catch (e) { return null; }
    if (!Array.isArray(arr) || arr.length !== n) return null;
    return arr.map(function (x) { return typeof x === 'string' ? x : x == null ? '' : String(x); });
  }
  return { LANGS: LANGS, lang: lang, nextLang: nextLang, skip: skip, batches: batches, system: system, user: user, parse: parse };
});
