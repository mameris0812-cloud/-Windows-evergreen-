'use strict';
(function () {
  var ev = window.evergreen, t = document.getElementById('t'), m = document.getElementById('m'), a = document.getElementById('a');
  ev.on('toast:show', function (p) {
    m.textContent = p.msg;
    a.hidden = !p.label; a.textContent = p.label || '';
    t.className = p.label ? 'act' : '';
    t.style.animation = 'none'; void t.offsetWidth; t.style.animation = '';
    // 나타나는 애니메이션(크기 변환) 중에도 실제 크기를 얻으려고 offset 크기를 쓴다
    requestAnimationFrame(function () { ev.send('toast:size', { w: t.offsetWidth, h: t.offsetHeight }); });
  });
  a.addEventListener('click', function () { ev.send('toast:action'); });
})();
