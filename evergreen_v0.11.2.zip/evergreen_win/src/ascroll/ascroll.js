'use strict';
// 자동 스크롤 조작 막대(맨 위의 작은 투명 뷰). 상태는 메인이 'as:state' 로 보내고, 단추는 'as:cmd' 로 알린다.
(function () {
  var ev = window.evergreen, $ = function (id) { return document.getElementById(id); };
  var p = $('p'), n = $('n'), u = $('u'), m = $('m'), f = $('f'), z = $('z'), x = $('x');
  x.innerHTML = icon('close', 22); m.innerHTML = icon('remove', 22); f.innerHTML = icon('add', 22);
  var timer = null, rep = null;

  function paint(s) {
    n.textContent = s.level;
    u.textContent = s.smart ? '스마트' : '단계';
    p.classList.toggle('smart', !!s.smart);
    p.classList.toggle('paused', !!s.paused);
    z.innerHTML = icon(s.paused ? 'play' : 'pause', 22);
    z.title = z.ariaLabel = s.paused ? '이어서 스크롤' : '일시정지';
    m.disabled = s.level <= s.min; f.disabled = s.level >= s.max;
    requestAnimationFrame(function () { ev.send('as:size', { w: p.offsetWidth + 52, h: p.offsetHeight + 36 }); });
  }
  ev.on('as:state', paint);

  function send(a) { ev.send('as:cmd', a); }
  // −/+ 는 꾹 누르면 계속 바뀐다
  function hold(btn, act) {
    btn.addEventListener('mousedown', function (e) {
      if (e.button !== 0 || btn.disabled) return;
      send(act);
      clearTimeout(timer); clearInterval(rep);
      timer = setTimeout(function () { rep = setInterval(function () { if (btn.disabled) { clearInterval(rep); return; } send(act); }, 110); }, 420);
    });
  }
  function release() { clearTimeout(timer); clearInterval(rep); }
  hold(m, 'slower'); hold(f, 'faster');
  window.addEventListener('mouseup', release); window.addEventListener('blur', release); document.addEventListener('mouseleave', release);
  z.addEventListener('click', function () { send('pause'); });
  x.addEventListener('click', function () { send('close'); });
})();
