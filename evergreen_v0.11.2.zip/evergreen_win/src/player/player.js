'use strict';
// 내장 플레이어 + 미러링 플레이어 화면. 같은 컨트롤을 두 가지 "뒤쪽"에 붙인다:
//  - 내장 플레이어(mode=player): 이 화면의 <video> (HLS 는 hls.js)
//  - 미러링(mode=mirror): 웹 페이지 안의 영상. 상태는 메인이 0.25초마다 읽어 오고(pl:mstate), 조작은 pl:cmd 로 보낸다.
(function () {
  var ev = window.evergreen, body = document.body;
  var $ = function (id) { return document.getElementById(id); };
  var MODE = new URLSearchParams(location.search).get('mode') === 'mirror' ? 'mirror' : 'player';
  body.classList.add(MODE === 'mirror' ? 'mirror' : 'local');
  var v = $('v');
  var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2, 3];
  var SUB_SIZE = ['작게', '보통', '크게', '아주 크게'], SUB_SCALE = [0.8, 1, 1.3, 1.7];
  var SUB_BG = ['기본', '없음', '반투명', '검정'], SUB_POS = ['낮게', '보통', '높게'], SUB_BOTTOM = [12, 28, 84];
  var FIT = [['contain', '화면에 맞추기'], ['cover', '화면 채우기 (확대)'], ['fill', '화면 늘리기']];

  var P = { media: null, prefs: { subSize: 1, subBg: 0, subPos: 1, subTr: 0, volume: 1, muted: false, swipe: true }, hls: null, fit: 0, retries: 0, fs: false };
  var st = { pos: 0, dur: 0, playing: false, speed: 1, buffered: 0, volume: 1, muted: false, loading: false, ended: false, live: false };
  var mst = null;                       // 미러링: 마지막으로 받은 페이지 상태
  var sub = { kind: 'off', label: '', cues: null, idx: -1, text: '' };
  var panel = { open: false, page: 'main', acts: [] };
  var dragging = false, uiT = 0, osdT = 0, zoom = { s: 1, x: 0, y: 0 }, lastTick = 0;

  // ───────── 아이콘 · 도움 ─────────
  [['bBack', 'back', 24], ['bPip', 'pip', 24], ['bFs', 'window_full', 24], ['bGear', 'settings', 24], ['bBack10', 'rewind_10', 32], ['bFwd10', 'forward_10', 32],
    ['icPlay', 'play', 40], ['icPause', 'pause', 40], ['bVol', 'volume_up', 24], ['bPrev', 'skip_prev', 26], ['bNext', 'skip_next', 26]].forEach(function (a) { $(a[0]).innerHTML = icon(a[1], a[2]); });
  $('loading').innerHTML = '<svg viewBox="0 0 76 76" width="76" height="76"><circle cx="38" cy="38" r="30" fill="none" stroke="rgba(255,255,255,.2)" stroke-width="4"/><path d="M38 8 A30 30 0 0 1 68 38" fill="none" stroke="var(--accent)" stroke-width="4" stroke-linecap="round"/></svg>';
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmt(s) {
    s = Math.max(0, Math.floor(s || 0));
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60, p = function (n) { return n < 10 ? '0' + n : '' + n; };
    return h ? h + ':' + p(m) + ':' + p(x) : m + ':' + p(x);
  }
  var speedLabel = function (s) { return (s % 1 === 0 ? s : s) + 'x'; };
  function osd(text, ms) {
    var o = $('osd'); o.textContent = text; o.classList.add('on');
    clearTimeout(osdT); osdT = setTimeout(function () { o.classList.remove('on'); }, ms || 900);
  }
  function savePrefs(p) { Object.assign(P.prefs, p); ev.send('pl:prefs', p); }

  // ───────── 뒤쪽(백엔드) ─────────
  function cmd(a, x) { ev.send('pl:cmd', { a: a, v: x }); }
  var B = {
    play: function () { if (MODE === 'mirror') cmd('play'); else { if (v.ended) v.currentTime = 0; var p = v.play(); if (p && p.catch) p.catch(function () {}); } },
    pause: function () { if (MODE === 'mirror') cmd('pause'); else v.pause(); },
    toggle: function () { (st.playing ? B.pause : B.play)(); },
    seek: function (t) { t = Math.max(0, Math.min(st.dur || t, t)); if (MODE === 'mirror') { cmd('seek', t); if (mst) mst.pos = t; } else { try { v.currentTime = t; } catch (e) { /* 아직 준비 전 */ } } st.pos = t; },
    rate: function (r) { if (MODE === 'mirror') cmd('rate', r); else v.playbackRate = r; st.speed = r; },
    volume: function (x) { x = Math.max(0, Math.min(1, x)); if (MODE === 'mirror') cmd('volume', x); else { v.volume = x; if (x > 0) v.muted = false; } st.volume = x; if (x > 0) st.muted = false; savePrefs({ volume: x, muted: false }); },
    mute: function (m) { if (MODE === 'mirror') cmd('mute', m); else v.muted = m; st.muted = m; savePrefs({ muted: m }); },
    fit: function (i) { P.fit = i; if (MODE === 'mirror') cmd('fit', FIT[i][0]); else v.className = i ? 'fit-' + FIT[i][0] : ''; },
  };
  function read() {
    if (MODE === 'mirror') {
      if (!mst) return;
      st.pos = mst.pos; st.dur = mst.dur; st.playing = mst.playing; st.speed = mst.speed; st.buffered = mst.buffered; st.volume = mst.volume; st.muted = mst.muted;
      st.loading = mst.loading; st.ended = mst.ended; st.live = mst.live;
      if (!dragging && mst.title && $('tTitle').textContent !== mst.title) setTitles(mst.title, mst.host);
    } else {
      var d = v.duration, b = 0;
      try { if (v.buffered.length) b = v.buffered.end(v.buffered.length - 1); } catch (e) { /* */ }
      st.pos = v.currentTime || 0; st.dur = isFinite(d) ? d : 0; st.live = !isFinite(d) && d !== undefined && v.readyState > 0; st.playing = !v.paused && !v.ended; st.speed = v.playbackRate;
      st.buffered = b; st.volume = v.volume; st.muted = v.muted; st.ended = v.ended;
      st.loading = (v.readyState < 3 && !v.paused && !v.ended && !$('err').classList.contains('on')) || v.seeking && v.readyState < 3;
    }
  }
  function setTitles(t, h) { $('tTitle').textContent = t || h || '동영상'; $('tHost').textContent = t && h ? h : ''; }

  // ───────── 화면 갱신 ─────────
  function paint() {
    read();
    body.classList.toggle('playing', st.playing);
    body.classList.toggle('loading', !!st.loading);
    if (!dragging) {
      var f = st.dur ? Math.min(1, st.pos / st.dur) : 0;
      $('seekFill').style.width = (f * 100) + '%'; $('seekThumb').style.left = (f * 100) + '%';
      $('seekBuf').style.width = (st.dur ? Math.min(100, st.buffered / st.dur * 100) : 0) + '%';
      $('tCur').textContent = fmt(st.pos);
    }
    $('tDur').textContent = st.live ? '실시간' : fmt(st.dur);
    $('seek').style.pointerEvents = st.dur ? '' : 'none'; $('seek').style.opacity = st.dur ? '' : '.5';
    var sp = speedLabel(st.speed); if ($('cSpeed').textContent !== sp) $('cSpeed').textContent = sp;
    $('bVol').innerHTML = icon(st.muted || st.volume === 0 ? 'volume_off' : 'volume_up', 24);
    if (document.activeElement !== $('vol')) $('vol').value = st.muted ? 0 : st.volume;
    updateSub();
    if (st.ended) poke(true);
  }
  function tick(ts) {
    if (ts - lastTick > 90) { lastTick = ts; paint(); }
    requestAnimationFrame(tick);
  }

  // ───────── 컨트롤 보이기/숨기기 ─────────
  function poke(keep) {
    body.classList.add('ui'); body.classList.remove('idle');
    clearTimeout(uiT);
    if (keep) return;
    uiT = setTimeout(function () { if (st.playing && !panel.open && !dragging) { body.classList.remove('ui'); body.classList.add('idle'); } }, 3000);
  }
  var lastMove = [0, 0];
  document.addEventListener('mousemove', function (e) { if (Math.abs(e.clientX - lastMove[0]) + Math.abs(e.clientY - lastMove[1]) < 3) return; lastMove = [e.clientX, e.clientY]; poke(); });
  document.addEventListener('mouseleave', function () { if (st.playing && !panel.open) { clearTimeout(uiT); uiT = setTimeout(function () { body.classList.remove('ui'); }, 600); } });

  // ───────── 재생 막대 ─────────
  var seekEl = $('seek'), dragT = 0, dragSent = 0;
  function fracAt(e) { var r = seekEl.getBoundingClientRect(); return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); }
  function seekPreview(f) { $('seekFill').style.width = (f * 100) + '%'; $('seekThumb').style.left = (f * 100) + '%'; $('tCur').textContent = fmt(f * st.dur); }
  seekEl.addEventListener('pointerdown', function (e) {
    if (!st.dur) return;
    e.preventDefault(); seekEl.setPointerCapture(e.pointerId); dragging = true; seekEl.classList.add('drag');
    dragT = fracAt(e) * st.dur; seekPreview(dragT / st.dur); poke(true);
  });
  seekEl.addEventListener('pointermove', function (e) {
    var f = fracAt(e), tip = $('seekTip'); tip.textContent = fmt(f * st.dur); tip.style.left = (f * 100) + '%';
    if (!dragging) return;
    dragT = f * st.dur; seekPreview(f);
    var now = Date.now(); if (MODE === 'player' && now - dragSent > 120) { dragSent = now; B.seek(dragT); } // 끄는 동안 그림도 따라오게
  });
  function seekEnd(e) {
    if (!dragging) return;
    dragging = false; seekEl.classList.remove('drag'); B.seek(dragT); poke();
  }
  seekEl.addEventListener('pointerup', seekEnd); seekEl.addEventListener('pointercancel', seekEnd);

  // ───────── 단추 ─────────
  function skip(d) { if (!st.dur && !st.live) return; B.seek(Math.max(0, st.pos + d)); osd((d > 0 ? '+' : '−') + Math.abs(d) + '초', 600); }
  $('bPlay').onclick = function () { B.toggle(); };
  $('bBack10').onclick = function () { skip(-10); }; $('bFwd10').onclick = function () { skip(10); };
  $('bBack').onclick = closePlayer;
  $('bFs').onclick = function () { ev.send('pl:fullscreen'); };
  $('bPip').onclick = function () { try { if (document.pictureInPictureElement) document.exitPictureInPicture(); else v.requestPictureInPicture(); } catch (e) { osd('작은 창으로 볼 수 없어요', 1500); } };
  $('bVol').onclick = function () { B.mute(!(st.muted || st.volume === 0)); if (st.volume === 0) B.volume(0.5); };
  $('vol').oninput = function () { B.volume(Number(this.value)); };
  $('cSpeed').onclick = cycleSpeed;
  $('cCc').onclick = function () { openPanel('subs'); };
  $('bGear').onclick = function () { openPanel('main'); };
  function cycleSpeed(back) { var i = SPEEDS.indexOf(st.speed); if (i < 0) i = 2; i = (i + (back === true ? -1 : 1) + SPEEDS.length) % SPEEDS.length; B.rate(SPEEDS[i]); osd('재생 속도 ' + speedLabel(SPEEDS[i])); }
  function closePlayer() {
    if (body.classList.contains('closing')) return;
    cleanup(); body.classList.add('closing'); setTimeout(function () { ev.send('pl:close'); }, MODE === 'mirror' ? 0 : 180);
  }
  function cleanup() { if (sleep) sleep.cancel(); if (P.hls) { try { P.hls.destroy(); } catch (e) { /* */ } P.hls = null; } try { v.pause(); } catch (e) { /* */ } }

  // ───────── 마우스: 한 번 = 재생/정지, 두 번(가운데 = 전체 화면, 양옆 = 10초), 끌어내리기 = 닫기, 휠 = 소리, Ctrl+휠 = 확대 ─────────
  var clickT = 0, swipe = null, swiped = false;
  function onControls(t) { return t.closest && t.closest('#top,#center,#bottom,#panel,#err'); }
  document.addEventListener('click', function (e) {
    if (panel.open || onControls(e.target) || swiped) { swiped = false; return; }
    clearTimeout(clickT); clickT = setTimeout(function () { toggleFx(); B.toggle(); }, 230);
  });
  document.addEventListener('dblclick', function (e) {
    if (panel.open || onControls(e.target)) return;
    clearTimeout(clickT);
    if (zoom.s > 1.01) { setZoom(1, 0, 0, true); return; }
    var f = e.clientX / innerWidth;
    if (f < 0.33) { skip(-10); ripple('l', '−10초'); } else if (f > 0.67) { skip(10); ripple('r', '+10초'); } else ev.send('pl:fullscreen');
  });
  function toggleFx() {  // 컨트롤이 닫혀 있을 때만 가운데에 재생/정지 효과 (열려 있으면 컨트롤에 이미 단추가 떠 있다)
    if (body.classList.contains('ui')) return;
    var d = document.createElement('div'); d.className = 'pop'; d.innerHTML = icon(st.playing ? 'pause' : 'play', 40); $('fx').appendChild(d); setTimeout(function () { d.remove(); }, 520);
  }
  function ripple(side, text) { var d = document.createElement('div'); d.className = 'rip ' + side; d.textContent = text; $('fx').appendChild(d); setTimeout(function () { d.remove(); }, 560); }
  document.addEventListener('wheel', function (e) {
    if (panel.open) return;
    e.preventDefault();
    if (e.ctrlKey && MODE === 'player') { var s = Math.max(1, Math.min(4, zoom.s * (e.deltaY < 0 ? 1.12 : 1 / 1.12))); setZoom(s, e.clientX, e.clientY); osd('확대 ' + Math.round(s * 100) + '%', 600); return; }
    var nv = Math.max(0, Math.min(1, (st.muted ? 0 : st.volume) + (e.deltaY < 0 ? 0.05 : -0.05)));
    B.volume(nv); osd('소리 ' + Math.round(nv * 100) + '%', 600);
  }, { passive: false });
  function setZoom(s, cx, cy, animate) {
    var r = { w: innerWidth, h: innerHeight };
    if (s <= 1.01) { zoom = { s: 1, x: 0, y: 0 }; } else {
      // 커서 아래 점이 그대로 있게 확대
      var k = s / zoom.s; zoom.x = cx - (cx - zoom.x) * k; zoom.y = cy - (cy - zoom.y) * k; zoom.s = s;
      zoom.x = Math.min(0, Math.max(r.w - r.w * s, zoom.x)); zoom.y = Math.min(0, Math.max(r.h - r.h * s, zoom.y));
    }
    v.style.transition = animate ? 'transform .2s' : 'none';
    v.style.transform = zoom.s === 1 ? '' : 'translate(' + zoom.x + 'px,' + zoom.y + 'px) scale(' + zoom.s + ')';
  }
  document.addEventListener('pointerdown', function (e) {
    if (e.button !== 0 || panel.open || onControls(e.target)) return;
    swipe = { x: e.clientX, y: e.clientY, mode: null, zx: zoom.x, zy: zoom.y };
  });
  document.addEventListener('pointermove', function (e) {
    if (!swipe) return;
    var dx = e.clientX - swipe.x, dy = e.clientY - swipe.y;
    if (!swipe.mode) {
      if (Math.abs(dx) + Math.abs(dy) < 10) return;
      if (zoom.s > 1.01) swipe.mode = 'pan'; else if (P.prefs.swipe && MODE === 'player' && dy > 0 && dy > Math.abs(dx) * 1.5) swipe.mode = 'down'; else { swipe = null; return; }
    }
    swiped = true;
    if (swipe.mode === 'pan') { zoom.x = swipe.zx + dx; zoom.y = swipe.zy + dy; setZoom(zoom.s, 0, 0); return; }
    // 영상이 손가락(커서)을 따라 내려오며 작아진다
    var f = Math.min(1, dy / innerHeight);
    var stg = $('stage'); stg.style.transition = 'none'; stg.style.transform = 'translateY(' + dy + 'px) scale(' + (1 - f * 0.45) + ')'; stg.style.opacity = String(1 - f * 0.7);
    body.style.background = 'rgba(0,0,0,' + (1 - f) + ')';
  });
  function swipeEnd(e) {
    if (!swipe) return;
    var s = swipe; swipe = null;
    if (s.mode !== 'down') { setTimeout(function () { swiped = false; }, 0); return; }
    var dy = e.clientY - s.y, stg = $('stage');
    if (dy > innerHeight * 0.22) { closePlayer(); return; }
    stg.style.transition = 'transform .25s cubic-bezier(.34,1.35,.64,1), opacity .2s'; stg.style.transform = ''; stg.style.opacity = ''; body.style.background = '';
    setTimeout(function () { swiped = false; }, 0);
  }
  document.addEventListener('pointerup', swipeEnd); document.addEventListener('pointercancel', swipeEnd);

  // ───────── 키보드 ─────────
  document.addEventListener('keydown', function (e) {
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    var k = e.key;
    if (document.activeElement === $('vol') && (k === 'ArrowLeft' || k === 'ArrowRight' || k === 'ArrowUp' || k === 'ArrowDown')) return;
    var used = true;
    if (k === 'Escape') { if (panel.open) closePanel(); else if (P.fs) ev.send('pl:fullscreen'); else closePlayer(); }
    else if (k === ' ' || k === 'k' || k === 'K') B.toggle();
    else if (k === 'ArrowLeft') skip(e.shiftKey ? -10 : -5); else if (k === 'ArrowRight') skip(e.shiftKey ? 10 : 5);
    else if (k === 'j' || k === 'J') skip(-10); else if (k === 'l' || k === 'L') skip(10);
    else if (k === 'ArrowUp' || k === 'ArrowDown') { var nv = Math.max(0, Math.min(1, (st.muted ? 0 : st.volume) + (k === 'ArrowUp' ? 0.05 : -0.05))); B.volume(nv); osd('소리 ' + Math.round(nv * 100) + '%', 600); }
    else if (k === 'm' || k === 'M') { B.mute(!st.muted); osd(st.muted ? '음소거' : '소리 켬', 600); }
    else if (k === 'f' || k === 'F' || k === 'F11') ev.send('pl:fullscreen');
    else if (k === 'c' || k === 'C') cycleSubs();
    else if ((k === 't' || k === 'T') && sub.kind !== 'off') cycleTr();
    else if (k === '>') cycleSpeed(); else if (k === '<') cycleSpeed(true);
    else if (k === 'Home') B.seek(0); else if (k === 'End' && st.dur) B.seek(st.dur - 0.5);
    else if (/^[0-9]$/.test(k) && st.dur) B.seek(st.dur * Number(k) / 10);
    else used = false;
    if (used) { e.preventDefault(); poke(); }
  });

  // ───────── 자막 ─────────
  function applySubStyle() {
    var s = $('sub'); s.className = 'bg' + P.prefs.subBg;
    document.documentElement.style.setProperty('--sub', SUB_SCALE[P.prefs.subSize]);
    s.style.bottom = SUB_BOTTOM[P.prefs.subPos] + 'px';
  }
  function trackList() {
    if (MODE === 'mirror') return ((mst && mst.tracks) || []).map(function (t) { return { idx: t.idx, label: t.label }; });
    var out = [], tl = v.textTracks;
    for (var i = 0; tl && i < tl.length; i++) if (tl[i].kind === 'subtitles' || tl[i].kind === 'captions') out.push({ idx: i, label: tl[i].label || tl[i].language || ('자막 ' + (out.length + 1)) });
    return out;
  }
  function trackCue() {
    var t = v.textTracks[sub.idx]; if (!t || !t.activeCues) return '';
    var s = [];
    for (var i = 0; i < t.activeCues.length; i++) { var d = document.createElement('div'); d.innerHTML = t.activeCues[i].text || ''; s.push((d.textContent || '').trim()); }
    return s.filter(Boolean).join('\n');
  }
  function updateSub() {
    var text = '';
    if (sub.kind === 'file' && sub.cues) text = EvSubtitle.textAt(sub.cues, st.pos);
    else if (sub.kind === 'track') text = MODE === 'mirror' ? ((mst && mst.cue) || '') : trackCue();
    if (text !== sub.text) { sub.text = text; renderSub(); }
    $('cCc').classList.toggle('dim', sub.kind === 'off');
    var tc = $('cTr'); tc.hidden = sub.kind === 'off'; if (!tc.hidden && tc.textContent !== trChipLabel()) tc.textContent = trChipLabel();
  }
  // ───────── 자막 번역 (Gemini) ─────────
  // 모드: 0 끔 · 1 번역만 · 2 번역 + 원문. 번역은 글 한 줄 단위로 캐시하고, 파일 자막은 앞으로 나올 줄을 미리 번역해 둔다(화면에 뜰 때 기다리지 않게).
  var TR_MODES = ['안 함', '번역만', '번역+원문'];
  var tr = { cache: new Map(), pending: new Set(), queue: [], timer: 0, busy: false, gen: 0, errAt: 0, off: false };
  function trLang() { return EvTranslate.lang(P.trLang); }
  function trChipLabel() { return P.prefs.subTr === 0 ? '번역 끔' : P.prefs.subTr === 1 ? '자막 번역' : '번역+원문'; }
  function subNorm(s) { return String(s || '').replace(/<[^>]+>/g, '').replace(/\s*\n\s*/g, ' ').trim(); }
  function trWanted(norm) { return P.prefs.subTr !== 0 && !!norm && !EvTranslate.skip(norm, P.trLang); }
  function renderSub() {
    var m = $('subMain'), o = $('subOrig'), text = sub.text, norm = subNorm(text), shown = text, orig = '', wait = false;
    if (text && trWanted(norm)) {
      var t = tr.cache.get(norm);
      if (t) { shown = t; if (P.prefs.subTr === 2) orig = text.replace(/<[^>]+>/g, ''); }
      else { wait = true; request(norm, true); }
    }
    m.textContent = shown; m.classList.toggle('on', !!shown); m.classList.toggle('wait', wait);
    o.textContent = orig; o.classList.toggle('on', !!orig);
  }
  function request(norm, urgent) {
    if (tr.cache.has(norm) || tr.pending.has(norm)) return;
    tr.pending.add(norm);
    if (urgent) tr.queue.unshift(norm); else tr.queue.push(norm);
    if (!tr.timer) tr.timer = setTimeout(pump, urgent ? 60 : 200);
  }
  function trFail(err) {
    var now = Date.now(); if (now - tr.errAt > 15000) { tr.errAt = now; osd('자막 번역 실패 · ' + err, 2600); }
  }
  function pump() {
    tr.timer = 0; if (tr.busy || !tr.queue.length) return;
    var batch = tr.queue.splice(0, 30), gen = tr.gen; tr.busy = true;
    ev.invoke('pl:tr', { texts: batch }).then(function (r) {
      tr.busy = false; batch.forEach(function (b) { tr.pending.delete(b); });
      if (gen !== tr.gen) { if (tr.queue.length) pump(); return; }
      if (!r || r.error || !r.out) { trFail((r && r.error) || '응답 없음'); tr.queue.length = 0; tr.pending.clear(); return; }
      batch.forEach(function (b, i) { if (r.out[i] && String(r.out[i]).trim()) tr.cache.set(b, String(r.out[i]).trim()); });
      if (tr.cache.size > 4000) { var n = 0; tr.cache.forEach(function (_v, k) { if (n++ < 500) tr.cache.delete(k); }); }
      renderSub();
      if (tr.queue.length) tr.timer = setTimeout(pump, 120);
    }, function () { tr.busy = false; batch.forEach(function (b) { tr.pending.delete(b); }); trFail('연결 실패'); });
  }
  // 파일 자막: 지금 위치부터 앞으로 나올 줄을 앞쪽부터 미리 번역한다 (최대 3000줄)
  function prefetchSubs() {
    if (P.prefs.subTr === 0 || sub.kind !== 'file' || !sub.cues) return;
    var cues = sub.cues, i = 0, seen = {}, out = [];
    while (i < cues.length && cues[i].end <= st.pos) i++;
    for (var n = 0; n < cues.length && out.length < 3000; n++) {
      var c = cues[(i + n) % cues.length], norm = subNorm(c.text);
      if (!trWanted(norm) || tr.cache.has(norm) || seen[norm]) continue;
      seen[norm] = 1; out.push(norm);
    }
    out.forEach(function (x) { request(x, false); });
  }
  function resetTr() { tr.gen++; tr.queue.length = 0; tr.pending.clear(); tr.busy = false; clearTimeout(tr.timer); tr.timer = 0; }
  function setTrMode(m, quiet) {
    savePrefs({ subTr: m }); resetTr();
    if (m !== 0 && !P.trLangKnown) P.trLangKnown = 1;
    renderSub(); prefetchSubs();
    if (!quiet) osd(m === 0 ? '자막 번역을 껐어요' : m === 1 ? '자막을 ' + trLang().name + '(으)로 번역해요' : trLang().name + ' 번역 + 원문을 함께 보여요', 1500);
  }
  function cycleTr() { setTrMode((P.prefs.subTr + 1) % 3); }
  $('cTr').onclick = cycleTr;
  function setSub(kind, o) {
    // 영상 자막 줄은 전부 'hidden' 으로 두고 우리가 직접 그린다 (크기·배경·위치 설정을 따르게)
    if (MODE === 'player') for (var i = 0; i < v.textTracks.length; i++) v.textTracks[i].mode = 'disabled';
    sub = { kind: kind, label: (o && o.label) || '', cues: (o && o.cues) || null, idx: o && o.idx != null ? o.idx : -1, text: '' };
    if (kind === 'track') { if (MODE === 'mirror') cmd('track', sub.idx); else v.textTracks[sub.idx].mode = 'hidden'; }
    else if (MODE === 'mirror') cmd('track', -1);
    $('subMain').classList.remove('on'); $('subOrig').classList.remove('on'); updateSub(); resetTr(); prefetchSubs();
  }
  function cycleSubs() {
    var list = trackList();
    if (sub.kind === 'file') { setSub('off'); osd('자막 끔'); return; }
    var cur = sub.kind === 'track' ? list.map(function (t) { return t.idx; }).indexOf(sub.idx) : -1, next = cur + 1;
    if (next >= list.length) { setSub('off'); osd('자막 끔'); } else { setSub('track', { idx: list[next].idx, label: list[next].label }); osd('자막 · ' + list[next].label); }
  }
  function loadSubFile(name, text) {
    var cues = EvSubtitle.parse(text);
    if (!cues.length) { osd('자막을 읽지 못했어요 (vtt · srt · ass · ttml)', 2200); return false; }
    setSub('file', { label: name, cues: cues }); osd('자막 · ' + name + ' (' + cues.length + '줄)', 1600); return true;
  }
  function loadSubUrl(o) {
    fetch(o.url).then(function (r) { if (!r.ok) throw new Error(r.status); return r.text(); }).then(function (t) { loadSubFile(o.label || '자막', t); }).catch(function () { osd('자막을 불러오지 못했어요', 2000); });
  }

  // ───────── 설정 카드 ─────────
  var sleep = EvSleep.SleepTimer(function () {
    B.pause(); poke(true); osd('취침 타이머로 재생을 멈췄어요', 3500);
  });
  function levels() { return P.hls && P.hls.levels ? P.hls.levels : []; }
  function levelLabel(l) { return l.height ? l.height + 'p' : (l.bitrate ? Math.round(l.bitrate / 1000) + 'kbps' : '화질'); }
  function openPanel(page) {
    panel.open = true; panel.page = page || 'main'; var p = $('panel');
    $('scrim').classList.add('on'); p.classList.remove('out'); p.classList.add('on'); renderPanel(); poke(true);
  }
  function closePanel() {
    if (!panel.open) return;
    panel.open = false; var p = $('panel'); p.classList.add('out'); $('scrim').classList.remove('on');
    setTimeout(function () { if (!panel.open) { p.classList.remove('on', 'out'); p.innerHTML = ''; } }, 140); poke();
  }
  $('scrim').addEventListener('mousedown', closePanel);
  function header(title, back) { return '<div class="ph">' + (back ? '<button class="ib" data-act="back">' + icon('back', 22) + '</button>' : '') + '<b>' + esc(title) + '</b></div>'; }
  function rows(list) {
    return list.map(function (r, i) {
      panel.acts.push(r.fn || null);
      var cls = 'row' + (i === 0 ? ' first' : '') + (i === list.length - 1 ? ' last' : '') + (r.sel ? ' sel' : '') + (r.dis ? ' dis' : '');
      return '<div class="' + cls + '" data-i="' + (panel.acts.length - 1) + '"><span class="lb">' + esc(r.lb) + '</span>' + (r.val != null ? '<span class="val">' + esc(r.val) + '</span>' : '') +
        (r.sel ? '<span class="ck">' + icon('check', 20) + '</span>' : (r.chev ? '<span class="ck" style="color:rgba(255,255,255,.55)">' + icon('chevron_right', 20) + '</span>' : '')) + '</div>';
    }).join('');
  }
  function go(page) { panel.page = page; renderPanel(); }
  function renderPanel() {
    var el = $('panel'), pg = panel.page, h = '', list = []; panel.acts = [];
    var fresh = function (fn) { return function () { fn(); renderPanel(); }; };
    if (pg === 'main') {
      h = header('설정', false);
      var lv = levels();
      if (lv.length > 1) { var cur = P.hls.currentLevel, auto = P.hls.autoLevelEnabled; list.push({ lb: '화질', val: auto ? '자동' + (lv[P.hls.currentLevel] ? ' (' + levelLabel(lv[P.hls.currentLevel]) + ')' : '') : levelLabel(lv[cur] || {}), chev: 1, fn: function () { go('quality'); } }); }
      if (P.hls && P.hls.audioTracks && P.hls.audioTracks.length > 1) list.push({ lb: '음성', val: (P.hls.audioTracks[P.hls.audioTrack] || {}).name || '', chev: 1, fn: function () { go('audio'); } });
      list.push({ lb: '자막', val: sub.kind === 'off' ? '끔' : (sub.kind === 'file' ? '파일 · ' : '영상 자막 · ') + sub.label, chev: 1, fn: function () { go('subs'); } });
      list.push({ lb: '재생 속도', val: speedLabel(st.speed), chev: 1, fn: function () { go('speed'); } });
      list.push({ lb: '취침 타이머', val: sleep.valueLabel(), chev: 1, fn: function () { go('sleep'); } });
      list.push({ lb: '화면 비율', val: FIT[P.fit][1], chev: 1, fn: function () { go('fit'); } });
      list.push({ lb: '동영상 저장', fn: function () { closePanel(); save(); } });
    } else if (pg === 'quality') {
      h = header('화질', true); var l2 = levels();
      list.push({ lb: '자동', sel: P.hls.autoLevelEnabled, fn: fresh(function () { P.hls.currentLevel = -1; }) });
      l2.map(function (l, i) { return { l: l, i: i }; }).sort(function (a, b) { return (b.l.height || 0) - (a.l.height || 0) || b.l.bitrate - a.l.bitrate; }).forEach(function (o) {
        list.push({ lb: levelLabel(o.l), val: o.l.bitrate ? Math.round(o.l.bitrate / 1000) + ' kbps' : '', sel: !P.hls.autoLevelEnabled && P.hls.currentLevel === o.i, fn: fresh(function () { P.hls.currentLevel = o.i; }) });
      });
    } else if (pg === 'audio') {
      h = header('음성', true);
      P.hls.audioTracks.forEach(function (t, i) { list.push({ lb: t.name || t.lang || ('음성 ' + (i + 1)), sel: P.hls.audioTrack === i, fn: fresh(function () { P.hls.audioTrack = i; }) }); });
    } else if (pg === 'subs') {
      h = header('자막', true);
      list.push({ lb: '끔', sel: sub.kind === 'off', fn: fresh(function () { setSub('off'); }) });
      trackList().forEach(function (t) { list.push({ lb: t.label, sel: sub.kind === 'track' && sub.idx === t.idx, fn: fresh(function () { setSub('track', { idx: t.idx, label: t.label }); }) }); });
      ((P.media && P.media.subs) || []).forEach(function (o) { list.push({ lb: o.label || '자막 파일', val: o.lang || '', sel: sub.kind === 'file' && sub.label === (o.label || '자막'), fn: function () { loadSubUrl(o); closePanel(); } }); });
      list.push({ lb: '자막 파일 열기…', fn: function () { ev.invoke('pl:subfile').then(function (r) { if (r && loadSubFile(r.name, r.text)) closePanel(); else if (r) renderPanel(); }); } });
      list.push({ lb: '자막 번역', val: TR_MODES[P.prefs.subTr] + (P.prefs.subTr ? ' · ' + trLang().name : ''), chev: 1, fn: function () { go('subtr'); } });
      list.push({ lb: '자막 스타일', val: SUB_SIZE[P.prefs.subSize] + ' · ' + SUB_BG[P.prefs.subBg], chev: 1, fn: function () { go('substyle'); } });
    } else if (pg === 'subtr') {
      h = header('자막 번역', true);
      TR_MODES.forEach(function (n, i) { list.push({ lb: i === 0 ? n : i === 1 ? trLang().name + ' 번역' : '번역 + 원문', sel: P.prefs.subTr === i, fn: fresh(function () { setTrMode(i, true); }) }); });
    } else if (pg === 'substyle') {
      h = header('자막 스타일', true);
      list.push({ lb: '글자 크기', val: SUB_SIZE[P.prefs.subSize], chev: 1, fn: function () { go('subsize'); } });
      list.push({ lb: '배경', val: SUB_BG[P.prefs.subBg], chev: 1, fn: function () { go('subbg'); } });
      list.push({ lb: '위치', val: SUB_POS[P.prefs.subPos], chev: 1, fn: function () { go('subpos'); } });
    } else if (pg === 'subsize' || pg === 'subbg' || pg === 'subpos') {
      var key = { subsize: 'subSize', subbg: 'subBg', subpos: 'subPos' }[pg], names = { subsize: SUB_SIZE, subbg: SUB_BG, subpos: SUB_POS }[pg];
      h = header({ subsize: '글자 크기', subbg: '배경', subpos: '위치' }[pg], true);
      names.forEach(function (n, i) { list.push({ lb: n, sel: P.prefs[key] === i, fn: fresh(function () { var o = {}; o[key] = i; savePrefs(o); applySubStyle(); if (!$('subMain').classList.contains('on')) previewSub(); }) }); });
    } else if (pg === 'speed') {
      h = header('재생 속도', true);
      SPEEDS.forEach(function (s) { list.push({ lb: s === 1 ? '보통 (1x)' : speedLabel(s), sel: st.speed === s, fn: fresh(function () { B.rate(s); }) }); });
    } else if (pg === 'sleep') {
      h = header('취침 타이머', true);
      list.push({ lb: '끔', sel: !sleep.active, fn: fresh(function () { sleep.cancel(); osd('취침 타이머를 껐어요'); }) });
      EvSleep.OPTIONS.forEach(function (m) { list.push({ lb: EvSleep.label(m) + ' 뒤', fn: function () { sleep.start(m); osd(EvSleep.label(m) + ' 뒤에 재생을 멈춰요', 1500); closePanel(); } }); });
    } else if (pg === 'fit') {
      h = header('화면 비율', true);
      FIT.forEach(function (f, i) { list.push({ lb: f[1], sel: P.fit === i, fn: fresh(function () { B.fit(i); }) }); });
    }
    el.innerHTML = h + rows(list);
  }
  $('panel').addEventListener('click', function (e) {
    if (e.target.closest('[data-act="back"]')) { go(panel.page === 'subtr' ? 'subs' : panel.page === 'subsize' || panel.page === 'subbg' || panel.page === 'subpos' ? 'substyle' : (panel.page === 'substyle' ? 'subs' : 'main')); return; }
    var r = e.target.closest('[data-i]'); if (!r) return;
    var fn = panel.acts[Number(r.dataset.i)]; if (fn) fn();
  });
  function previewSub() { var m = $('subMain'); m.textContent = '자막 미리보기'; m.classList.add('on'); clearTimeout(previewSub.t); previewSub.t = setTimeout(function () { sub.text = '\u0000'; updateSub(); }, 1800); }

  // ───────── 저장 ─────────
  function save() { ev.send('pl:save', { url: MODE === 'mirror' ? (mst && mst.src) || '' : (P.media && P.media.url) || '', title: $('tTitle').textContent }); }

  // ───────── 재생 시작 · 오류 ─────────
  function showError(title, hint, code) {
    $('errT').textContent = title; $('errH').textContent = (hint || '') + (code ? '\n' + code : ''); $('err').classList.add('on'); body.classList.remove('loading'); poke(true);
  }
  function hideError() { $('err').classList.remove('on'); }
  var MEDIA_ERR = { 1: '재생이 중단되었어요', 2: '네트워크 문제로 영상을 불러오지 못했어요', 3: '영상을 해석하지 못했어요', 4: '이 영상은 재생할 수 없어요' };
  v.addEventListener('error', function () {
    var e = v.error; if (!e || P.hls) return;
    showError(MEDIA_ERR[e.code] || '재생 오류', e.code === 4 ? '지원하지 않는 형식이거나, 주소가 막혔거나 만료되었을 수 있어요. 페이지에서 직접 보려면 미러링을 써 보세요.' : e.code === 3 ? '지원하지 않는 코덱일 수 있어요.' : '', 'MEDIA_ERR_' + e.code + (e.message ? ' · ' + e.message : ''));
  });
  v.addEventListener('playing', hideError); v.addEventListener('canplay', hideError);
  $('errRetry').onclick = function () { hideError(); P.retries = 0; attach(P.media.url, st.pos); };
  function attach(url, startAt) {
    if (P.hls) { try { P.hls.destroy(); } catch (e) { /* */ } P.hls = null; }
    var start = startAt > 1 ? startAt : 0;
    if (window.EvHls.looksLikeHls(url, '')) {
      if (window.Hls && window.Hls.isSupported()) {
        var h = P.hls = new window.Hls({ enableWorker: true, startPosition: start || -1, maxBufferLength: 40, backBufferLength: 30 });
        h.loadSource(url); h.attachMedia(v);
        h.on(window.Hls.Events.ERROR, function (_e, d) {
          if (!d.fatal) return;
          if (d.type === window.Hls.ErrorTypes.NETWORK_ERROR && P.retries++ < 3) { setTimeout(function () { h.startLoad(); }, 600 * P.retries); return; }
          if (d.type === window.Hls.ErrorTypes.MEDIA_ERROR && P.retries++ < 3) { h.recoverMediaError(); return; }
          showError(d.type === window.Hls.ErrorTypes.NETWORK_ERROR ? '네트워크 문제로 영상을 불러오지 못했어요' : '이 영상은 재생할 수 없어요', '스트리밍 목록(m3u8)을 읽는 중 오류가 났어요.', 'HLS · ' + (d.details || d.type) + (d.response && d.response.code ? ' · HTTP ' + d.response.code : ''));
        });
        h.on(window.Hls.Events.MANIFEST_PARSED, function () { P.retries = 0; var p = v.play(); if (p && p.catch) p.catch(function () {}); });
        h.on(window.Hls.Events.LEVEL_SWITCHED, function () { if (panel.open && (panel.page === 'main' || panel.page === 'quality')) renderPanel(); });
      } else if (v.canPlayType('application/vnd.apple.mpegurl')) { v.src = url; if (start) v.currentTime = start; v.play().catch(function () {}); }
      else { showError('스트리밍(m3u8) 재생 모듈이 없어요', 'npm install 을 다시 하면 hls.js 가 설치돼요.', 'hls.js 없음'); }
    } else {
      v.src = url; if (start) v.addEventListener('loadedmetadata', function () { v.currentTime = start; }, { once: true });
      var p = v.play(); if (p && p.catch) p.catch(function () {});
    }
  }

  // ───────── 시작 ─────────
  ev.on('pl:init', function (m) {
    P.media = m; Object.assign(P.prefs, m.prefs || {}); P.trLang = m.trLang || 'ko';
    document.documentElement.classList.toggle('dark', !!m.dark); body.classList.toggle('dark', !!m.dark);
    document.documentElement.style.setProperty('--cap', (m.capRight || 0) + 'px');
    setTitles(m.title, m.host); applySubStyle();
    $('bPip').hidden = MODE === 'mirror' || !document.pictureInPictureEnabled;
    $('bPrev').hidden = $('bNext').hidden = true;
    if (MODE === 'mirror') { poke(); return; }
    v.volume = P.prefs.volume; v.muted = !!P.prefs.muted; st.volume = v.volume;
    attach(m.url, m.startAt || 0);
    poke();
  });
  ev.on('pl:mstate', function (s) { mst = s; });
  ev.on('pl:fs', function (m) { P.fs = !!m.on; document.documentElement.style.setProperty('--cap', (m.on ? 0 : m.capRight) + 'px'); $('bFs').title = m.on ? '전체 화면 끝내기 (F)' : '전체 화면 (F)'; });
  ev.on('pl:toast', function (t) { osd(t, 2200); });
  requestAnimationFrame(tick);
  window.__player = { st: st, B: B, openPanel: openPanel, closePanel: closePanel, setSub: setSub, loadSubFile: loadSubFile, poke: poke, osd: osd, showError: showError, sleep: sleep, sub: function () { return sub; } };
  ev.send('pl:ready');
})();
