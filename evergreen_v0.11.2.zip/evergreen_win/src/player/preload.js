'use strict';
// 플레이어 화면(내장 플레이어 · 미러링 컨트롤)에만 붙는 다리.
const { contextBridge, ipcRenderer } = require('electron');
const SEND = new Set(['pl:ready', 'pl:close', 'pl:fullscreen', 'pl:prefs', 'pl:save', 'pl:cmd']);
const RECV = new Set(['pl:init', 'pl:mstate', 'pl:fs', 'pl:toast']);
const INVOKE = new Set(['pl:subfile', 'pl:tr']);
contextBridge.exposeInMainWorld('evergreen', {
  send: (ch, payload) => { if (SEND.has(ch)) ipcRenderer.send(ch, payload); },
  on: (ch, cb) => { if (RECV.has(ch)) ipcRenderer.on(ch, (_e, p) => cb(p)); },
  invoke: (ch, payload) => (INVOKE.has(ch) ? ipcRenderer.invoke(ch, payload) : Promise.reject(new Error('blocked'))),
});
