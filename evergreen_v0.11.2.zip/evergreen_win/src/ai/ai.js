'use strict';
(function () {
  const ev = window.evergreen;
  const $ = (s) => document.querySelector(s);
  const esc = EvMd.esc;
  const I = (n, s) => icon(n, s || 18);
  let info = null, msgs = [], busy = false, cur = null, attach = [], searchOnce = null, view = 'chat', chatId = null, pageOk = false, pageRef = true, stuck = true, renderT = null;
  const listEl = $('#list'), scrollEl = $('#scroll'), inputEl = $('#input'), sheet = $('#sheet');

  // ───────── 고정 아이콘 ─────────
  $('#logo').innerHTML = I('ai', 16);
  $('#bNew').innerHTML = I('add', 20); $('#bHist').innerHTML = I('history', 20); $('#bSet').innerHTML = I('settings', 20); $('#bClose').innerHTML = I('close', 20);
  $('#bAttach').innerHTML = I('add', 15);
  $('#jump').innerHTML = I('arrow_down', 20);

  // ───────── 맨 아래로 ─────────
  const atBottom = () => scrollEl.scrollHeight - scrollEl.scrollTop - scrollEl.clientHeight < 60;
  function toEnd(force) { if (force || stuck) scrollEl.scrollTop = scrollEl.scrollHeight; }
  scrollEl.addEventListener('scroll', () => { stuck = atBottom(); $('#jump').hidden = stuck; });
  $('#jump').addEventListener('click', () => { stuck = true; toEnd(true); });

  // ───────── 그리기 ─────────
  function attHtml(a) { return '<span class="att">' + I(/\.(png|jpe?g|gif|webp|bmp)$/i.test(a) ? 'image' : 'doc_text', 14) + '<span>' + esc(a) + '</span></span>'; }
  function thinkHtml(m, live) {
    if (!m.thought && !live && !m.thinkMs) return '';
    const sec = m.thinkMs ? (m.thinkMs / 1000).toFixed(1) + '초' : '';
    const head = live && !m.text ? '<span class="glyph"></span><span>생각하는 중…</span>' : '<span class="glyph done">' + I('check_bold', 11) + '</span><span>' + (sec ? sec + ' 동안 생각했어요' : '생각 과정') + '</span>';
    return '<div class="think' + (m._open ? ' open' : '') + '"><button class="think-h" type="button">' + head + (m.thought ? '<span class="chev">' + I('expand_more', 16) + '</span>' : '') + '</button>' +
      (m.thought ? '<div class="think-b">' + EvMd.render(m.thought) + '</div>' : '') + '</div>';
  }
  function toolsHtml(m) {
    if (!m.tools || !m.tools.length) return '';
    return '<div class="tools">' + m.tools.map((t) => '<div class="tool ' + t.status + '" data-id="' + t.id + '"><span class="ti">' + (t.status === 'run' ? '<span class="glyph"></span>' : t.status === 'ok' ? I('check_bold', 12) : I('close', 12)) + '</span><span class="tl">' + esc(t.label) + '</span>' +
      '<span class="td">' + esc(t.status === 'denied' ? '거절됨' : t.status === 'fail' && t.note ? t.note : t.detail || '') + '</span></div>').join('') + '</div>';
  }
  function srcHtml(m) {
    let h = '';
    if (m.queries && m.queries.length) h += '<div class="queries">' + I('search', 13) + '<span>' + esc(m.queries.slice(0, 3).join(' · ')) + '</span></div>';
    if (info && info.settings.sources && m.sources && m.sources.length) h += '<div class="sources">' + m.sources.slice(0, 8).map((s) => '<a class="src" data-url="' + esc(s.url) + '" title="' + esc(s.url) + '">' + I('globe', 13) + '<span>' + esc(s.title) + '</span></a>').join('') + '</div>';
    return h;
  }
  function msgHtml(m, i, last, live) {
    if (m.role === 'user') {
      return '<div class="msg user" data-i="' + i + '">' + (m.attach && m.attach.length ? '<div class="atts">' + m.attach.map(attHtml).join('') + '</div>' : '') + '<div class="bub">' + esc(m.shown || m.text) + '</div></div>';
    }
    const body = m.text ? EvMd.render(m.text, { streaming: live && busy }) : (live && busy && !m.tools.length ? '' : '');
    return '<div class="msg ai' + (last ? ' last' : '') + '" data-i="' + i + '">' + thinkHtml(m, live) + toolsHtml(m) + '<div class="body">' + body + '</div>' + srcHtml(m) +
      (m.error ? '<div class="err">' + esc(m.error) + (/키/.test(m.error) ? '' : '') + '</div>' : '') +
      (!live || !busy ? '<div class="acts"><button class="act cp" type="button">' + I('copy', 15) + '복사</button>' + (last ? '<button class="act re" type="button">' + I('refresh', 15) + '다시 생성</button>' : '') + '</div>' : '') +
      (m.model && !live ? '' : '') + '</div>';
  }
  function emptyHtml() {
    const noKey = info && !info.keys.length;
    return '<div class="empty"><div class="orb">' + I('ai', 30) + '</div><h2>' + (noKey ? 'API 키를 넣어 주세요' : '무엇을 도와드릴까요?') + '</h2><p>' +
      (noKey ? '⚙ 설정에서 구글 AI 스튜디오의 무료 API 키를 넣으면<br>채팅 · 페이지 요약 · 앱 조작을 쓸 수 있어요.' : '지금 보는 페이지에 대해 묻거나,<br>탭 · 북마크 · 설정을 말로 시켜 보세요.') + '</p></div>';
  }
  function draw(keepScroll) {
    if (!msgs.length) { listEl.innerHTML = emptyHtml(); drawChips(); return; }
    const y = scrollEl.scrollTop;
    listEl.innerHTML = msgs.map((m, i) => msgHtml(m, i, i === msgs.length - 1, i === msgs.length - 1 && m === cur)).join('');
    afterRender(listEl);
    if (keepScroll) scrollEl.scrollTop = y; else toEnd(true);
    drawChips();
  }
  // 답변 하나만 다시 그린다 (받는 중에는 이것만 자주 부른다)
  function drawCur() {
    if (!cur) return;
    const i = msgs.indexOf(cur), el = listEl.querySelector('.msg[data-i="' + i + '"]');
    if (!el) return draw();
    const html = msgHtml(cur, i, true, true), tmp = document.createElement('div'); tmp.innerHTML = html;
    const open = el.querySelector('.think') && el.querySelector('.think').classList.contains('open');
    const nu = tmp.firstChild; if (open && nu.querySelector('.think')) nu.querySelector('.think').classList.add('open');
    // 이미 그려진 그래프는 그대로 두어 그리기 애니메이션이 다시 돌지 않게 한다
    el.replaceWith(nu); afterRender(nu); toEnd(false);
  }
  function scheduleCur() { if (renderT) return; renderT = setTimeout(() => { renderT = null; drawCur(); }, 60); }

  // 그래프 · 코드 복사 · 링크
  let gid = 0;
  function afterRender(root) {
    root.querySelectorAll('.graph').forEach((el) => {
      const spec = EvGraph.parse(el.dataset.src || '');
      if (spec.isEmpty) { el.innerHTML = '<div class="wait">그래프를 그리는 중…</div>'; return; }
      const r = EvGraph.render(spec, { width: Math.max(260, el.clientWidth || 340), uid: 'g' + (++gid) });
      el.innerHTML = r.svg;
      const svg = el.querySelector('svg'); if (!svg) return;
      const hov = svg.querySelector('.hover'); let tip = null;
      const clear = () => { hov.innerHTML = ''; if (tip) { tip.remove(); tip = null; } };
      const move = (e) => {
        const b = svg.getBoundingClientRect(), x = (e.clientX - b.left) * (r.meta.W / b.width), h = EvGraph.hover(r.meta, x);
        if (!h) return clear();
        let g = '<line x1="' + h.anchor + '" x2="' + h.anchor + '" y1="' + r.meta.plot.top + '" y2="' + r.meta.plot.bottom + '" stroke="var(--muted)" stroke-width="1.2" stroke-dasharray="4 3"/>';
        if (h.slot) g = '<rect x="' + h.slot.x + '" y="' + r.meta.plot.top + '" width="' + h.slot.w + '" height="' + r.meta.plot.h + '" fill="var(--text)" fill-opacity=".07"/>';
        h.dots.forEach((d) => { g += '<circle cx="' + d.x + '" cy="' + d.y + '" r="6" fill="var(--surface)"/><circle cx="' + d.x + '" cy="' + d.y + '" r="4.4" fill="' + d.color + '"/>'; });
        hov.innerHTML = g;
        if (!tip) { tip = document.createElement('div'); tip.className = 'gtip'; el.appendChild(tip); }
        tip.innerHTML = '<b>' + esc(h.head) + '</b>' + h.rows.map((rw) => '<div><i style="background:' + rw.color + '"></i>' + esc(rw.text) + '</div>').join('');
        const px = h.anchor / r.meta.W * b.width, w = tip.offsetWidth;
        tip.style.left = Math.max(4, Math.min(b.width - w - 4, px + 12 > b.width - w ? px - w - 12 : px + 12)) + 'px';
      };
      svg.addEventListener('pointermove', move); svg.addEventListener('pointerleave', clear); svg.addEventListener('pointerdown', move);
      // 점: 위에 가져가면 이름 · 축 값
      svg.querySelectorAll('.pt').forEach((p) => {
        const m = spec.points[+p.dataset.i], cx = r.meta.px(m.x), cy = r.meta.py(m.y);
        p.addEventListener('pointerenter', () => {
          let g = '<g pointer-events="none"><line x1="' + cx + '" x2="' + cx + '" y1="' + cy + '" y2="' + r.meta.ayPos + '" stroke="' + r.meta.ptColor + '" stroke-width="1.2" stroke-dasharray="4 3"/><line x1="' + cx + '" x2="' + r.meta.axPos + '" y1="' + cy + '" y2="' + cy + '" stroke="' + r.meta.ptColor + '" stroke-width="1.2" stroke-dasharray="4 3"/>';
          const chip = (t, x, y) => { const w = t.length * 6.6 + 12; return '<rect x="' + (x - w / 2) + '" y="' + (y - 8.5) + '" width="' + w + '" height="17" rx="8.5" fill="' + r.meta.ptColor + '"/><text x="' + x + '" y="' + (y + 4) + '" text-anchor="middle" font-size="11" fill="#fff">' + esc(t) + '</text>'; };
          if (r.meta.zeroY && Math.abs(m.x) > 1e-9) g += chip(EvGraph.fmt(m.x), cx, r.meta.ayPos + (m.y < 0 ? -14 : 14));
          if (r.meta.zeroX && Math.abs(m.y) > 1e-9) { const w = EvGraph.fmt(m.y).length * 6.6 + 12; g += chip(EvGraph.fmt(m.y), r.meta.axPos + (m.x > 0 ? -(w / 2 + 6) : w / 2 + 6), cy); }
          if (m.label && !EvGraph.isExtremum(m.label)) g += '<text x="' + Math.max(r.meta.plot.left + 20, Math.min(r.meta.plot.right - 20, cx)) + '" y="' + Math.max(cy - 13, r.meta.plot.top + 13) + '" text-anchor="middle" font-size="11.5" fill="var(--text)" stroke="var(--surface)" stroke-width="3.5" paint-order="stroke" stroke-linejoin="round">' + esc(m.label) + '</text>';
          hov.innerHTML = g + '</g>';
        });
        p.addEventListener('pointerleave', clear);
      });
    });
  }
  listEl.addEventListener('click', (e) => {
    const a = e.target.closest('a[data-url]');
    if (a) { e.preventDefault(); ev.send('ai:open-url', a.dataset.url); return; }
    const th = e.target.closest('.think-h');
    if (th) { th.parentElement.classList.toggle('open'); const m = msgs[+th.closest('.msg').dataset.i]; if (m) m._open = th.parentElement.classList.contains('open'); return; }
    const cp = e.target.closest('.code .copy');
    if (cp) { copy(cp.closest('.code').querySelector('code').textContent, cp); return; }
    const c2 = e.target.closest('.act.cp');
    if (c2) { copy(msgs[+c2.closest('.msg').dataset.i].text, c2); return; }
    if (e.target.closest('.act.re')) regen();
  });
  function copy(text, btn) {
    const done = () => { if (!btn) return; const o = btn.innerHTML; btn.textContent = '복사됨'; setTimeout(() => { btn.innerHTML = o; }, 1100); };
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(done, () => {}); else done();
  }

  // ───────── 바로 물어보기 칩 · 입력 줄 ─────────
  const QUICK = [['이 페이지 요약', '이 페이지를 핵심만 요약해 줘'], ['쉬운 말로 설명', '이 페이지 내용을 쉬운 말로 설명해 줘'], ['표로 정리', '이 페이지의 핵심 정보를 표로 정리해 줘'], ['한국어로 번역', '이 페이지 내용을 한국어로 번역해 줘'], ['중요한 숫자만', '이 페이지에서 중요한 숫자와 날짜만 뽑아 줘']];
  function drawChips() {
    const box = $('#chips');
    if (msgs.length) { box.innerHTML = ''; return; }
    box.innerHTML = QUICK.map((q, i) => '<button class="chip' + (pageOk ? '' : ' off') + '" data-i="' + i + '" type="button">' + esc(q[0]) + '</button>').join('');
  }
  $('#chips').addEventListener('click', (e) => {
    const c = e.target.closest('.chip'); if (!c || busy) return;
    if (!pageOk) { notice('새 탭 화면에는 요약할 페이지가 없어요. 웹 페이지를 연 뒤 눌러 보세요'); return; }
    const q = QUICK[+c.dataset.i]; send(q[1], q[0]);
  });
  function drawBar() {
    const send = $('#bSend'), has = inputEl.value.trim() || attach.length;
    send.className = 'send' + (busy ? ' stop' : has ? '' : ' empty');
    send.innerHTML = busy ? I('stop_circle', 18) : I('send', 18); send.title = busy ? '멈추기 (Esc)' : '보내기 (Enter)';
    $('#box').classList.toggle('busy', busy);
    $('#tPage').className = 'pill' + (pageRef && pageOk ? ' on' : ' off'); $('#tPage').innerHTML = I('page_ref', 15) + '페이지';
    const sOn = searchOnce == null ? !!(info && info.settings.search) : searchOnce;
    $('#tSearch').className = 'pill' + (sOn ? ' on' : ''); $('#tSearch').innerHTML = I('globe', 15) + '검색';
    $('#tSearch').title = '이 질문에 웹 검색 ' + (sOn ? '켜짐' : '꺼짐') + ' (누르면 바뀜)';
    $('#attach').innerHTML = attach.map((a, i) => '<span class="att" data-i="' + i + '" title="누르면 뺍니다">' + I(a.mime.indexOf('image/') === 0 ? 'image' : 'doc_text', 14) + '<span>' + esc(a.name) + '</span></span>').join('');
    const m = info && info.models; $('#modelChip').textContent = cur && cur.model ? cur.model : (lastModel || '자동 선택'); $('#modelChip').title = lastReason || '질문에 맞춰 모델을 자동으로 골라요' + (m ? '\n가벼운 질문 ' + m.lite + ' · 코딩·깊은 추론 ' + m.hydrogen : '');
    const kb = $('#keyBadge');
    if (info && info.keyCount > 1) { kb.hidden = false; kb.textContent = '키 ' + (info.keyNo || 1) + '/' + info.keyCount; } else kb.hidden = true;
  }
  let lastModel = '', lastReason = '';
  $('#tPage').addEventListener('click', () => { pageRef = !pageRef; ev.invoke('ai:setting', { key: 'pageRef', value: pageRef }).then((i) => { if (i) info = i; }); drawBar(); });
  $('#tSearch').addEventListener('click', () => { const cur0 = searchOnce == null ? !!info.settings.search : searchOnce; searchOnce = !cur0; if (searchOnce === !!info.settings.search) searchOnce = null; drawBar(); });
  $('#bAttach').addEventListener('click', () => $('#file').click());
  $('#file').addEventListener('change', (e) => { addFiles(Array.prototype.slice.call(e.target.files)); e.target.value = ''; });
  $('#attach').addEventListener('click', (e) => { const a = e.target.closest('.att'); if (a) { attach.splice(+a.dataset.i, 1); drawBar(); } });
  function addFiles(files) {
    files.forEach((f) => {
      if (attach.length >= 5) { notice('첨부는 5개까지 붙일 수 있어요'); return; }
      if (f.size > 8 * 1024 * 1024) { notice('「' + f.name + '」 은(는) 8MB 가 넘어서 붙일 수 없어요'); return; }
      const mime = f.type || (/\.(md|txt|csv|json|log)$/i.test(f.name) ? 'text/plain' : '');
      if (!/^(image\/|application\/pdf|text\/)/.test(mime)) { notice('사진 · PDF · 글 파일만 붙일 수 있어요'); return; }
      const r = new FileReader();
      r.onload = () => { attach.push({ name: f.name, mime: mime, base64: String(r.result).split(',')[1] || '' }); drawBar(); };
      r.readAsDataURL(f);
    });
  }
  document.addEventListener('paste', (e) => { const fs = Array.prototype.filter.call((e.clipboardData && e.clipboardData.files) || [], (f) => /^image\//.test(f.type)); if (fs.length) { e.preventDefault(); addFiles(fs); } });
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', (e) => { e.preventDefault(); addFiles(Array.prototype.slice.call(e.dataTransfer.files)); });
  inputEl.addEventListener('input', () => { inputEl.style.height = 'auto'; inputEl.style.height = Math.min(168, inputEl.scrollHeight) + 'px'; drawBar(); });
  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (!busy) send(); }
    else if (e.key === 'Escape') { if (busy) ev.send('ai:stop'); else if (view !== 'chat') closeSheet(); else inputEl.blur(); }
  });
  $('#bSend').addEventListener('click', () => { if (busy) ev.send('ai:stop'); else send(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { if (view !== 'chat') closeSheet(); else if (busy) ev.send('ai:stop'); } });

  function notice(t, warn, ms) {
    const n = $('#notice'); n.textContent = t; n.className = warn ? 'warn' : ''; n.hidden = false;
    clearTimeout(notice.t); notice.t = setTimeout(() => { n.hidden = true; }, ms || 4200);
  }

  // ───────── 보내기 ─────────
  function send(text, shown, regenFlag) {
    if (busy) return;
    text = text != null ? text : inputEl.value.trim();
    if (!text && !attach.length && !regenFlag) return;
    const req = { text: text, shown: shown, search: searchOnce, attach: attach.slice(), regen: !!regenFlag };
    if (!regenFlag) {
      msgs.push({ role: 'user', text: text || '(첨부 파일을 봐 줘)', shown: shown, attach: attach.map((a) => a.name) });
      inputEl.value = ''; inputEl.style.height = 'auto'; attach = []; searchOnce = null;
    }
    busy = true; stuck = true;
    cur = { role: 'model', text: '', thought: '', thinkMs: 0, queries: [], sources: [], tools: [], model: '' };
    msgs.push(cur); draw(); drawBar();
    ev.invoke('ai:send', req).then(() => { }, () => { });
  }
  function regen() {
    if (busy) return;
    let i = msgs.length - 1; while (i >= 0 && msgs[i].role !== 'user') i--;
    if (i < 0) return;
    const u = msgs[i]; msgs.length = i + 1;
    send(u.text, u.shown, true);
  }

  // ───────── 호스트가 보내는 일 ─────────
  function onEvent(m) {
    switch (m.type) {
      case 'opened': info = m.info; refreshPage(); drawBar(); if (!msgs.length) draw(); focusSoon(); break;
      case 'focus': focusSoon(); break;
      case 'state': if (window.EvTheme) EvTheme.apply(m.state.extTheme); refreshPage(m.state); break;
      case 'prefill': inputEl.value = m.text; inputEl.dispatchEvent(new Event('input')); focusSoon(); if (m.send) send(); break;
      case 'start': break;
      case 'model': lastModel = m.label; lastReason = m.reason || ''; if (cur) cur.model = m.label; drawBar(); break;
      case 'think-ms': if (cur) { cur.thinkMs = m.ms; scheduleCur(); } break;
      case 'thought': if (cur) { cur.thought += m.delta; scheduleCur(); } break;
      case 'text': if (cur) { cur.text += m.delta; scheduleCur(); } break;
      case 'grounding': if (cur) { cur.queries = m.queries; cur.sources = m.sources; scheduleCur(); } break;
      case 'tool': if (cur) { const i = cur.tools.findIndex((t) => t.id === m.tool.id); if (i >= 0) cur.tools[i] = m.tool; else cur.tools.push(m.tool); scheduleCur(); } break;
      case 'confirm': showConfirm(m); break;
      case 'notice': notice(m.text); break;
      case 'keyswitch': { notice(m.text); if (info) { info.keyNo = m.to; info.keyCount = m.total; } drawBar(); const kb = $('#keyBadge'); kb.classList.add('flash'); setTimeout(() => kb.classList.remove('flash'), 900); break; }
      case 'error': if (m.code === 'nokey') { notice(m.text, true, 7000); openSettings(); busy = false; if (cur) { msgs.splice(msgs.indexOf(cur), 1); } cur = null; draw(); drawBar(); } else if (cur) { cur.error = m.text; scheduleCur(); } break;
      case 'done': {
        busy = false; if (cur) { if (!cur.thinkMs) cur.thinkMs = m.thinkMs; } const last = cur; cur = null; chatId = m.id; if (info) { info.chats = m.chats; info.keyNo = m.keyNo; info.keyCount = m.keyCount; }
        clearTimeout(renderT); renderT = null;
        if (last && !last.text && !last.error && !last.tools.length) msgs.splice(msgs.indexOf(last), 1);
        draw(true); toEnd(false); drawBar(); ev.invoke('ai:info').then((i) => { if (i) { info = i; drawBar(); } }); break;
      }
    }
  }
  function showConfirm(m) {
    if (!cur) return;
    const el = document.createElement('div'); el.className = 'confirm';
    el.innerHTML = '<div class="q"><small>AI 가 실행하려고 해요</small>' + esc(m.text) + '</div><div class="row"><button class="btn dng" data-ok="0" type="button">거절</button><button class="btn pri" data-ok="1" type="button">허용</button></div>';
    const host = listEl.querySelector('.msg.ai:last-child .tools') || listEl.querySelector('.msg.ai:last-child .body');
    (host ? host.parentElement : listEl).insertBefore(el, host ? host.nextSibling : null);
    el.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-ok]'); if (!b) return;
      ev.send('ai:confirm', { id: m.id, ok: b.dataset.ok === '1' });
      el.classList.add('done'); el.querySelector('.q small').textContent = b.dataset.ok === '1' ? '허용했어요' : '거절했어요';
    });
    toEnd(true);
  }
  function focusSoon() { setTimeout(() => { if (view === 'chat') inputEl.focus(); }, 30); }
  function refreshPage(state) {
    const w = state && state.wins.filter((x) => x.id === state.activeWin)[0], t = w && w.tabs.filter((x) => x.id === w.active)[0];
    if (state) { pageOk = !!(t && /^https?:/i.test(t.url || '')); drawBar(); if (!msgs.length) drawChips(); }
    else ev.invoke('ai:page-title').then((p) => { pageOk = !!(p && /^https?:/i.test(p.url)); drawBar(); if (!msgs.length) drawChips(); });
  }

  // ───────── 머리줄 단추 ─────────
  $('#bNew').addEventListener('click', () => newChat());
  function newChat() { ev.invoke('ai:new').then((r) => { msgs = []; cur = null; busy = false; chatId = null; lastModel = ''; lastReason = ''; if (r && info) info.chats = r.chats; closeSheet(); draw(); drawBar(); focusSoon(); }); }
  $('#bClose').addEventListener('click', () => ev.send('ai:close'));
  $('#bHist').addEventListener('click', () => (view === 'hist' ? closeSheet() : openHistory()));
  $('#bSet').addEventListener('click', () => (view === 'set' ? closeSheet() : openSettings()));
  function closeSheet() { view = 'chat'; sheet.hidden = true; sheet.innerHTML = ''; focusSoon(); }
  function sheetHead(title) { return '<div class="sh-head"><button class="hb" id="shBack" title="뒤로">' + I('back', 20) + '</button><b>' + title + '</b></div>'; }

  // 대화 기록
  function openHistory() {
    view = 'hist'; sheet.hidden = false;
    ev.invoke('ai:info').then((i) => { if (i) info = i; drawHistory(); });
  }
  function ago(t) { const d = Date.now() - t, m = Math.floor(d / 60000); return m < 1 ? '방금' : m < 60 ? m + '분 전' : m < 1440 ? Math.floor(m / 60) + '시간 전' : Math.floor(m / 1440) + '일 전'; }
  function drawHistory() {
    const list = info.chats;
    sheet.innerHTML = sheetHead('대화 기록') + '<div class="sh-body">' + (list.length ? '<div class="card">' + list.map((c) => '<div class="hist' + (c.id === chatId ? ' cur' : '') + '" data-id="' + c.id + '"><div class="tx"><div class="tt">' + esc(EvMath.plain(c.title)) + '</div><div class="sub">' + ago(c.updated) + ' · ' + c.count + '줄</div></div><button class="x" title="삭제" type="button">' + I('delete', 16) + '</button></div>').join('') + '</div>' +
      '<div style="text-align:center;margin-top:14px"><button class="mini dng" id="clearAll" type="button">기록 모두 지우기</button></div>' : '<div class="none">저장된 대화가 없어요</div>') + '</div>';
    $('#shBack').onclick = closeSheet;
    sheet.querySelectorAll('.hist').forEach((h) => h.addEventListener('click', (e) => {
      if (e.target.closest('.x')) { ev.invoke('ai:delete', h.dataset.id).then((l) => { info.chats = l; if (h.dataset.id === chatId) { msgs = []; chatId = null; draw(); } drawHistory(); }); return; }
      ev.invoke('ai:load', h.dataset.id).then((c) => { if (!c) return; msgs = c.messages; cur = null; chatId = c.id; busy = false; closeSheet(); draw(); drawBar(); });
    }));
    const ca = $('#clearAll'); if (ca) ca.onclick = () => ev.invoke('ai:clear-chats').then(() => { info.chats = []; msgs = []; chatId = null; draw(); drawHistory(); });
  }

  // 설정
  function openSettings() { view = 'set'; sheet.hidden = false; ev.invoke('ai:info').then((i) => { if (i) info = i; drawSettings(); }); }
  const sw = (key, on) => '<span class="sw' + (on ? ' on' : '') + '" data-k="' + key + '"></span>';
  function drawSettings() {
    const s = info.settings, u = info.usage, max = Math.max(1, ...u.days.map((d) => d.calls + d.limit));
    const dow = '일월화수목금토';
    const keyRows = info.keys.length ? info.keys.map((k, i) => '<div class="row keyrow" data-i="' + i + '"><span class="no">' + (i + 1) + '</span><div class="tx"><code>' + esc(k.mask) + '</code><div class="st' + (k.status ? ' bad' : '') + '" data-st>' + (k.status ? esc(k.status) : '쓸 수 있어요 · 오늘 ' + k.today.calls + '번 사용') + '</div></div><button class="mini" data-act="test" type="button">확인</button><button class="mini dng" data-act="del" type="button">삭제</button></div>').join('') : '<div class="row"><div class="tx"><span class="sub">등록한 키가 없어요</span></div></div>';
    sheet.innerHTML = sheetHead('AI 설정') + '<div class="sh-body">' +
      '<div class="sec"><h3>API 키</h3><div class="card">' + keyRows + '<div class="addkey"><input id="keyIn" type="password" placeholder="AIza… 키 붙여 넣기" spellcheck="false" autocomplete="off"><button class="btn pri" id="keyAdd" type="button">추가</button></div></div>' +
      '<div class="hint">키를 여러 개 넣으면 한도(429)가 찬 키는 쉬게 하고 다른 키로 바꿔 보내요. 키는 이 컴퓨터의 윈도우 보안 저장소로 암호화돼요. 무료 키는 <a data-ext="https://aistudio.google.com/apikey">구글 AI 스튜디오</a>에서 받을 수 있어요.</div></div>' +
      '<div class="sec"><h3>답변</h3><div class="card">' +
      '<div class="row" data-tg="search"><div class="tx">웹 검색<span class="sub">필요할 때 구글 검색을 붙여 최신 정보로 답해요</span></div>' + sw('search', s.search) + '</div>' +
      '<div class="row" data-tg="sources"><div class="tx">출처 칩<span class="sub">참고한 사이트를 답 아래에 보여 줘요</span></div>' + sw('sources', s.sources) + '</div>' +
      '<div class="row" data-tg="thoughts"><div class="tx">사고 과정 표시<span class="sub">모델이 정리한 생각의 요약을 보여 줘요</span></div>' + sw('thoughts', s.thoughts) + '</div>' +
      '<div class="row" data-tg="pageRef"><div class="tx">지금 페이지 참고<span class="sub">질문에 보고 있는 페이지의 글을 함께 보내요</span></div>' + sw('pageRef', s.pageRef) + '</div></div></div>' +
      '<div class="sec"><h3>에이전트</h3><div class="card"><div class="row" data-tg="agent"><div class="tx">AI 에이전트<span class="sub">탭 · 북마크 · 설정 · 웹 페이지 클릭과 입력을 AI 가 직접 해요. 삭제 · 결제 같은 일은 매번 확인해요</span></div>' + sw('agent', s.agent) + '</div>' +
      '<div class="row" data-tg="auto"><div class="tx">자율 모드<span class="sub">「알아서 끝까지 해 줘」 같은 말에 더 긴 작업을 스스로 이어 가요</span></div>' + sw('auto', s.auto) + '</div></div></div>' +
      '<div class="sec"><h3>사용량 (오늘 · 구글 한도 기준 날짜)</h3><div class="card">' + (u.any ? '<div class="stat"><div><b>' + u.today.calls + '</b><span>요청</span></div><div><b>' + u.tokens + '</b><span>토큰</span></div><div><b>' + u.today.limit + '</b><span>한도 도달</span></div></div>' +
      '<div class="bars">' + u.days.map((d, i) => '<i class="' + (d.calls + d.limit ? '' : 'zero') + (i === u.days.length - 1 ? ' today' : '') + '" style="height:' + Math.max(4, Math.round((d.calls + d.limit) / max * 46)) + 'px" title="' + d.day.slice(4, 6) + '/' + d.day.slice(6) + ' (' + dow[new Date(+d.day.slice(0, 4), +d.day.slice(4, 6) - 1, +d.day.slice(6)).getDay()] + ') ' + d.calls + '번"></i>').join('') + '</div>' +
      u.byModel.map((m) => '<div class="row"><div class="tx">' + esc(m.model) + '<span class="sub">' + m.calls + '번 · 토큰 ' + m.tokens + (m.limit ? ' · 한도 ' + m.limit + '번' : '') + (m.errors ? ' · 실패 ' + m.errors + '번' : '') + '</span></div></div>').join('') +
      '<div class="row"><div class="tx"><span class="sub">하루 한도는 ' + esc(u.resetIn) + ' 뒤 초기화돼요 · 이 컴퓨터에서 보낸 요청만 세요</span></div><button class="mini dng" id="clrUsage" type="button">기록 지우기</button></div>' : '<div class="row"><div class="tx"><span class="sub">아직 쓴 기록이 없어요</span></div></div>') + '</div>' +
      (info.resting ? '<div class="hint">지금 쉬는 모델: ' + esc(info.resting) + '</div>' : '') + '</div>' +
      '<div class="sec"><h3>모델</h3><div class="hint">모델은 직접 고르지 않아도 돼요. 가벼운 질문과 사진은 <b>' + esc(info.models.lite) + '</b>, 코딩과 깊은 추론은 <b>' + esc(info.models.hydrogen) + '</b>가 맡고, 막히면 서로 바꿔 써요. 머리줄의 모델 이름에 마우스를 올리면 고른 이유가 보여요.</div></div></div>';
    $('#shBack').onclick = closeSheet;
    sheet.querySelectorAll('[data-tg]').forEach((r) => r.addEventListener('click', () => { const k = r.dataset.tg; ev.invoke('ai:setting', { key: k, value: !info.settings[k] }).then((i) => { if (i) { info = i; if (k === 'pageRef') pageRef = i.settings.pageRef; drawSettings(); drawBar(); } }); }));
    const add = () => { const v = $('#keyIn').value; if (!v.trim()) return; ev.invoke('ai:key-add', v).then((r) => { if (r && r.ok) { info = r.info; drawSettings(); drawBar(); if (!msgs.length) draw(); } else if (r) notice(r.error, true, 5000); }); };
    $('#keyAdd').onclick = add; $('#keyIn').addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
    sheet.querySelectorAll('.keyrow').forEach((r) => r.addEventListener('click', (e) => {
      const b = e.target.closest('[data-act]'); if (!b) return; const i = +r.dataset.i;
      if (b.dataset.act === 'del') ev.invoke('ai:key-remove', i).then((x) => { if (x) { info = x; drawSettings(); drawBar(); if (!msgs.length) draw(); } });
      else { const st = r.querySelector('[data-st]'); st.className = 'st'; st.textContent = '확인하는 중…'; ev.invoke('ai:key-test', i).then((x) => { st.className = 'st ' + (x && x.ok ? 'ok' : 'bad'); st.textContent = x && x.ok ? '정상이에요 (쓸 수 있는 키)' : (x && x.error) || '확인하지 못했어요'; }); }
    }));
    const cu = $('#clrUsage'); if (cu) cu.onclick = () => ev.invoke('ai:clear-usage').then((i) => { if (i) { info = i; drawSettings(); } });
    sheet.querySelectorAll('[data-ext]').forEach((a) => a.addEventListener('click', () => ev.send('ai:external', a.dataset.ext)));
  }

  // ───────── 너비 끌기 ─────────
  const grip = $('#grip');
  grip.addEventListener('pointerdown', (e) => { grip.setPointerCapture(e.pointerId); grip.classList.add('drag'); });
  grip.addEventListener('pointermove', (e) => { if (grip.classList.contains('drag')) ev.send('ai:resize', { screenX: e.screenX }); });
  grip.addEventListener('pointerup', () => grip.classList.remove('drag'));
  window.addEventListener('resize', () => { if (msgs.length && !busy) draw(true); });

  ev.on('ai:event', onEvent);
  ev.on('state', (s) => { if (window.EvTheme) EvTheme.apply(s.extTheme); refreshPage(s); });
  draw(); drawBar();
  ev.invoke('ai:info').then((i) => { if (i) { info = i; pageRef = i.settings.pageRef; drawBar(); if (!msgs.length) draw(); } });
  refreshPage();
})();
