(function(){
 /* 미러링: 페이지 안의 영상을 화면 전체로 키우고(다른 건 숨김) 앱의 컨트롤이 위에 얹힌다. 앱이 state()/cmd() 를 불러 상태를 읽고 조작한다.
    사이트의 재생기 로직은 그대로 두고 그 영상 요소만 화면에 맞춘다 (안드로이드 미러링과 같은 방식). */
 if(window.__evMir) return;
 var S={v:null,on:false,fit:'contain',style:null,els:[],hadControls:false,track:-1,cue:'',tt:null};
 var KEEP='data-evm';
 function area(v){
  var r=v.getBoundingClientRect();
  var w=Math.max(0,Math.min(r.right,innerWidth)-Math.max(r.left,0)), h=Math.max(0,Math.min(r.bottom,innerHeight)-Math.max(r.top,0));
  return w*h;
 }
 function findVideo(){
  var list=[].slice.call(document.querySelectorAll('video')), best=null, bs=-1;
  for(var i=0;i<list.length;i++){
   var v=list[i];
   if(!(v.currentSrc||v.src||v.srcObject||v.readyState>0)) continue;
   var s=area(v)+((!v.paused&&!v.ended)?1e9:0)+(v.readyState>=2?1e6:0);
   if(s>bs){bs=s;best=v}
  }
  return best;
 }
 /* 원래 인라인 스타일을 기억해 두었다가 끌 때 되돌린다 */
 function setImp(el,props){
  if(!el.__evm){el.__evm={};S.els.push(el)}
  for(var k in props){
   if(!(k in el.__evm)) el.__evm[k]=[el.style.getPropertyValue(k),el.style.getPropertyPriority(k)];
   el.style.setProperty(k,props[k],'important');
  }
 }
 function restoreAll(){
  for(var i=0;i<S.els.length;i++){
   var el=S.els[i], m=el.__evm; if(!m) continue;
   for(var k in m){ if(m[k][0]) el.style.setProperty(k,m[k][0],m[k][1]); else el.style.removeProperty(k); }
   delete el.__evm; el.removeAttribute(KEEP);
  }
  S.els=[];
 }
 function fitCss(){ return S.fit==='cover'?'cover':S.fit==='fill'?'fill':'contain'; }
 function paint(){
  var v=S.v; if(!v) return;
  setImp(v,{'position':'fixed','top':'0','left':'0','right':'0','bottom':'0','width':'100vw','height':'100vh','max-width':'none','max-height':'none','min-width':'0','min-height':'0','margin':'0','padding':'0','transform':'none','object-fit':fitCss(),'z-index':'2147483647','background':'#000','visibility':'visible','opacity':'1','border':'0','inset':'0'});
 }
 function on(){
  if(S.on) return {ok:true};
  var v=findVideo(); if(!v) return {ok:false};
  S.v=v; S.on=true; S.fit='contain';
  var n=v.parentElement;
  while(n&&n!==document.documentElement){
   n.setAttribute(KEEP,'1');
   var pos=getComputedStyle(n).position;
   var p={'transform':'none','filter':'none','backdrop-filter':'none','perspective':'none','contain':'none','clip-path':'none','mask':'none','isolation':'auto','will-change':'auto','overflow':'visible','mix-blend-mode':'normal','opacity':'1'};
   if(pos!=='static') p['z-index']='2147483646';
   setImp(n,p);
   n=n.parentElement;
  }
  v.setAttribute(KEEP,'1'); S.els.push(v); v.__evm=v.__evm||{};
  setImp(document.documentElement,{'overflow':'hidden'});
  if(document.body) setImp(document.body,{'overflow':'hidden'});
  S.style=document.createElement('style');
  S.style.textContent='body *:not(['+KEEP+']){visibility:hidden !important} body *:not(['+KEEP+']) *{visibility:hidden !important}';
  (document.head||document.documentElement).appendChild(S.style);
  S.hadControls=v.controls; try{v.controls=false}catch(e){}
  paint();
  /* 사이트 스크립트가 크기를 다시 정해도 계속 화면에 맞춘다 */
  S.iv=setInterval(function(){ if(S.on&&S.v&&S.v.isConnected) paint(); },700);
  return {ok:true};
 }
 function off(){
  if(!S.on) return;
  S.on=false; clearInterval(S.iv);
  setTrack(-1,true);
  restoreAll();
  if(S.style&&S.style.parentNode) S.style.parentNode.removeChild(S.style);
  S.style=null;
  try{if(S.v) S.v.controls=S.hadControls}catch(e){}
  S.v=null;
 }
 function tracks(){
  var out=[], v=S.v; if(!v||!v.textTracks) return out;
  for(var i=0;i<v.textTracks.length;i++){
   var t=v.textTracks[i];
   if(t.kind==='subtitles'||t.kind==='captions') out.push({idx:i,label:t.label||t.language||('자막 '+(out.length+1)),lang:t.language||''});
  }
  return out;
 }
 function setTrack(i,quiet){
  var v=S.v; if(!v||!v.textTracks) return;
  if(S.tt){ try{S.tt.oncuechange=null; S.tt.mode='disabled'}catch(e){} S.tt=null; }
  S.track=-1; S.cue='';
  if(i>=0&&v.textTracks[i]){
   var t=v.textTracks[i]; S.tt=t; S.track=i;
   t.mode='hidden';
   var read=function(){ var a=t.activeCues, s=[]; if(a) for(var k=0;k<a.length;k++){ var d=document.createElement('div'); d.innerHTML=a[k].text||''; s.push((d.textContent||'').trim()) } S.cue=s.filter(Boolean).join('\n'); };
   t.oncuechange=read; read();
  }
 }
 function state(){
  var v=S.v;
  if(!S.on||!v||!v.isConnected) return {on:false,gone:true};
  var d=v.duration, buf=0;
  try{ if(v.buffered&&v.buffered.length) buf=v.buffered.end(v.buffered.length-1) }catch(e){}
  return {on:true,pos:v.currentTime||0,dur:isFinite(d)?d:0,live:!isFinite(d),playing:!v.paused&&!v.ended,ended:!!v.ended,speed:v.playbackRate||1,
   buffered:buf,volume:v.volume,muted:v.muted,loading:(v.readyState<3&&!v.paused&&!v.ended),title:document.title||'',host:location.hostname,
   src:v.currentSrc||v.src||'',tracks:tracks(),track:S.track,cue:S.cue,fit:S.fit,vw:v.videoWidth||0,vh:v.videoHeight||0};
 }
 function cmd(a,x){
  var v=S.v; if(!v) return;
  try{
   if(a==='play') v.play(); else if(a==='pause') v.pause();
   else if(a==='toggle'){ if(v.paused||v.ended) v.play(); else v.pause(); }
   else if(a==='seek'){ var t=Number(x); if(isFinite(t)) v.currentTime=Math.max(0,t); }
   else if(a==='rate') v.playbackRate=Number(x)||1;
   else if(a==='volume'){ v.volume=Math.max(0,Math.min(1,Number(x))); if(v.volume>0) v.muted=false; }
   else if(a==='mute') v.muted=!!x;
   else if(a==='fit'){ S.fit=(x==='cover'||x==='fill')?x:'contain'; paint(); }
   else if(a==='track') setTrack(Number(x));
  }catch(e){}
 }
 window.__evMir={on:on,off:off,state:state,cmd:cmd};
})();
