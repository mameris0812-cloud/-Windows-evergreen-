(function(){
 if(window.__evYtAd) return; window.__evYtAd=1;
 if(!/(^|\.)youtube\.com$/.test(location.hostname)) return;
 /* ── 광고 데이터 미리 지우기: 영상 정보(player 응답)에서 광고 목록을 빼서 광고가 아예 시작되지 않게 한다.
    아래 건너뛰기·16배속 넘기기는 이게 놓친 광고를 위한 두 번째 방어선이다. EvMedia.ytAdPrune() 이 꺼져 있으면 아무것도 바꾸지 않는다 ── */
 var pOnAt=0,pOnV=false;
 function pruneOn(){var n=Date.now();if(n-pOnAt>1000){pOnAt=n;try{pOnV=!!EvMedia.ytAdPrune()}catch(e){pOnV=false}}return pOnV}
 var PKEYS=['adPlacements','playerAds','adSlots'];
 function prune(o){
  try{
   if(!o||typeof o!=='object') return;
   if(Array.isArray(o)){ for(var i=0;i<o.length&&i<8;i++) prune(o[i]); return; }
   var has=false,k;
   for(k=0;k<PKEYS.length;k++){ if(o[PKEYS[k]]!==undefined) has=true; }
   if(has&&pruneOn()){ for(k=0;k<PKEYS.length;k++){ try{ delete o[PKEYS[k]]; }catch(e){} } }
   if(o.playerResponse&&typeof o.playerResponse==='object') prune(o.playerResponse);
   if(o.response&&typeof o.response==='object'&&o.response.playerResponse) prune(o.response.playerResponse);
  }catch(e){}
 }
 var jp=JSON.parse;
 try{
  /* 페이지 첫 로드: 주소창에서 바로 연 영상은 정보가 페이지 안에 들어 있다 */
  var ipr;
  var d0=Object.getOwnPropertyDescriptor(window,'ytInitialPlayerResponse');
  if(!d0||d0.configurable){
   Object.defineProperty(window,'ytInitialPlayerResponse',{configurable:true,enumerable:true,get:function(){return ipr},set:function(v){ prune(v); ipr=v; }});
  }
 }catch(e){}
 try{
  JSON.parse=function(){
   var r=jp.apply(this,arguments);
   try{ if(r&&typeof r==='object'&&(Array.isArray(r)?r.length<8:(r.playerResponse||r.adPlacements!==undefined||r.playerAds!==undefined))) prune(r); }catch(e){}
   return r;
  };
 }catch(e){}
 try{
  /* 영상 사이를 넘어갈 때: 유튜브가 새 영상 정보를 fetch 로 받아 온다 */
  var of=window.fetch;
  if(of){
   window.fetch=function(input){
    var p=of.apply(this,arguments);
    try{
     var u=(typeof input==='string')?input:((input&&input.url)||'');
     if(u.indexOf('/youtubei/v1/player')<0||!pruneOn()) return p;
    }catch(e){ return p; }
    return p.then(function(res){
     try{
      if(!res||!res.ok) return res;
      return res.clone().text().then(function(t){
       var j; try{ j=jp(t); }catch(e){ return res; }
       prune(j);
       var out=new Response(JSON.stringify(j),{status:res.status,statusText:res.statusText,headers:res.headers});
       try{ Object.defineProperty(out,'url',{value:res.url}); }catch(e){}
       return out;
      },function(){ return res; });
     }catch(e){ return res; }
    });
   };
  }
 }catch(e){}
 var onAt=0,onV=true;
 function on(){var n=Date.now();if(n-onAt>500){onAt=n;try{onV=!!EvMedia.ytAdBlock()}catch(e){onV=false}}return onV}
 var st=null;
 var SKIP='.ytp-skip-ad-button,.ytp-ad-skip-button-modern,.ytp-ad-skip-button,.ytp-ad-skip-button-container button,.ytp-ad-skip-button-slot button,.ytp-skip-ad button,.videoAdUiSkipButton,button[class*="skip-ad" i]';
 var tapAt=0,tapBtn=null,tapN=0;
 /* 진짜 터치: 유튜브는 스크립트가 보낸 클릭(isTrusted=false)을 무시하는 때가 있다. 그럴 때를 위해 앱이 화면 위 그 자리를 손가락처럼 직접 눌러 준다 */
 function nativeTap(el){
  try{
   if(window!==window.top) return;
   var r=el.getBoundingClientRect(); if(r.width<=0||r.height<=0) return;
   var cx=r.left+r.width/2, cy=r.top+r.height/2;
   var at=document.elementFromPoint(cx,cy);          // 그 자리에 버튼이 실제로 보일 때만 (다른 것이 덮고 있으면 엉뚱한 곳을 누르게 된다)
   if(!at||!(at===el||el.contains(at))) return;
   var vv=window.visualViewport;
   var vw=(vv&&vv.width)||window.innerWidth||0; if(!vw) return;
   EvMedia.ytSkipTap(cx-(vv?vv.offsetLeft:0), cy-(vv?vv.offsetTop:0), vw);
  }catch(e){}
 }
 /* 건너뛰기 버튼: 크기·display 로만 '보이는지' 본다 (미러링 중에는 요소가 visibility:hidden 이라 그걸로 판단하면 안 된다) */
 function skipBtn(){
  try{
   var bs=document.querySelectorAll(SKIP);
   for(var i=0;i<bs.length;i++){ var r=bs[i].getBoundingClientRect(); if(r.width>0&&r.height>0&&getComputedStyle(bs[i]).display!=='none') return bs[i]; }
   var cs=document.querySelectorAll('.ytp-ad-player-overlay-layout button,.video-ads button,.ytp-ad-module button');
   for(var j=0;j<cs.length;j++){ var r2=cs[j].getBoundingClientRect(); if(r2.width>0&&r2.height>0&&/^\s*(건너뛰기|skip)/i.test(cs[j].textContent||'')) return cs[j]; }
  }catch(e){}
  return null;
 }
 /* click() 하나로는 눌림으로 안 치는 때가 있어 포인터·마우스 이벤트를 순서대로 보낸다 */
 function tap(el){
  try{
   var r=el.getBoundingClientRect(),o={bubbles:true,cancelable:true,composed:true,view:window,clientX:r.left+r.width/2,clientY:r.top+r.height/2,button:0};
   ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(n){ try{ el.dispatchEvent(n.indexOf('pointer')===0?new PointerEvent(n,o):new MouseEvent(n,o)); }catch(e){} });
  }catch(e){}
 }
 function css(){
  var want=on();
  if(want&&!st){
   st=document.createElement('style');
   // 영상 없는 광고(피드 광고 카드·배너·스폰서·플레이어 위 이미지/글자 광고)까지 숨긴다. 모바일(ytm-/ad-slot-)과 데스크톱(ytd-) 이름을 모두 포함
   st.textContent=[
    'ytd-ad-slot-renderer','ytm-ad-slot-renderer','ad-slot-renderer','ytd-in-feed-ad-layout-renderer','ytm-in-feed-ad-layout-renderer','in-feed-ad-layout-renderer',
    'ytd-display-ad-renderer','ytm-display-ad-renderer','ytd-promoted-video-renderer','ytm-promoted-video-renderer','ytd-promoted-sparkles-web-renderer','ytm-promoted-sparkles-web-renderer',
    'ytd-promoted-sparkles-text-search-renderer','ytm-promoted-sparkles-text-search-renderer','ytd-banner-promo-renderer','ytm-banner-promo-renderer','ytd-statement-banner-renderer','ytm-statement-banner-renderer',
    'ytd-companion-slot-renderer','ytm-companion-slot-renderer','ytm-companion-ad-renderer','ytd-action-companion-ad-renderer','ytd-brand-video-shelf-renderer','ytd-brand-video-singleton-renderer','ytm-brand-video-singleton-renderer',
    'ytd-video-masthead-ad-v3-renderer','ytm-video-masthead-ad-v3-renderer','ytd-primetime-promo-renderer','ytd-player-legacy-desktop-watch-ads-renderer','ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"]',
    'ytd-rich-item-renderer:has(ytd-ad-slot-renderer)','ytm-rich-item-renderer:has(ad-slot-renderer)','ytm-item-section-renderer:has(ytm-promoted-sparkles-web-renderer)','ytm-item-section-renderer:has(ad-slot-renderer)',
    'ytm-shorts-lockup-view-model:has(.ad-badge)','#masthead-ad','#player-ads','#companion','.ytd-ad-slot-renderer','.ytd-display-ad-renderer',
    '.ytp-ad-overlay-container','.ytp-ad-overlay-slot','.ytp-ad-image-overlay','.ytp-ad-text-overlay','.ytp-paid-content-overlay','.ytp-ad-module .ytp-ad-image'
   ].join(',')+'{display:none!important}';
   (document.head||document.documentElement).appendChild(st);
  }else if(!want&&st){ st.remove(); st=null; }
 }
 var byUs=false,seekKey='',seekAt=0;
 setInterval(function(){
  css();
  var v=document.querySelector('video.html5-main-video')||document.querySelector('video');
  if(!on()){
   if(byUs&&v){ byUs=false; v.playbackRate=1; v.muted=!!v.__evMuted; }
   return;
  }
  var shown=!!document.querySelector('.ad-showing,.ytp-ad-player-overlay,.ytp-ad-module .ytp-ad-text');
  var x=document.querySelector('.ytp-ad-overlay-close-button'); if(x) x.click();
  /* 건너뛰기 버튼이 보이면 광고 상태와 상관없이 누른다 (광고 영상이 이미 끝나 '사이트 방문' 끝 카드만 떠 있을 때는 영상 길이가 있어 아래 넘기기로는 안 넘어간다) */
  var sb=skipBtn();
  if(sb){
   var nw=Date.now();
   if(nw-tapAt>700){
    tapAt=nw;
    if(sb===tapBtn) tapN++; else { tapBtn=sb; tapN=1; }
    tap(sb);
    /* 스크립트 클릭으로 안 넘어가면(같은 버튼이 0.7초 뒤에도 있으면) 진짜 터치로 몇 번 더 누른다 */
    if(tapN>=2&&tapN<=4) nativeTap(sb);
   }
  }else{ tapBtn=null; tapN=0; }
  if(!v) return;
  if(shown&&isFinite(v.duration)&&v.duration>0&&!v.ended){
   if(!byUs){byUs=true; v.__evMuted=v.muted;}
   v.muted=true; v.playbackRate=16;
   /* 끝으로 옮기기는 광고 하나당 한 번만: 0.25초마다 계속 옮기면 받던 조각이 계속 취소돼서 로딩이 한참 걸린다. 2.5초 지나도 안 끝났을 때만 다시 */
   var sk=(v.currentSrc||'')+'|'+v.duration, snow=Date.now();
   if(sk!==seekKey){ seekKey=sk; seekAt=snow; try{ v.currentTime=Math.max(0,v.duration-0.1); }catch(e){} }
   else if(!v.seeking&&snow-seekAt>2500&&v.currentTime<v.duration-0.5){ seekAt=snow; try{ v.currentTime=Math.max(0,v.duration-0.1); }catch(e){} }
  }else if(byUs){
   byUs=false; seekKey=''; v.playbackRate=1; v.muted=!!v.__evMuted;
  }else if(!shown&&v.playbackRate>=16){
   /* 광고를 넘기다 영상 요소가 바뀌어 16배속이 본 영상에 남으면 데이터가 모자라 로딩만 도니 되돌린다 */
   v.playbackRate=1;
  }
 },250);
})();
