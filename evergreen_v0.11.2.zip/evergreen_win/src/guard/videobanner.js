// ── 영상 배너 감지: 화면에 올라온 <video> 가 배너 광고로 보이면 멈추고 가린다 ──
 (function(){
  var host=location.hostname.toLowerCase();
  // 영상 사이트 본 플레이어는 건드리지 않는다 
  if(/(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com|netflix\.com|twitch\.tv|tving\.com|wavve\.com|watcha\.com)$/.test(host)) return;
  var STRONG=/(^|[^a-z0-9])(ad|ads|adv|advert|adverts|advertise|advertising|advertisement|adsense|adfit|adslot|adunit|sponsor|sponsored|sponsors)([^a-z0-9]|$)|광고|스폰서/i;
  var WEAK=/(^|[^a-z0-9])(banner|banners|bnr)([^a-z0-9]|$)|배너/i;
  var IAB=[[728,90],[970,90],[970,250],[468,60],[320,50],[320,100],[300,250],[336,280],[300,600],[160,600],[120,600],[250,250],[200,200],[300,50],[234,60],[125,125],[300,100],[360,100],[360,200],[360,50],[375,100]];
  var seen=new WeakSet();
  var memo=new Map();
  var stat={n:0};
  var userSel=[];
  try{ userSel=JSON.parse(EvMedia.aduser(location.hostname)||'[]'); }catch(e){}

  function srcs(v){
   var out=[];
   try{ if(v.currentSrc) out.push(v.currentSrc); }catch(e){}
   try{ var a=v.getAttribute('src'); if(a) out.push(new URL(a,location.href).href); }catch(e){}
   try{ var ss=v.querySelectorAll('source[src]'); for(var i=0;i<ss.length;i++) out.push(new URL(ss[i].getAttribute('src'),location.href).href); }catch(e){}
   return out;
  }
  function attrText(e){
   var t='';
   try{
    t+=' '+(e.id||'');
    var c=e.className; t+=' '+(typeof c==='string'?c:(c&&c.baseVal)||'');
    var as=e.attributes;
    for(var i=0;i<as.length;i++){
     var n=as[i].name;
     if(n.indexOf('data-ad')===0||n.indexOf('data-banner')===0||n==='aria-label'||n==='title'||n==='name'||n==='alt'||n==='data-testid') t+=' '+n.replace('data-','')+' '+as[i].value;
    }
   }catch(x){}
   // 'ad-free' 'ads-block' 같은 말은 광고가 아니라 광고를 없앤다는 뜻
   return t.replace(/ads?[-_]?(free|block\w*)/gi,'');
  }
  function hostOf(h){ try{ return new URL(h,location.href).hostname.toLowerCase(); }catch(e){ return ''; } }
  function reg(h){ var p=h.split('.'); if(p.length<=2) return h; var l2=p.slice(-2).join('.'); return /^(co|or|go|ne|ac|com|org)\.[a-z]{2}$/.test(l2)?p.slice(-3).join('.'):l2; }
  function isIab(w,h){
   for(var i=0;i<IAB.length;i++){
    var bw=IAB[i][0], bh=IAB[i][1];
    if(Math.abs(w-bw)<=bw*0.06&&Math.abs(h-bh)<=bh*0.06) return true;
    // 가로로 꽉 채우는 모바일 배너: 높이가 표준이고 비율이 비슷
    if(Math.abs(h-bh)<=bh*0.06&&w>=bw*0.9&&w/h<=bw/bh*1.15&&w/h>=bw/bh*0.85) return true;
   }
   return false;
  }

  // 영상이 배너 광고인 이유가 있으면 그 이유를, 아니면 '' 를 돌려준다
  function why(v){
   var r=v.getBoundingClientRect();
   var w=r.width, h=r.height;
   var vw=window.innerWidth||document.documentElement.clientWidth||360, vh=window.innerHeight||600;
   var list=srcs(v), i;
   // (a) 영상 주소 자체가 광고 서버 / 광고 영상 주소 모양
   for(i=0;i<list.length;i++){
    if(list[i].indexOf('http')!==0) continue;
    var m=memo.get(list[i]);
    if(m===undefined){
     try{ m=!!EvMedia.advid(list[i],location.hostname); }catch(e){ m=false; }
     if(memo.size>300) memo.clear();
     memo.set(list[i],m);
    }
    if(m) return 'src';
   }
   var hasCtl=v.hasAttribute('controls');
   var dur=v.duration;
   if(isFinite(dur)&&dur>180) return '';           // 긴 영상은 본편
   if(hasCtl) return '';                           // 재생바가 있으면 사람이 보라고 둔 영상
   var inPlayer=false;
   try{ inPlayer=!!v.closest('[class*="player" i],[id*="player" i],[class*="video-js" i],[class*="jwplayer" i],[class*="plyr" i],[class*="vjs" i]'); }catch(e){}
   var silentLoop=(v.muted||v.hasAttribute('muted')||v.defaultMuted)&&(v.loop||v.hasAttribute('loop')||v.autoplay||v.hasAttribute('autoplay'));
   // (b) 바로 위 몇 단계 안에 '광고' 이름
   var e=v, d=0, strong=false, weak=false;
   while(e&&d<6&&e!==document.body&&e!==document.documentElement){
    var t=attrText(e);
    if(STRONG.test(t)) strong=true; else if(WEAK.test(t)) weak=true;
    e=e.parentElement; d++;
   }
   if(w<2||h<2) return '';
   var small=h<=450;
   if(strong&&!inPlayer&&h<=Math.max(450,vh*0.7)) return 'name';
   if(weak&&small&&silentLoop) return 'banner';
   // (c) 표준 광고 크기 + 소리 없는 반복/자동 재생
   if(silentLoop&&isIab(w,h)) return 'size';
   // (d) 다른 사이트로 가는 링크로 감싼, 재생바 없는 소리 없는 영상 = 눌러서 이동하는 영상 배너
   if(silentLoop&&small){
    var a=v.closest('a[href]');
    if(a){
     var ah=hostOf(a.getAttribute('href'));
     if(ah&&reg(ah)!==reg(host)) return 'link';
    }
   }
   return '';
  }

  // 숨길 요소: 영상을 감싼 같은 크기 링크/상자까지 올라가고, '광고' 이름이 붙은 가까운 상자가 있으면 그것까지
  function target(v){
   var vr=v.getBoundingClientRect();
   var el=v, p, k=0;
   while(k<4){
    p=el.parentElement;
    if(!p||p===document.body||p===document.documentElement) break;
    var pr=p.getBoundingClientRect();
    var onlyMe=(p.querySelectorAll('video,img,iframe,canvas').length<=1)&&!((p.innerText||'').trim().length>40);
    if(onlyMe&&pr.width<=vr.width+16&&pr.height<=vr.height+16){ el=p; k++; } else break;
   }
   var e=el, d=0, best=null, vh=window.innerHeight||600;
   while(e&&d<4&&e.parentElement&&e!==document.body){
    if(STRONG.test(attrText(e))){
     var r=e.getBoundingClientRect();
     if(r.height<=Math.max(450,vh*0.7)&&r.width>0) best=e;
    }
    e=e.parentElement; d++;
   }
   return best||el;
  }

  function kill(v,reason){
   if(seen.has(v)) return;
   seen.add(v);
   try{ v.pause(); }catch(e){}
   try{ v.muted=true; v.removeAttribute('autoplay'); v.removeAttribute('src'); var ss=v.querySelectorAll('source'); for(var i=0;i<ss.length;i++) ss[i].remove(); v.load(); }catch(e){}
   try{ var t=target(v); t.style.setProperty('display','none','important'); t.setAttribute('data-ev-adhid',reason); }catch(e){}
   try{ v.style.setProperty('display','none','important'); }catch(e){}
   stat.n++;
   try{ EvMedia.adhid(location.hostname); }catch(e){}
  }

  function stopHidden(){
   // 직접 고른 광고 안의 영상: 가려도 소리가 나지 않게 멈춘다
   for(var i=0;i<userSel.length;i++){
    var els; try{ els=document.querySelectorAll(userSel[i]); }catch(e){ continue; }
    for(var j=0;j<els.length;j++){
     var el=els[j];
     var vs=el.tagName==='VIDEO'?[el]:el.querySelectorAll('video');
     for(var k=0;k<vs.length;k++){
      var v=vs[k];
      try{ if(!v.paused||v.autoplay){ v.pause(); v.muted=true; v.removeAttribute('autoplay'); } }catch(e){}
     }
    }
   }
  }

  function scan(){
   try{
    var vs=document.getElementsByTagName('video');
    for(var i=0;i<vs.length;i++){
     var v=vs[i];
     if(seen.has(v)) continue;
     var r=''; try{ r=why(v); }catch(e){}
     if(r) kill(v,r);
    }
    if(userSel.length) stopHidden();
   }catch(e){}
  }

  var timer=0;
  function later(){ if(timer) return; timer=setTimeout(function(){ timer=0; scan(); },250); }
  document.addEventListener('DOMContentLoaded',scan);
  window.addEventListener('load',function(){ scan(); setTimeout(scan,1200); setTimeout(scan,4000); });
  // 영상이 재생을 시작하거나 크기를 알게 되는 순간 (play / loadedmetadata 는 거품이 올라오지 않아 capture 로 받는다)
  document.addEventListener('play',function(e){ if(e.target&&e.target.tagName==='VIDEO'&&!seen.has(e.target)){ var r=''; try{ r=why(e.target); }catch(x){} if(r) kill(e.target,r); } },true);
  document.addEventListener('loadedmetadata',function(e){ if(e.target&&e.target.tagName==='VIDEO'&&!seen.has(e.target)){ var r=''; try{ r=why(e.target); }catch(x){} if(r) kill(e.target,r); } },true);
  try{
   new MutationObserver(later).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src','class','id','style','loop','muted','autoplay']});
  }catch(e){}
  scan();
 })();
