(function(){
 if(window.__evAd) return; window.__evAd=1;
 try{ if(!EvMedia.adblock()) return; }catch(e){ return; }
 // ── 팝업/클릭 가로채기 광고 차단 ──
 try{
  var _open=window.open;
  window.open=function(u){
   try{
    var abs=u?new URL(String(u),location.href).href:'';
    var act=navigator.userActivation?navigator.userActivation.isActive:true;
    if(!act||(abs&&EvMedia.adurl(abs))) return null;
   }catch(e){}
   return _open.apply(window,arguments);
  };
  document.addEventListener('click',function(e){
   try{
    var a=e.target&&e.target.closest?e.target.closest('a[href]'):null;
    if(a&&EvMedia.adurl(a.href)){e.preventDefault();e.stopImmediatePropagation();}
   }catch(x){}
  },true);
 }catch(e){}
 // ── fetch / XHR / sendBeacon 으로 나가는 광고 요청은 진짜 광고 차단기처럼 '네트워크 오류'로 실패시킨다 ──
 // (앱이 빈 응답을 돌려주면 페이지에서는 요청이 성공한 것으로 보여, 차단 테스트가 '뚫림'으로 나온다)
 try{
  var memo=new Map();
  var isBlocked=function(u){
   try{
    var s=String(u&&u.url?u.url:u);
    var abs=new URL(s,location.href).href;
    if(abs.indexOf('http')!==0) return false;
    var v=memo.get(abs);
    if(v===undefined){
     v=!!EvMedia.adreq(abs,location.hostname);
     if(memo.size>600) memo.clear();
     memo.set(abs,v);
    }
    return v;
   }catch(e){ return false; }
  };
  var _fetch=window.fetch;
  if(_fetch){
   window.fetch=function(input,init){
    if(isBlocked(input)) return Promise.reject(new TypeError('Failed to fetch'));
    return _fetch.apply(this,arguments);
   };
  }
  var _xo=XMLHttpRequest.prototype.open, _xs=XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open=function(m,u){ try{ this.__evu=u; }catch(e){} return _xo.apply(this,arguments); };
  XMLHttpRequest.prototype.send=function(){
   if(this.__evu!==undefined&&isBlocked(this.__evu)){
    var x=this;
    setTimeout(function(){ try{ x.dispatchEvent(new ProgressEvent('error')); x.dispatchEvent(new ProgressEvent('loadend')); }catch(e){} },0);
    return;
   }
   return _xs.apply(this,arguments);
  };
  if(navigator.sendBeacon){
   var _sb=navigator.sendBeacon.bind(navigator);
   navigator.sendBeacon=function(u,d){ return isBlocked(u)?false:_sb(u,d); };
  }
 }catch(e){}
 // 화면 전체를 덮은 투명 클릭 가로채기 막(터치하는 순간 팝업을 여는 광고)을 터치 직전에 치운다
 if(window===window.top){
  var isOverlay=function(el){
   try{
    if(!el||el===document.body||el===document.documentElement) return false;
    // 파일 올리기 칸(투명하게 화면을 덮는 <input type=file> 등)은 광고 막이 아니니 지우지 않는다
    // (파일 칸이 있는 페이지는 sweep 맨 앞에서 이미 걸러낸다)
    if(el.tagName==='INPUT'||el.tagName==='LABEL') return false;
    var cs=getComputedStyle(el), w=innerWidth, h=innerHeight;
    var fixed=cs.position==='fixed';
    var z=parseInt(cs.zIndex,10)||0;
    if(!fixed&&!(cs.position==='absolute'&&z>=1000&&(el.offsetParent===document.body||el.offsetParent===null))) return false;
    var r=el.getBoundingClientRect();
    if(r.width<w*0.6||r.height<h*0.6) return false;
    if(el.closest('video,[class*=player],[id*=player],[class*=modal],[class*=dialog],[role=dialog]')) return false;
    var bg=cs.backgroundColor;
    var transp=(bg==='rgba(0, 0, 0, 0)'||bg==='transparent')&&cs.backgroundImage==='none';
    var empty=!(el.innerText||'').trim()&&!el.querySelector('img,video,canvas,svg,input,button,audio');
    return parseFloat(cs.opacity)<0.05||(transp&&empty);
   }catch(e){return false}
  };
  // 터치할 때마다 도는 검사라, 칸마다 DOM 전체를 훑던 것을 한 번의 가벼운 검사로 바꿨다 (큰 페이지에서 터치당 ~6ms → ~0.3ms)
  var hasFileInput=function(){
   var l=document.getElementsByTagName('input');
   for(var i=0;i<l.length;i++){ if(l[i].type==='file') return true; }
   return false;
  };
  var sweep=function(x,y){
   try{
    // 파일 올리기 칸이 있는 페이지에서는 투명한 덮개(업로드 버튼·드롭 영역)를 광고 막으로 오해해 지우지 않는다
    if(hasFileInput()) return;
    var els=document.elementsFromPoint(x,y);
    for(var i=0;i<els.length;i++){ if(isOverlay(els[i])){ els[i].remove(); } }
   }catch(e){}
  };
  document.addEventListener('touchstart',function(e){
   var t=e.touches&&e.touches[0]; if(t) sweep(t.clientX,t.clientY);
  },{capture:true,passive:true});
  document.addEventListener('mousedown',function(e){ sweep(e.clientX,e.clientY); },true);
 }
 function addCss(t){var s=document.createElement('style');s.textContent=t;(document.head||document.documentElement).appendChild(s)}
/*__VIDEO_BANNER__*/
})();
