'use strict';
// 광고 차단 현황 · 보안 현황 · 광고·보안 설정 · HTTPS 대체 연결 대화상자 (안드로이드 AdBlockStatsUi · SecurityStatsUi 와 같은 구성)
(function () {
  var Ov = window.EvOv, esc = Ov.esc, ev = Ov.ev, A = window.EvDlg.api, dlg = document.getElementById('dlg');
  var live = null;
  var n = function (v) { return Number(v || 0).toLocaleString('ko-KR'); };
  var DOW = '일월화수목금토';

  function dayLabels() {
    var out = [], d = new Date();
    for (var i = 6; i >= 0; i--) out.push(DOW.charAt(new Date(d.getTime() - i * 86400000).getDay()));
    return out;
  }
  function ago(t) {
    if (!t) return '아직 내려받지 않음';
    var min = Math.floor((Date.now() - t) / 60000);
    if (min < 1) return '방금 전';
    if (min < 60) return min + '분 전';
    if (min < 1440) return Math.floor(min / 60) + '시간 전';
    return Math.floor(min / 1440) + '일 전';
  }
  function niceTop(max) {
    var steps = [4, 8, 10, 20, 40, 60, 80, 100, 200, 400, 600, 800, 1000, 2000, 4000, 6000, 8000, 10000, 20000, 40000, 100000, 1000000];
    for (var i = 0; i < steps.length; i++) if (steps[i] >= max) return steps[i];
    return Math.ceil((max + 1) / 2) * 2;
  }
  // 이 화면은 style 속성을 막는 보안 정책(CSP) 아래라서, 값은 CSSOM 으로 넣는다
  function paintStyles(root) {
    Array.prototype.forEach.call(root.querySelectorAll('[data-w]'), function (el) { el.style.width = el.getAttribute('data-w') + '%'; });
    Array.prototype.forEach.call(root.querySelectorAll('[data-bg]'), function (el) { el.style.background = el.getAttribute('data-bg'); });
  }
  function head(icon, title, sub) {
    return '<div class="ph"><span class="phi">' + icon + '</span><span class="pht"><b>' + esc(title) + '</b><small>' + esc(sub) + '</small></span></div>';
  }
  function sec(t) { return '<div class="ps">' + esc(t) + '</div>'; }
  function line(l, v) { return '<div class="pr"><span>' + esc(l) + '</span><b>' + esc(v) + '</b></div>'; }

  // 최근 7일 막대그래프. stacks[i] = [{ c: 색, v: 값 }] (아래부터 쌓음), 한 가지 색이면 stacks 없이 totals 만
  function chart(totals, stacks) {
    var W = 340, H = 176, L = 6, R = 300, top = 26, bot = 136, slot = (R - L) / 7, bw = slot * 0.42;
    var topV = niceTop(Math.max.apply(null, totals.concat([0])));
    var labels = dayLabels(), g = '';
    [topV, topV / 2].forEach(function (v) {
      var y = bot - (bot - top) * v / topV;
      g += '<line x1="' + L + '" y1="' + y + '" x2="' + R + '" y2="' + y + '" class="gl"/><text x="' + (R + 8) + '" y="' + (y + 4) + '" class="gt">' + v + '</text>';
    });
    g += '<line x1="' + L + '" y1="' + bot + '" x2="' + R + '" y2="' + bot + '" class="gl"/>';
    for (var i = 0; i < 7; i++) {
      var cx = L + slot * (i + 0.5), v = totals[i], x0 = cx - bw / 2;
      if (v > 0) {
        var h = Math.max(bw, (bot - top) * v / topV), y = bot;
        var parts = stacks && stacks[i] ? stacks[i] : [{ c: 'var(--accent)', v: v }];
        var cid = 'bc' + i, r = bw / 2;
        g += '<clipPath id="' + cid + '"><path d="M' + x0 + ',' + bot + ' V' + (bot - h + r) + ' Q' + x0 + ',' + (bot - h) + ' ' + (x0 + r) + ',' + (bot - h) + ' H' + (x0 + bw - r) + ' Q' + (x0 + bw) + ',' + (bot - h) + ' ' + (x0 + bw) + ',' + (bot - h + r) + ' V' + bot + ' Z"/></clipPath><g clip-path="url(#' + cid + ')">';
        parts.forEach(function (p) {
          if (p.v <= 0) return;
          var sh = h * p.v / v; g += '<rect x="' + x0 + '" y="' + (y - sh) + '" width="' + bw + '" height="' + sh + '" fill="' + p.c + '"/>'; y -= sh;
        });
        g += '</g><text x="' + cx + '" y="' + (bot - h - 6) + '" class="gv" text-anchor="middle">' + v + '</text>';
      } else {
        g += '<rect x="' + x0 + '" y="' + (bot - 3) + '" width="' + bw + '" height="3" rx="1.5" class="g0"/>';
      }
      if (i === 6) g += '<circle cx="' + cx + '" cy="' + (bot + 20) + '" r="12" class="gtd"/><text x="' + cx + '" y="' + (bot + 24) + '" text-anchor="middle" class="gtt">' + labels[i] + '</text>';
      else g += '<text x="' + cx + '" y="' + (bot + 24) + '" text-anchor="middle" class="gt">' + labels[i] + '</text>';
    }
    return '<svg class="wk" viewBox="0 0 ' + W + ' ' + H + '" width="100%">' + g + '</svg>';
  }

  // ───────── 광고 차단 현황 ─────────
  function adBody(s) {
    var tile = function (l, v) { return '<div class="tl"><b>' + v + '</b><small>' + l + '</small></div>'; };
    var out = '<div class="tiles">' + tile('이 페이지', s.pageBlocked == null ? '-' : n(s.pageBlocked)) + tile('오늘', n(s.today)) + tile('전체', n(s.total)) + '</div>' +
      sec('최근 7일') + chart(s.week) +
      sec('종류별 (이번에 앱을 켠 뒤)') + line('광고·추적 요청', n(s.requests) + '건') + line('팝업·광고 페이지 이동', n(s.popups) + '건') +
      sec('가장 많이 막은 곳');
    out += s.top.length ? s.top.map(function (t) { return line(t[0], n(t[1]) + '건'); }).join('') : '<div class="pe">아직 막은 광고가 없어요. 사이트를 둘러보면 여기에 쌓여요.</div>';
    out += sec('차단 목록') + line('차단 도메인', n(s.lists.hosts) + '개') + line('주소 필터 규칙 (EasyList 등)', n(s.lists.rules) + '개') +
      line('화면 광고 숨김 규칙', n(s.lists.css) + '개') + line('악성 사이트 목록', n(s.lists.malware) + '개') +
      line('마지막 업데이트', s.lists.updating ? '받는 중…' : ago(s.lists.updated));
    return out;
  }
  function openAd(s) {
    var since = new Date(s.since), ds = since.getFullYear() + '.' + String(since.getMonth() + 1).padStart(2, '0') + '.' + String(since.getDate()).padStart(2, '0');
    var cur = s;
    A.show('<div class="sp">' + head(icon('shield_person', 26), '광고 차단 현황', s.enabled ? '광고 차단 켜짐 · ' + ds + ' 부터 집계' : '광고 차단이 꺼져 있어요 · 켜면 다시 집계됩니다') +
      '<div id="spb" class="pb">' + adBody(s) + '</div></div>' +
      A.btns([{ id: 'rs', label: '통계 초기화', cls: 'danger left' }, { id: 'up', label: '지금 목록 업데이트' }, { id: 'ok', label: '닫기', cls: 'primary' }]), function () {
      dlg.classList.add('wide');
      live = { kind: 'adstats', paint: function (st) { cur = st; var b = document.getElementById('spb'); if (b) { b.innerHTML = adBody(st); paintStyles(b); } } };
      A.onEnter(A.cancel);
      A.wire({
        ok: A.cancel,
        up: function () { Ov.cmd('sec:update-lists'); },
        rs: function () {
          window.EvDlg.open('confirm', { title: '통계를 초기화할까요?', msg: '오늘·전체·종류별 차단 건수와 사이트별 기록이 0으로 돌아갑니다. 차단 목록과 설정은 그대로예요.', ok: '초기화', fn: function () { Ov.cmd('sec:reset-ads'); reopen('adstats'); } });
        },
      });
    });
  }

  // ───────── 보안 현황 ─────────
  function secBody(p) {
    var pr = p.protection, frac = Math.max(0.08, pr.score / pr.max);
    var lv = ['약하게', '보통', '최대'].map(function (t, i) { return '<span class="' + (i === pr.level ? 'on' : '') + '">' + t + '<small>' + (i === 1 ? '권장' : '&nbsp;') + '</small></span>'; }).join('');
    var colors = p.kinds.map(function (k) { return k.color; });
    var totals = p.days.map(function (d) { return d.total; });
    var stacks = p.days.map(function (d) { return d.parts.map(function (v, i) { return { c: colors[i], v: v }; }); });
    return '<div class="lvb"><i data-w="' + (frac * 100) + '"></i></div><div class="lvl">' + lv + '</div>' +
      (pr.off.length ? '<div class="off">꺼져 있어요: ' + esc(pr.off.join(' · ')) + '</div>' : '') +
      '<div class="today">' + (p.today === 0 ? '오늘은 아직 차단한 게 없어요' : '오늘 ' + n(p.today) + '번 차단함') + '</div>' + chart(totals, stacks) +
      sec('종류별 (오늘 · 7일)') + p.kinds.map(function (k) {
        return '<div class="pr"><i class="kc" data-bg="' + k.color + '"></i><span>' + esc(k.label) + '</span><b>' + n(k.today) + ' · ' + n(k.week) + '</b></div>';
      }).join('');
  }
  function openSec(p) {
    A.show('<div class="sp">' + head(icon('shield_check_filled', 26), '보안 현황', '최근 7일 · 이 기기에만 저장돼요') + '<div id="spb" class="pb">' + secBody(p) + '</div></div>' +
      A.btns([{ id: 'rs', label: '기록 지우기', cls: 'danger left' }, { id: 'st', label: '설정' }, { id: 'ok', label: '닫기', cls: 'primary' }]), function () {
      dlg.classList.add('wide');
      paintStyles(dlg);
      live = { kind: 'secstats', paint: function (st) { var b = document.getElementById('spb'); if (b) { b.innerHTML = secBody(st); paintStyles(b); } } };
      A.onEnter(A.cancel);
      A.wire({
        ok: A.cancel,
        st: function () { A.close(); Ov.cmd('dialog:secset'); },
        rs: function () {
          window.EvDlg.open('confirm', { title: '기록을 지울까요?', msg: '최근 7일 차단 기록이 0으로 돌아갑니다. 설정은 그대로예요.', ok: '지우기', fn: function () { Ov.cmd('sec:reset-sec'); reopen('secstats'); } });
        },
      });
    });
  }

  function reopen(kind) {
    ev.invoke('data:get', kind).then(function (st) { if (st) window.EvDlg.open(kind, { stats: st }); });
  }

  // ───────── 광고·보안 설정 ─────────
  var ITEMS = [
    ['광고', [
      ['adBlock', '광고 차단', '광고·추적 주소와 화면의 광고 영역을 막아요'],
      ['ytAdBlock', '유튜브 광고 건너뛰기', '영상 광고를 자동으로 넘겨요 (광고 차단과 따로 켜고 꺼요)'],
      ['ytAdPrune', '유튜브 광고 미리 지우기', '광고가 시작되기 전에 영상 정보에서 광고를 빼요'],
    ]],
    ['보안', [
      ['strictTrackers', '트래커 차단 (엄격)', '필요한 곳만 빼고 알려진 추적 서비스로 가는 요청을 모두 막아요'],
      ['skipCaptcha', '캡차 건너뛰기', '서드파티 쿠키를 막아 인증 업체가 나를 따라다니며 추적하지 못하게 해요'],
      ['malwareWarning', '악성 사이트 경고', '알려진 악성·피싱 사이트로 가면 경고 화면을 보여 줘요'],
      ['httpsFirst', 'HTTPS 우선 연결', 'http 주소는 보안 연결(https)로 올려서 연결해요'],
      ['blockAutoDownload', '자동 다운로드 차단', '누르지 않았는데 시작되는 다운로드를 막아요'],
      ['blockBackRedirect', '뒤로가기 중 자동 이동 차단', '뒤로가기를 눌러도 페이지가 도로 보내는 함정을 막아요'],
      ['notifyBackBlocked', '뒤로가기 차단 알림', '막았을 때 알려 줘요'],
      ['blockHijackNav', '클릭 가로채기 이동 차단', '빈 곳을 눌렀는데 다른 사이트로 보내는 것을 막아요'],
    ]],
  ];
  function openSet(p) {
    var s = p.settings;
    var rows = ITEMS.map(function (g) {
      return '<div class="ps">' + g[0] + '</div>' + g[1].map(function (it) {
        return '<label class="swrow"><span><b>' + it[1] + '</b><small>' + it[2] + '</small></span><input type="checkbox" class="sw" data-k="' + it[0] + '"' + (s[it[0]] ? ' checked' : '') + '></label>';
      }).join('');
    }).join('');
    A.show('<div class="sp">' + head(icon('shield', 26), '광고·보안 설정', '바꾸면 바로 적용돼요 (현재 탭은 새로 불러와요)') + '<div class="pb">' + rows + '</div></div>' +
      A.btns([{ id: 'ad', label: '광고 차단 현황', cls: 'left' }, { id: 'sc', label: '보안 현황' }, { id: 'ok', label: '닫기', cls: 'primary' }]), function () {
      dlg.classList.add('wide');
      A.onEnter(A.cancel);
      dlg.onchange = function (e) { var k = e.target && e.target.getAttribute('data-k'); if (k) Ov.cmd('sec:set', { key: k, value: e.target.checked }); };
      A.wire({ ok: A.cancel, ad: function () { A.close(); Ov.cmd('panel:adstats'); }, sc: function () { A.close(); Ov.cmd('panel:secstats'); } });
    });
  }

  // ───────── https 로 안 될 때 ─────────
  function openFb(p) {
    A.show('<div class="dt">보안 연결(HTTPS)을 쓸 수 없어요</div><div class="db"><p class="msg"><b>' + esc(p.host) + '</b><br><br>이 사이트는 보안 연결을 지원하지 않는 것 같아요. 보안되지 않은 연결(http)로 계속하면 주고받는 내용이 다른 사람에게 보일 수 있어요.</p></div>' +
      A.btns([{ id: 'no', label: '취소' }, { id: 'ok', label: 'http로 계속', cls: 'primary' }]), function () {
      A.onCancel(function () { Ov.cmd('sec:http-continue', { token: p.token, yes: false }); });
      A.wire({ no: A.cancel, ok: function () { A.close(); Ov.cmd('sec:http-continue', { token: p.token, yes: true }); } });
    });
  }

  var E = window.EvDlg;
  E.define('adstats', function (p) { openAd(p.stats); });
  E.define('secstats', function (p) { openSec(p.stats); });
  E.define('secset', function (p) { openSet(p); });
  E.define('httpfb', openFb);

  // 창이 떠 있는 동안 차단 기록이 바뀌면 숫자·그래프도 따라 바뀐다
  ev.on('data:changed', function (k) {
    if (k !== 'sec' || !live || dlg.hidden || !document.getElementById('spb')) { if (dlg.hidden) live = null; return; }
    var l = live;
    ev.invoke('data:get', l.kind).then(function (st) { if (st && live === l && !dlg.hidden) l.paint(st); });
  });
})();
