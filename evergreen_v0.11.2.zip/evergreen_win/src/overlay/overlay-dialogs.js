'use strict';
// 가운데 대화상자: 북마크 편집 · 즐겨찾기 편집 · 글자 입력 · 확인 · 폴더 고르기 · 화면 확대/축소
(function () {
  var Ov = window.EvOv, esc = Ov.esc;
  var dlg = document.getElementById('dlg'), scrim = document.getElementById('scrim');
  var onCancel = null, onEnter = null;

  function show(html, bind) {
    api.onState = null; dlg.classList.remove('wide', 'xwide'); dlg.onchange = null;
    dlg.innerHTML = html; dlg.hidden = false; scrim.hidden = false; Ov.dlgOpen = true;
    dlg.classList.remove('in'); scrim.classList.remove('in'); void dlg.offsetWidth; dlg.classList.add('in'); scrim.classList.add('in');
    bind();
    var f = dlg.querySelector('input[type=text], input:not([type])'); if (f) { f.focus(); f.select(); }
  }
  function close() { api.onState = null; dlg.classList.remove('wide', 'xwide'); dlg.onchange = null; dlg.hidden = true; scrim.hidden = true; dlg.innerHTML = ''; Ov.dlgOpen = false; onCancel = null; onEnter = null; Ov.dlgClosed(); }
  function cancel() { var c = onCancel; close(); if (c) c(); }
  function btns(list) { return '<div class="da">' + list.map(function (b) { return '<button class="btn ' + (b.cls || '') + '" data-b="' + b.id + '">' + esc(b.label) + '</button>'; }).join('') + '</div>'; }
  function field(id, label, value, ph) {
    return '<label class="fld"><span>' + esc(label) + '</span><input id="' + id + '" type="text" spellcheck="false" autocomplete="off" value="' + esc(value || '') + '" placeholder="' + esc(ph || '') + '"></label><div class="err" id="' + id + 'E"></div>';
  }
  function $(id) { return document.getElementById(id); }
  function setErr(id, msg) { $(id + 'E').textContent = msg; $(id).classList.toggle('bad', !!msg); }
  function wire(map) {
    dlg.onclick = function (e) { var b = e.target.closest('[data-b]'); if (b && map[b.dataset.b]) map[b.dataset.b](e); };
  }

  var D = {};
  D.bookmark = function (p) {
    var opts = '<option value="0">폴더 없음</option>' + p.folders.map(function (f) { return '<option value="' + f.id + '"' + (f.id === p.folderId ? ' selected' : '') + '>' + esc(f.name) + '</option>'; }).join('');
    var list = [{ id: 'no', label: '취소' }];
    if (p.id != null) list.unshift({ id: 'del', label: '삭제', cls: 'danger left' });
    list.push({ id: 'ok', label: '저장', cls: 'primary' });
    show('<div class="dt">' + (p.id == null ? '북마크 추가' : '북마크 수정') + '</div><div class="db">' + field('f1', '이름', p.title) + field('f2', '주소', p.url) +
      '<label class="fld"><span>폴더</span><select id="f3">' + opts + '</select></label></div>' + btns(list), function () {
      var save = function () {
        var url = $('f2').value.trim();
        if (!url || /\s/.test(url)) { setErr('f2', '주소를 입력하세요'); return; }
        Ov.cmd('bm:save', { id: p.id, url: url, title: $('f1').value, folderId: Number($('f3').value) }); close();
      };
      onEnter = save;
      wire({ no: cancel, ok: save, del: function () { Ov.cmd('bm:delete', [p.id]); close(); } });
    });
  };
  D.shortcut = function (p) {
    var isNew = p.index == null;
    var list = [{ id: 'no', label: '취소' }, { id: 'ok', label: '저장', cls: 'primary' }];
    if (isNew) list.unshift({ id: 'reset', label: '기본값으로', cls: 'left' });
    show('<div class="dt">' + (isNew ? '즐겨찾기 추가' : '즐겨찾기 편집') + '</div><div class="db">' + field('f1', '이름', p.name) + field('f2', '주소', p.url, 'example.com') + '</div>' + btns(list), function () {
      var save = function () {
        var url = $('f2').value.trim();
        if (!url || /\s/.test(url)) { setErr('f2', '올바른 주소를 입력해 주세요'); return; }
        Ov.cmd('sc:save', { index: p.index, name: $('f1').value, url: url }); close();
      };
      onEnter = save;
      wire({ no: cancel, ok: save, reset: function () { Ov.cmd('sc:reset'); close(); } });
    });
  };
  D.prompt = function (p) {
    show('<div class="dt">' + esc(p.title) + '</div><div class="db">' + field('f1', p.label || '', p.value) + '</div>' + btns([{ id: 'no', label: '취소' }, { id: 'ok', label: p.ok || '확인', cls: 'primary' }]), function () {
      var go = function () { var v = $('f1').value.trim(); if (!v) { setErr('f1', '이름을 입력하세요'); return; } close(); p.fn(v); };
      onEnter = go; wire({ no: cancel, ok: go });
    });
  };
  D.confirm = function (p) {
    show('<div class="dt">' + esc(p.title) + '</div><div class="db"><p class="msg">' + esc(p.msg || '') + '</p></div>' + btns([{ id: 'no', label: '취소' }, { id: 'ok', label: p.ok || '확인', cls: p.danger ? 'danger-fill' : 'primary' }]), function () {
      var go = function () { close(); p.fn(); };
      onEnter = go; wire({ no: cancel, ok: go });
    });
  };
  D.pickfolder = function (p) {
    var rows = [{ id: 0, name: '폴더 없음' }].concat(p.folders).map(function (f) {
      return '<div class="pick' + (f.id === p.current ? ' on' : '') + '" data-b="p' + f.id + '">' + icon(f.id ? 'folder' : 'remove', 22) + '<span>' + esc(f.name) + '</span>' + (f.id === p.current ? icon('check', 20) : '') + '</div>';
    }).join('');
    show('<div class="dt">폴더 선택</div><div class="db pl">' + rows + '</div>' + btns([{ id: 'no', label: '취소' }]), function () {
      var map = { no: cancel };
      [{ id: 0, name: '' }].concat(p.folders).forEach(function (f) { map['p' + f.id] = function () { close(); p.fn(f.id, f.name); }; });
      wire(map);
    });
  };
  // 화면 확대/축소 (안드로이드 showPageZoomDialog: 50~500%, 10% 단위, 움직이는 동안 바로 미리보기, 이 탭에만 적용)
  D.zoom = function () {
    var t = Ov.curTab(), S = Ov.S; if (!t) return;
    var v = t.zoom, tabOnly = !!t.zoomOnly, global = S.prefs.zoom;
    var hint = function () { return tabOnly ? '다른 탭은 전체 설정(' + global + '%)을 따라요' : '모든 탭과 새 탭에 적용돼요'; };
    show('<div class="dt">화면 확대/축소</div><div class="db"><div class="zv" id="zv"></div>' +
      '<div class="zr"><button class="zb" data-b="m" title="줄이기">' + icon('remove', 22) + '</button><input id="zs" type="range" min="50" max="500" step="10"><button class="zb" data-b="p" title="키우기">' + icon('add', 22) + '</button></div>' +
      '<label class="swrow"><span><b>이 탭에만 적용</b><small id="zh"></small></span><input id="zt" type="checkbox" class="sw"></label></div>' +
      btns([{ id: 'r', label: '100%로', cls: 'left' }, { id: 'no', label: '취소' }, { id: 'ok', label: '적용', cls: 'primary' }]), function () {
      var s = $('zs'), tg = $('zt');
      var paint = function () { $('zv').textContent = v + '%'; s.value = v; $('zh').textContent = hint(); tg.checked = tabOnly; };
      var set = function (x, live) { v = Math.max(50, Math.min(500, Math.round(x / 10) * 10)); paint(); Ov.cmd('zoom:preview', v); };
      paint();
      s.addEventListener('input', function () { set(Number(s.value)); });
      tg.addEventListener('change', function () { tabOnly = tg.checked; paint(); });
      var apply = function () { Ov.cmd('zoom:set', { value: v, tabOnly: tabOnly }); close(); };
      onEnter = apply;
      onCancel = function () { Ov.cmd('zoom:preview-end'); };
      wire({ no: cancel, ok: apply, r: function () { set(100); }, m: function () { set(v - 10); }, p: function () { set(v + 10); } });
    });
  };

  scrim.addEventListener('mousedown', cancel);
  dlg.addEventListener('keydown', function (e) { if (e.key === 'Enter' && onEnter && e.target.tagName !== 'BUTTON' && e.target.tagName !== 'SELECT') { e.preventDefault(); onEnter(); } });
  // overlay-sec.js 같은 다른 파일이 같은 대화상자 틀을 쓰도록 내어 준다
  var api = { show: show, close: close, cancel: cancel, btns: btns, wire: wire, $: $, field: field,
    onEnter: function (f) { onEnter = f; }, onCancel: function (f) { onCancel = f; }, dlg: function () { return dlg; }, onState: null };
  window.EvDlg = { open: function (kind, params) { if (D[kind]) D[kind](params || {}); }, cancel: cancel, define: function (kind, fn) { D[kind] = fn; }, api: api };
  window.EvOv.ev.on('overlay:dialog', function (m) { window.EvDlg.open(m.kind, m.params); });
})();
