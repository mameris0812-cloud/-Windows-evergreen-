'use strict';
// 확장 프로그램 · 테마 대화상자: 웹스토어/파일 설치, 켜기·끄기, 열기(팝업), 설정, 삭제, 테마 고르기
(function () {
  var Ov = window.EvOv, esc = Ov.esc, ev = Ov.ev, A = window.EvDlg.api, dlg = document.getElementById('dlg');
  window.EvDlg.define('extensions', function (p) {
    var tab = (p && p.tab) || 'ext', list = [], msg = null, busy = false, $ = A.$;

    function row(x) {
      var ico = x.icon ? '<img src="' + esc(x.icon) + '" alt="">' : '<span class="xl">' + esc((x.name || '?').charAt(0).toUpperCase()) + '</span>';
      var sub = [x.version ? 'v' + x.version : '', x.source, x.theme ? '' : (x.mv ? 'MV' + x.mv : '')].filter(Boolean).join(' · ');
      var note = x.error ? '<div class="xn bad">불러오지 못했어요: ' + esc(x.error) + '</div>' : (x.warning && x.enabled ? '<div class="xn">' + esc(x.warning) + '</div>' : '');
      var ctl;
      if (x.theme) ctl = x.active ? '<span class="xchip">사용 중</span>' : '<button class="xb" data-x="theme" data-id="' + esc(x.id) + '">적용</button>';
      else ctl = (x.enabled && (x.popup || x.options) ? '<button class="xb" data-x="popup" data-id="' + esc(x.id) + '">열기</button>' : '') +
        (x.enabled && x.options && x.popup ? '<button class="xb" data-x="options" data-id="' + esc(x.id) + '">설정</button>' : '') +
        '<button class="xsw' + (x.enabled ? ' on' : '') + '" data-x="toggle" data-id="' + esc(x.id) + '" aria-label="켜기/끄기"><i></i></button>';
      return '<div class="xrow' + (x.enabled || x.active ? '' : ' off') + '"><div class="xi">' + ico + '</div><div class="xt"><b>' + esc(x.name) + '</b><small>' + esc(sub) + '</small>' +
        (x.description ? '<small class="xd">' + esc(x.description) + '</small>' : '') + note + '</div><div class="xc">' + ctl +
        '<button class="xb del" data-x="del" data-id="' + esc(x.id) + '" title="삭제">' + Ov.ico('delete') + '</button></div></div>';
    }
    function drawList() {
      var items = list.filter(function (x) { return tab === 'theme' ? x.theme : !x.theme; });
      var h = '';
      if (tab === 'theme') h += '<div class="xrow' + (list.some(function (x) { return x.active; }) ? ' off' : '') + '"><div class="xi"><span class="xl">●</span></div><div class="xt"><b>기본 (초록)</b><small>앱 기본 색</small></div><div class="xc">' +
        (list.some(function (x) { return x.active; }) ? '<button class="xb" data-x="theme" data-id="">적용</button>' : '<span class="xchip">사용 중</span>') + '</div></div>';
      h += items.length ? items.map(row).join('') : '<div class="xempty">' + (tab === 'theme' ? '설치한 테마가 없어요. 웹스토어의 테마 주소를 넣어 설치해 보세요.' : '설치한 확장 프로그램이 없어요.') + '</div>';
      $('xList').innerHTML = h;
      $('xTabE').className = 'xtab' + (tab === 'ext' ? ' sel' : ''); $('xTabT').className = 'xtab' + (tab === 'theme' ? ' sel' : '');
      var m = $('xMsg'); m.textContent = msg ? msg.t : ''; m.className = 'xmsg' + (msg && msg.bad ? ' bad' : '');
      $('xGo').disabled = busy; $('xFile').disabled = busy; $('xGo').textContent = busy ? '설치 중…' : '설치';
    }
    function refresh() { return ev.invoke('ext:list').then(function (l) { list = l || []; drawList(); }); }
    function done(r) {
      busy = false;
      if (!r || r.canceled) { drawList(); return; }
      if (r.ok) { var x = r.ext; msg = { t: '설치했어요 · ' + x.name + ' v' + x.version + (x.warning ? ' — ' + x.warning : '') }; tab = x.theme ? 'theme' : 'ext'; $('xIn').value = ''; } else msg = { t: r.error || '설치하지 못했어요', bad: true };
      refresh();
    }
    function install() {
      var v = $('xIn').value.trim(); if (!v || busy) return;
      busy = true; msg = { t: '웹스토어에서 받는 중…' }; drawList();
      ev.invoke('ext:store', v).then(done);
    }

    var html = '<div class="dt">확장 프로그램 · 테마</div><div class="db xdb">' +
      '<div class="xtabs"><button id="xTabE" class="xtab sel" data-x="tab" data-t="ext">확장 프로그램</button><button id="xTabT" class="xtab" data-x="tab" data-t="theme">테마</button></div>' +
      '<div class="xin"><input id="xIn" type="text" spellcheck="false" autocomplete="off" placeholder="웹스토어 주소 또는 확장 프로그램 ID"><button id="xGo" class="xb pri" data-x="store">설치</button><button id="xFile" class="xb" data-x="file">파일…</button></div>' +
      '<div id="xMsg" class="xmsg"></div><div id="xList" class="xlist"></div></div>' + A.btns([{ id: 'ok', label: '닫기', cls: 'primary' }]);
    A.show(html, function () {
      dlg.classList.add('xwide'); dlg.classList.add('wide');
      dlg.onclick = function (e) {
        var b = e.target.closest('[data-x]'), c = e.target.closest('[data-b]');
        if (c && c.dataset.b === 'ok') return A.cancel();
        if (!b) return;
        var a = b.dataset.x, id = b.dataset.id;
        if (a === 'tab') { tab = b.dataset.t; msg = null; drawList(); }
        else if (a === 'store') install();
        else if (a === 'file') { busy = true; msg = null; drawList(); ev.invoke('ext:file').then(done); }
        else if (a === 'toggle') { var on = !b.classList.contains('on'); ev.invoke('ext:toggle', { id: id, on: on }).then(function (l) { list = l || []; drawList(); }); }
        else if (a === 'popup') { A.cancel(); setTimeout(function () { ev.invoke('ext:popup', id); }, 140); }
        else if (a === 'options') { A.cancel(); setTimeout(function () { ev.invoke('ext:options', id); }, 140); }
        else if (a === 'theme') ev.invoke('ext:theme', id || null).then(function (r) { if (r && !r.ok) msg = { t: r.error, bad: true }; else msg = null; refresh(); });
        else if (a === 'del') {
          var x = list.filter(function (q) { return q.id === id; })[0];
          window.EvDlg.open('confirm', { title: '삭제할까요?', msg: (x ? x.name : '이 항목') + ' 을(를) 삭제합니다. 저장된 설정도 함께 지워져요.', ok: '삭제', danger: true,
            fn: function () { ev.invoke('ext:remove', id).then(function () { window.EvDlg.open('extensions', { tab: tab }); }); } });
        }
      };
      A.onEnter(function () { if (document.activeElement === $('xIn')) install(); else A.cancel(); });
      refresh();
    });
  });
})();
