'use strict';
// 메뉴·목록·대화상자 같은 팝업은 웹 화면 위에 떠야 하므로 맨 위의 투명 층(이 화면)에서 그린다.
// overlay.js = 뼈대 + 메뉴류, overlay-lists.js = 북마크·방문 기록·다운로드, overlay-dialogs.js = 대화상자.
(function () {
  var ev = window.evergreen;
  var card = document.getElementById('card');
  var Ov = window.EvOv = { ev: ev, card: card, S: null, cur: null, kinds: {}, dlgOpen: false };
  var closing = false, editing = 0, subOpen = false;
  var THEME_LABEL = { system: '시스템', light: '라이트', dark: '다크' };
  var THEME_ORDER = ['system', 'light', 'dark'];

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  Ov.esc = esc;
  Ov.cmd = function (name, arg) { ev.send('app:cmd', { name: name, arg: arg }); };
  Ov.act = function (name, arg) { Ov.cmd(name, arg); Ov.close(); };
  Ov.ico = function (n) { return '<span class="ic">' + icon(n, 24) + '</span>'; };
  Ov.toast = function (m) { Ov.cmd('toast', m); };
  Ov.copy = function (text) {
    var done = function () { Ov.toast('복사했습니다'); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, function () { Ov.toast('복사하지 못했어요'); });
    else Ov.toast('복사하지 못했어요');
  };
  Ov.curTab = function () {
    var S = Ov.S; if (!S) return null;
    var w = S.wins.filter(function (x) { return x.id === S.activeWin; })[0];
    return w ? w.tabs.filter(function (t) { return t.id === w.active; })[0] : null;
  };
  function row(o) {
    return '<div class="row' + (o.cls ? ' ' + o.cls : '') + '"' + (o.id ? ' data-do="' + o.id + '"' : '') + (o.arg != null ? ' data-arg="' + esc(o.arg) + '"' : '') + '>' +
      (o.lead || '') + '<span class="lb">' + o.label + '</span>' + (o.tail || '') + '</div>';
  }
  Ov.row = row;

  // ───────── 자리 · 열고 닫기 ─────────
  function place() {
    var k = Ov.kinds[Ov.cur.kind] || {}, W = k.width || 296, a = Ov.cur.anchor, vw = window.innerWidth, vh = window.innerHeight;
    var left = Ov.cur.left ? a.x : a.x + a.w - W;
    left = Math.max(8, Math.min(left, vw - W - 8));
    card.style.width = W + 'px';
    card.style.left = left + 'px';
    card.style.top = (a.y + a.h + 6) + 'px';
    card.style.height = k.tall ? Math.max(260, Math.min(k.tall, vh - (a.y + a.h + 6) - 14)) + 'px' : '';
    var ox = Math.max(0, Math.min(W, a.x + a.w / 2 - left));
    card.style.transformOrigin = ox + 'px 0';
  }
  Ov.draw = function () {
    var k = Ov.kinds[Ov.cur.kind];
    card.className = (k.cls || '') + (card.classList.contains('in') ? ' in' : '');
    k.render(Ov.cur, card);
  };
  Ov.open = function (m) {
    Ov.S = m.state; closeSub(); editing = 0; closing = false;
    if (m.kind === 'none') { Ov.cur = null; card.className = ''; card.innerHTML = ''; return; }
    Ov.cur = m;
    card.className = ''; place(); Ov.draw();
    void card.offsetWidth; card.classList.add('in');
  };
  // 같은 자리에서 다른 종류로 (메뉴 → 북마크 목록, 목록 → 메뉴)
  Ov.switchKind = function (kind, extra) {
    closeSub();
    Ov.cur = Object.assign({}, Ov.cur, { kind: kind, data: extra || null, fromMenu: kind !== 'menu' && Ov.cur.kind === 'menu' });
    if (kind === 'menu') Ov.cur.fromMenu = false;
    place(); Ov.draw();
  };
  function maybeHide() { if (!Ov.cur && !Ov.dlgOpen) ev.send('popup:hide'); }
  Ov.closeCard = function () {
    if (!Ov.cur || closing) { return; }
    closing = true; closeSub(); card.classList.remove('in'); card.classList.add('out');
    setTimeout(function () { Ov.cur = null; closing = false; card.className = ''; card.innerHTML = ''; maybeHide(); }, 150);
  };
  Ov.close = function () { if (Ov.dlgOpen) return; Ov.closeCard(); if (!Ov.cur) maybeHide(); };
  Ov.dlgClosed = function () { maybeHide(); };

  // ───────── 작은 메뉴 (목록 줄의 ⋮ 메뉴) ─────────
  var sub = document.getElementById('sub'), subback = document.getElementById('subback');
  function closeSub() { if (!subOpen) return; subOpen = false; sub.hidden = true; subback.hidden = true; sub.innerHTML = ''; }
  Ov.closeSub = closeSub;
  // spec: { title, subtitle, icon, items: [{ icon, label, danger, fn }] }, a: 기준 단추 위치
  Ov.sub = function (a, spec) {
    var W = 268, vw = window.innerWidth, vh = window.innerHeight;
    sub.innerHTML = (spec.title ? '<div class="sh"><span class="shi">' + icon(spec.icon || 'globe', 22) + '</span><span class="shl"><b>' + esc(spec.title) + '</b>' + (spec.subtitle ? '<small>' + esc(spec.subtitle) + '</small>' : '') + '</span></div>' : '') +
      spec.items.map(function (it, i) { return '<div class="row' + (it.danger ? ' danger' : '') + '" data-i="' + i + '">' + Ov.ico(it.icon) + '<span class="lb">' + esc(it.label) + '</span></div>'; }).join('');
    sub.hidden = false; subback.hidden = false; subOpen = true;
    sub.style.width = W + 'px';
    var left = Math.max(8, Math.min(a.x + a.w - W, vw - W - 8)), top = a.y + a.h + 4;
    sub.style.left = left + 'px'; sub.style.top = top + 'px';
    var h = sub.offsetHeight;
    if (top + h > vh - 8) sub.style.top = Math.max(8, a.y - h - 4) + 'px';
    sub.classList.remove('in'); void sub.offsetWidth; sub.classList.add('in');
    sub.onclick = function (e) {
      var r = e.target.closest('[data-i]'); if (!r) return;
      var it = spec.items[Number(r.dataset.i)]; closeSub(); if (it && it.fn) it.fn();
    };
  };
  subback.addEventListener('mousedown', closeSub);

  // ───────── 메뉴류 ─────────
  var K = Ov.kinds;
  K.menu = {
    width: 296,
    render: function (m, el) {
      var S = Ov.S, theme = S.prefs.theme, eng = S.engines.filter(function (e) { return e.key === S.prefs.engine; })[0], t = Ov.curTab();
      var web = !!(t && /^https?:/i.test(t.url || ''));
      var asS = S.autoScroll || {}, asCfg = window.EvAutoScroll.normalize(asS.cfg), asRun = !!(asS.running && t && asS.tabId === t.id);
      var zoomRow = web ? row({ id: 'dlg:zoom', lead: Ov.ico('text'), label: '화면 확대/축소', tail: '<span class="val">' + t.zoom + '%</span>' }) : '';
      el.innerHTML = row({ id: 'tab:new', lead: Ov.ico('add'), label: '새 탭' }) +
        row({ id: 'incog', lead: Ov.ico('incognito'), label: '새 시크릿 탭' }) +
        row({ id: 'win:new', lead: Ov.ico('window_new'), label: '새 창' }) + '<div class="sep"></div>' +
        (web ? row({ id: 'bm:toggle', lead: Ov.ico(t.bookmarked ? 'bookmark' : 'bookmark_border'), label: t.bookmarked ? '북마크 수정' : '북마크에 추가' }) : '') +
        row({ id: 'go:bookmarks', lead: Ov.ico('bookmark_border'), label: '북마크' }) +
        row({ id: 'go:history', lead: Ov.ico('history'), label: '방문 기록' }) +
        row({ id: 'go:downloads', lead: Ov.ico('download'), label: '다운로드' }) + '<div class="sep"></div>' +
        row({ id: 'panel:adstats', lead: Ov.ico('shield_person'), label: '광고 차단 현황', tail: S.sec ? '<span class="val">' + (S.sec.adBlock ? '켜짐' : '꺼짐') + '</span>' : '' }) +
        row({ id: 'panel:secstats', lead: Ov.ico('shield_check_filled'), label: '보안 현황<span class="sub">' + esc(S.sec ? S.sec.summary : '') + '</span>' }) +
        row({ id: 'dialog:secset', lead: Ov.ico('shield'), label: '광고·보안 설정' }) + '<div class="sep"></div>' +
        zoomRow +
        row({ id: 'bar:toggle', lead: Ov.ico('lines3'), label: '북마크 막대', tail: '<span class="val">' + (S.prefs.bookmarkBar ? '켜짐' : '꺼짐') + '</span>' }) +
        row({ id: 'theme', lead: Ov.ico('dark'), label: '테마', tail: '<span class="val">' + THEME_LABEL[theme] + '</span>' }) +
        row({ id: 'engine', lead: Ov.ico('search'), label: '검색 엔진', tail: '<span class="val">' + esc(eng ? eng.name : '') + '</span>' }) + '<div class="sep"></div>' +
        (web ? row({ id: 'page:translate', lead: Ov.ico('globe'), label: t.tr === 'done' ? '원문 보기' : t.tr === 'running' ? '번역 멈추기' : '페이지 번역', tail: '<span class="val">' + esc((S.langs || []).filter(function (l) { return l.key === S.prefs.trLang; }).map(function (l) { return l.name; })[0] || '') + '</span>' }) +
          row({ id: 'trlang', lead: Ov.ico('text'), label: '번역할 언어' }) +
          row({ id: 'trimg:toggle', lead: Ov.ico('image'), label: '이미지 속 글자도 번역<span class="sub">만화 · 웹툰 · 캡처 안의 글자</span>', tail: '<span class="val">' + (S.prefs.trImages ? '켜짐' : '꺼짐') + '</span>' }) : '') +
        (web ? row({ id: 'ascroll:toggle', lead: Ov.ico('auto_scroll'), label: asRun ? '자동 스크롤 끝내기' : '자동 스크롤', tail: '<span class="val">' + (asRun ? '켜짐' : '꺼짐') + '</span>' }) : '') +
        row({ id: 'dlg:ascroll', lead: Ov.ico('settings'), label: '자동 스크롤 설정<span class="sub">' + (asCfg.smart ? '스마트 · 내용 ' + asCfg.contentLevel + ' · 빈 그림 ' + asCfg.blankLevel + '단계' : asCfg.speed + '단계') + '</span>' }) +
        (web ? row({ id: 'player:mirror', lead: Ov.ico('movie'), label: '영상 미러링 플레이어' }) : '') +
        (web && t.media ? row({ id: 'player:media', lead: Ov.ico('play'), label: '감지된 영상 내장 플레이어로 열기<span class="sub">영상 ' + t.media + '개 감지</span>' }) : '') +
        row({ id: 'dlg:playurl', lead: Ov.ico('globe'), label: '주소로 영상 열기' }) +
        row({ id: 'player:file', lead: Ov.ico('file'), label: '영상 파일 열기' }) + '<div class="sep"></div>' +
        row({ id: 'dlg:extensions', lead: Ov.ico('puzzle'), label: '확장 프로그램 · 테마' }) +
        row({ id: 'app:devtools', lead: Ov.ico('code'), label: '개발자 도구' }) +
        row({ id: 'dlg:about', lead: Ov.ico('page_ref'), label: '앱 정보 · 업데이트 로그', tail: '<span class="val">v' + esc(S.version || '') + '</span>' });
    },
    click: function (d, a) {
      var S = Ov.S;
      if (d === 'ai:toggle') return Ov.act('ai:toggle');
      if (d === 'incog') return Ov.act('tab:new', { incognito: true });
      if (d.indexOf('go:') === 0) return Ov.switchKind(d.slice(3));
      if (d === 'dlg:zoom') { Ov.closeCard(); return EvDlg.open('zoom', {}); }
      if (d === 'dlg:playurl' || d === 'dlg:about' || d === 'dlg:extensions' || d === 'dlg:ascroll') { Ov.closeCard(); return EvDlg.open(d.slice(4), {}); }
      if (d === 'theme') return Ov.cmd('theme:set', THEME_ORDER[(THEME_ORDER.indexOf(S.prefs.theme) + 1) % 3]);
      if (d === 'engine') { var ks = S.engines.map(function (x) { return x.key; }); return Ov.cmd('engine:set', ks[(ks.indexOf(S.prefs.engine) + 1) % ks.length]); }
      if (d === 'bar:toggle' || d === 'trimg:toggle') return Ov.cmd(d);
      if (d === 'trlang') { var ls = S.langs || [], ix = ls.map(function (l) { return l.key; }).indexOf(S.prefs.trLang); return Ov.cmd('trlang:set', ls[(ix + 1) % ls.length].key); }
      return Ov.act(d, /^\d+$/.test(a || '') ? Number(a) : undefined);
    },
  };
  K.windows = {
    width: 296,
    render: function (m, el) {
      var S = Ov.S;
      el.innerHTML = S.wins.map(function (x) {
        var on = x.id === S.activeWin;
        if (editing === x.id) return '<div class="row' + (on ? ' act' : '') + '"><span class="bd">' + x.num + '</span><input id="rn" value="' + esc(x.name) + '" maxlength="30"></div>';
        return '<div class="row' + (on ? ' act' : '') + '" data-do="win:switch" data-arg="' + x.id + '"><span class="bd">' + x.num + '</span>' +
          '<span class="lb">' + esc(x.name) + '<span class="sub">탭 ' + x.tabs.length + '개</span></span>' +
          '<button class="mini" data-do="rename" data-arg="' + x.id + '" title="이름 바꾸기">' + icon('edit', 22) + '</button>' +
          (S.wins.length > 1 ? '<button class="mini" data-do="win:delete" data-arg="' + x.id + '" title="창 삭제">' + icon('delete', 22) + '</button>' : '') + '</div>';
      }).join('') + '<div class="sep"></div>' + row({ id: 'win:new', lead: Ov.ico('add'), label: '새 창' });
      if (editing) { var i = document.getElementById('rn'); if (i) { i.focus(); i.select(); } }
    },
    click: function (d, a, e) {
      if (d === 'rename') { e.stopPropagation(); editing = Number(a); Ov.draw(); return; }
      Ov.act(d, /^\d+$/.test(a || '') ? Number(a) : undefined);
    },
  };
  K.tabs = {
    width: 340,
    render: function (m, el) {
      var S = Ov.S, w = S.wins.filter(function (x) { return x.id === S.activeWin; })[0];
      el.innerHTML = '<div class="hd">' + esc(w.name) + ' · 탭 ' + w.tabs.length + '개</div>' + w.tabs.map(function (t) {
        var fv = t.favicon ? '<span class="fv"><img src="' + esc(t.favicon) + '" referrerpolicy="no-referrer" alt=""></span>' : '<span class="fv">' + icon(t.incognito ? 'incognito' : 'globe', 18) + '</span>';
        return '<div class="row' + (t.id === w.active ? ' act' : '') + '" data-do="tab:activate" data-arg="' + t.id + '">' + fv +
          '<span class="lb">' + esc(t.title || EvLists.shortUrl(t.url) || '새 탭') + '</span><button class="mini" data-do="tab:close-keep" data-arg="' + t.id + '" title="탭 닫기">' + icon('close', 22) + '</button></div>';
      }).join('');
    },
    click: function (d, a, e) {
      if (d === 'tab:close-keep') { e.stopPropagation(); return Ov.cmd('tab:close', Number(a)); }
      Ov.act(d, /^\d+$/.test(a || '') ? Number(a) : undefined);
    },
  };
  K.tabmenu = {
    width: 200,
    render: function (m, el) {
      el.innerHTML = row({ id: 'tab:duplicate', arg: m.data.id, lead: Ov.ico('copy'), label: '탭 복제' }) + row({ id: 'tab:close', arg: m.data.id, lead: Ov.ico('close'), label: '탭 닫기' });
    },
    click: function (d, a) { Ov.act(d, /^\d+$/.test(a || '') ? Number(a) : undefined); },
  };
  // 새 탭 화면의 즐겨찾기 타일 메뉴 (안드로이드 showShortcutMenu)
  K.scmenu = {
    width: 250,
    render: function (m, el) {
      var d = m.data;
      el.innerHTML = '<div class="hd">' + esc(d.name) + '</div>' +
        row({ id: 'sc:edit', lead: Ov.ico('edit'), label: '편집' }) +
        (d.index > 0 ? row({ id: 'sc:prev', lead: Ov.ico('back'), label: '앞으로 옮기기' }) : '') +
        (d.index < d.count - 1 ? row({ id: 'sc:next', lead: Ov.ico('forward'), label: '뒤로 옮기기' }) : '') +
        row({ id: 'sc:delete', cls: 'danger', lead: Ov.ico('delete'), label: '삭제' });
    },
    click: function (d) {
      var x = Ov.cur.data;
      if (d === 'sc:edit') { Ov.closeCard(); return EvDlg.open('shortcut', { index: x.index, name: x.name, url: x.url }); }
      if (d === 'sc:prev') return Ov.act('sc:move', { index: x.index, dir: -1 });
      if (d === 'sc:next') return Ov.act('sc:move', { index: x.index, dir: 1 });
      if (d === 'sc:delete') return Ov.act('sc:delete', x.index);
    },
  };
  // 북마크 막대: 폴더 칩 → 그 폴더의 북마크 / 북마크 칩 우클릭 → 메뉴
  K.bmfolder = {
    width: 320,
    render: function (m, el) {
      el.innerHTML = '<div class="hd">…</div>';
      ev.invoke('data:get', 'bookmarks').then(function (d) {
        if (!d || Ov.cur !== m) return;
        var f = d.folders.filter(function (x) { return x.id === m.data.folderId; })[0];
        var list = d.bookmarks.filter(function (b) { return b.folderId === m.data.folderId; });
        el.innerHTML = '<div class="hd">' + esc(f ? f.name : '폴더') + '</div>' + list.map(function (b) {
          return '<div class="row" data-do="nav:go" data-arg="' + esc(b.url) + '"><span class="fv">' + EvFav.html(b.url, b.fav, 18, 'bookmark') + '</span><span class="lb">' + esc(EvLists.displayTitle(b.title, b.url)) +
            '<span class="sub">' + esc(EvLists.shortUrl(b.url)) + '</span></span></div>';
        }).join('');
      });
    },
    click: function (d, a) { Ov.act(d, a); },
  };
  K.bmmenu = {
    width: 230,
    render: function (m, el) {
      el.innerHTML = row({ id: 'new', lead: Ov.ico('add'), label: '새 탭에서 열기' }) + row({ id: 'incog', lead: Ov.ico('incognito'), label: '시크릿 탭에서 열기' }) +
        row({ id: 'copy', lead: Ov.ico('copy'), label: '주소 복사' }) + row({ id: 'edit', lead: Ov.ico('edit'), label: '수정' }) + row({ id: 'del', cls: 'danger', lead: Ov.ico('delete'), label: '삭제' });
    },
    click: function (d) {
      var id = Ov.cur.data.id;
      ev.invoke('data:get', 'bookmarks').then(function (r) {
        var b = r && r.bookmarks.filter(function (x) { return x.id === id; })[0]; if (!b) return;
        if (d === 'new') Ov.act('tab:new', { input: b.url });
        else if (d === 'incog') Ov.act('tab:new', { input: b.url, incognito: true });
        else if (d === 'copy') { Ov.copy(b.url); Ov.close(); }
        else if (d === 'edit') { Ov.closeCard(); Ov.cmd('bm:edit', b.id); }
        else if (d === 'del') Ov.act('bm:delete', [b.id]);
      });
    },
  };

  // ───────── 입력 연결 ─────────
  ev.on('overlay:show', function (m) { if (m && m.state && window.EvTheme) EvTheme.apply(m.state.extTheme); Ov.open(m); });
  ev.on('overlay:close', function () { if (Ov.dlgOpen) return; closeSub(); Ov.closeCard(); if (!Ov.cur) maybeHide(); });
  ev.on('state', function (s) { Ov.S = s; if (window.EvTheme) EvTheme.apply(s.extTheme); if (window.EvDlg && EvDlg.api.onState) EvDlg.api.onState(s); if (Ov.cur && !closing && !editing && Ov.kinds[Ov.cur.kind].live !== false) Ov.draw(); });
  ev.on('data:changed', function (k) { if (Ov.cur && !closing && Ov.kinds[Ov.cur.kind].onData) Ov.kinds[Ov.cur.kind].onData(k); });
  document.getElementById('backdrop').addEventListener('mousedown', function () { if (!Ov.dlgOpen) Ov.close(); });
  document.addEventListener('contextmenu', function (e) { if (Ov.kinds[Ov.cur && Ov.cur.kind] && Ov.kinds[Ov.cur.kind].ctx && Ov.kinds[Ov.cur.kind].ctx(e)) { e.preventDefault(); return; } e.preventDefault(); if (!Ov.dlgOpen && !subOpen && e.target.id === 'backdrop') Ov.close(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      if (Ov.dlgOpen) EvDlg.cancel(); else if (subOpen) closeSub(); else if (editing) { editing = 0; Ov.draw(); } else if (Ov.cur && Ov.kinds[Ov.cur.kind].esc && Ov.kinds[Ov.cur.kind].esc()) return; else Ov.close();
    } else if (e.key === 'Enter' && editing) {
      var i = document.getElementById('rn'), id = editing; editing = 0;
      if (i && i.value.trim()) Ov.cmd('win:rename', { id: id, name: i.value }); Ov.draw();
    }
  });
  card.addEventListener('click', function (e) {
    var k = Ov.cur && Ov.kinds[Ov.cur.kind]; if (!k || !k.click) return;
    var el = e.target.closest('[data-do]'); if (!el) return;
    k.click(el.getAttribute('data-do'), el.getAttribute('data-arg'), e, el);
  });
})();
