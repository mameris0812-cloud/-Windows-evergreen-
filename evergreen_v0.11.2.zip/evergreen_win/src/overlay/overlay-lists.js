'use strict';
// 북마크 · 방문 기록 · 다운로드 목록 팝업 (안드로이드 태블릿 목록 팝업: 제목줄 + 폴더 칩 + 둥근 카드 안의 목록)
(function () {
  var Ov = window.EvOv, K = Ov.kinds, esc = Ov.esc, LS = window.EvLists, ev = Ov.ev;
  var ALL = 'all';
  var WIDTH = 460, TALL = 660;

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dateTime(t) { var d = new Date(t); return d.getFullYear() + '.' + pad(d.getMonth() + 1) + '.' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function rect(el) { var r = el.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; }

  // ───── 공통 조각 ─────
  function head(title, m, st, opts) {
    return '<div class="lh"><button class="ib" data-do="back" title="' + (m.fromMenu ? '메뉴로' : '닫기') + '">' + icon('back', 24) + '</button>' +
      '<div class="lt">' + esc(st.sel.on ? (st.sel.keys.size ? st.sel.keys.size + '개 선택됨' : '항목을 선택하세요') : title) + '</div>' +
      (opts.more ? '<button class="ib" data-do="hmore" title="더보기">' + icon('more', 22) + '</button>' : '') +
      (opts.canSelect ? '<button class="txt" data-do="selmode">' + (st.sel.on ? '취소' : '선택') + '</button>' : '') +
      '<button class="ib" data-do="x" title="닫기">' + icon('close', 22) + '</button></div>';
  }
  function chips(entries, selected, canAdd) {
    return '<div class="chips">' + entries.map(function (e) {
      return '<button class="chip' + (e.id === selected ? ' on' : '') + '" data-do="chip" data-arg="' + e.id + '">' + (e.id !== ALL ? icon('folder', 18) : '') + esc(e.label) + '</button>';
    }).join('') + (canAdd ? '<button class="chip add" data-do="chipadd">＋ 폴더</button>' : '') + '</div>';
  }
  function foot(st, total) {
    if (!st.sel.on) return '';
    var n = st.sel.keys.size;
    return '<div class="lf"><button class="txt" data-do="selall">' + (total && n === total ? '선택 해제' : '전체 선택') + '</button><span class="sp"></span><button class="txt danger" data-do="seldel"' + (n ? '' : ' disabled') + '>' + (n ? '삭제 (' + n + ')' : '삭제') + '</button></div>';
  }
  function lrow(o, st) {
    var on = st.sel.on && st.sel.keys.has(o.key);
    var lead = st.sel.on ? '<span class="ck' + (on ? ' on' : '') + '">' + (on ? icon('check_bold', 18) : '') + '</span>' : o.icon;
    return '<div class="lr' + (on ? ' sel' : '') + (o.cls ? ' ' + o.cls : '') + '" data-do="row" data-arg="' + esc(o.key) + '"><span class="ri">' + lead + '</span>' +
      '<span class="rt"><b>' + esc(o.title) + '</b><small>' + esc(o.sub) + '</small>' + (o.pg != null ? '<i class="pg"><u data-w="' + o.pg + '"></u></i>' : '') + '</span>' +
      '<button class="ib mo" data-do="more" data-arg="' + esc(o.key) + '" title="더보기">' + icon('more', 22) + '</button></div>';
  }
  function shell(m, st, title, opts, body, chipsHtml, total) {
    return head(title, m, st, opts) + (chipsHtml || '') + '<div class="lc"><div class="ls">' + body + '</div></div>' + foot(st, total);
  }
  function mount(el, html, st) {
    var old = el.querySelector('.ls'), top = old ? old.scrollTop : 0;
    el.innerHTML = html;
    el.querySelectorAll('[data-w]').forEach(function (u) { u.style.width = u.dataset.w + '%'; });
    var ls = el.querySelector('.ls'); if (ls) ls.scrollTop = top;
    if (st.anim) {
      var rows = el.querySelectorAll('.lr[data-day="' + st.anim.day + '"]'), i = 0;
      rows.forEach(function (r) { r.classList.add(st.anim.opening ? 'in' : 'out'); r.style.animationDelay = Math.min(i++ * 26, 200) + 'ms'; });
      st.anim = null;
    }
  }
  function newState() { return { data: null, folder: ALL, sel: { on: false, keys: new Set() }, anim: null, days: null }; }
  function exitSel(st) { st.sel.on = false; st.sel.keys.clear(); }
  function toggleSel(st, key) { if (st.sel.keys.has(key)) st.sel.keys.delete(key); else st.sel.keys.add(key); }
  function load(m, what, el) {
    ev.invoke('data:get', what).then(function (d) { if (!d || Ov.cur !== m) return; m.st.data = d; Ov.draw(); });
  }
  function common(d, a, m, st) { // 모든 목록이 같은 단추
    if (d === 'back') { m.fromMenu ? Ov.switchKind('menu') : Ov.close(); return true; }
    if (d === 'x') { Ov.close(); return true; }
    if (d === 'selmode') { st.sel.on ? exitSel(st) : (st.sel.on = true); Ov.draw(); return true; }
    return false;
  }
  function folderMenu(kind, f, anchor) {
    Ov.sub(anchor, { title: f.name, subtitle: '폴더', icon: 'folder', items: [
      { icon: 'edit', label: '이름 변경', fn: function () { EvDlg.open('prompt', { title: '폴더 이름 변경', label: '폴더 이름', value: f.name, fn: function (v) { Ov.cmd('folder:rename', { kind: kind, id: f.id, name: v }); } }); } },
      { icon: 'delete', label: '폴더 삭제', danger: true, fn: function () {
        EvDlg.open('confirm', { title: '폴더를 삭제할까요?', msg: "'" + f.name + "' 폴더를 삭제합니다. 안의 " + (kind === 'bm' ? '북마크' : '파일') + '은 그대로 남습니다.', ok: '삭제', danger: true, fn: function () { Ov.cmd('folder:remove', { kind: kind, id: f.id }); } });
      } },
    ] });
  }
  function addFolder(kind, st) {
    EvDlg.open('prompt', { title: '새 폴더', label: '폴더 이름', value: '', fn: function (name) {
      ev.invoke('app:call', { name: 'folder:add', arg: { kind: kind, name: name } }).then(function (f) { if (f) { st.folder = f.id; exitSel(st); } });
    } });
  }

  // ───────── 북마크 ─────────
  function bmShown(st) {
    var all = st.data.bookmarks;
    return st.folder === ALL ? all : all.filter(function (b) { return b.folderId === st.folder; });
  }
  K.bookmarks = {
    width: WIDTH, tall: TALL, cls: 'list',
    render: function (m, el) {
      var st = m.st || (m.st = newState());
      if (!st.data) { el.innerHTML = head('북마크', m, st, {}); load(m, 'bookmarks'); return; }
      var d = st.data;
      if (st.folder !== ALL && !d.folders.some(function (f) { return f.id === st.folder; })) st.folder = ALL;
      var names = {}; d.folders.forEach(function (f) { names[f.id] = f.name; });
      var shown = bmShown(st);
      st.keys = shown.map(function (b) { return String(b.id); });
      var entries = [{ id: ALL, label: '전체 (' + d.bookmarks.length + ')' }].concat(d.folders.map(function (f) { return { id: f.id, label: f.name + ' (' + d.bookmarks.filter(function (b) { return b.folderId === f.id; }).length + ')' }; }));
      var body = shown.length ? shown.map(function (b) {
        var fn = names[b.folderId];
        return lrow({ key: String(b.id), icon: EvFav.html(b.url, b.fav, 22, 'bookmark'), title: LS.displayTitle(b.title, b.url), sub: fn && st.folder === ALL ? b.url + ' · ' + fn : b.url }, st);
      }).join('') : '<div class="le">' + (st.folder === ALL ? '북마크가 없습니다<br>웹페이지에서 메뉴 → ‘북마크에 추가’ 를 눌러 보세요' : '이 폴더는 비어 있습니다<br>북마크의 ⋮ 메뉴 → ‘폴더로 이동’ 으로 옮겨 보세요') + '</div>';
      mount(el, shell(m, st, '북마크', { more: true, canSelect: true }, body, chips(entries, st.folder, true), st.keys.length), st);
    },
    click: function (d, a, e, el) {
      var m = Ov.cur, st = m.st; if (!st.data) return;
      if (common(d, a, m, st)) return;
      if (d === 'hmore') return Ov.sub(rect(el), { items: [
        { icon: 'download', label: '북마크 가져오기…', fn: function () { Ov.act('bm:import'); } },
        { icon: 'file', label: '북마크 내보내기…', fn: function () { Ov.act('bm:export'); } },
      ] });
      if (d === 'chip') { st.folder = a === ALL ? ALL : Number(a); exitSel(st); return Ov.draw(); }
      if (d === 'chipadd') return addFolder('bm', st);
      if (d === 'selall') { st.sel.keys.size === st.keys.length ? st.sel.keys.clear() : st.keys.forEach(function (k) { st.sel.keys.add(k); }); return Ov.draw(); }
      if (d === 'seldel') { var ids = Array.from(st.sel.keys).map(Number); exitSel(st); return Ov.cmd('bm:delete', ids); }
      var b = st.data.bookmarks.filter(function (x) { return String(x.id) === a; })[0]; if (!b) return;
      if (d === 'row') { if (st.sel.on) { toggleSel(st, a); return Ov.draw(); } return Ov.act('nav:go', b.url); }
      if (d === 'more') {
        var name = LS.displayTitle(b.title, b.url);
        Ov.sub(rect(el), { title: name, subtitle: b.url, icon: 'bookmark', items: [
          { icon: 'add', label: '새 탭에서 열기', fn: function () { Ov.act('tab:new', { input: b.url }); } },
          { icon: 'edit', label: '수정', fn: function () { Ov.closeCard(); Ov.cmd('bm:edit', b.id); } },
          { icon: 'folder', label: '폴더로 이동', fn: function () {
            EvDlg.open('pickfolder', { folders: st.data.folders, current: b.folderId, fn: function (id, fname) { Ov.cmd('bm:move', { ids: [b.id], folderId: id, folderName: fname }); } });
          } },
          { icon: 'copy', label: '주소 복사', fn: function () { Ov.copy(b.url); } },
          { icon: 'delete', label: '삭제', danger: true, fn: function () { EvDlg.open('confirm', { title: '북마크를 삭제할까요?', msg: "'" + name + "'", ok: '삭제', danger: true, fn: function () { Ov.cmd('bm:delete', [b.id]); } }); } },
        ] });
      }
    },
    ctx: function (e) {
      var m = Ov.cur, st = m.st; if (!st || !st.data) return false;
      var r = e.target.closest('.lr'), c = e.target.closest('.chip');
      if (r) { st.sel.on = true; toggleSel(st, r.dataset.arg); Ov.draw(); return true; }
      if (c && c.dataset.arg && c.dataset.arg !== ALL) { var f = st.data.folders.filter(function (x) { return String(x.id) === c.dataset.arg; })[0]; if (f) { folderMenu('bm', f, rect(c)); return true; } }
      return false;
    },
    esc: function () { var st = Ov.cur.st; if (st && st.sel.on) { exitSel(st); Ov.draw(); return true; } return false; },
    onData: function (k) { if (k === 'bookmarks') load(Ov.cur, 'bookmarks'); },
  };

  // ───────── 방문 기록 ─────────
  K.history = {
    width: WIDTH, tall: TALL, cls: 'list',
    render: function (m, el) {
      var st = m.st || (m.st = newState());
      if (!st.data) { el.innerHTML = head('방문 기록', m, st, {}); load(m, 'history'); return; }
      var now = st.data.now, groups = LS.groupHistory(st.data.items, now);
      if (!st.days) st.days = new Set([LS.RECENT_DAY, LS.startOfDay(now)]); // 처음엔 '최근 1시간'과 오늘이 펼쳐져 있다
      st.keys = st.data.items.map(function (h) { return h.url; }); // 전체 선택은 접힌 날의 기록까지
      var body = groups.map(function (g) {
        var open = st.days.has(g.day);
        var html = '<div class="dh' + (open ? ' open' : '') + '" data-do="day" data-arg="' + g.day + '"><span>' + esc(g.label) + '</span><i>' + icon('expand_more', 24) + '</i></div>';
        if (open) html += g.items.map(function (h) {
          var tl = LS.timeLabel(h.time);
          return lrow({ key: h.url, cls: '', icon: EvFav.html(h.url, h.fav, 22, 'globe'), title: LS.displayTitle(h.title, h.url), sub: tl ? tl + ' · ' + h.url : h.url }, st).replace('class="lr', 'data-day="' + g.day + '" class="lr');
        }).join('');
        return html;
      }).join('') || '<div class="le">방문 기록이 없습니다</div>';
      mount(el, shell(m, st, '방문 기록', { canSelect: true }, body, '', st.keys.length), st);
    },
    click: function (d, a, e, el) {
      var m = Ov.cur, st = m.st; if (!st.data) return;
      if (common(d, a, m, st)) return;
      if (d === 'day') {
        var day = Number(a), opening = !st.days.has(day), hdr = el;
        if (opening) { st.days.add(day); st.anim = { day: day, opening: true }; return Ov.draw(); }
        var rows = Ov.card.querySelectorAll('.lr[data-day="' + day + '"]');
        hdr.classList.remove('open');
        rows.forEach(function (r) { r.classList.add('out'); });
        setTimeout(function () { if (Ov.cur !== m) return; st.days.delete(day); Ov.draw(); }, rows.length ? 160 : 0);
        return;
      }
      if (d === 'selall') { st.sel.keys.size === st.keys.length ? st.sel.keys.clear() : st.keys.forEach(function (k) { st.sel.keys.add(k); }); return Ov.draw(); }
      if (d === 'seldel') { var urls = Array.from(st.sel.keys); exitSel(st); return Ov.cmd('hist:delete', urls); }
      if (d === 'row') { if (st.sel.on) { toggleSel(st, a); return Ov.draw(); } return Ov.act('nav:go', a); }
      if (d === 'more') {
        var h = st.data.items.filter(function (x) { return x.url === a; })[0]; if (!h) return;
        Ov.sub(rect(el), { title: LS.displayTitle(h.title, h.url), subtitle: h.url, icon: 'globe', items: [
          { icon: 'add', label: '새 탭에서 열기', fn: function () { Ov.act('tab:new', { input: h.url }); } },
          { icon: 'copy', label: '주소 복사', fn: function () { Ov.copy(h.url); } },
          { icon: 'delete', label: '기록에서 삭제', danger: true, fn: function () { Ov.cmd('hist:delete', [h.url]); } },
        ] });
      }
    },
    ctx: function (e) { var st = Ov.cur.st, r = e.target.closest('.lr'); if (st && st.data && r) { st.sel.on = true; toggleSel(st, r.dataset.arg); Ov.draw(); return true; } return false; },
    esc: function () { var st = Ov.cur.st; if (st && st.sel.on) { exitSel(st); Ov.draw(); return true; } return false; },
    onData: function (k) { if (k === 'history') load(Ov.cur, 'history'); },
  };

  // ───────── 다운로드 ─────────
  K.downloads = {
    width: WIDTH, tall: TALL, cls: 'list',
    render: function (m, el) {
      var st = m.st || (m.st = newState());
      if (!st.data) { el.innerHTML = head('다운로드', m, st, {}); load(m, 'downloads'); return; }
      var d = st.data;
      if (st.folder !== ALL && !d.folders.some(function (f) { return f.id === st.folder; })) st.folder = ALL;
      var inFolder = function (x) { return st.folder === ALL || d.folderMap[x.key] === st.folder; };
      var done = d.done.filter(inFolder);
      var active = st.folder === ALL ? d.active : []; // 받는 중인 파일은 폴더에 넣을 수 없어 '전체'에만
      st.keys = done.map(function (x) { return x.key; });
      var entries = [{ id: ALL, label: '전체 (' + (d.done.length + d.active.length) + ')' }].concat(d.folders.map(function (f) { return { id: f.id, label: f.name + ' (' + d.done.filter(function (x) { return d.folderMap[x.key] === f.id; }).length + ')' }; }));
      var body = active.map(function (a) {
        var pct = a.total > 0 ? Math.min(100, Math.floor(a.received * 100 / a.total)) : 0;
        var speed = a.speed > 0 && !a.paused ? ' · ' + LS.fmtSize(Math.round(a.speed)) + '/s' : '';
        var tag = a.paused ? '일시정지됨 · ' : '';
        var sub = a.total > 0 ? tag + pct + '% · ' + LS.fmtSize(a.received) + ' / ' + LS.fmtSize(a.total) + speed : tag + LS.fmtSize(a.received) + speed;
        return lrow({ key: 'a:' + a.id, cls: 'act', icon: icon('download', 22), title: a.name || '다운로드 준비 중…', sub: sub, pg: pct }, { sel: { on: false, keys: new Set() } });
      }).join('') + done.map(function (x) {
        var parts = []; if (x.size > 0) parts.push(LS.fmtSize(x.size)); if (x.time > 0) parts.push(dateTime(x.time));
        return lrow({ key: x.key, icon: icon('file', 22), title: x.name, sub: parts.join(' · ') }, st);
      }).join('');
      if (!body) body = '<div class="le">받은 파일이 없습니다</div>';
      mount(el, shell(m, st, '다운로드', { canSelect: true }, body, chips(entries, st.folder, true), st.keys.length), st);
    },
    click: function (d, a, e, el) {
      var m = Ov.cur, st = m.st; if (!st.data) return;
      if (common(d, a, m, st)) return;
      if (d === 'chip') { st.folder = a === ALL ? ALL : Number(a); exitSel(st); return Ov.draw(); }
      if (d === 'chipadd') return addFolder('dl', st);
      if (d === 'selall') { st.sel.keys.size === st.keys.length ? st.sel.keys.clear() : st.keys.forEach(function (k) { st.sel.keys.add(k); }); return Ov.draw(); }
      if (d === 'seldel') {
        var keys = Array.from(st.sel.keys);
        return EvDlg.open('confirm', { title: '파일 ' + keys.length + '개를 삭제할까요?', msg: '파일이 휴지통으로 이동합니다.', ok: '삭제', danger: true, fn: function () { exitSel(st); Ov.cmd('dl:delete', keys); } });
      }
      if (d !== 'row' && d !== 'more') return;
      if (a.indexOf('a:') === 0) { // 받는 중
        var id = Number(a.slice(2)), act = st.data.active.filter(function (x) { return x.id === id; })[0]; if (!act) return;
        return Ov.sub(rect(el), { title: act.name, subtitle: act.paused ? '일시정지됨' : '다운로드 중', icon: 'download', items: [
          act.paused ? { icon: 'play', label: '다운로드 재개', fn: function () { Ov.cmd('dl:resume', id); } } : { icon: 'pause', label: '일시정지', fn: function () { Ov.cmd('dl:pause', id); } },
          { icon: 'close', label: '다운로드 취소', danger: true, fn: function () { Ov.cmd('dl:cancel', id); } },
        ] });
      }
      var x = st.data.done.filter(function (f) { return f.key === a; })[0]; if (!x) return;
      if (d === 'row') { if (st.sel.on) { toggleSel(st, a); return Ov.draw(); } return Ov.cmd('dl:open', x.key); }
      Ov.sub(rect(el), { title: x.name, subtitle: LS.fmtSize(x.size), icon: 'file', items: [
        { icon: 'file', label: '열기', fn: function () { Ov.cmd('dl:open', x.key); } },
        { icon: 'open_tab', label: '폴더에서 보기', fn: function () { Ov.cmd('dl:show', x.key); } },
        { icon: 'folder', label: '폴더로 이동', fn: function () { EvDlg.open('pickfolder', { folders: st.data.folders, current: st.data.folderMap[x.key] || 0, fn: function (id, fname) { Ov.cmd('dl:move', { keys: [x.key], folderId: id, folderName: fname }); } }); } },
        { icon: 'delete', label: '삭제', danger: true, fn: function () { EvDlg.open('confirm', { title: '파일을 삭제할까요?', msg: "'" + x.name + "' 파일이 휴지통으로 이동합니다.", ok: '삭제', danger: true, fn: function () { Ov.cmd('dl:delete', [x.key]); } }); } },
      ] });
    },
    ctx: function (e) {
      var st = Ov.cur.st; if (!st || !st.data) return false;
      var r = e.target.closest('.lr'), c = e.target.closest('.chip');
      if (r && r.dataset.arg.indexOf('a:') !== 0) { st.sel.on = true; toggleSel(st, r.dataset.arg); Ov.draw(); return true; }
      if (c && c.dataset.arg && c.dataset.arg !== ALL) { var f = st.data.folders.filter(function (x) { return String(x.id) === c.dataset.arg; })[0]; if (f) { folderMenu('dl', f, rect(c)); return true; } }
      return false;
    },
    esc: function () { var st = Ov.cur.st; if (st && st.sel.on) { exitSel(st); Ov.draw(); return true; } return false; },
    onData: function (k) { if (k === 'downloads') load(Ov.cur, 'downloads'); },
  };
  // 목록 팝업은 앱 상태(state)가 바뀔 때마다 다시 그리지 않는다 (데이터가 바뀔 때만)
  ['bookmarks', 'history', 'downloads'].forEach(function (k) { K[k].live = false; });
})();
