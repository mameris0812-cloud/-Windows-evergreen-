'use strict';
// 자동 스크롤 설정 대화상자 (안드로이드 설정의 「자동 스크롤 …」 항목들을 한 창에 모았다).
// 바꾸는 즉시 메인에 알려 저장하고, 돌고 있는 자동 스크롤에도 바로 적용된다.
(function () {
  var Ov = window.EvOv, A = window.EvAutoScroll, esc = Ov.esc;
  var E = window.EvDlg, api = E.api, dlg = api.dlg();

  function pageHeight() { return Math.max(300, window.innerHeight - 100); } // 도구 줄을 뺀 웹 화면 높이(대략)
  function head(title, sub) {
    return '<div class="ph"><span class="phi">' + icon('auto_scroll', 26) + '</span><span class="pht"><b>' + esc(title) + '</b><small>' + esc(sub) + '</small></span></div>';
  }
  function slider(k, label, hint) {
    return '<div class="asr" data-row="' + k + '"><div class="ash"><b>' + label + '</b><span class="asv" data-v="' + k + '"></span></div>' +
      '<div class="zr"><button class="zb sm" data-b="' + k + '-" title="한 단계 줄이기">' + icon('remove', 20) + '</button>' +
      '<input type="range" min="' + A.MIN_LEVEL + '" max="' + A.MAX_LEVEL + '" step="1" data-k="' + k + '">' +
      '<button class="zb sm" data-b="' + k + '+" title="한 단계 올리기">' + icon('add', 20) + '</button></div>' +
      '<small class="ahint" data-h="' + k + '">' + hint + '</small></div>';
  }
  function toggle(k, label, sub) {
    return '<label class="swrow"><span><b>' + label + '</b><small data-s="' + k + '">' + sub + '</small></span><input type="checkbox" class="sw" data-t="' + k + '"></label>';
  }

  E.define('ascroll', function () {
    var S = Ov.S || {}, cfg = A.normalize(S.autoScroll && S.autoScroll.cfg);
    var h = pageHeight();
    var body = '<div class="asd">' +
      '<div class="ps">속도</div>' +
      slider('speed', '자동 스크롤 속도', '') +
      toggle('smart', '스마트 자동 스크롤', '화면을 읽어서 글·그림이 보이면 천천히, 빈 그림만 보이면 빠르게 흘러요') +
      '<div class="asm">' + slider('contentLevel', '내용(글·그림)이 보일 때', '') + slider('blankLevel', '빈 그림만 보일 때', '') + '</div>' +
      '<div class="ps">동작</div>' +
      toggle('pauseAtEnd', '웹툰 끝에서 멈춤', '') +
      toggle('controls', '조작 막대', '') +
      '<div class="asr"><div class="ash"><b>화면을 만지면</b></div><small class="ahint">휠을 굴리거나 화면을 누르거나 이동 키를 눌렀을 때예요 · Esc 는 항상 멈춰요</small>' +
      '<div class="seg" id="astouch"><button data-b="t0">만지는 동안만 멈췄다가 이어서</button><button data-b="t1">완전히 멈춤</button></div></div>' +
      '</div>';
    api.show('<div class="sp">' + head('자동 스크롤', '웹툰 · 긴 글을 손 안 대고 볼 때 · Ctrl+Shift+S') + '<div class="pb">' + body + '</div></div>' +
      api.btns([{ id: 'rs', label: '기본값으로', cls: 'left' }, { id: 'ok', label: '닫기', cls: 'primary' }]), function () {
      dlg.classList.add('wide');
      var q = function (sel) { return dlg.querySelector(sel); };
      function paint() {
        ['speed', 'contentLevel', 'blankLevel'].forEach(function (k) {
          var r = q('input[data-k=' + k + ']'); if (document.activeElement !== r) r.value = cfg[k];
          var sec = A.secondsLabel(A.screenSeconds(cfg[k], h));
          q('[data-v=' + k + ']').textContent = cfg[k] + '단계';
          q('[data-h=' + k + ']').textContent = '화면 한 장을 내려가는 데 약 ' + sec;
          r.style.setProperty('--fill', ((cfg[k] - A.MIN_LEVEL) / (A.MAX_LEVEL - A.MIN_LEVEL) * 100) + '%');
        });
        Array.prototype.forEach.call(dlg.querySelectorAll('input[data-t]'), function (c) { c.checked = !!cfg[c.dataset.t]; });
        q('[data-row=speed]').classList.toggle('dim', cfg.smart);
        q('.asm').classList.toggle('dim', !cfg.smart);
        q('[data-h=speed]').textContent = cfg.smart ? '스마트 자동 스크롤이 켜져 있어 아래의 내용·빈 그림 단계를 써요' : '화면 한 장을 내려가는 데 약 ' + A.secondsLabel(A.screenSeconds(cfg.speed, h));
        q('[data-s=pauseAtEnd]').textContent = cfg.pauseAtEnd
          ? (cfg.controls ? '마지막 컷에 닿으면 댓글로 넘어가기 전에 일시정지해요' : '마지막 컷에 닿으면 멈춰요 · 조작 막대가 꺼져 있어 일시정지 대신 정지해요')
          : '꺼져 있어요 · 웹툰 끝에서도 멈추지 않고 댓글·추천 목록까지 계속 흘러요';
        q('[data-s=controls]').textContent = cfg.controls ? '자동 스크롤 중 화면 아래에 닫기·속도 조절·일시정지 막대가 떠요' : '꺼져 있어요 · 멈추려면 Esc 를 누르거나 화면을 눌러요';
        Array.prototype.forEach.call(q('#astouch').children, function (b, i) { b.classList.toggle('on', cfg.touch === i); });
      }
      function set(k, v) {
        cfg = A.normalize(Object.assign({}, cfg, (function (o) { o[k] = v; return o; })({})));
        // 스마트의 두 단계는 '빈 그림 ≥ 내용' 을 지킨다
        if (k === 'contentLevel' && cfg.blankLevel < cfg.contentLevel) cfg.blankLevel = cfg.contentLevel;
        if (k === 'blankLevel' && cfg.blankLevel < cfg.contentLevel) cfg.contentLevel = cfg.blankLevel;
        paint(); Ov.cmd('ascroll:set', cfg);
      }
      dlg.oninput = function (e) { var t = e.target; if (t && t.dataset && t.dataset.k && dlg.contains(t) && t.closest('.asd')) set(t.dataset.k, Number(t.value)); };
      dlg.onchange = function (e) { var t = e.target; if (t && t.dataset && t.dataset.t && t.closest('.asd')) set(t.dataset.t, t.checked); };
      var map = { ok: api.cancel, t0: function () { set('touch', 0); }, t1: function () { set('touch', 1); },
        rs: function () { cfg = A.normalize(null); paint(); Ov.cmd('ascroll:set', cfg); } };
      ['speed', 'contentLevel', 'blankLevel'].forEach(function (k) {
        map[k + '-'] = function () { set(k, cfg[k] - 1); }; map[k + '+'] = function () { set(k, cfg[k] + 1); };
      });
      api.wire(map); api.onEnter(api.cancel);
      paint();
    });
  });
})();
