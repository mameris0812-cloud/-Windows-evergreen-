'use strict';
// 플레이어 관련 대화상자: 영상 주소 입력 · 앱 정보(업데이트 로그)
(function () {
  var Ov = window.EvOv, esc = Ov.esc, A = window.EvDlg.api;
  window.EvDlg.define('playurl', function () {
    A.show('<div class="dt">주소로 영상 열기</div><div class="db">' + A.field('f1', '영상 주소 (mp4 · webm · m3u8 …)', '', 'https://') + '</div>' + A.btns([{ id: 'no', label: '취소' }, { id: 'ok', label: '재생', cls: 'primary' }]), function () {
      var go = function () {
        var u = A.$('f1').value.trim();
        if (!/^https?:\/\/\S+$/i.test(u)) { A.$('f1E').textContent = 'http:// 또는 https:// 로 시작하는 주소를 입력하세요'; A.$('f1').classList.add('bad'); return; }
        A.close(); Ov.cmd('player:open', u);
      };
      A.onEnter(go); A.wire({ no: A.cancel, ok: go });
    });
  });
  // 업데이트 카드: 상태(phase)에 따라 한 줄 설명 + 단추. 진행 중에는 막대가 차오른다.
  function updCard(u) {
    if (!u || !u.supported) return '<div class="upd"><div class="ut"><b>업데이트</b><span>설치해서 쓰는 앱에서 켜져요</span></div></div>';
    var title = '최신 버전이에요', sub = u.checkedAt ? '마지막 확인 ' + new Date(u.checkedAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '아직 확인하지 않았어요', btn = { id: 'chk', label: '업데이트 확인' }, bar = '';
    if (u.phase === 'checking') { title = '확인하는 중…'; sub = ''; btn = { id: 'chk', label: '확인 중', dis: true }; bar = '<div class="ubar ind"><i></i></div>'; }
    else if (u.phase === 'downloading') { title = 'v' + esc(u.version || '') + ' 받는 중 ' + (u.percent || 0) + '%'; sub = '앱을 쓰는 동안 조용히 받아요'; btn = { id: 'chk', label: '받는 중', dis: true }; bar = '<div class="ubar"><i data-w="' + (u.percent || 0) + '"></i></div>'; }
    else if (u.phase === 'ready') { title = '새 버전 v' + esc(u.version || '') + ' 준비됐어요'; sub = '다시 시작하면 바로 적용돼요'; btn = { id: 'ins', label: '다시 시작', primary: true }; }
    else if (u.phase === 'error') { title = '확인하지 못했어요'; sub = esc(u.error || ''); }
    return '<div class="upd ' + (u.phase || '') + '"><div class="ut"><b>' + title + '</b><span>' + sub + '</span>' + bar + '</div>' +
      '<button class="btn' + (btn.primary ? ' primary' : '') + '" data-b="' + btn.id + '"' + (btn.dis ? ' disabled' : '') + '>' + btn.label + '</button></div>' +
      '<label class="uauto"><span>자동으로 업데이트 확인</span><input type="checkbox" class="sw" id="uauto"' + (u.auto ? ' checked' : '') + '></label>';
  }
  function paintBars(root) { Array.prototype.forEach.call(root.querySelectorAll('.ubar i[data-w]'), function (i) { i.style.width = i.getAttribute('data-w') + '%'; }); }
  window.EvDlg.define('about', function () {
    var S = Ov.S || {}, list = S.changelog || [];
    var html = '<div class="dt">앱 정보</div><div class="db"><div class="abt"><img src="../../assets/icon.png" alt=""><div><b>Evergreen</b><span>Windows · v' + esc(S.version || '') + '</span></div></div>' +
      '<div id="updBox">' + updCard(S.update) + '</div>' +
      '<div class="dt sm">업데이트 로그</div><div class="chlog">' +
      list.map(function (e) { return '<div class="chv"><b>v' + esc(e.version) + '</b><small>' + esc(e.date) + '</small></div><ul>' + e.notes.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul>'; }).join('') + '</div></div>' + A.btns([{ id: 'ok', label: '닫기', cls: 'primary' }]);
    A.show(html, function () {
      A.onEnter(A.cancel);
      A.wire({ ok: A.cancel, chk: function () { Ov.cmd('update:check'); }, ins: function () { Ov.cmd('update:install'); } });
      A.dlg().onchange = function (e) { if (e.target && e.target.id === 'uauto') Ov.cmd('update:auto', !!e.target.checked); };
      paintBars(A.$('updBox'));
      A.onState = function (s) { var b = A.$('updBox'); if (b) { b.innerHTML = updCard(s.update); paintBars(b); } };
    });
  });
})();
