'use strict';
(function () {
  var ev = window.evergreen;
  var $ = function (s) { return document.querySelector(s); };
  var S = null, lastTab = 0, drag = null, seen = null, seenWin = 0;
  var urlEl = $('#url'), tabsEl = $('#tabs'), scrollEl = $('#tabsScroll');

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function cmd(name, arg) { ev.send('app:cmd', { name: name, arg: arg }); }
  function display(u) { return u ? String(u).replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/$/, '') : ''; }
  function curWin() { return S && S.wins.filter(function (w) { return w.id === S.activeWin; })[0]; }
  function curTab() { var w = curWin(); return w && w.tabs.filter(function (t) { return t.id === w.active; })[0]; }

  // 고정 아이콘
  $('#newTab').innerHTML = icon('strip_add', 20);
  $('#back').innerHTML = icon('back', 24);
  $('#fwd').innerHTML = icon('forward', 24);
  $('#home').innerHTML = icon('home', 24);
  $('#aiBtn').innerHTML = icon('ai', 24);
  $('#menu').innerHTML = icon('more', 24);
  $('#dlIcon').innerHTML = icon('arrow_down', 18);

  function favHtml(t) {
    if (t.incognito && !t.favicon) return '<span class="fav incog">' + icon('incognito', 18) + '</span>';
    if (t.favicon) return '<span class="fav"><img src="' + esc(t.favicon) + '" referrerpolicy="no-referrer" alt=""></span>';
    return '<span class="fav"><span class="' + (t.loading ? 'spin' : '') + '">' + icon('globe', 18) + '</span></span>';
  }
  // 탭을 닫을 때: 옆으로 줄어들며 사라진 뒤(0.14초) 닫는다. 움직임 줄이기 설정이면 바로 닫는다.
  var calm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)');
  function closeAnimated(el, id) {
    if (!el || (calm && calm.matches) || el.classList.contains('dying')) return cmd('tab:close', id);
    el.classList.add('dying');
    setTimeout(function () { cmd('tab:close', id); }, 140);
  }
  function render() {
    if (!S) return;
    var w = curWin(); if (!w) return;
    $('#winBadge').textContent = w.num;
    $('#winBadge').title = w.name + ' · 창 목록';
    $('#tabCount').textContent = w.tabs.length > 99 ? '99+' : w.tabs.length;
    tabsEl.style.setProperty('--n', w.tabs.length);
    if (!drag) {
      // 새로 생긴 탭만 부드럽게 나타나게 한다(처음 그릴 때 · 다른 창으로 바꿀 때는 모두 '이미 있던 것'으로 본다)
      var fresh = !!seen && seenWin === w.id, prev = seen || {};
      seen = {}; seenWin = w.id;
      tabsEl.innerHTML = w.tabs.map(function (t) {
        var title = t.title || display(t.url) || '새 탭';
        seen[t.id] = 1;
        return '<div class="tab' + (t.id === w.active ? ' sel' : '') + (fresh && !prev[t.id] ? ' born' : '') + '" data-id="' + t.id + '" draggable="true" title="' + esc(title) + '">' +
          favHtml(t) + '<span class="title">' + esc(title) + '</span>' +
          (t.audible ? '<span class="snd">' + icon('volume_up', 14) + '</span>' : '') +
          '<button class="x" title="탭 닫기">' + icon('close', 16) + '</button></div>';
      }).join('');
      var sel = tabsEl.querySelector('.tab.sel');
      if (sel && w.active !== lastTab) sel.scrollIntoView({ inline: 'nearest', block: 'nearest' });
      scrollEl.classList.toggle('overflow', scrollEl.scrollWidth > scrollEl.clientWidth + 1);
    }
    var t = curTab();
    $('#back').disabled = !t || !t.canBack;
    $('#fwd').disabled = !t || !t.canFwd;
    $('#refresh').innerHTML = icon(t && t.loading ? 'close' : 'refresh', 20);
    $('#refresh').title = t && t.loading ? '중지' : '새로고침 (Ctrl+R)';
    var ic = $('#urlIcon');
    ic.className = t && t.secure ? 'secure' : '';
    ic.innerHTML = icon(t && t.secure ? 'lock' : (t && t.url ? 'globe' : 'search'), 16);
    if (document.activeElement !== urlEl || (t && t.id !== lastTab)) urlEl.value = t ? display(t.url) : '';
    // 별(북마크) · 확대 배지 · 다운로드 진행 · 북마크 막대
    var web = !!(t && /^https?:/i.test(t.url || ''));
    var star = $('#star');
    star.disabled = !web;
    star.classList.toggle('on', !!(t && t.bookmarked));
    star.innerHTML = icon(t && t.bookmarked ? 'bookmark' : 'bookmark_border', 20);
    star.title = t && t.bookmarked ? '북마크 수정 (Ctrl+D)' : '북마크에 추가 (Ctrl+D)';
    var zc = $('#zoomChip');
    zc.hidden = !(web && t.zoom !== 100);
    if (!zc.hidden) { zc.textContent = t.zoom + '%'; zc.title = '화면 확대/축소 ' + t.zoom + '%' + (t.zoomOnly ? ' (이 탭만)' : ''); }
    var dl = S.dl || { count: 0, progress: 0 }, db = $('#dl');
    db.hidden = !dl.count;
    db.classList.toggle('unk', dl.progress < 0);
    db.style.setProperty('--p', dl.progress < 0 ? .28 : dl.progress);
    db.title = '다운로드 ' + dl.count + '개 받는 중' + (dl.progress >= 0 ? ' · ' + Math.round(dl.progress * 100) + '%' : '') + ' (Ctrl+J)';
    $('#aiBtn').classList.toggle('on', !!(S.ai && S.ai.open));
    drawBar();
    progress(t);
    lastTab = w.active;
  }

  // 로딩 막대
  var prog = $('#progress i'), progTab = 0, progLoading = false, progTimer = null;
  function setBar(scale, op, ms) { prog.style.transition = ms ? 'transform ' + ms + 'ms cubic-bezier(.2,.7,.2,1), opacity .25s' : 'none'; prog.style.transform = 'scaleX(' + scale + ')'; prog.style.opacity = op; }
  function progress(t) {
    var loading = !!(t && t.loading), id = t ? t.id : 0;
    if (id !== progTab) { progTab = id; progLoading = false; clearTimeout(progTimer); setBar(0, 0, 0); }
    if (loading && !progLoading) {
      progLoading = true; clearTimeout(progTimer);
      setBar(0.02, 1, 0); void prog.offsetWidth; setBar(0.82, 1, 6000);
    } else if (!loading && progLoading) {
      progLoading = false; setBar(1, 1, 220);
      progTimer = setTimeout(function () { setBar(1, 0, 0); prog.style.transition = 'opacity .25s'; prog.style.opacity = 0; }, 260);
    }
  }

  ev.on('state', function (s) { S = s; if (window.EvTheme) EvTheme.apply(s.extTheme); render(); });
  ev.on('data:changed', function (k) { if (k === 'bookmarks') loadBar(); });
  ev.on('focus-url', function () { urlEl.focus(); urlEl.select(); });

  // 탭 줄 입력
  tabsEl.addEventListener('click', function (e) {
    var tab = e.target.closest('.tab'); if (!tab) return;
    var id = Number(tab.dataset.id);
    if (e.target.closest('.x')) closeAnimated(e.target.closest('.tab'), id); else cmd('tab:activate', id);
  });
  tabsEl.addEventListener('auxclick', function (e) {
    if (e.button !== 1) return; var tab = e.target.closest('.tab'); if (tab) { e.preventDefault(); closeAnimated(tab, Number(tab.dataset.id)); }
  });
  tabsEl.addEventListener('contextmenu', function (e) {
    var tab = e.target.closest('.tab'); if (!tab) return; e.preventDefault();
    var r = tab.getBoundingClientRect();
    ev.send('popup:open', { kind: 'tabmenu', anchor: { x: e.clientX, y: r.top, w: 0, h: r.height }, data: { id: Number(tab.dataset.id) } });
  });
  scrollEl.addEventListener('wheel', function (e) { if (e.deltaY) { scrollEl.scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
  $('#strip').addEventListener('dblclick', function (e) { if (e.target.id === 'dragFill' || e.target.id === 'strip') cmd('tab:new'); });
  $('#newTab').addEventListener('click', function () { cmd('tab:new'); });
  window.addEventListener('resize', function () { scrollEl.classList.toggle('overflow', scrollEl.scrollWidth > scrollEl.clientWidth + 1); });

  // 끌어서 순서 바꾸기
  tabsEl.addEventListener('dragstart', function (e) {
    var tab = e.target.closest('.tab'); if (!tab) return;
    drag = { id: Number(tab.dataset.id), to: -1 }; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(drag.id));
  });
  tabsEl.addEventListener('dragover', function (e) {
    if (!drag) return; e.preventDefault();
    var els = Array.prototype.slice.call(tabsEl.querySelectorAll('.tab'));
    els.forEach(function (n) { n.classList.remove('drop-before', 'drop-after'); });
    var idx = els.length;
    for (var i = 0; i < els.length; i++) { var r = els[i].getBoundingClientRect(); if (e.clientX < r.left + r.width / 2) { idx = i; break; } }
    drag.to = idx;
    if (idx < els.length) els[idx].classList.add('drop-before'); else if (els.length) els[els.length - 1].classList.add('drop-after');
  });
  function endDrag(apply) {
    if (!drag) return;
    var d = drag; drag = null;
    var w = curWin();
    if (apply && w && d.to >= 0) { var from = w.tabs.map(function (t) { return t.id; }).indexOf(d.id); var to = d.to > from ? d.to - 1 : d.to; if (to !== from) cmd('tab:move', { id: d.id, index: to }); }
    render();
  }
  tabsEl.addEventListener('drop', function (e) { e.preventDefault(); endDrag(true); });
  tabsEl.addEventListener('dragend', function () { endDrag(false); });

  // 주소창
  urlEl.addEventListener('focus', function () { var t = curTab(); urlEl.value = t && t.url ? t.url : ''; setTimeout(function () { urlEl.select(); }, 0); });
  urlEl.addEventListener('blur', function () { var t = curTab(); urlEl.value = t ? display(t.url) : ''; ev.send('suggest:blur'); });
  urlEl.addEventListener('input', function () {
    var r = $('#urlWrap').getBoundingClientRect();
    ev.send('suggest:query', { q: urlEl.value, rect: { x: r.left, y: r.top, w: r.width, h: r.height } });
  });
  urlEl.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { var v = urlEl.value; ev.send('suggest:hide'); urlEl.blur(); cmd('nav:go', v); }
    else if (e.key === 'Escape') { ev.send('suggest:hide'); urlEl.blur(); }
    else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); ev.send('suggest:move', e.key === 'ArrowDown' ? 1 : -1); }
  });
  ev.on('suggest:fill', function (text) { urlEl.value = text; urlEl.setSelectionRange(text.length, text.length); });
  $('#back').addEventListener('click', function () { cmd('nav:back'); });
  $('#fwd').addEventListener('click', function () { cmd('nav:forward'); });
  $('#home').addEventListener('click', function () { cmd('nav:home'); });
  $('#aiBtn').addEventListener('click', function () { cmd('ai:toggle'); });
  $('#refresh').addEventListener('click', function () { var t = curTab(); cmd(t && t.loading ? 'nav:stop' : 'nav:reload'); });

  // 팝업 (바깥 층에서 그린다)
  function pop(kind, el, left) {
    var r = el.getBoundingClientRect();
    ev.send('popup:open', { kind: kind, anchor: { x: r.left, y: r.top, w: r.width, h: r.height }, left: !!left });
  }
  $('#menu').addEventListener('click', function () { pop('menu', $('#menu')); });
  $('#star').addEventListener('click', function () { cmd('bm:toggle'); });
  $('#zoomChip').addEventListener('click', function () { cmd('dialog:zoom'); });
  $('#dl').addEventListener('click', function () { pop('downloads', $('#menu')); });

  // 북마크 막대: 폴더(안에 북마크가 있는 것만) 먼저, 그다음 폴더 없는 북마크
  var BM = { bookmarks: [], folders: [] };
  function loadBar() { ev.invoke('data:get', 'bookmarks').then(function (d) { if (d) { BM = d; drawBar(); } }); }
  function drawBar() {
    var bar = $('#bmbar'), on = !!(S && S.prefs.bookmarkBar && BM.bookmarks.length);
    $('#top').classList.toggle('hasbar', on);
    if (!on) { bar.hidden = true; $('#bmlist').innerHTML = ''; return; }
    var key = JSON.stringify([BM, 1]);
    bar.hidden = false;
    if (bar.dataset.k === key) return;
    bar.dataset.k = key;
    var html = [];
    BM.folders.forEach(function (f) {
      if (!BM.bookmarks.some(function (b) { return b.folderId === f.id; })) return;
      html.push('<button class="bm" data-folder="' + f.id + '" title="' + esc(f.name) + '">' + icon('folder', 16) + '<span class="lb">' + esc(f.name) + '</span></button>');
    });
    BM.bookmarks.filter(function (b) { return !b.folderId; }).forEach(function (b) {
      var name = EvLists.displayTitle(b.title, b.url);
      html.push('<button class="bm" data-id="' + b.id + '" data-url="' + esc(b.url) + '" title="' + esc(name + '\n' + b.url) + '">' + EvFav.html(b.url, b.fav, 16, 'bookmark') + '<span class="lb">' + esc(name) + '</span></button>');
    });
    $('#bmlist').innerHTML = html.join('<i class="bsep"></i>');
  }
  $('#bmbar').addEventListener('click', function (e) {
    var c = e.target.closest('.bm'); if (!c) return;
    if (c.dataset.folder) { var r = c.getBoundingClientRect(); ev.send('popup:open', { kind: 'bmfolder', anchor: { x: r.left, y: r.top, w: r.width, h: r.height }, left: true, data: { folderId: Number(c.dataset.folder) } }); }
    else cmd('nav:go', c.dataset.url);
  });
  $('#bmbar').addEventListener('auxclick', function (e) { var c = e.target.closest('.bm'); if (e.button === 1 && c && c.dataset.url) { e.preventDefault(); cmd('tab:new', { input: c.dataset.url }); } });
  $('#bmbar').addEventListener('contextmenu', function (e) {
    var c = e.target.closest('.bm'); if (!c || !c.dataset.id) return; e.preventDefault();
    var r = c.getBoundingClientRect();
    ev.send('popup:open', { kind: 'bmmenu', anchor: { x: r.left, y: r.top, w: r.width, h: r.height }, left: true, data: { id: Number(c.dataset.id) } });
  });
  $('#bmbar').addEventListener('wheel', function (e) { if (e.deltaY) { $('#bmbar').scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
  loadBar();
  $('#winBadge').addEventListener('click', function () { pop('windows', $('#winBadge'), true); });
  $('#tabList').addEventListener('click', function () { pop('tabs', $('#tabList')); });

  // 화면 높이를 알려 웹 영역 위치를 맞춘다
  function reportH() { ev.send('ui:chrome-height', $('#top').offsetHeight); }
  new ResizeObserver(reportH).observe($('#top'));
  reportH();
  ev.send('ui:ready');
})();
