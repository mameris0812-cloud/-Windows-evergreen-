'use strict';
document.getElementById('si').innerHTML = icon('search', 22);
document.getElementById('go').innerHTML = icon('arrow_up', 22);
document.getElementById('f').addEventListener('submit', function (e) {
  e.preventDefault();
  var v = document.getElementById('q').value.trim();
  if (v && window.evergreenNewTab) window.evergreenNewTab.go(v);
});

// 즐겨찾기 타일
(function () {
  var nt = window.evergreenNewTab, box = document.getElementById('sc'), list = [];
  if (!nt) return;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function glyph(s) { return s.glyph || (s.name || '?').trim().charAt(0).toUpperCase(); }
  function draw() {
    box.innerHTML = list.map(function (s, i) {
      return '<button class="tile" data-i="' + i + '" title="' + esc(s.url) + '"><span class="face">' + esc(glyph(s)) + '</span><span class="lbl">' + esc(s.name) + '</span></button>';
    }).join('') + '<button class="tile add" data-add="1" title="즐겨찾기 추가"><span class="face">' + icon('add', 24) + '</span><span class="lbl">추가</span></button>';
  }
  var pressTimer = null, longDone = false;
  box.addEventListener('click', function (e) {
    var t = e.target.closest('.tile'); if (!t) return;
    if (longDone) { longDone = false; return; }
    if (t.dataset.add) nt.add(); else if (list[t.dataset.i]) nt.go(list[t.dataset.i].url);
  });
  box.addEventListener('contextmenu', function (e) {
    var t = e.target.closest('.tile'); if (!t || t.dataset.add) return;
    e.preventDefault(); nt.menu(Number(t.dataset.i), e.clientX, e.clientY);
  });
  // 터치로 길게 누르기
  box.addEventListener('pointerdown', function (e) {
    var t = e.target.closest('.tile'); if (!t || t.dataset.add || e.pointerType === 'mouse') return;
    clearTimeout(pressTimer);
    pressTimer = setTimeout(function () { longDone = true; nt.menu(Number(t.dataset.i), e.clientX, e.clientY); }, 520);
  });
  ['pointerup', 'pointercancel', 'pointermove'].forEach(function (n) { box.addEventListener(n, function () { clearTimeout(pressTimer); }); });
  nt.onShortcuts(function (l) { list = l; draw(); });
  nt.shortcuts().then(function (l) { list = l; draw(); });
})();

// 개인정보 카드 (안드로이드 homeAdCard · homeSecCard): 이번 주 막은 광고 수 · 오늘 막은 위협 수 — 누르면 현황 창
(function () {
  var nt = window.evergreenNewTab; if (!nt || !nt.cards) return;
  var box = document.getElementById('cards'), cAd = document.getElementById('cAd'), cSec = document.getElementById('cSec');
  document.getElementById('cAdI').innerHTML = icon('shield_person', 36);
  document.getElementById('cSecI').innerHTML = icon('shield_check_filled', 36);
  function fmt(n) { return Number(n || 0).toLocaleString('ko-KR'); }
  function strong(text, num) { var i = text.indexOf(num); return text.slice(0, i) + '<b>' + num + '</b>' + text.slice(i + num.length); }
  function paint(c) {
    if (!c) return;
    var a = fmt(c.adWeek), s = fmt(c.secToday);
    document.getElementById('cAdT').innerHTML = strong('이번 주 광고 ' + a + '개를 차단했습니다.', a);
    document.getElementById('cSecT').innerHTML = c.secToday > 0 ? strong('오늘 ' + s + '번 차단했습니다.', s) : '오늘 차단한 위협이 아직 없습니다.';
    box.hidden = false;
  }
  var last = 0;
  function open(which, el) { var now = Date.now(); if (now - last < 600) return; last = now; var r = el.getBoundingClientRect(); nt.openCard(which, { x: r.left, y: r.top, w: r.width, h: r.height }); }
  cAd.addEventListener('click', function () { open('ad', cAd); });
  cSec.addEventListener('click', function () { open('sec', cSec); });
  nt.onCards(paint);
  nt.cards().then(paint);
})();
