'use strict';
// 웹사이트 아이콘 (안드로이드 Favicons.kt 와 같은 순서):
//  ① 웹페이지가 알려 준 아이콘 → ② 사이트의 /favicon.ico → ③ 외부 서비스 → ④ 기본 아이콘(지구본·북마크)
// 외부 서비스에 사이트 주소(호스트)가 전달되는 게 싫으면 EXTERNAL 을 null 로 바꾼다.
(function () {
  var EXTERNAL = 'https://www.google.com/s2/favicons?sz=64&domain=';
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function hostOf(u) { try { return new URL(u).hostname.replace(/^www\./i, ''); } catch (e) { return ''; } }

  // fav: 저장된 아이콘 주소(없으면 ''), fb: 끝내 못 구했을 때 보일 아이콘 이름
  function html(url, fav, size, fb) {
    var h = hostOf(url), start = fav ? 0 : 1;
    var src = fav || (h ? 'https://' + h + '/favicon.ico' : '');
    if (!src) return window.icon(fb || 'globe', size);
    return '<img class="evfav" width="' + size + '" height="' + size + '" alt="" referrerpolicy="no-referrer" data-h="' + esc(h) + '" data-s="' + start +
      '" data-fb="' + esc(fb || 'globe') + '" data-sz="' + size + '" src="' + esc(src) + '">';
  }

  // 이미지를 못 받으면 다음 후보로 (error 는 거품이 일지 않아 캡처 단계에서 듣는다)
  document.addEventListener('error', function (e) {
    var im = e.target;
    if (!im || im.tagName !== 'IMG' || !im.classList.contains('evfav')) return;
    var stage = Number(im.dataset.s), h = im.dataset.h;
    if (stage === 0 && h) { im.dataset.s = '1'; im.src = 'https://' + h + '/favicon.ico'; return; }
    if (stage <= 1 && h && EXTERNAL) { im.dataset.s = '2'; im.src = EXTERNAL + encodeURIComponent(h); return; }
    var span = document.createElement('span');
    span.className = 'evfav-fb';
    span.innerHTML = window.icon(im.dataset.fb, Number(im.dataset.sz));
    im.replaceWith(span);
  }, true);

  window.EvFav = { html: html, hostOf: hostOf };
})();
