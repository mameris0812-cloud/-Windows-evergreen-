'use strict';
(function () {
  var ev = window.evergreen, card = document.getElementById('card'), items = [], sel = -1;
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function short(u) { return u.replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/$/, ''); }
  function draw() {
    card.innerHTML = items.map(function (s, i) {
      var url = /^https?:\/\//i.test(s);
      return '<div class="it' + (i === sel ? ' on' : '') + '" data-i="' + i + '"><span class="ic">' + icon(url ? 'globe' : 'search', 20) + '</span><span class="tx">' + esc(url ? short(s) : s) + '</span></div>';
    }).join('');
    requestAnimationFrame(function () { ev.send('suggest:size', { h: document.body.scrollHeight }); });
  }
  ev.on('suggest:show', function (p) {
    var same = items.length === p.items.length && items.every(function (x, i) { return x === p.items[i]; });
    items = p.items; sel = p.selected;
    if (same) { mark(); return; }
    draw();
  });
  function mark() { Array.prototype.forEach.call(card.children, function (n, i) { n.classList.toggle('on', i === sel); }); }
  ev.on('suggest:hl', function (i) { sel = i; mark(); });
  // 눌렀을 때(mousedown) 바로 고른다: 주소창이 포커스를 잃기 전에 처리하려고
  card.addEventListener('mousedown', function (e) {
    var n = e.target.closest('.it'); if (!n) return;
    e.preventDefault(); ev.send('suggest:pick', items[Number(n.dataset.i)]);
  });
})();
