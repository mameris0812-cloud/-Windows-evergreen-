'use strict';
// 웹페이지(탭) 안에서 도는 다리.
//  - 새 탭 화면(file://…/newtab.html): 검색 · 즐겨찾기 타일 · 개인정보 카드
//  - 웹 페이지(http/https): 광고·보안 (3단계) — 숨김 CSS 넣기, 팝업·클릭 가로채기·광고 영상 스크립트, 누른 곳 알리기
//  - 악성 사이트 경고 화면(data:): 돌아가기 / 계속 단추
const { contextBridge, ipcRenderer, webFrame } = require('electron');

if (location.protocol === 'file:' && /newtab\.html$/.test(location.pathname)) {
  contextBridge.exposeInMainWorld('evergreenNewTab', {
    go: (text) => ipcRenderer.send('nav:go', { input: String(text || '') }),
    shortcuts: () => ipcRenderer.invoke('newtab:shortcuts'),
    onShortcuts: (cb) => ipcRenderer.on('shortcuts', (_e, list) => cb(list)),
    menu: (index, x, y) => ipcRenderer.send('newtab:menu', { index: Number(index), x: Number(x), y: Number(y) }),
    add: () => ipcRenderer.send('newtab:add'),
    cards: () => ipcRenderer.invoke('newtab:cards'),
    onCards: (cb) => ipcRenderer.on('cards', (_e, c) => cb(c)),
    openCard: (which, rect) => ipcRenderer.send('newtab:card', { which: which === 'sec' ? 'sec' : 'ad', rect }),
  });
} else if (location.protocol === 'data:') {
  contextBridge.exposeInMainWorld('evergreenWarn', {
    back: (token) => ipcRenderer.send('sec:warn', { act: 'back', token: String(token) }),
    proceed: (token) => ipcRenderer.send('sec:warn', { act: 'proceed', token: String(token) }),
  });
} else if (/^https?:$/.test(location.protocol) && window === window.top) {
  installGuard();
}

function installGuard() {
  const name = '__ev' + Math.random().toString(36).slice(2, 10);
  let init = null;
  try { init = ipcRenderer.sendSync('sec:init', { name, host: location.hostname, href: location.href }); } catch (e) { return; }
  if (!init) return;
  const flags = { adblock: !!init.adblock, yt: !!init.yt, prune: !!init.prune };
  ipcRenderer.on('sec:flags', (_e, f) => { if (f) Object.assign(flags, f); });

  // 누른 곳 알리기: 클릭 가로채기 · 자동 다운로드 판단에 쓴다 (진짜 사용자 입력만)
  const tap = (e) => {
    if (!e.isTrusted) return;
    let a = null;
    try { a = e.target && e.target.closest ? e.target.closest('a[href]') : null; } catch (x) { /* 그림 요소 등 */ }
    ipcRenderer.send('sec:tap', { onLink: !!a, href: a ? a.href : '' });
  };
  window.addEventListener('pointerdown', tap, true);
  window.addEventListener('keydown', tap, true);

  // 페이지 스크립트에게 주는 다리 (안드로이드 EvMedia 와 같은 이름·같은 뜻)
  const bridge = {
    adblock: () => flags.adblock,
    adurl: (u) => flags.adblock && !!ipcRenderer.sendSync('sec:adurl', String(u)),
    adreq: (u) => flags.adblock && !!ipcRenderer.sendSync('sec:adreq', String(u)),
    advid: (u) => flags.adblock && !!ipcRenderer.sendSync('sec:advid', String(u)),
    adhid: () => { ipcRenderer.send('sec:adhid'); },
    aduser: () => '[]',
    ytAdBlock: () => flags.yt,
    ytAdPrune: () => flags.prune,
    ytSkipTap: (x, y) => { ipcRenderer.send('sec:yt-tap', { x: Number(x), y: Number(y) }); },
  };
  if (init.code) {
    contextBridge.exposeInMainWorld(name, bridge);
    try { webFrame.executeJavaScript(init.code).catch(() => {}); } catch (e) { /* 아직 준비 전 */ }
  }
  // 화면 광고 숨김은 사이트의 보안 정책(CSP)에 막히지 않는 사용자 스타일로 넣는다
  if (init.css) { try { webFrame.insertCSS(init.css); } catch (e) { document.addEventListener('DOMContentLoaded', () => { try { webFrame.insertCSS(init.css); } catch (x) { /* 포기 */ } }, { once: true }); } }
}
