'use strict';
// AI 대화 기록 저장 (userData/evergreen-ai-chats.json). 사진·파일 첨부는 저장하지 않고 이름만 남긴다. 최대 60개 대화 · 대화당 200줄.
const fs = require('fs');
const path = require('path');
const MAX_CHATS = 60, MAX_MSGS = 200;

class ChatStore {
  constructor(dir, file) {
    this.file = path.join(dir, file || 'evergreen-ai-chats.json'); this.chats = []; this._t = null;
    try { const j = JSON.parse(fs.readFileSync(this.file, 'utf8')); if (Array.isArray(j.chats)) this.chats = j.chats; } catch (e) { /* 처음 */ }
  }
  list() { return this.chats.slice().sort((a, b) => b.updated - a.updated).map((c) => ({ id: c.id, title: c.title, updated: c.updated, count: c.messages.length })); }
  get(id) { const c = this.chats.filter((x) => x.id === id)[0]; return c ? JSON.parse(JSON.stringify(c)) : null; }
  // chat: { id?, messages:[{role,text,...}] } → id
  save(chat, now) {
    const t = now == null ? Date.now() : now;
    const msgs = chat.messages.slice(-MAX_MSGS).map((m) => { const c = Object.assign({}, m); delete c.images; return c; });
    const first = msgs.filter((m) => m.role === 'user')[0];
    const title = String(chat.title || (first && (first.shown || first.text)) || '새 대화').replace(/\s+/g, ' ').trim().slice(0, 60) || '새 대화';
    let c = chat.id ? this.chats.filter((x) => x.id === chat.id)[0] : null;
    if (!c) { c = { id: chat.id || 'c' + t.toString(36) + Math.random().toString(36).slice(2, 6) }; this.chats.push(c); }
    c.title = chat.title ? title : (c.title && c.titleSet ? c.title : title); c.updated = t; c.messages = msgs; c.agent = !!chat.agent;
    if (this.chats.length > MAX_CHATS) { this.chats.sort((a, b) => b.updated - a.updated); this.chats.length = MAX_CHATS; }
    this._schedule();
    return c.id;
  }
  rename(id, title) { const c = this.chats.filter((x) => x.id === id)[0]; if (c) { c.title = String(title).trim().slice(0, 60) || c.title; c.titleSet = true; this._schedule(); } }
  remove(id) { this.chats = this.chats.filter((x) => x.id !== id); this._schedule(); }
  clear() { this.chats = []; this._schedule(); }
  _schedule() { if (this._t) return; this._t = setTimeout(() => { this._t = null; this.flush(); }, 600); }
  flush() {
    try { fs.mkdirSync(path.dirname(this.file), { recursive: true }); fs.writeFileSync(this.file + '.tmp', JSON.stringify({ chats: this.chats })); fs.renameSync(this.file + '.tmp', this.file); } catch (e) { /* 저장 실패는 조용히 */ }
  }
}
module.exports = { ChatStore };
