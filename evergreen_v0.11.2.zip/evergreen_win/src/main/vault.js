'use strict';
// API 키를 윈도우 보안 저장소(DPAPI, Electron safeStorage)로 암호화해 저장한다 (안드로이드 KeyVault 와 같은 역할).
// 보안 저장소를 쓸 수 없으면 앱 전용 저장소에 그대로 저장한다 ("p:" 표시).
function makeVault(safeStorage) {
  const can = () => { try { return !!safeStorage && safeStorage.isEncryptionAvailable(); } catch (e) { return false; } };
  return {
    encrypt(plain) {
      if (can()) { try { return 'e:' + safeStorage.encryptString(String(plain)).toString('base64'); } catch (e) { /* 아래로 */ } }
      return 'p:' + plain;
    },
    decrypt(stored) {
      if (typeof stored !== 'string') return null;
      if (stored.indexOf('p:') === 0) return stored.slice(2);
      if (stored.indexOf('e:') !== 0 || !can()) return null;
      try { return safeStorage.decryptString(Buffer.from(stored.slice(2), 'base64')); } catch (e) { return null; }
    },
  };
}
module.exports = { makeVault };
