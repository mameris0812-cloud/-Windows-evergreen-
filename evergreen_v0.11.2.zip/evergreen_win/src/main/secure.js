'use strict';
// 광고·보안 (3단계): 요청 차단 · 트래커 · 악성 사이트 · HTTPS 우선 · 클릭 가로채기 · 뒤로가기 함정 · 자동 다운로드 ·
// 유튜브 광고 · 서드파티 쿠키. 안드로이드 MainActivity 의 shouldInterceptRequest / shouldOverrideUrlLoading 과 같은 순서로 판정한다.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { ipcMain, webContents } = require('electron');
const { AdEngine, matchesSet, ALLOW, hostOfUrl, registrable } = require('../shared/adengine');
const { TrackerBlocker, ESSENTIAL } = require('../shared/trackers');
const { SecStats, K, KINDS, FIRST_SECURITY } = require('../shared/secstats');
const { T, fromResourceType, inferType } = require('../shared/netfilter');
const G = require('../shared/guard');
const { AdLists } = require('./adlists');

const GUARD_DIR = path.join(__dirname, '..', 'guard');
const read = (n) => fs.readFileSync(path.join(GUARD_DIR, n), 'utf8');

const DEFAULTS = {
  adBlock: true, ytAdBlock: true, ytAdPrune: true, strictTrackers: false, skipCaptcha: false,
  malwareWarning: true, blockAutoDownload: true, blockBackRedirect: true, notifyBackBlocked: true,
  httpsFirst: true, blockHijackNav: true,
};
const DOWNLOAD_TOUCH_MS = 15000;
const LEVELS = ['약하게', '보통', '최대'];
const KIND_LABELS = ['광고·추적 요청', '광고 팝업·페이지 이동', '트래커 (엄격 모드)', '클릭 가로채기 이동', '자동 다운로드', '뒤로가기 중 자동 이동', '악성 사이트', '보안 연결(HTTPS)로 올림'];
const KIND_COLORS = ['#7E57C2', '#EF5350', '#5C6BC0', '#FF9800', '#26A69A', '#42A5F5', '#D81B60', '#66BB6A'];

/** 유튜브 광고 차단이 켜져 있으면, 유튜브에서 광고 영상·광고 정보를 받는 구글 광고 서버 요청은 막지 않는다
 *  (막으면 유튜브가 한참 기다리다 포기하느라 광고 시작 때 로딩이 길어진다. 광고는 막는 대신 바로 넘긴다) */
function ytAdServerPass(pageHost, host) {
  if (!pageHost || !host) return false;
  const p = pageHost.toLowerCase();
  if (!(p === 'youtube.com' || p.endsWith('.youtube.com'))) return false;
  const h = host.toLowerCase();
  return ['doubleclick.net', '2mdn.net', 'googlesyndication.com', 'googleadservices.com'].some((d) => h === d || h.endsWith('.' + d));
}

class Security {
  /**
   * deps: { store, userData, tabOf(webContents) → tab, tabById(webContents.id) → tab, tabByTabId(id) → tab, toast(msg, action), hooks }
   * hooks: { closeTab(tab), openTab(tab, url), load(tab, url), warn(tab, html, url), leave(tab), dialog(kind, params), goBack(tab), reloadActive(), notify() }
   */
  constructor(deps) {
    this.d = deps;
    this.s = Object.assign({}, DEFAULTS, deps.store.get('sec') || {});
    this.eng = new AdEngine();
    this.tr = new TrackerBlocker();
    this.stats = new SecStats(deps.store.get('secstats'));
    this.malware = new Set();
    this.lists = new AdLists(deps.userData, this.eng, { malware: (set) => { this.malware = set; } });
    this.httpAllowed = new Set();
    this.hijackAllowed = new Set();
    this.malwareOk = new Set();
    this.warnTokens = new Map();
    this.fbTokens = new Map();
    this._saveT = null;
    this._notifyT = null;
    this.stats.onChange(() => { this._saveSoon(); this._notifySoon(); });
    this._code = new Map();
    this._registerIpc();
  }

  // ───────── 설정 ─────────
  get(k) { return this.s[k]; }
  settings() { return Object.assign({}, this.s); }
  set(key, value) {
    if (!(key in DEFAULTS)) return;
    const v = !!value;
    if (this.s[key] === v) return;
    this.s[key] = v;
    this.d.store.set('sec', this.s);
    this._pushFlags();
    // 페이지 안에서 도는 규칙·차단은 새로 불러와야 반영된다 (안드로이드도 현재 탭을 다시 불러온다)
    if (['adBlock', 'strictTrackers', 'skipCaptcha'].includes(key)) this.d.hooks.reloadActive();
    this.d.hooks.notify();
  }
  /** 보호 점수: 핵심 6개 + 엄격 트래커 + 캡차 건너뛰기 = 최대 8 (안드로이드 SecurityStatsUi.Toggles) */
  protection() {
    const s = this.s;
    const core = [s.adBlock, s.malwareWarning, s.httpsFirst, s.blockAutoDownload, s.blockBackRedirect, s.blockHijackNav];
    const score = core.filter(Boolean).length + [s.strictTrackers, s.skipCaptcha].filter(Boolean).length;
    const level = score === 8 ? 2 : core.filter(Boolean).length >= 5 ? 1 : 0;
    const off = [];
    if (!s.adBlock) off.push('광고 차단');
    if (!s.malwareWarning) off.push('악성 사이트 알림');
    if (!s.httpsFirst) off.push('HTTPS 우선 연결');
    if (!s.blockAutoDownload) off.push('자동 다운로드 차단');
    if (!s.blockBackRedirect) off.push('뒤로가기 중 자동 이동 차단');
    if (!s.blockHijackNav) off.push('클릭 가로채기 이동 차단');
    if (!s.strictTrackers) off.push('트래커 차단(엄격)');
    if (!s.skipCaptcha) off.push('캡차 건너뛰기(서드파티 쿠키 차단)');
    return { score, max: 8, level, levelName: LEVELS[level], off };
  }

  // ───────── 시작 · 목록 ─────────
  async start() {
    await this.lists.load();
    const age = Date.now() - this.lists.lastUpdated;
    // 목록이 없거나 3일이 지났으면 조용히 새로 받는다
    if (!this.lists.lastUpdated || age > 3 * 86400000) setTimeout(() => this.updateLists(false), 20000);
  }
  async updateLists(manual) {
    try {
      const n = await this.lists.update();
      if (manual) this.d.toast('차단 목록을 업데이트했어요 · 도메인 ' + n.toLocaleString('ko-KR') + '개');
    } catch (e) {
      if (manual) this.d.toast('차단 목록을 받지 못했어요 · 인터넷 연결을 확인해 주세요');
    }
    this.d.hooks.notify();
  }
  flush() { this.d.store.set('secstats', this.stats.serialize()); }
  _saveSoon() { if (this._saveT) return; this._saveT = setTimeout(() => { this._saveT = null; this.flush(); }, 5000); }
  _notifySoon() { if (this._notifyT) return; this._notifyT = setTimeout(() => { this._notifyT = null; this.d.hooks.notify(); }, 300); }

  // ───────── 세션에 붙이기 ─────────
  attachSession(ses) {
    ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*', 'ws://*/*', 'wss://*/*'] }, (d, cb) => {
      try { this._onRequest(d, cb); } catch (e) { cb({}); }
    });
    // 서드파티 쿠키 차단 ('캡차 건너뛰기'): 켜져 있으면 다른 사이트로 가는 요청의 쿠키를 빼고 받은 쿠키도 버린다
    ses.webRequest.onBeforeSendHeaders({ urls: ['http://*/*', 'https://*/*'] }, (d, cb) => {
      if (!this.s.skipCaptcha || d.resourceType === 'mainFrame') return cb({});
      const t = this.d.tabById(d.webContentsId);
      if (!t || !this._isThird(d.url, t.curHost)) return cb({});
      const h = Object.assign({}, d.requestHeaders);
      for (const k of Object.keys(h)) if (k.toLowerCase() === 'cookie') delete h[k];
      cb({ requestHeaders: h });
    });
    ses.webRequest.onHeadersReceived({ urls: ['http://*/*', 'https://*/*'] }, (d, cb) => {
      if (!this.s.skipCaptcha || d.resourceType === 'mainFrame') return cb({});
      const t = this.d.tabById(d.webContentsId);
      if (!t || !this._isThird(d.url, t.curHost)) return cb({});
      const h = Object.assign({}, d.responseHeaders);
      for (const k of Object.keys(h)) if (k.toLowerCase() === 'set-cookie') delete h[k];
      cb({ responseHeaders: h });
    });
  }
  _isThird(url, pageHost) {
    const h = hostOfUrl(url);
    return !!h && !!pageHost && registrable(h) !== registrable(String(pageHost).toLowerCase());
  }

  _onRequest(d, cb) {
    const t = this.d.tabById(d.webContentsId);
    if (!t) return cb({});
    let u;
    try { u = new URL(d.url); } catch (e) { return cb({}); }
    if (d.resourceType === 'mainFrame') return this._onMain(t, u, d, cb);
    const host = u.hostname;
    const pageHost = t.curHost || null;
    const type = fromResourceType(d.resourceType);
    const ytPass = this.s.ytAdBlock && ytAdServerPass(pageHost, host);
    // 이미 허용으로 판정된 호스트(영상 조각 등)는 바로 통과
    if (this.s.adBlock && !ytPass && !this.eng.quickAllow(host, pageHost) && this.eng.shouldBlock(host, pageHost, d.url, type)) {
      this.stats.add(K.AD, host); t.adBlocked = (t.adBlocked || 0) + 1;
      return cb({ cancel: true });
    }
    if (this.s.strictTrackers && !ytPass && this.tr.shouldBlock(host, pageHost)) {
      this.tr.blockedCount++; this.stats.add(K.TRACKER);
      return cb({ cancel: true });
    }
    cb({});
  }

  /** 주소창·링크로 새 문서를 열 때 (안드로이드 shouldInterceptRequest 의 isForMainFrame 부분 + HTTPS 우선) */
  _onMain(t, u, d, cb) {
    const host = u.hostname;
    if (!/^https?:$/.test(u.protocol)) return cb({});
    // 악성·피싱 사이트: 경고 화면을 대신 보여 준다
    if (this.s.malwareWarning && this.malware.size && !this.malwareOk.has(host) && matchesSet(host.toLowerCase(), this.malware)) {
      this.stats.add(K.MALWARE);
      t.secBlock = { kind: 'malware', url: d.url, host };
      return cb({ cancel: true });
    }
    // 스크립트가 띄운 팝업이 광고 서버로 가면 아무것도 안 보여주고 탭을 닫는다
    if (this.s.adBlock && t.scriptPopup && this.eng.isAdHost(host)) {
      this.stats.add(K.POPUP, host); t.adBlocked = (t.adBlocked || 0) + 1;
      t.secBlock = { kind: 'popup' };
      this.d.toast('광고 팝업을 차단했습니다');
      setImmediate(() => this.d.hooks.closeTab(t));
      return cb({ cancel: true });
    }
    // HTTPS 우선: http 링크는 https 로 올려서 연결한다
    if (this.s.httpsFirst && u.protocol === 'http:') {
      const prev = t.upgradedFrom;
      if (prev && hostOfUrl(prev) === host.toLowerCase()) {
        // https 로 올렸더니 서버가 스스로 http 로 되돌려 보낸 경우: 무한 반복을 막고 그대로 둔다
        this.httpAllowed.add(host.toLowerCase());
        t.upgradedFrom = null;
      } else {
        const up = G.upgradeUrl(d.url, this.httpAllowed);
        if (up) {
          t.upgradedFrom = d.url;
          this.stats.add(K.HTTPS);
          return cb({ redirectURL: up });
        }
      }
    }
    t.curHost = host;
    t.adBlocked = 0; // 새 페이지로 가면 '이 페이지' 차단 건수를 다시 센다
    cb({});
  }

  /** 불러오기가 막혔거나 실패했을 때: true 면 오류 화면을 띄우지 않는다 */
  handleFail(t, code, url) {
    const b = t.secBlock;
    if (b) {
      t.secBlock = null;
      if (b.kind === 'malware') {
        this.d.toast('⚠ 악성 사이트로 의심되어 접속을 막았습니다');
        this.d.hooks.warn(t, this._warnPage(t, b.url, b.host), b.url);
      }
      return true;
    }
    // https 로 올린 연결이 안 되면 http 로 계속할지 묻는다 (이름을 못 찾는 경우는 http 로 가도 소용없으니 제외)
    if (t.upgradedFrom && /^https:/i.test(url || '') && hostOfUrl(url) === hostOfUrl(t.upgradedFrom) && code !== -105 && code !== -3) {
      const httpUrl = t.upgradedFrom;
      const token = crypto.randomBytes(8).toString('hex');
      this.fbTokens.set(token, { tabId: t.id, url: httpUrl });
      this.d.hooks.dialog('httpfb', { host: hostOfUrl(httpUrl), url: httpUrl, token });
    }
    return false;
  }

  // ───────── 페이지 이동 검사 (클릭 가로채기 · 광고 이동 · 뒤로가기 함정) ─────────
  /** 탭 하나에 이동 감시를 붙인다 (will-navigate: 페이지 스크립트가 시작한 이동, will-redirect: 서버 리다이렉트) */
  wireTab(t) {
    const wc = t.view.webContents;
    const check = (isRedirect) => (e, urlArg) => {
      const url = (e && e.url) || urlArg;
      if (e && e.isMainFrame === false) return;
      let dest;
      try { dest = new URL(url); } catch (x) { return; }
      if (!/^https?:$/.test(dest.protocol)) return;
      const now = Date.now();
      const from = wc.getURL();
      // 사용자 동작 없는 광고 서버 이동은 막는다
      if (this.s.adBlock && !this._tapRecent(t, now, 2500) && this.eng.isAdHost(dest.hostname)) {
        this.stats.add(K.POPUP, dest.hostname); t.adBlocked = (t.adBlocked || 0) + 1;
        e.preventDefault();
        return;
      }
      // '클릭 가로채기' 차단: 링크가 아닌 곳을 눌렀는데 전혀 다른 사이트로 보내는 경우
      if (this.s.blockHijackNav) {
        const win = isRedirect ? G.TAP_WINDOW.redirect : G.TAP_WINDOW.normal;
        if (G.isHijackedNav({ dest, from, isRedirect, lastHopAt: t.lastHopAt, now, allowed: this.hijackAllowed, tap: this._tap(t, now, win) })) {
          e.preventDefault();
          this._hijackBlocked(t, dest.href, false);
          return;
        }
        t.lastHopAt = now;
      }
      // 뒤로가기 함정: 뒤로가기 직후 사용자 동작 없이 페이지가 스스로 다른 곳으로 보내려 하면 막는다
      if (G.isBackTrap({ enabled: this.s.blockBackRedirect, hasTapSince: t.tapMark !== t.backTouchMark, backAt: t.backAt, now, from, backTarget: t.backTarget, backLeft: t.backLeft, dest: dest.href })) {
        e.preventDefault();
        t.backAt = 0;
        this.stats.add(K.BACK);
        if (this.s.notifyBackBlocked) this.d.toast('뒤로가기 중 자동 이동을 차단했습니다');
        setImmediate(() => this.d.hooks.goBack(t));
      }
    };
    wc.on('will-navigate', check(false));
    wc.on('will-redirect', check(true));
  }

  /** 뒤로가기를 누르기 직전에 부른다: 뒤로가기 함정 판단용 기록 */
  noteBack(t) {
    const wc = t.view.webContents;
    t.backAt = Date.now();
    t.backTouchMark = t.tapMark || 0;
    t.backLeft = wc.getURL();
    try {
      const h = wc.navigationHistory;
      const i = h.getActiveIndex();
      t.backTarget = i > 0 ? h.getEntryAtIndex(i - 1).url : null;
    } catch (e) { t.backTarget = null; }
  }

  _tap(t, now, windowMs) {
    if (!t.tapAt || now - t.tapAt > windowMs) return { recent: false, onLink: false, href: '' };
    return { recent: true, onLink: !!t.tapOnLink, href: t.tapHref || '' };
  }
  _tapRecent(t, now, ms) { return !!t.tapAt && now - t.tapAt <= ms; }

  /** window.open / target=_blank 로 새 창을 열려 할 때. true 면 막는다 */
  checkPopup(t, url) {
    let dest;
    try { dest = new URL(url); } catch (e) { return false; }
    if (!/^https?:$/.test(dest.protocol)) return false;
    if (this.s.adBlock && this.eng.isAdHost(dest.hostname)) {
      this.stats.add(K.POPUP, dest.hostname); t.adBlocked = (t.adBlocked || 0) + 1;
      this.d.toast('광고 팝업을 차단했습니다');
      return true;
    }
    if (this.s.blockHijackNav) {
      const now = Date.now();
      if (G.isHijackedNav({ dest, from: t.view.webContents.getURL(), isRedirect: false, lastHopAt: 0, now, allowed: this.hijackAllowed, tap: this._tap(t, now, G.TAP_WINDOW.popup) })) {
        this._hijackBlocked(t, dest.href, true);
        return true;
      }
    }
    return false;
  }

  _hijackBlocked(t, url, popup) {
    this.stats.add(K.HIJACK);
    const host = hostOfUrl(url) || '';
    this.d.toast((popup ? '클릭 가로채기 팝업을 차단했습니다 · ' : '클릭 가로채기 이동을 차단했습니다 · ') + host, {
      label: '이동', fn: () => { this.hijackAllowed.add(G.siteKey(host)); if (popup) this.d.hooks.openTab(t, url); else this.d.hooks.load(t, url); },
    });
  }

  // ───────── 다운로드 ─────────
  /** 사용자가 누르지 않았는데 시작된 자동 다운로드를 막는다. true 면 받게 둔다 */
  allowDownload(wc, url) {
    if (!this.s.blockAutoDownload) return true;
    const t = wc && this.d.tabOf(wc);
    if (!t) return true;
    const now = Date.now();
    const last = Math.max(t.tapAt || 0, t.userDlAt || 0);
    if (now - last <= DOWNLOAD_TOUCH_MS) return true;
    this.stats.add(K.AUTO_DL);
    this.d.toast('자동 다운로드를 차단했습니다');
    return false;
  }

  // ───────── 경고 화면 · 안내 ─────────
  _warnPage(t, url, host) {
    const token = crypto.randomBytes(8).toString('hex');
    this.warnTokens.set(token, { tabId: t.id, url, host });
    const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    return '<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>악성 사이트 경고</title><style>' +
      ':root{color-scheme:light dark;--bg:#FCE8E6;--fg:#410E0B;--card:#fff;--line:#E7E9ED;--ac:#2FA35B;--dg:#C5221F}' +
      '@media(prefers-color-scheme:dark){:root{--bg:#2B1514;--fg:#F9DEDC;--card:#1A1C20;--line:#2E3238;--ac:#6FCF97;--dg:#F28B82}}' +
      'body{margin:0;min-height:100vh;display:grid;place-items:center;background:var(--bg);color:var(--fg);font-family:"Segoe UI Variable Text","Segoe UI","Malgun Gothic",sans-serif}' +
      '.c{width:min(520px,calc(100vw - 32px));background:var(--card);color:var(--fg);border-radius:28px;padding:32px 28px 24px;box-shadow:0 10px 28px rgba(0,0,0,.16)}' +
      '.i{width:56px;height:56px;border-radius:18px;background:var(--bg);color:var(--dg);display:grid;place-items:center;font-size:30px;font-weight:700}' +
      'h1{margin:18px 0 8px;font-size:24px}p{margin:0 0 6px;line-height:1.6;font-size:15px;opacity:.85}' +
      '.h{margin:14px 0 22px;padding:10px 14px;border-radius:14px;background:var(--bg);font-weight:600;word-break:break-all}' +
      '.b{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}button{height:44px;padding:0 20px;border:0;border-radius:22px;font:inherit;font-weight:700;cursor:pointer}' +
      '.p{background:var(--ac);color:#fff}.s{background:none;color:var(--dg)}</style></head><body><div class="c"><div class="i">!</div>' +
      '<h1>악성 사이트로 의심돼요</h1><p>이 사이트는 악성 코드를 퍼뜨리거나 개인정보를 빼내는 곳으로 알려진 목록에 있어요.</p><div class="h">' + esc(host) + '</div>' +
      '<div class="b"><button class="s" id="go">위험을 알고 계속</button><button class="p" id="back">돌아가기</button></div></div><script>' +
      'var T=' + JSON.stringify(token) + ';document.getElementById("back").onclick=function(){window.evergreenWarn&&evergreenWarn.back(T)};' +
      'document.getElementById("go").onclick=function(){window.evergreenWarn&&evergreenWarn.proceed(T)};</script></body></html>';
  }

  // ───────── 페이지 안으로 보내는 스크립트 ─────────
  _pageCode(name, wantAd, wantYt) {
    let ad = this._code.get('ad');
    if (!ad) { ad = read('cosmetic.js').replace('/*__VIDEO_BANNER__*/', read('videobanner.js')); this._code.set('ad', ad); }
    let yt = this._code.get('yt');
    if (!yt) { yt = read('ytad.js'); this._code.set('yt', yt); }
    return '(function(){var EvMedia=window[' + JSON.stringify(name) + '];if(!EvMedia)return;' + (wantAd ? ad : '') + '\n' + (wantYt ? yt : '') + '\n})();';
  }

  _pushFlags() {
    const f = { adblock: this.s.adBlock, yt: this.s.ytAdBlock, prune: this.s.ytAdPrune };
    for (const wc of webContents.getAllWebContents()) {
      const t = this.d.tabOf(wc);
      if (t && !wc.isDestroyed()) { try { wc.send('sec:flags', f); } catch (e) { /* 닫히는 중 */ } }
    }
  }

  _registerIpc() {
    const tabOf = (e) => this.d.tabOf(e.sender);
    // 페이지가 열릴 때 한 번: 설정 · 이 사이트 광고 숨김 CSS · 페이지 안에서 도는 스크립트
    ipcMain.on('sec:init', (e, m) => {
      const t = tabOf(e);
      if (!t || !m) { e.returnValue = null; return; }
      const host = String(m.host || '').toLowerCase();
      const isYt = host === 'youtube.com' || host.endsWith('.youtube.com');
      const wantAd = this.s.adBlock;
      const wantYt = isYt;
      e.returnValue = {
        adblock: this.s.adBlock, yt: this.s.ytAdBlock, prune: this.s.ytAdPrune,
        css: wantAd ? this.eng.topCss(host) : '',
        code: wantAd || wantYt ? this._pageCode(String(m.name), wantAd, wantYt) : '',
      };
    });
    ipcMain.on('sec:adurl', (e, url) => { e.returnValue = !!(tabOf(e) && this.s.adBlock && this.eng.isAdUrl(String(url))); });
    ipcMain.on('sec:adreq', (e, url) => {
      const t = tabOf(e);
      let r = false;
      if (t && this.s.adBlock) {
        const host = hostOfUrl(String(url));
        if (host && this.eng.shouldBlock(host, t.curHost, String(url), inferType(String(url), null, false))) {
          r = true; this.stats.add(K.AD, host); t.adBlocked = (t.adBlocked || 0) + 1;
        }
      }
      e.returnValue = r;
    });
    ipcMain.on('sec:advid', (e, url) => { const t = tabOf(e); e.returnValue = !!(t && this.s.adBlock && this.eng.isAdVideoUrl(String(url), t.curHost)); });
    ipcMain.on('sec:adhid', (e) => { const t = tabOf(e); if (t && this.s.adBlock) { this.stats.add(K.AD, t.curHost); t.adBlocked = (t.adBlocked || 0) + 1; } });
    ipcMain.on('sec:tap', (e, m) => {
      const t = tabOf(e); if (!t || !m) return;
      t.tapAt = Date.now(); t.tapOnLink = !!m.onLink; t.tapHref = String(m.href || '').slice(0, 2000); t.tapMark = (t.tapMark || 0) + 1;
    });
    // 유튜브 '건너뛰기' 버튼을 진짜 마우스 클릭으로 눌러 준다 (페이지 스크립트의 클릭은 무시될 때가 있다)
    ipcMain.on('sec:yt-tap', (e, m) => {
      const t = tabOf(e); if (!t || !m || !isFinite(m.x) || !isFinite(m.y)) return;
      const wc = t.view.webContents;
      if (!/(^|\.)youtube\.com$/.test(hostOfUrl(wc.getURL()) || '')) return;
      const z = wc.getZoomFactor() || 1;
      const x = Math.round(m.x * z), y = Math.round(m.y * z);
      try {
        wc.sendInputEvent({ type: 'mouseMove', x, y });
        wc.sendInputEvent({ type: 'mouseDown', x, y, button: 'left', clickCount: 1 });
        wc.sendInputEvent({ type: 'mouseUp', x, y, button: 'left', clickCount: 1 });
      } catch (x2) { /* 창이 닫히는 중 */ }
    });
    // 악성 사이트 경고 화면의 단추
    ipcMain.on('sec:warn', (e, m) => {
      const w = m && this.warnTokens.get(String(m.token));
      const t = w && this.d.tabById(e.sender.id);
      if (!w || !t || t.id !== w.tabId) return;
      if (m.act === 'proceed') { this.malwareOk.add(w.host); this.warnTokens.delete(m.token); this.d.hooks.load(t, w.url); }
      else if (m.act === 'back') { this.warnTokens.delete(m.token); this.d.hooks.leave(t); }
    });
  }

  /** 'http 로 계속' 대화상자의 선택 */
  httpContinue(token, yes) {
    const f = this.fbTokens.get(String(token));
    if (!f) return;
    this.fbTokens.delete(String(token));
    const t = this.d.tabByTabId(f.tabId);
    if (!t) return;
    t.upgradedFrom = null;
    if (yes) { const h = hostOfUrl(f.url); if (h) this.httpAllowed.add(h); this.d.hooks.load(t, f.url); }
  }

  // ───────── 화면에 보내는 값 ─────────
  /** 설정 목록 줄·메뉴에 보여 줄 한 줄 요약 */
  summary() {
    const p = this.protection();
    const today = this.stats.todayTotal();
    return '보호 수준 ' + p.levelName + ' · ' + (today === 0 ? '오늘 차단 없음' : '오늘 ' + today.toLocaleString('ko-KR') + '번 차단');
  }
  homeCards() {
    const week = this.stats.weekTotal(K.AD);
    const today = this.stats.todayTotal();
    return { adWeek: week, secToday: today };
  }
  adPayload(pageBlocked) {
    const st = this.stats.adSummary();
    return Object.assign(st, {
      enabled: this.s.adBlock, pageBlocked: pageBlocked == null ? null : pageBlocked,
      lists: { hosts: this.eng.hostRuleCount, rules: this.eng.pathRuleCount, css: this.eng.genericCssCount + this.eng.siteCssCount, updated: this.lists.lastUpdated, updating: this.lists.updating, malware: this.lists.malwareCount },
    });
  }
  secPayload() {
    const p = this.protection();
    const t = this.stats.dayKey();
    const days = Array.from({ length: 7 }, (_, i) => {
      const day = t - (6 - i);
      const parts = [];
      for (let k = FIRST_SECURITY; k < KINDS; k++) parts.push(this.stats.count(day, k));
      const date = new Date(Date.now() - (6 - i) * 86400000);
      return { total: parts.reduce((a, b) => a + b, 0), parts, dow: '일월화수목금토'[date.getDay()] };
    });
    const kinds = [];
    for (let k = FIRST_SECURITY; k < KINDS; k++) kinds.push({ k, label: KIND_LABELS[k], color: KIND_COLORS[k], today: this.stats.today(k), week: this.stats.weekTotal(k) });
    return { protection: p, days, today: days[6].total, kinds, firstSecurity: FIRST_SECURITY, settings: this.settings() };
  }

  /** 앱 명령 (overlay 에서 app:cmd 로 온다). 처리했으면 true */
  command(name, arg, activeTab) {
    switch (name) {
      case 'sec:set': if (arg) this.set(String(arg.key), arg.value); return true;
      case 'sec:update-lists': this.updateLists(true); return true;
      case 'sec:reset-ads': this.stats.resetAds(); return true;
      case 'sec:reset-sec': this.stats.resetSecurity(); return true;
      case 'sec:http-continue': if (arg) this.httpContinue(arg.token, !!arg.yes); return true;
      default: return false;
    }
  }
}

module.exports = { Security, DEFAULTS, ytAdServerPass };
