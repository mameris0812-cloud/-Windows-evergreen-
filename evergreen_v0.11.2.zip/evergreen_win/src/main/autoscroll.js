'use strict';
// 자동 스크롤 (안드로이드 AutoScroller 를 윈도우로 옮김). 웹툰·긴 글을 손 안 대고 볼 때 쓴다.
//  - 페이지 안의 운전자(shared/autoscroll.js DRIVER_JS)가 화면 프레임마다 부드럽게 내려간다. 여기(메인)는 속도 · 멈춤 · 끝 감지만 맡는다.
//  - 일반 모드: 설정의 속도 단계 / 스마트 모드: 화면을 작게 캡처해 빈 그림이면 빠르게, 내용이 있으면 천천히.
//  - 화면 아래에 조작 막대(−/+, 일시정지, 닫기)를 띄운다 (설정에서 끌 수 있음).
//  - 페이지를 만지면(휠 · 클릭 · 키) 설정에 따라 '만지는 동안만 멈춤' 또는 '완전히 멈춤'.
//  - 다른 탭 · 탭이 닫힘 · 새 페이지로 이동 · 전체화면에서는 저절로 멈춘다. 웹툰 마지막 컷에 닿으면 멈추거나 일시정지.
const A = require('../shared/autoscroll');
const T = A.TUNING;
const WORLD = 977; // 페이지 스크립트가 볼 수 없는 따로 떨어진 실행 공간

class AutoScroller {
  // d: { store, toast(msg), allowed(tab) → bool, pill: { show(s), update(s), hide() }, changed() }
  constructor(d) {
    this.d = d;
    this.tab = null; this.wc = null; this.running = false;
    this._timer = null; this._busy = false;
    this._reset();
  }

  get cfg() { return A.normalize(this.d.store.get('autoScroll')); }
  setCfg(patch) {
    this.d.store.set('autoScroll', A.normalize(Object.assign({}, this.cfg, patch)));
    if (this.running) this._pillUpdate();
    this.d.changed && this.d.changed();
  }
  isRunningOn(tab) { return this.running && !!tab && tab === this.tab; }
  snapshot() { return { cfg: this.cfg, running: this.running, tabId: this.tab ? this.tab.id : null, paused: this.running && this.userPaused }; }

  _reset() {
    this.userPaused = false; this.menuHold = false; this.resumeAt = 0; this.tn0 = 0; this.esc0 = 0;
    this.everMoved = false; this.bottomSince = 0; this.stuckSince = 0; this.lastY = null;
    this.endProbeBusy = false; this.endProbeAt = 0; this.endNextMs = T.END_PROBE_MS; this.endHits = 0; this.endHandled = false;
    this.endFadeStart = 0; this.endExtraPx = 0;
    this.smartLevel = 0; this.smartTargetLv = 0; this.smartBusy = false; this.smartLast = 0; this.smartFails = 0; this.smartOk = false;
    this.lastTick = 0; this.sentRun = null; this.sentSpeed = -1; this.pillAt = 0; this.driverMissing = 0;
  }

  _run(code) {
    const wc = this.wc;
    if (!wc || wc.isDestroyed()) return Promise.reject(new Error('gone'));
    return wc.executeJavaScriptInIsolatedWorld(WORLD, [{ code }]);
  }

  async start(tab) {
    if (!tab || !tab.view || tab.view.webContents.isDestroyed()) return false;
    if (this.running && this.tab === tab) return true;
    const url = tab.view.webContents.getURL();
    if (!/^https?:|^file:/i.test(url) || /newtab\.html/.test(url)) { this.d.toast('웹 페이지를 연 탭에서만 자동 스크롤을 쓸 수 있어요'); return false; }
    this.stop(null);
    this.tab = tab; this.wc = tab.view.webContents; this.running = true;
    this._reset();
    const c = this.cfg;
    this.smartLevel = c.contentLevel; this.smartTargetLv = c.contentLevel;
    try { await this._run(A.DRIVER_JS); } catch (e) { this.stop(null); this.d.toast('이 페이지에서는 자동 스크롤을 시작하지 못했어요'); return false; }
    if (!this.running || this.tab !== tab) return false;
    if (c.controls) this.d.pill.show(this._pillState());
    this.d.toast('자동 스크롤을 시작했어요');
    this.lastTick = Date.now();
    this._timer = setInterval(() => this._tick(), 60);
    this.d.changed && this.d.changed();
    return true;
  }
  toggle(tab) { if (this.isRunningOn(tab)) this.stop('자동 스크롤을 멈췄어요'); else this.start(tab); }

  stop(message) {
    const was = this.running;
    clearInterval(this._timer); this._timer = null;
    if (this.wc && !this.wc.isDestroyed()) this._run(A.STOP_JS).catch(() => {});
    this.running = false; this.tab = null; this.wc = null;
    this.d.pill.hide();
    if (was) { if (message) this.d.toast(message); this.d.changed && this.d.changed(); }
  }

  // 새 페이지로 넘어가기 시작할 때: 일시정지 중이면 막대를 두고 끝 상태만 처음으로(새 화에서 ▶ 로 이어 감), 흐르는 중이면 멈춘다
  onNavigate(tab) {
    if (!this.isRunningOn(tab)) return;
    if (this.userPaused && this.d.pill.shown()) {
      this.endHandled = false; this.endHits = 0; this.bottomSince = 0; this.stuckSince = 0; this.everMoved = false;
      this.endProbeBusy = false; this.endNextMs = T.END_PROBE_MS; this.endFadeStart = 0; this.endExtraPx = 0; this.lastY = null;
      this.driverMissing = 1; // 새 문서에는 운전자가 없으니 다시 심는다
    } else this.stop(null);
  }
  // 문서가 새로 만들어졌다(같은 탭 안 이동): 운전자를 다시 심는다
  onDomReady(tab) {
    if (!this.isRunningOn(tab) || !this.driverMissing) return;
    this._run(A.DRIVER_JS).then(() => { this.driverMissing = 0; this.sentRun = null; this.tn0 = 0; this.esc0 = 0; }).catch(() => {});
  }
  // 우클릭 메뉴가 떠 있는 동안 잠깐 멈추고, 닫히면 잠시 뒤 이어 흐른다
  holdForMenu(tab, hold) {
    if (!this.isRunningOn(tab)) return;
    if (hold) { if (this.endFadeStart) this.stop(null); else this.menuHold = true; }
    else if (this.menuHold) { this.menuHold = false; this.resumeAt = Date.now() + T.RESUME_DELAY_MS; }
  }

  // ───────── 조작 막대 ─────────
  command(act) {
    if (!this.running) return;
    if (act === 'close') return this.stop('자동 스크롤을 멈췄어요');
    if (act === 'pause') {
      this.userPaused = !this.userPaused; this.stuckSince = 0; this.bottomSince = 0; this.lastY = null;
      if (!this.userPaused) { this.endFadeStart = 0; this.resumeAt = Date.now() + 120; }
      return this._pillUpdate();
    }
    if (act === 'faster' || act === 'slower') this.changeLevel(act === 'faster' ? 1 : -1);
  }
  // 일반 모드는 속도 단계, 스마트 모드는 내용·빈 그림 단계를 함께 올리고 내린다
  changeLevel(delta) {
    const c = this.cfg;
    if (c.smart) this.setCfg({ contentLevel: c.contentLevel + delta, blankLevel: c.blankLevel + delta });
    else this.setCfg({ speed: c.speed + delta });
  }
  applyControlsSetting() {
    if (!this.running) return;
    if (this.cfg.controls) this.d.pill.show(this._pillState()); else this.d.pill.hide();
  }
  _pillState() {
    const c = this.cfg;
    return { level: c.smart ? Math.round(this.smartLevel || c.contentLevel) : c.speed, smart: c.smart, paused: this.userPaused, min: A.MIN_LEVEL, max: A.MAX_LEVEL };
  }
  _pillUpdate() { if (this.cfg.controls) this.d.pill.update(this._pillState()); }

  // ───────── 한 번의 점검 ─────────
  async _tick() {
    if (!this.running || this._busy) return;
    this._busy = true;
    const tab = this.tab;
    try {
      const now = Date.now();
      const dt = Math.min(0.2, Math.max(0, (now - this.lastTick) / 1000));
      this.lastTick = now;
      if (!tab || !this.wc || this.wc.isDestroyed() || !this.d.allowed(tab)) { this.stop(null); return; }
      let raw = '';
      try { raw = await this._run('window.__evAS&&window.__evAS.alive?window.__evAS.state():""'); } catch (e) { raw = ''; }
      if (!this.running || this.tab !== tab) return;
      if (!raw) {
        // 운전자가 없다: 문서가 바뀐 직후일 수 있으니 잠깐은 기다리고, 계속 없으면 다시 심는다
        if (++this.driverMissing > 3) { this.driverMissing = 1; this._run(A.DRIVER_JS).then(() => { this.sentRun = null; this.tn0 = 0; this.esc0 = 0; }).catch(() => {}); }
        return;
      }
      this.driverMissing = 0;
      const st = JSON.parse(raw), c = this.cfg;
      if (st.esc > (this.esc0 || 0)) { this.esc0 = st.esc; this.stop('자동 스크롤을 멈췄어요'); return; }
      // 만졌는지 (휠 · 클릭 · 키 · 스크롤바)
      if (st.tn > this.tn0) {
        this.tn0 = st.tn;
        if (this.endFadeStart || (c.touch === 1 && !this.userPaused)) { this.stop('자동 스크롤을 멈췄어요'); return; }
      }
      const touching = st.touching || st.hold > 0;
      if (this.endFadeStart && (touching || this.menuHold)) { this.stop(null); return; }
      const flowing = !this.userPaused && !touching && !this.menuHold && now >= this.resumeAt;

      if (flowing) {
        // 웹툰 끝 확인
        if (c.pauseAtEnd && !this.endFadeStart && now - this.endProbeAt >= this.endNextMs && !this.endProbeBusy) { this.endProbeAt = now; this._probeEnd(); }
        // 맨 아래에 닿은 채 오래 있으면 끈다 (페이지가 1px 씩 늘어나는 곳에서도)
        if (st.moved) this.everMoved = true;
        if (this.everMoved && st.remain <= 4) {
          if (!this.bottomSince) this.bottomSince = now;
          else if (now - this.bottomSince >= T.END_HOLD_MS) { this.stop('페이지 끝에 닿아 자동 스크롤을 껐어요'); return; }
        } else this.bottomSince = 0;
        // 움직이지 않는다
        const moved = this.lastY != null ? st.y - this.lastY : 0;
        if (this.lastY != null && Math.abs(moved) < 0.5) {
          if (!this.stuckSince) this.stuckSince = now;
          else if (now - this.stuckSince >= T.END_HOLD_MS + 500) {
            if (this.endExtraPx > 0) this._finishEnd();
            else { this.stop(this.everMoved ? '페이지 끝에 닿아 자동 스크롤을 껐어요' : '이 페이지는 자동으로 스크롤할 수 없어요'); return; }
          }
        } else this.stuckSince = 0;
        if (this.endExtraPx > 0 && moved > 0) { this.endExtraPx -= moved * (this.wc.getZoomFactor() || 1); if (this.endExtraPx <= 0) this._finishEnd(); }
      } else { this.stuckSince = 0; this.bottomSince = 0; }
      this.lastY = st.y;

      // 속도
      let level = c.smart ? this._smartStep(dt, now, st, c) : c.speed;
      let fade = 1;
      if (this.endFadeStart) {
        const ft = Math.min(1, (now - this.endFadeStart) / T.END_FADE_MS);
        if (ft >= 1) { this.stop(null); return; }
        fade = (1 - ft) * (1 - ft);
      }
      const zoom = this.wc.getZoomFactor() || 1;
      const speed = flowing && !this.userPaused ? A.dipPerSecond(level) * fade / zoom : 0;
      const run = speed > 0;
      if (run !== this.sentRun || Math.abs(speed - this.sentSpeed) >= 1) {
        this.sentRun = run; this.sentSpeed = speed;
        this._run('window.__evAS&&__evAS.set(' + run + ',' + speed.toFixed(1) + ')').catch(() => {});
      }
      if (c.smart && c.controls && now - this.pillAt > 400) { this.pillAt = now; this._pillUpdate(); }
    } catch (e) { /* 다음 점검에서 다시 */ } finally { this._busy = false; }
  }

  _probeEnd() {
    this.endProbeBusy = true;
    const tab = this.tab;
    this._run(A.END_PROBE_JS).then((raw) => {
      this.endProbeBusy = false;
      if (!this.running || this.tab !== tab || this.userPaused) return;
      const remain = parseInt(String(raw), 10);
      if (!isFinite(remain)) { this.endHits = 0; return; }
      this.endNextMs = !this.endHandled && remain >= -300 && remain <= 900 ? 200 : T.END_PROBE_MS;
      if (remain > T.END_REARM_PX) { this.endHandled = false; this.endExtraPx = 0; }
      if (remain <= T.END_NEAR_PX && !this.endHandled) {
        if (++this.endHits >= 2) { this.endHits = 0; this.endHandled = true; this.endExtraPx = T.END_EXTRA_PX; } // 조금 더 내려간 다음 멈춘다
      } else this.endHits = 0;
    }).catch(() => { this.endProbeBusy = false; });
  }
  _finishEnd() {
    this.endExtraPx = 0;
    if (this.d.pill.shown()) {
      this.userPaused = true; this.stuckSince = 0;
      this._pillUpdate();
      this.d.toast('웹툰 끝에 닿아 자동 스크롤을 일시정지했어요');
      this._run('window.__evAS&&__evAS.set(false,0)').catch(() => {}); this.sentRun = false; this.sentSpeed = 0;
    } else this.endFadeStart = Date.now();
  }

  // ───────── 스마트: 화면을 읽어 빈 그림이면 빠르게 ─────────
  _smartStep(dt, now, st, c) {
    const cLv = c.contentLevel, bLv = Math.max(c.blankLevel, c.contentLevel);
    if (now - this.smartLast >= T.SMART_SAMPLE_MS && !this.smartBusy) { this.smartLast = now; this._sample(st); }
    const target = this.smartOk ? Math.max(cLv, Math.min(bLv, this.smartTargetLv)) : cLv; // 화면을 못 읽으면 안전하게 내용 단계
    this.smartLevel = A.smartFollow(this.smartLevel || cLv, target, dt, cLv, bLv);
    return this.smartLevel;
  }
  _sample(st) {
    const wc = this.wc, tab = this.tab;
    if (!wc || wc.isDestroyed()) return;
    const w = Math.max(1, Math.round(st.w || 0)), h = Math.max(1, Math.round(st.h || 0));
    // 위·아래 가장자리를 뺀 가운데 띠
    const rect = { x: Math.round(w * 0.08), y: Math.round(h * 0.12), width: Math.max(1, Math.round(w * 0.84)), height: Math.max(1, Math.round(h * 0.7)) };
    if (rect.width < 80 || rect.height < 80) { this._smartFail(); return; }
    this.smartBusy = true;
    let p;
    try { p = wc.capturePage(rect, { stayHidden: true }); } catch (e) { this.smartBusy = false; this._smartFail(); return; }
    p.then((img) => {
      this.smartBusy = false;
      if (!this.running || this.tab !== tab || !img || img.isEmpty()) { this._smartFail(); return; }
      const small = img.resize({ width: 160, quality: 'good' });
      const sz = small.getSize();
      const frac = A.blankFraction(small.toBitmap(), sz.width, sz.height, true);
      this.smartFails = 0; this.smartOk = true;
      const c = this.cfg;
      this.smartTargetLv = A.smartTarget(frac, c.contentLevel, Math.max(c.blankLevel, c.contentLevel));
    }).catch(() => { this.smartBusy = false; this._smartFail(); });
  }
  _smartFail() { if (++this.smartFails >= 10) this.smartOk = false; }
}
module.exports = { AutoScroller };
