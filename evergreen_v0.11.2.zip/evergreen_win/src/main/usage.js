'use strict';
// AI 사용량 기록 (안드로이드 GeminiUsage 와 같은 규칙): (키 · 모델 · 날짜)별로 호출 수 · 토큰 · 한도 도달 · 실패를 센다.
//  - 하루의 기준은 구글 무료 한도가 초기화되는 태평양 시간 자정이다 → 「오늘 쓴 양」이 「하루 한도」와 같은 날을 가리킨다.
//  - 키는 저장하지 않고 SHA-256 앞 8자리(되돌릴 수 없는 이름표)만 쓴다. 14일치만 남긴다.
//  - 저장 모양은 글 한 줄(`날짜|키표|모델|호출|한도|실패|입력토큰|출력토큰`).
const crypto = require('crypto');

const KEEP_DAYS = 14;
const FMT = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Los_Angeles', year: 'numeric', month: '2-digit', day: '2-digit' });
const dayKey = (ms) => FMT.format(new Date(ms)).replace(/-/g, '');
// 다음 한도 초기화(태평양 자정) 시각. 서머타임 전환일(23·25시간)도 맞게 이분 탐색으로 구한다
function resetAt(ms) {
  const k = dayKey(ms);
  let lo = ms, hi = ms + 26 * 3600000;
  while (hi - lo > 1000) { const mid = Math.floor((lo + hi) / 2); if (dayKey(mid) === k) lo = mid; else hi = mid; }
  return hi;
}
const keyId = (key) => crypto.createHash('sha256').update(String(key), 'utf8').digest('hex').slice(0, 8);
const newTally = () => ({ calls: 0, limit: 0, errors: 0, tokIn: 0, tokOut: 0 });
const addTally = (a, b) => { a.calls += b.calls; a.limit += b.limit; a.errors += b.errors; a.tokIn += b.tokIn; a.tokOut += b.tokOut; return a; };
const tokens = (t) => t.tokIn + t.tokOut;
// 1,234 → "1,234" · 12,345 → "1.2만" · 1,234,567 → "123만" · 123,456,789 → "1.2억"
function formatTokens(n) {
  const trim = (v) => { const s = v.toFixed(1); return s.endsWith('.0') ? s.slice(0, -2) : s; };
  if (n < 10000) return n.toLocaleString('en-US');
  if (n < 1000000) return trim(n / 10000) + '만';
  if (n < 100000000) return Math.floor(n / 10000).toLocaleString('en-US') + '만';
  return trim(n / 100000000) + '억';
}
function formatDuration(ms) {
  const min = Math.floor(ms / 60000);
  if (min < 1) return '1분 미만';
  if (min < 60) return min + '분';
  return min % 60 === 0 ? min / 60 + '시간' : Math.floor(min / 60) + '시간 ' + (min % 60) + '분';
}

class Usage {
  constructor(store, storeKey, now) {
    this.store = store || null; this.storeKey = storeKey || 'aiUsage'; this.now = now || Date.now;
    this.rows = new Map();
    if (store) this.load(store.get(this.storeKey) || '');
    this.prune(this.now());
  }
  load(text) {
    this.rows.clear();
    String(text || '').split('\n').forEach((line) => {
      const f = line.split('|');
      if (f.length !== 8) return;
      const n = f.slice(3).map((x) => (/^\d+$/.test(x) ? parseInt(x, 10) : -1));
      if (n.some((x) => x < 0)) return; // 깨진 줄은 건너뛴다
      this.rows.set(f[0] + '|' + f[1] + '|' + f[2], { calls: n[0], limit: n[1], errors: n[2], tokIn: n[3], tokOut: n[4] });
    });
  }
  dump() { return Array.from(this.rows.entries()).map(([k, t]) => k + '|' + t.calls + '|' + t.limit + '|' + t.errors + '|' + t.tokIn + '|' + t.tokOut).join('\n'); }
  _save() { if (this.store) this.store.set(this.storeKey, this.dump()); }
  // 요청 하나의 결과를 센다. code 가 2xx 면 호출 + 토큰, 한도(429 중 quota)면 한도 도달, 나머지(0 = 네트워크 오류 포함)는 실패
  record(key, model, code, quota, inTok, outTok, nowMs) {
    if (!key) return;
    const t0 = nowMs == null ? this.now() : nowMs;
    const id = dayKey(t0) + '|' + keyId(key) + '|' + model;
    const isNew = !this.rows.has(id);
    if (isNew) this.rows.set(id, newTally());
    const t = this.rows.get(id);
    if (code >= 200 && code <= 299) { t.calls++; t.tokIn += Math.max(0, inTok | 0); t.tokOut += Math.max(0, outTok | 0); }
    else if (code === 429 && quota) t.limit++;
    else t.errors++;
    if (isNew) this.prune(t0);
    this._save();
  }
  prune(nowMs) {
    const oldest = dayKey(nowMs - KEEP_DAYS * 86400000);
    for (const k of Array.from(this.rows.keys())) if (k.split('|')[0] < oldest) this.rows.delete(k);
  }
  clear() { this.rows.clear(); this._save(); }
  day(d) { const sum = newTally(); this.rows.forEach((t, k) => { if (k.indexOf(d + '|') === 0) addTally(sum, t); }); return sum; }
  today(nowMs) { return this.day(dayKey(nowMs == null ? this.now() : nowMs)); }
  todayForKey(key, nowMs) {
    const prefix = dayKey(nowMs == null ? this.now() : nowMs) + '|' + keyId(key) + '|', sum = newTally();
    this.rows.forEach((t, k) => { if (k.indexOf(prefix) === 0) addTally(sum, t); });
    return sum;
  }
  // 오늘 모델별 합계 (호출이 많은 순)
  todayByModel(nowMs) {
    const prefix = dayKey(nowMs == null ? this.now() : nowMs) + '|', by = new Map();
    this.rows.forEach((t, k) => { if (k.indexOf(prefix) === 0) { const m = k.slice(k.lastIndexOf('|') + 1); if (!by.has(m)) by.set(m, newTally()); addTally(by.get(m), t); } });
    return Array.from(by.entries()).map(([model, t]) => ({ model, tally: t })).sort((a, b) => b.tally.calls - a.tally.calls || tokens(b.tally) - tokens(a.tally));
  }
  // 오늘까지 n일의 날짜별 합계 (오래된 날 → 오늘, 기록이 없는 날도 빈 합계)
  recentDays(n, nowMs) {
    const base = nowMs == null ? this.now() : nowMs, out = [], seen = new Set();
    for (let i = n - 1; i >= 0; i--) { const d = dayKey(base - i * 86400000); if (seen.has(d)) continue; seen.add(d); out.push({ day: d, tally: this.day(d) }); }
    return out;
  }
  hasAnyRecord() { return Array.from(this.rows.values()).some((t) => t.calls || t.limit || t.errors); }
  // 설정 화면에 보낼 모양
  summary(keys, nowMs) {
    const t0 = nowMs == null ? this.now() : nowMs;
    return {
      today: this.today(t0), byModel: this.todayByModel(t0), days: this.recentDays(7, t0),
      perKey: (keys || []).map((k) => this.todayForKey(k, t0)), resetIn: resetAt(t0) - t0, any: this.hasAnyRecord(),
    };
  }
}
module.exports = { Usage, dayKey, resetAt, keyId, formatTokens, formatDuration, tokens, KEEP_DAYS };
