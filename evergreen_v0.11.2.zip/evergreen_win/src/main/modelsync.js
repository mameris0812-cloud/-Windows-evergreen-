'use strict';
// AI 모델이 종료되거나 새 버전으로 바뀌어도 앱을 고치지 않고 이어 쓰게 한다 (안드로이드 ModelSync).
// 구글의 모델 목록(models.list)을 받아서, 칸마다(Flash-Lite · Hydrogen) 쓰는 모델이 목록에서 사라졌거나 종료 예정이면 같은 계열의 새 모델로 바꾼다.
//  - 앱을 켤 때 저장해 둔 결과를 바로 쓰고, 12시간이 지났으면 백그라운드에서 새로 받는다 (refreshIfStale)
//  - 요청이 모델 없음(404)으로 실패하면 그 자리에서 새로 받아 바뀐 모델로 다시 보낸다 (refreshNow)
//  - 목록을 못 받거나 이상하면(Flash 계열이 하나도 없는 등) 아무것도 바꾸지 않는다
const G = require('../shared/gemini');
const STALE_MS = 12 * 3600000, RETRY_GAP_MS = 10 * 60000, JUST_FETCHED_MS = 20000;

class ModelSync {
  constructor(o) {
    this.g = o.g; this.store = o.store; this.fetch = o.fetch || ((...a) => globalThis.fetch(...a)); this.base = o.base || 'https://generativelanguage.googleapis.com/v1beta';
    this.now = o.now || Date.now; this.key = o.storeKey || 'aiModelSync';
    this.lastFetch = 0; this.lastTry = 0; this.inflight = null;
  }
  // 앱을 켤 때 한 번: 저장해 둔 교체 결과를 적용한다 (앱이 업데이트되어 기본 모델이 바뀌었으면 버린다)
  init() {
    const s = this.store && this.store.get(this.key);
    if (!s) return;
    this.lastFetch = s.at || 0;
    if (s.base === this.g.models.baseKey() && s.map) this.g.models.apply(s.map);
  }
  refreshIfStale(key) {
    if (!key) return;
    const t = this.now();
    if (t - this.lastFetch < STALE_MS || t - this.lastTry < RETRY_GAP_MS) return;
    this.lastTry = t;
    this.refreshNow(key).catch(() => {});
  }
  // 새로 받았거나 방금 받았으면 true, 못 받았으면 false
  async refreshNow(key) {
    if (!key) return false;
    const t = this.now();
    if (t - this.lastFetch < JUST_FETCHED_MS) return true;
    if (this.inflight) return this.inflight;
    this.lastTry = t;
    this.inflight = (async () => {
      const avail = await this._fetchList(key);
      if (!avail) return false;
      this.lastFetch = this.now();
      const next = this.g.models.resolveAll(avail);
      if (next) this.g.models.apply(next);
      if (this.store) this.store.set(this.key, { base: this.g.models.baseKey(), map: this.g.models.currentMap(), at: this.lastFetch });
      return true;
    })().finally(() => { this.inflight = null; });
    return this.inflight;
  }
  // id → 종료 예정 여부 (generateContent 를 쓸 수 있는 모델만). 못 받으면 null
  async _fetchList(key) {
    const out = {}; let token = '';
    try {
      for (let page = 0; page < 5; page++) {
        const u = this.base + '/models?pageSize=1000' + (token ? '&pageToken=' + encodeURIComponent(token) : '');
        const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 10000);
        let j;
        try {
          const res = await this.fetch(u, { headers: { 'x-goog-api-key': key }, signal: ctl.signal });
          if (!res.ok) return null;
          j = await res.json();
        } finally { clearTimeout(to); }
        (j.models || []).forEach((m) => {
          const id = String(m.name || '').replace(/^models\//, '');
          if (!id) return;
          const methods = m.supportedGenerationMethods;
          if (methods && methods.indexOf('generateContent') < 0) return;
          out[id] = G.isEnding(m.modelStatus, this.now());
        });
        token = j.nextPageToken || '';
        if (!token) break;
      }
    } catch (e) { return null; }
    return Object.keys(out).length ? out : null;
  }
}
module.exports = { ModelSync };
