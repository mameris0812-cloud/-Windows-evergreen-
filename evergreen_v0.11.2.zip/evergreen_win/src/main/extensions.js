'use strict';
// 5단계: 확장 프로그램. 크롬 확장 기능 자체는 Electron(크로미엄) 이 맡고, 이 모듈은 설치(웹스토어 · crx · zip) · 켜기/끄기 · 삭제 · 팝업 · 테마를 관리한다.
//  - 설치된 것은 userData/extensions/<id>/ 에 풀어 두고, 켜져 있는 것을 앱을 켤 때마다 일반 탭 세션에 불러온다(시크릿 탭에는 불러오지 않는다).
//  - 크롬 테마(manifest.theme)는 불러오지 않고 색만 뽑아 앱 색 변수로 쓴다.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebContentsView, ipcMain, dialog } = require('electron');
const { readZip } = require('../shared/zip');
const { parseCrx, idFromKey } = require('../shared/crx');
const C = require('../shared/extcompat');
const { themeVars } = require('../shared/theme');

const MAX_ZIP = 160 * 1024 * 1024;
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' + C.STORE_CHROME_VERSION + ' Safari/537.36';
const ID_OK = /^[a-z0-9-]{1,40}$/;
const POPUP_MAX = { w: 800, h: 600 };

class ExtManager {
  // h: { userData, ses(), toast(msg), openTab(url), win(), store, chromeH(), changed(), raise() }
  constructor(h) {
    this.h = h;
    this.root = path.join(h.userData, 'extensions');
    this.indexFile = path.join(this.root, 'index.json');
    this.eids = new Map();            // 폴더 id → Electron 이 붙인 실제 확장 프로그램 id (불러온 것만)
    this.errors = new Map();          // 폴더 id → 불러오기 실패 이유
    this.popup = null;
    this.index = {};
    try { this.index = JSON.parse(fs.readFileSync(this.indexFile, 'utf8')) || {}; } catch (e) { this.index = {}; }
  }
  _api() { const s = this.h.ses(); return s.extensions || s; }   // electron 35+ 는 session.extensions, 그 전은 session 자체
  _save() { try { fs.mkdirSync(this.root, { recursive: true }); fs.writeFileSync(this.indexFile, JSON.stringify(this.index)); } catch (e) { /* 다음에 다시 */ } }
  _dir(id) { return path.join(this.root, id); }
  _manifest(id) { try { return JSON.parse(fs.readFileSync(path.join(this._dir(id), 'manifest.json'), 'utf8').replace(/^\uFEFF/, '')); } catch (e) { return null; } }

  async init() {
    for (const id of Object.keys(this.index)) {
      if (!ID_OK.test(id) || !fs.existsSync(this._dir(id))) { delete this.index[id]; continue; }
      const m = this._manifest(id);
      if (m && !m.theme && this.index[id].enabled !== false) await this._load(id);
    }
    this._save();
  }
  async _load(id) {
    try {
      const ext = await this._api().loadExtension(this._dir(id), { allowFileAccess: false });
      this.eids.set(id, ext.id); this.errors.delete(id);
    } catch (e) { this.errors.set(id, String((e && e.message) || e).slice(0, 160)); }
  }
  async _unload(id) {
    const eid = this.eids.get(id);
    this.eids.delete(id);
    if (eid) { try { await this._api().removeExtension(eid); } catch (e) { /* 이미 없음 */ } }
  }

  _localized(id, m) {
    let msgs = null;
    try {
      const loc = m.default_locale || 'en';
      for (const l of [loc, 'ko', 'en']) { const f = path.join(this._dir(id), '_locales', l, 'messages.json'); if (fs.existsSync(f)) { const o = JSON.parse(fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, '')); msgs = {}; for (const k of Object.keys(o)) msgs[k.toLowerCase()] = o[k]; break; } }
    } catch (e) { msgs = null; }
    return (s) => C.localize(s, msgs);
  }
  _icon(id, m) {
    try {
      const a = m.action || m.browser_action || m.page_action || {};
      const di = a.default_icon;
      let rel = typeof di === 'string' ? di : (C.bestIcon(di) || C.bestIcon(m.icons));
      if (!rel) return '';
      const f = path.resolve(this._dir(id), rel);
      if (!f.startsWith(this._dir(id) + path.sep) || fs.statSync(f).size > 400 * 1024) return '';
      const ext = path.extname(f).toLowerCase();
      const mime = ext === '.svg' ? 'image/svg+xml' : ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg' : 'image/png';
      return 'data:' + mime + ';base64,' + fs.readFileSync(f).toString('base64');
    } catch (e) { return ''; }
  }
  _info(id) {
    const m = this._manifest(id); if (!m) return null;
    const L = this._localized(id, m), e = this.index[id] || {}, a = m.action || m.browser_action || m.page_action || {};
    const theme = !!m.theme;
    return {
      id, eid: this.eids.get(id) || '', name: L(m.name) || id, version: String(m.version || ''), description: L(m.description || '').slice(0, 300), theme,
      enabled: theme ? this.h.store.get('extTheme') === id : e.enabled !== false, icon: this._icon(id, m), mv: m.manifest_version,
      popup: !!a.default_popup, options: !!((m.options_ui && m.options_ui.page) || m.options_page), warning: C.manifestWarning(m), error: this.errors.get(id) || '',
      source: e.storeId ? '웹스토어' : '파일', perms: (Array.isArray(m.permissions) ? m.permissions : []).filter((p) => typeof p === 'string').slice(0, 12), active: theme && this.h.store.get('extTheme') === id,
    };
  }
  list() { return Object.keys(this.index).map((id) => this._info(id)).filter(Boolean).sort((a, b) => a.name.localeCompare(b.name, 'ko')); }

  // ── 설치 ──
  async installBuffer(buf, meta = {}) {
    if (buf.length > MAX_ZIP) throw new Error('파일이 너무 커요 (160MB 이하만 가능)');
    const c = parseCrx(buf);
    const entries = readZip(c.zip);
    const me = entries.find((e) => e.name === 'manifest.json');
    if (!me) throw new Error('확장 프로그램이 아니에요 (manifest.json 이 없어요)');
    let m;
    try { m = JSON.parse(me.data().toString('utf8').replace(/^\uFEFF/, '')); } catch (e) { throw new Error('manifest.json 을 읽지 못했어요'); }
    const bad = C.manifestIncompat(m);
    if (bad) throw new Error(bad);
    // 폴더 id: 크롬과 같은 id (key 에서) → 웹스토어 id 와 같아진다. 키가 없으면 이름으로 만든 id
    let id;
    if (typeof m.key === 'string' && m.key) { try { id = idFromKey(Buffer.from(m.key, 'base64')); } catch (e) { id = null; } }
    if (!id && c.id) { id = c.id; m.key = c.key || m.key; }
    if (!id) id = 'local-' + crypto.createHash('sha1').update(String(m.name || 'ext')).digest('hex').slice(0, 12);
    if (!ID_OK.test(id)) throw new Error('확장 프로그램 id 가 올바르지 않아요');
    const tmp = path.join(this.root, '.tmp-' + crypto.randomBytes(4).toString('hex'));
    try {
      for (const e of entries) {
        if (e.dir) continue;
        const f = path.join(tmp, e.name);
        fs.mkdirSync(path.dirname(f), { recursive: true });
        fs.writeFileSync(f, e.name === 'manifest.json' ? JSON.stringify(m) : e.data());
      }
      await this._unload(id);
      fs.rmSync(this._dir(id), { recursive: true, force: true });
      fs.renameSync(tmp, this._dir(id));
    } catch (e) { fs.rmSync(tmp, { recursive: true, force: true }); throw e; }
    const prev = this.index[id] || {};
    this.index[id] = { enabled: prev.enabled !== false, storeId: meta.storeId || prev.storeId || '', installedAt: Date.now() };
    if (!m.theme && this.index[id].enabled) await this._load(id);
    this._save(); this.h.changed();
    const info = this._info(id);
    if (info.error) throw new Error('불러오지 못했어요: ' + info.error);
    return info;
  }
  async installFile() {
    const r = await dialog.showOpenDialog(this.h.win(), { title: '확장 프로그램 설치 (.crx · .zip)', properties: ['openFile'], filters: [{ name: '확장 프로그램', extensions: ['crx', 'zip'] }] });
    if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
    return this._wrap(() => this.installBuffer(fs.readFileSync(r.filePaths[0])));
  }
  async installStore(input) {
    const id = C.parseStoreId(input);
    if (!id) return { ok: false, error: '웹스토어 주소나 확장 프로그램 ID(영문 32자)를 확인해 주세요' };
    return this._wrap(async () => {
      let r;
      try { r = await fetch(C.storeCrxUrl(id), { headers: { 'User-Agent': UA }, redirect: 'follow', signal: AbortSignal.timeout(60000) }); } catch (e) { throw new Error('웹스토어에 연결하지 못했어요. 인터넷 연결을 확인해 주세요'); }
      if (r.status === 204 || r.status === 404) throw new Error('웹스토어에서 이 확장 프로그램을 찾지 못했어요 (없어졌거나 내려받을 수 없는 항목)');
      if (!r.ok) throw new Error('웹스토어 서버 응답 오류 (' + r.status + ')');
      if (Number(r.headers.get('content-length') || 0) > MAX_ZIP) throw new Error('파일이 너무 커요 (160MB 이하만 가능)');
      return this.installBuffer(Buffer.from(await r.arrayBuffer()), { storeId: id });
    });
  }
  async _wrap(fn) { try { return { ok: true, ext: await fn() }; } catch (e) { return { ok: false, error: String((e && e.message) || e) }; } }

  // ── 켜기/끄기 · 삭제 · 테마 ──
  async setEnabled(id, on) {
    if (!this.index[id]) return;
    const m = this._manifest(id); if (!m || m.theme) return;
    this.index[id].enabled = !!on;
    if (on) await this._load(id); else await this._unload(id);
    this._save(); this.h.changed();
  }
  async remove(id) {
    if (!this.index[id]) return;
    if (this.popup && this.popup.id === id) this.closePopup();
    await this._unload(id);
    fs.rmSync(this._dir(id), { recursive: true, force: true });
    delete this.index[id];
    if (this.h.store.get('extTheme') === id) this.h.store.set('extTheme', null);
    this._save(); this.h.changed();
  }
  setTheme(id) {
    if (id) { const m = this._manifest(id); if (!m || !m.theme) return { ok: false, error: '테마가 아니에요' }; if (!themeVars(m)) return { ok: false, error: '이 테마는 색 정보가 없어 적용할 수 없어요 (이미지로만 된 테마)' }; }
    this.h.store.set('extTheme', id || null); this.h.changed();
    return { ok: true };
  }
  activeTheme() { const id = this.h.store.get('extTheme'); const m = id && this._manifest(id); return m ? themeVars(m) : null; }

  // ── 팝업 · 설정 페이지 ──
  _page(id, kind) {
    const m = this._manifest(id), eid = this.eids.get(id); if (!m || !eid) return null;
    let rel = null;
    if (kind === 'popup') rel = (m.action || m.browser_action || m.page_action || {}).default_popup;
    else rel = (m.options_ui && m.options_ui.page) || m.options_page;
    if (!rel || typeof rel !== 'string') return null;
    return 'chrome-extension://' + eid + '/' + rel.replace(/^\/+/, '');
  }
  openOptions(id) { const u = this._page(id, 'options'); if (!u) { this.h.toast('이 확장 프로그램에는 설정 페이지가 없어요'); return false; } this.h.openTab(u); return true; }
  openPopup(id) {
    const u = this._page(id, 'popup');
    if (!u) { if (this._page(id, 'options')) return this.openOptions(id); this.h.toast('이 확장 프로그램은 눌러서 여는 화면이 없어요'); return false; }
    this.closePopup();
    const win = this.h.win(), ses = this.h.ses();
    const view = new WebContentsView({ webPreferences: { session: ses, contextIsolation: true, sandbox: true } });
    try { if (view.setBorderRadius) view.setBorderRadius(12); } catch (e) { /* 구버전 */ }
    this.popup = { id, view };
    const place = (w, h) => {
      const [cw] = win.getContentSize();
      w = Math.max(220, Math.min(POPUP_MAX.w, Math.ceil(w))); h = Math.max(100, Math.min(POPUP_MAX.h, Math.ceil(h)));
      view.setBounds({ x: Math.max(8, cw - w - 12), y: this.h.chromeH() + 4, width: w, height: h });
    };
    place(360, 420);
    win.contentView.addChildView(view);
    this.h.raise();
    const wc = view.webContents;
    wc.setWindowOpenHandler(({ url }) => { this.h.openTab(url); this.closePopup(); return { action: 'deny' }; });
    wc.on('before-input-event', (e, i) => { if (i.type === 'keyDown' && i.key === 'Escape') this.closePopup(); });
    wc.on('blur', () => setTimeout(() => { if (this.popup && this.popup.view === view) this.closePopup(); }, 120));
    wc.on('did-finish-load', () => {
      wc.executeJavaScript('(function(){var b=document.body,d=document.documentElement;return [Math.max(b.scrollWidth,d.scrollWidth),Math.max(b.scrollHeight,d.scrollHeight)]})()').then((s) => { if (this.popup && this.popup.view === view) place(s[0], s[1]); }).catch(() => {});
      wc.focus();
    });
    wc.loadURL(u).catch(() => { this.h.toast('확장 프로그램 화면을 열지 못했어요'); this.closePopup(); });
    return true;
  }
  closePopup() {
    const p = this.popup; this.popup = null;
    if (!p) return;
    const win = this.h.win();
    try { if (win && !win.isDestroyed()) win.contentView.removeChildView(p.view); } catch (e) { /* */ }
    try { if (!p.view.webContents.isDestroyed()) p.view.webContents.close(); } catch (e) { /* */ }
  }
  front() { const p = this.popup, w = this.h.win(); if (p && w && !w.isDestroyed()) { try { w.contentView.addChildView(p.view); } catch (e) { /* */ } } }

  register(fromUi) {
    const ok = (v) => typeof v === 'string' && ID_OK.test(v) && !!this.index[v];
    ipcMain.handle('ext:list', (e) => (fromUi(e) ? this.list() : []));
    ipcMain.handle('ext:store', (e, input) => (fromUi(e) ? this.installStore(String(input || '')) : null));
    ipcMain.handle('ext:file', (e) => (fromUi(e) ? this.installFile() : null));
    ipcMain.handle('ext:toggle', async (e, m) => { if (fromUi(e) && m && ok(m.id)) await this.setEnabled(m.id, !!m.on); return this.list(); });
    ipcMain.handle('ext:remove', async (e, id) => { if (fromUi(e) && ok(id)) await this.remove(id); return this.list(); });
    ipcMain.handle('ext:popup', (e, id) => (fromUi(e) && ok(id) ? this.openPopup(id) : false));
    ipcMain.handle('ext:options', (e, id) => (fromUi(e) && ok(id) ? this.openOptions(id) : false));
    ipcMain.handle('ext:theme', (e, id) => (fromUi(e) && (id === null || ok(id)) ? this.setTheme(id) : null));
  }
}
module.exports = { ExtManager };
