'use strict';
const fs = require('fs');
const path = require('path');
const { app, shell } = require('electron');

const { safeName, uniquePath } = require('./fsutil');

class Downloads {
  // hooks: { changed(), toast(msg, action) }
  constructor(data, hooks) {
    this.data = data;
    this.hooks = hooks;
    this.seq = 0;
    this.active = new Map(); // id → 기록(받는 중)
    this.mem = [];           // 시크릿 탭에서 받은 파일 (저장하지 않고 이번 실행 동안만 보인다)
    this._t = null;
  }

  // gate(url, webContents): false 를 돌려주면 그 다운로드를 취소한다 (자동 다운로드 차단)
  attach(ses, incognito, gate) {
    ses.on('will-download', (_e, item, wc) => {
      if (gate && !gate(item.getURL(), wc)) { item.cancel(); return; }
      this._start(item, !!incognito);
    });
  }

  _start(item, incognito) {
    const dir = app.getPath('downloads');
    const name = safeName(item.getFilename());
    const file = uniquePath(dir, name);
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) { /* 아래 저장에서 실패하면 알려 준다 */ }
    item.setSavePath(file);
    const rec = { id: ++this.seq, item, incognito, name: path.basename(file), path: file, url: item.getURL(), total: item.getTotalBytes(), received: 0,
      speed: 0, paused: false, t0: Date.now(), lastT: Date.now(), lastB: 0, mime: item.getMimeType() };
    this.active.set(rec.id, rec);
    this.hooks.toast('다운로드를 시작합니다 · ' + rec.name);
    item.on('updated', (_e, state) => {
      rec.received = item.getReceivedBytes();
      rec.total = item.getTotalBytes();
      rec.paused = item.isPaused();
      const now = Date.now();
      if (now - rec.lastT >= 700) { // 속도는 0.7초 이상 간격으로 계산해 출렁이지 않게
        const v = ((rec.received - rec.lastB) * 1000) / (now - rec.lastT);
        rec.speed = rec.speed ? rec.speed * 0.6 + v * 0.4 : v;
        rec.lastT = now; rec.lastB = rec.received;
      }
      if (state === 'interrupted') rec.speed = 0;
      this._notify();
    });
    item.once('done', (_e, state) => {
      this.active.delete(rec.id);
      if (state === 'completed') {
        let size = rec.received;
        try { size = fs.statSync(rec.path).size; } catch (e) { /* 그대로 */ }
        const done = { key: incognito ? 'i:' + rec.id : this.data.nextDlKey(), name: rec.name, path: rec.path, size, time: Date.now(), url: rec.url, mime: rec.mime };
        if (incognito) this.mem.unshift(done); else this.data.addDownload(done);
        this.hooks.toast('다운로드를 마쳤습니다 · ' + rec.name, { label: '열기', name: 'dl:open', arg: done.key });
      } else if (state === 'interrupted') {
        try { fs.unlinkSync(rec.path); } catch (e) { /* 이미 없음 */ }
        this.hooks.toast('다운로드가 중단되었습니다 · ' + rec.name);
      } else { // cancelled
        try { fs.unlinkSync(rec.path); } catch (e) { /* */ }
      }
      this._flush();
    });
    this._notify();
  }

  // 조각을 모아 만드는 받기(HLS 등): spec = { name, url, mime, run(ctl, dir) → { path, name, note } }. 받는 중 목록·진행 고리에 똑같이 나온다.
  startJob(spec) {
    const dir = app.getPath('downloads');
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) { /* 아래에서 실패하면 알려 준다 */ }
    const ac = new AbortController();
    const rec = { id: ++this.seq, item: null, incognito: false, name: safeName(spec.name), path: '', url: spec.url, total: 0, received: 0, speed: 0, paused: false,
      t0: Date.now(), lastT: Date.now(), lastB: 0, mime: spec.mime || '', cancelled: false, segTotal: 0, segDone: 0 };
    const ctl = {
      signal: ac.signal, onAbort: null,
      cancelled: () => rec.cancelled,
      bytes: (n) => {
        rec.received += n;
        const now = Date.now();
        if (now - rec.lastT >= 700) {
          const v = ((rec.received - rec.lastB) * 1000) / (now - rec.lastT);
          rec.speed = rec.speed ? rec.speed * 0.6 + v * 0.4 : v; rec.lastT = now; rec.lastB = rec.received;
        }
        this._notify();
      },
      // 전체 크기는 모르니, 받은 조각의 평균 크기로 어림한다
      segment: () => { rec.segDone++; if (rec.segTotal && rec.segDone >= 2) rec.total = Math.max(rec.received, Math.round((rec.received / rec.segDone) * rec.segTotal)); this._notify(); },
      setSegments: (n) => { rec.segTotal = n; },
      phase: () => { rec.total = rec.received; rec.speed = 0; this._notify(); }, // 합치는 중 = 다 받은 상태
    };
    rec.item = { cancel: () => { rec.cancelled = true; ac.abort(); if (ctl.onAbort) ctl.onAbort(); }, isPaused: () => false, canResume: () => false, pause() {}, resume() {} };
    this.active.set(rec.id, rec);
    this.hooks.toast('다운로드를 시작합니다 · ' + rec.name);
    this._notify();
    Promise.resolve().then(() => spec.run(ctl, dir)).then((r) => {
      this.active.delete(rec.id);
      let size = rec.received;
      try { size = fs.statSync(r.path).size; } catch (e) { /* 그대로 */ }
      const done = { key: this.data.nextDlKey(), name: r.name, path: r.path, size, time: Date.now(), url: rec.url, mime: rec.mime };
      this.data.addDownload(done);
      this.hooks.toast('다운로드를 마쳤습니다 · ' + r.name + (r.note || ''), { label: '열기', name: 'dl:open', arg: done.key });
      this._flush();
    }).catch((e) => {
      this.active.delete(rec.id);
      if (!rec.cancelled) this.hooks.toast('다운로드가 중단되었습니다 · ' + rec.name + ' (' + String((e && e.message) || e).slice(0, 80) + ')');
      this._flush();
    });
    return rec.id;
  }

  _notify() { if (this._t) return; this._t = setTimeout(() => { this._t = null; this.hooks.changed(); }, 400); }
  _flush() { clearTimeout(this._t); this._t = null; this.hooks.changed(); }

  // 화면에 보낼 모양 (받는 중 + 끝난 것). 지워진 파일은 목록에서 뺀다.
  snapshot() {
    const active = [...this.active.values()].map((r) => ({ id: r.id, name: r.name, total: r.total, received: r.received, speed: r.speed, paused: r.paused }))
      .sort((a, b) => b.id - a.id);
    const all = this.mem.concat(this.data.downloads());
    const keep = all.filter((d) => fs.existsSync(d.path));
    if (keep.length !== all.length) {
      const gone = new Set(all.filter((d) => !keep.includes(d)).map((d) => d.key));
      this.mem = this.mem.filter((d) => !gone.has(d.key));
      const persisted = this.data.downloads().filter((d) => !gone.has(d.key));
      if (persisted.length !== this.data.downloads().length) this.data.setDownloads(persisted);
    }
    return { active, done: keep, folders: this.data.folders('dl'), folderMap: this.data.dlFolderMap() };
  }
  summary() {
    let rec = 0, tot = 0, unknown = false;
    for (const r of this.active.values()) { rec += r.received; if (r.total > 0) tot += r.total; else unknown = true; }
    return { count: this.active.size, progress: !this.active.size ? 0 : (unknown || !tot ? -1 : Math.min(1, rec / tot)) };
  }

  _find(key) { return this.mem.concat(this.data.downloads()).find((d) => d.key === key); }
  cancel(id) { const r = this.active.get(id); if (r) r.item.cancel(); }
  pause(id) { const r = this.active.get(id); if (r && !r.item.isPaused()) { r.item.pause(); r.paused = true; this._flush(); } }
  resume(id) { const r = this.active.get(id); if (r && r.item.canResume()) { r.item.resume(); r.paused = false; this._flush(); } }
  async open(key) {
    const d = this._find(key);
    if (!d) return;
    if (!fs.existsSync(d.path)) { this.hooks.toast('파일이 없어요 · 이미 지워졌거나 옮겨졌어요'); this._flush(); return; }
    const err = await shell.openPath(d.path);
    if (err) this.hooks.toast('파일을 열지 못했어요');
  }
  show(key) { const d = this._find(key); if (d && fs.existsSync(d.path)) shell.showItemInFolder(d.path); }
  // 파일을 휴지통으로 보내고 기록에서 뺀다. 휴지통으로 못 보내면 기록만 남긴다(파일은 그대로).
  async remove(keys) {
    let ok = 0;
    for (const k of keys) {
      const d = this._find(k);
      if (!d) continue;
      try { if (fs.existsSync(d.path)) await shell.trashItem(d.path); ok++; } catch (e) { this.hooks.toast('파일을 지우지 못했어요 · ' + d.name); continue; }
      this.mem = this.mem.filter((x) => x.key !== k);
      this.data.removeDownloads([k]);
    }
    this._flush();
    return ok;
  }
}
module.exports = { Downloads };
