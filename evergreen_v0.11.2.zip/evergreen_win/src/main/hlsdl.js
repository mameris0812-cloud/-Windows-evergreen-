'use strict';
// HLS 받기: 조각을 6개씩 동시에 받아 순서대로 이어 붙인다 (안드로이드 HlsDownload.download 와 같다).
// ctx: { headers(url) → 요청 머리글, cancelled() → bool, onBytes(n), onSegment() }
const crypto = require('crypto');
const Hls = require('../shared/hls');

const PARALLEL = 6;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class HttpErr extends Error { constructor(code) { super('HTTP ' + code); this.code = code; } }

async function fetchBytes(ctx, url, rangeStart = -1, rangeLen = -1) {
  let last = null;
  for (let attempt = 0; attempt < 4; attempt++) {
    if (ctx.cancelled()) throw new Error('cancelled');
    try {
      const h = Object.assign({}, ctx.headers(url));
      if (rangeStart >= 0 && rangeLen > 0) h.Range = 'bytes=' + rangeStart + '-' + (rangeStart + rangeLen - 1);
      const r = await fetch(url, { headers: h, redirect: 'follow', signal: ctx.signal });
      if (!r.ok) throw new HttpErr(r.status);
      return Buffer.from(await r.arrayBuffer());
    } catch (e) {
      if (ctx.cancelled()) throw new Error('cancelled');
      last = e;
      // 주소가 틀렸거나 권한이 없으면 다시 해도 소용없다
      if (e instanceof HttpErr && e.code >= 400 && e.code <= 499 && e.code !== 408 && e.code !== 429) throw e;
      await sleep((ctx.retryMs == null ? 400 : ctx.retryMs) * (attempt + 1));
    }
  }
  throw last || new Error('받기 실패');
}
const fetchText = (ctx) => async (url) => (await fetchBytes(ctx, url)).toString('utf8').replace(/^\uFEFF/, '');
const plan = (ctx, url) => Hls.plan(fetchText(ctx), url);

async function keyBytes(ctx, k) {
  if (!ctx.keyCache) ctx.keyCache = new Map();
  if (ctx.keyCache.has(k.uri)) return ctx.keyCache.get(k.uri);
  const b = await fetchBytes(ctx, k.uri);
  if (b.length !== 16) throw new Error('암호화 키 형식이 맞지 않아요');
  ctx.keyCache.set(k.uri, b);
  return b;
}
function decrypt(data, key, iv) {
  try {
    const d = crypto.createDecipheriv('aes-128-cbc', key, Buffer.from(iv));
    return Buffer.concat([d.update(data), d.final()]);
  } catch (e) { // 끝 패딩이 없는 스트림
    const d = crypto.createDecipheriv('aes-128-cbc', key, Buffer.from(iv));
    d.setAutoPadding(false);
    return Buffer.concat([d.update(data.subarray(0, data.length - (data.length % 16))), d.final()]);
  }
}
async function fetchSegment(ctx, s) {
  const raw = await fetchBytes(ctx, s.url, s.rangeStart, s.rangeLen);
  ctx.onBytes(raw.length);
  if (!s.key) return raw;
  return decrypt(raw, await keyBytes(ctx, s.key), s.key.iv || Hls.seqIv(s.seq));
}

// 한 줄기(영상 또는 소리)를 순서대로 이어서 write(buf) 로 보낸다. write 는 Promise 를 돌려줘도 된다.
async function download(ctx, stream, write) {
  if (stream.init) {
    const b = await fetchBytes(ctx, stream.init.url, stream.init.rangeStart, stream.init.rangeLen);
    ctx.onBytes(b.length);
    await write(b);
  }
  const pending = [];
  let next = 0;
  const feed = () => { while (next < stream.segs.length && pending.length < PARALLEL * 2) { const p = fetchSegment(ctx, stream.segs[next++]); p.catch(() => {}); pending.push(p); } };
  feed();
  while (pending.length) {
    const buf = await pending.shift();
    await write(buf);
    ctx.onSegment();
    feed();
  }
}
module.exports = { plan, download, fetchBytes, decrypt };
