'use strict';
const path = require('path');
const { WebContentsView, ipcMain } = require('electron');

const SRC = path.join(__dirname, '..');
const SHADOW = 14; // 추천 창 그림자가 잘리지 않게 두르는 여백(px)

// 웹 화면은 네이티브 뷰라서 그 위에 뜨는 작은 것들(토스트, 주소창 추천)은 각각 작은 투명 뷰로 그린다.
// 뷰 크기를 내용에 딱 맞춰서, 뷰가 떠 있는 동안에도 그 밖의 웹 화면은 그대로 눌린다.
class Floats {
  // hooks: { pick(text), isDark() }
  constructor(win, hooks) {
    this.win = win;
    this.hooks = hooks;
    this.ready = new Map();
    this.queue = new Map();
    this.toastV = this._make('toast', 'toast.html');
    this.sugV = this._make('suggest', 'suggest.html');
    this.pillV = this._make('ascroll', 'ascroll.html'); // 자동 스크롤 조작 막대
    this.pillSize = null; this.pillOn = false;
    this.toastAction = null; this.toastTimer = null; this.toastSize = null;
    this.items = []; this.index = -1; this.query = ''; this.rect = null; this.sugSize = null;

    ipcMain.on('toast:size', (e, s) => { if (e.sender === this.toastV.webContents && s) { this.toastSize = s; this._placeToast(); } });
    ipcMain.on('toast:action', (e) => { if (e.sender === this.toastV.webContents) { const fn = this.toastAction; this.hideToast(); if (fn) fn(); } });
    ipcMain.on('as:size', (e, s) => { if (e.sender === this.pillV.webContents && s && this.pillOn) { this.pillSize = s; this._placePill(); } });
    ipcMain.on('as:cmd', (e, act) => { if (e.sender === this.pillV.webContents && typeof act === 'string' && hooks.autoCmd) hooks.autoCmd(act); });
    ipcMain.on('suggest:size', (e, s) => { if (e.sender === this.sugV.webContents && s && this.items.length) { this.sugSize = s; this._placeSuggest(); } });
    ipcMain.on('suggest:pick', (e, text) => { if (e.sender === this.sugV.webContents && typeof text === 'string') { this.suggestHide(); hooks.pick(text); } });
  }

  _make(name, file) {
    const v = new WebContentsView({ webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false } });
    v.setBackgroundColor('#00000000');
    v.setVisible(false);
    this.win.contentView.addChildView(v);
    v.webContents.once('did-finish-load', () => {
      this.ready.set(name, true);
      const q = this.queue.get(name);
      if (q) { this.queue.delete(name); v.webContents.send(q.ch, q.payload); }
    });
    v.webContents.loadFile(path.join(SRC, name, file));
    return v;
  }
  _send(name, v, ch, payload) {
    if (v.webContents.isDestroyed()) return;
    if (this.ready.get(name)) v.webContents.send(ch, payload); else this.queue.set(name, { ch, payload });
  }
  raise() {
    try { this.win.contentView.addChildView(this.pillV); this.win.contentView.addChildView(this.toastV); this.win.contentView.addChildView(this.sugV); } catch (e) { /* 창이 닫히는 중 */ }
  }
  relayout() { this._placePill(); this._placeToast(); this._placeSuggest(); }

  // ───────── 토스트 ─────────
  toast(msg, action) {
    clearTimeout(this.toastTimer);
    this.toastAction = action ? (action.fn || null) : null;
    this.toastSize = null;
    this._send('toast', this.toastV, 'toast:show', { msg: String(msg), label: action ? action.label : '', dark: this.hooks.isDark() });
    this.toastTimer = setTimeout(() => this.hideToast(), action ? 5200 : 3000);
  }
  hideToast() { clearTimeout(this.toastTimer); this.toastAction = null; this.toastSize = null; this.toastV.setVisible(false); }
  _placeToast() {
    if (!this.toastSize || this.win.isDestroyed()) return;
    const [w, h] = this.win.getContentSize();
    const tw = Math.min(Math.ceil(this.toastSize.w), w - 24), th = Math.ceil(this.toastSize.h);
    const lift = this.pillOn && this.pillSize ? this.pillSize.h - 14 : 0; // 조작 막대가 떠 있으면 그 위로
    this.toastV.setBounds({ x: Math.round((w - tw) / 2), y: Math.max(0, h - th - 28 - lift), width: tw, height: th });
    this.toastV.setVisible(true);
    this.raise();
  }

  // ───────── 자동 스크롤 조작 막대 ─────────
  // state: { level, smart, paused, min, max }
  pillShow(state) { this.pillOn = true; this._send('ascroll', this.pillV, 'as:state', state); }
  pillUpdate(state) { if (this.pillOn) this._send('ascroll', this.pillV, 'as:state', state); }
  pillHide() { this.pillOn = false; this.pillSize = null; this.pillV.setVisible(false); this._placeToast(); }
  pillShown() { return this.pillOn; }
  _placePill() {
    if (!this.pillOn || !this.pillSize || this.win.isDestroyed()) return;
    const [w, h] = this.win.getContentSize();
    const pw = Math.min(Math.ceil(this.pillSize.w), w - 16), ph = Math.ceil(this.pillSize.h);
    this.pillV.setBounds({ x: Math.round((w - pw) / 2), y: Math.max(0, h - ph + 2), width: pw, height: ph });
    this.pillV.setVisible(true);
    this.raise();
    this._placeToast();
  }

  // ───────── 주소창 추천 ─────────
  // rect: 주소창(urlWrap)의 창 안 위치 {x, y, w, h}
  suggestShow(items, rect, query) {
    if (!items.length) { this.suggestHide(); return; }
    const same = this.items.length === items.length && this.items.every((x, i) => x === items[i]);
    this.items = items; this.rect = rect; this.query = query;
    if (!same) this.index = -1;
    this._send('suggest', this.sugV, 'suggest:show', { items, selected: this.index, dark: this.hooks.isDark() });
  }
  suggestHide() {
    this.items = []; this.index = -1; this.sugSize = null;
    this.sugV.setVisible(false);
  }
  isSuggesting() { return this.items.length > 0; }
  // 위/아래 화살표: 고른 글자를 돌려준다 (맨 위에서 위로 / 맨 아래에서 아래로 가면 처음 입력한 글자로)
  suggestMove(dir) {
    if (!this.items.length) return null;
    const n = this.items.length;
    let i = this.index + dir;
    if (this.index === -1 && dir < 0) i = n - 1;
    if (i >= n || i < -1) i = -1;
    this.index = i;
    this._send('suggest', this.sugV, 'suggest:hl', i);
    return i === -1 ? this.query : this.items[i];
  }
  _placeSuggest() {
    if (!this.sugSize || !this.rect || !this.items.length || this.win.isDestroyed()) return;
    const r = this.rect;
    this.sugV.setBounds({ x: Math.round(r.x - SHADOW), y: Math.round(r.y + r.h + 2), width: Math.round(r.w + SHADOW * 2), height: Math.ceil(this.sugSize.h) });
    this.sugV.setVisible(true);
    this.raise();
  }
}
module.exports = { Floats };
