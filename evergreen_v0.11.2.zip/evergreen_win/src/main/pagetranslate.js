'use strict';
// 페이지 번역: 페이지의 글 노드를 모아 Gemini 로 번역하고 그 자리에서 바꾼다. 다시 누르면 원문으로 되돌린다.
// d: { images?: ImageTranslator, imagesOn() → 이미지 속 글자도 번역할지, run(wc, code) → 페이지에서 실행한 결과, call(fn, ...args) → 코드 문자열, PT(스크립트 함수들), makeClient(), pick() → { key, model } | null, toast, changed }
const T = require('../shared/translate');

const MAX_NODES = 1500, PARALLEL = 3;

class PageTranslator {
  constructor(d) { this.d = d; this.st = new Map(); } // wcId → { phase, cancel, done, total }
  status(id) { const s = this.st.get(id); return s ? s.phase : 'idle'; }
  forget(id) { const s = this.st.get(id); if (s) s.cancelled = true; this.st.delete(id); if (this.d.images) this.d.images.forget(id); }

  async toggle(wc, langKey) {
    const id = wc.id, cur = this.status(id);
    if (cur === 'running') { this.cancel(id); this.d.toast('번역을 멈췄어요'); return 'idle'; }
    if (cur === 'done') { await this.restore(wc); return 'idle'; }
    return this.translate(wc, langKey);
  }
  cancel(id) { const s = this.st.get(id); if (s) { s.cancelled = true; try { if (s.client) s.client.cancel(); } catch (e) { /* */ } } if (this.d.images) this.d.images.cancel(id); }

  async restore(wc) {
    this.st.delete(wc.id);
    try { await this.d.run(wc, this.d.call(this.d.PT.trRestoreFn)); } catch (e) { /* 페이지가 이미 바뀜 */ }
    if (this.d.images) await this.d.images.clear(wc);   // 이미지 위에 덮은 번역도 걷는다
    this.d.changed(); this.d.toast('원문으로 되돌렸어요');
  }

  async translate(wc, langKey) {
    const d = this.d, id = wc.id, L = T.lang(langKey);
    const k = d.pick();
    if (!k) { d.toast('페이지 번역은 Gemini API 키가 필요해요. AI 창 설정에서 키를 넣어 주세요'); return 'idle'; }
    const s = { phase: 'running', cancelled: false, client: null, done: 0, total: 0 };
    this.st.set(id, s); d.changed();
    d.toast(L.name + '(으)로 번역하는 중…');
    try {
      const nodes = await d.run(wc, d.call(d.PT.trCollectFn, MAX_NODES));
      const items = (nodes || []).filter((n) => !T.skip(n.t, L.key));
      const withImages = !!(d.images && d.imagesOn && d.imagesOn());
      if (!items.length && !withImages) { this.st.delete(id); d.changed(); d.toast('번역할 글이 없어요 (이미 ' + L.name + '이에요)'); return 'idle'; }
      // 같은 글은 한 번만 보낸다
      const uniq = new Map(); items.forEach((n) => { if (!uniq.has(n.t)) uniq.set(n.t, []); uniq.get(n.t).push(n.i); });
      const list = Array.from(uniq.keys()).map((t, i) => ({ i, t }));
      s.total = list.length;
      const queue = T.batches(list);
      let failed = 0, applied = 0, lastErr = '';
      const work = async () => {
        for (;;) {
          if (s.cancelled) return;
          const b = queue.shift(); if (!b) return;
          const res = await this._batch(b, L, s, k);
          if (s.cancelled) return;
          if (res.error) { failed += b.length; lastErr = res.error; continue; }
          const pairs = [];
          b.forEach((it, j) => { const tr = res.out[j]; if (tr && tr.trim()) uniq.get(it.t).forEach((nodeIdx) => pairs.push([nodeIdx, tr])); });
          if (pairs.length) { try { applied += await d.run(wc, d.call(d.PT.trApplyFn, pairs)); } catch (e) { s.cancelled = true; return; } }
          s.done += b.length;
        }
      };
      await Promise.all(Array.from({ length: PARALLEL }, work));
      if (s.cancelled) { if (this.st.get(id) === s) this.st.delete(id); d.changed(); return 'idle'; }
      // 이미지 속 글자(설정을 켠 경우): 글 번역이 끝난 뒤 이어서. 이미지가 하나라도 번역되면 글이 없어도 '번역함'으로 본다
      let imgApplied = 0, imgErr = '';
      if (withImages) {
        d.toast('이미지 속 글자를 번역하는 중…');
        const ir = await d.images.translateAll(wc, L.key, { isCancelled: () => s.cancelled });
        imgApplied = ir.applied; imgErr = ir.error;
        if (s.cancelled) { if (this.st.get(id) === s) this.st.delete(id); d.changed(); return 'idle'; }
      }
      if (!applied && !imgApplied) { this.st.delete(id); d.changed(); d.toast('번역하지 못했어요' + ((lastErr || imgErr) ? ': ' + (lastErr || imgErr) : '')); return 'idle'; }
      s.phase = 'done'; d.changed();
      d.toast(failed ? '일부만 번역했어요 (' + failed + '줄 실패)' : imgApplied ? L.name + '(으)로 번역했어요 (이미지 ' + imgApplied + '장 포함)' : L.name + '(으)로 번역했어요', { label: '원문 보기', name: 'page:translate' });
      return 'done';
    } catch (e) {
      if (this.st.get(id) === s) this.st.delete(id); d.changed();
      d.toast('번역하지 못했어요: ' + String((e && e.message) || e).split('\n')[0].slice(0, 80));
      return 'idle';
    }
  }

  // 한 묶음 번역. 답의 개수가 안 맞으면 반으로 나눠 다시 보낸다(한 줄까지 줄여도 안 되면 그 줄은 원문 그대로).
  async _batch(b, L, s, k) {
    const d = this.d;
    let text = '';
    const c = d.makeClient(); s.client = c;
    const r = await c.stream({ key: d.pick().key, model: k.model, system: T.system(L.key), history: [{ role: 'user', text: T.user(b) }], json: true, thinking: 'minimal', search: false,
      cb: { text: (x) => { text += x; } } });
    if (s.cancelled) return { error: 'cancelled' };
    if (!r.ok) return { error: String(r.error || '').split('\n')[0] };
    const out = T.parse(text, b.length);
    if (out) return { out };
    if (b.length === 1) return { out: [b[0].t] };
    const h = Math.ceil(b.length / 2);
    const x = await this._batch(b.slice(0, h), L, s, k); if (x.error) return x;
    const y = await this._batch(b.slice(h), L, s, k); if (y.error) return y;
    return { out: x.out.concat(y.out) };
  }
}
module.exports = { PageTranslator };
