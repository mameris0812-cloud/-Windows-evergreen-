'use strict';
const fs = require('fs');
const path = require('path');
// 아주 단순한 JSON 저장소 (userData/evergreen-prefs.json). 쓰기는 모아서 한 번에.
class Store {
  constructor(dir, file, defaults) {
    this.file = path.join(dir, file);
    this.data = Object.assign({}, defaults);
    try { Object.assign(this.data, JSON.parse(fs.readFileSync(this.file, 'utf8'))); } catch (e) { /* 처음 실행 */ }
    this._t = null;
  }
  get(k) { return this.data[k]; }
  set(k, v) { this.data[k] = v; this._schedule(); }
  _schedule() {
    if (this._t) return;
    this._t = setTimeout(() => { this._t = null; this.flush(); }, 400);
  }
  flush() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.data));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (e) { /* 저장 실패는 조용히 */ }
  }
}
module.exports = { Store };
