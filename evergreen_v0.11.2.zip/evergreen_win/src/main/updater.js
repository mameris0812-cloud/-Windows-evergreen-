'use strict';
// 자동 업데이트: electron-updater(GitHub Releases) 를 감싼 얇은 층. 실제 업데이트 라이브러리는 주입받아서 테스트할 수 있다.
// 상태: idle → checking → (none | available → downloading → ready | error). 화면에는 snapshot().update 로 전달한다.
const DAY = 24 * 3600 * 1000;

class UpdateManager {
  // d: { updater(electron-updater 의 autoUpdater, 없으면 null), store, toast, changed, version, packaged, now? }
  constructor(d) {
    this.d = d;
    this.u = d.updater || null;
    this.s = { phase: 'idle', version: null, percent: 0, error: null, checkedAt: d.store.get('updCheckedAt') || 0, supported: !!(this.u && d.packaged) };
    this.timer = null;
    this.manual = false;
    if (this.u) this._wire();
  }
  _wire() {
    const u = this.u;
    u.autoDownload = true;          // 새 버전이 있으면 조용히 받아 둔다
    u.autoInstallOnAppQuit = true;  // 앱을 끌 때 알아서 설치
    u.allowPrerelease = false;
    u.on('checking-for-update', () => this._set({ phase: 'checking', error: null }));
    u.on('update-available', (i) => { this._set({ phase: 'downloading', version: i && i.version, percent: 0 }); });
    u.on('update-not-available', () => {
      this._set({ phase: 'none', checkedAt: this._now() });
      this.d.store.set('updCheckedAt', this.s.checkedAt);
      if (this.manual) this.d.toast('최신 버전이에요 (v' + this.d.version + ')');
      this.manual = false;
    });
    u.on('download-progress', (p) => this._set({ phase: 'downloading', percent: Math.max(0, Math.min(100, Math.round((p && p.percent) || 0))) }));
    u.on('update-downloaded', (i) => {
      this._set({ phase: 'ready', version: (i && i.version) || this.s.version, percent: 100, checkedAt: this._now() });
      this.d.store.set('updCheckedAt', this.s.checkedAt);
      this.d.toast('새 버전 v' + this.s.version + ' 준비됐어요', { label: '다시 시작', name: 'update:install' });
    });
    u.on('error', (e) => {
      const msg = friendlyError(e);
      this._set({ phase: 'error', error: msg });
      if (this.manual) this.d.toast('업데이트를 확인하지 못했어요: ' + msg);
      this.manual = false;
    });
  }
  _now() { return this.d.now ? this.d.now() : Date.now(); }
  _set(p) { Object.assign(this.s, p); if (this.d.changed) this.d.changed(); }
  snapshot() { return Object.assign({}, this.s); }
  // 켜질 때 한 번, 그 뒤 하루에 한 번. (설정 '자동 업데이트' 가 꺼져 있으면 직접 누를 때만)
  start() {
    if (!this.s.supported) return;
    const first = setTimeout(() => this.maybeAuto(), 15000);
    if (first.unref) first.unref();
    this.timer = setInterval(() => this.maybeAuto(), 6 * 3600 * 1000);
    if (this.timer.unref) this.timer.unref();
  }
  maybeAuto() {
    if (!this.d.store.get('autoUpdate')) return;
    if (this._now() - (this.s.checkedAt || 0) < DAY) return;
    this.check(false);
  }
  async check(manual) {
    if (!this.s.supported) { if (manual) this.d.toast(this.u ? '설치해서 쓰는 앱에서만 업데이트를 확인해요' : '이 빌드에는 업데이트 기능이 없어요'); return false; }
    if (this.s.phase === 'checking' || this.s.phase === 'downloading') return false;
    if (this.s.phase === 'ready') { if (manual) this.d.toast('새 버전 v' + this.s.version + ' 이(가) 이미 준비돼 있어요'); return false; }
    this.manual = !!manual;
    try { await this.u.checkForUpdates(); } catch (e) { /* 'error' 이벤트로 이미 알렸다 */ if (this.s.phase !== 'error') this._set({ phase: 'error', error: friendlyError(e) }); }
    return true;
  }
  installNow() {
    if (this.s.phase !== 'ready' || !this.u) return false;
    try { this.u.quitAndInstall(false, true); return true; } catch (e) { this._set({ phase: 'error', error: friendlyError(e) }); return false; }
  }
  setAuto(on) { this.d.store.set('autoUpdate', !!on); if (this.d.changed) this.d.changed(); }
  dispose() { if (this.timer) clearInterval(this.timer); this.timer = null; }
}

function friendlyError(e) {
  const m = String((e && e.message) || e || '');
  if (/ENOTFOUND|ECONNREFUSED|ETIMEDOUT|ENETUNREACH|net::ERR|network/i.test(m)) return '인터넷에 연결되어 있는지 확인해 주세요';
  if (/404|Not Found|Cannot find latest/i.test(m)) return '아직 올라온 새 버전이 없어요';
  if (/403|rate limit/i.test(m)) return '잠시 뒤에 다시 시도해 주세요';
  if (/sha512|checksum|signature/i.test(m)) return '받은 파일이 올바르지 않아요. 다시 시도해 주세요';
  return m.split('\n')[0].slice(0, 80) || '알 수 없는 오류';
}

// electron-updater 는 설치된 앱에만 들어 있다(개발 중 · 테스트에는 없을 수 있음). 없으면 null.
function loadAutoUpdater() {
  try { return require('electron-updater').autoUpdater; } catch (e) { return null; }
}

module.exports = { UpdateManager, friendlyError, loadAutoUpdater };
