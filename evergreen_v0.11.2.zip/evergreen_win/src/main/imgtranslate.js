'use strict';
// 이미지 속 글자 번역: 페이지의 이미지를 모아 → 한 장씩(긴 이미지는 조각으로) Gemini 비전에 보내 글자 위치와 번역을 받고 → 이미지 위에 덮는다.
// 안드로이드는 ML Kit 으로 글자를 읽고 따로 번역했지만, 윈도우에는 ML Kit 이 없어서 '읽기 + 번역'을 Gemini 한 번에 맡긴다. 덮는 쪽(pagetools.img*Fn)은 안드로이드 것을 그대로 옮겼다.
// d: { run(wc, code), call(fn, ...args), PT, toast, changed, makeClient(), pickVision() → { key, model } | null, fetchImage(wc, url) → Buffer + mime }
const I = require('../shared/imgtr');
const T = require('../shared/translate');

class ImageTranslator {
  constructor(d) { this.d = d; this.st = new Map(); } // wcId → { cancelled, clients:Set }
  busy(id) { return this.st.has(id); }
  cancel(id) { const s = this.st.get(id); if (s) { s.cancelled = true; s.clients.forEach((c) => { try { c.cancel(); } catch (e) { /* */ } }); } }
  forget(id) { this.cancel(id); this.st.delete(id); }

  // 페이지의 이미지 전부(최대 40장). opts.isCancelled: 바깥(페이지 번역)의 중단 신호. 반환: { total, applied, error }
  async translateAll(wc, langKey, opts) {
    return this._run(wc, langKey, null, opts || {});
  }
  // 이미지 한 장(우클릭한 것)
  async translateOne(wc, langKey, url) {
    const r = await this._run(wc, langKey, url, {});
    const d = this.d;
    if (r.notFound) d.toast('이미지를 찾지 못했어요. 이미 번역한 이미지이거나, 화면에서 찾을 수 없는 이미지예요');
    else if (r.cancelled) d.toast('번역을 멈췄어요');
    else if (r.applied) d.toast('이미지를 번역했어요', { label: '번역 해제', name: 'img:untranslate' });
    else d.toast(r.error ? '이미지를 번역하지 못했어요: ' + r.error : '번역할 글자를 찾지 못했어요');
    return r;
  }
  async clear(wc, url) { try { return await this.d.run(wc, this.d.call(this.d.PT.imgCoverFn, url || '', 'clear')); } catch (e) { return 0; } }
  async has(wc, url) { try { return (await this.d.run(wc, this.d.call(this.d.PT.imgCoverFn, url, 'has'))) > 0; } catch (e) { return false; } }

  async _run(wc, langKey, onlyUrl, opts) {
    const d = this.d, id = wc.id, L = T.lang(langKey), res = { total: 0, applied: 0, error: '', cancelled: false, notFound: false };
    if (this.st.has(id)) { this.cancel(id); }
    const s = { cancelled: false, clients: new Set() }; this.st.set(id, s);
    const stopped = () => s.cancelled || (opts.isCancelled && opts.isCancelled());
    const vk = d.pickVision();
    if (!vk) { this.st.delete(id); res.error = 'Gemini API 키가 필요해요'; if (onlyUrl) d.toast('이미지 번역은 Gemini API 키가 필요해요. AI 창 설정에서 키를 넣어 주세요'); return res; }
    if (onlyUrl) d.toast('이미지 속 글자를 번역하는 중…');
    try {
      const tok = await d.run(wc, '(function(){var id=String(Math.random()).slice(2);window.__evId=id;return id})()');
      const col = await d.run(wc, d.call(d.PT.imgCollectFn, I.LIM.MAX_IMAGES));
      let items = (col && col.items) || [];
      if (onlyUrl) { const want = I.sameKey(onlyUrl); items = items.filter((x) => x.u === onlyUrl || I.sameKey(x.u) === want); if (!items.length) { res.notFound = true; return res; } }
      res.total = items.length;
      if (!items.length) return res;
      let next = 0, done = 0;
      const worker = async () => {
        for (;;) {
          if (stopped()) return;
          const it = items[next++]; if (!it) return;
          try { await d.run(wc, d.call(d.PT.imgBusyFn, tok, it.k, 1)); } catch (e) { s.cancelled = true; return; }
          let out = null;
          try { out = await this._image(wc, it, L, vk, s, tok, stopped); } catch (e) { res.error = res.error || String((e && e.message) || e).split('\n')[0].slice(0, 80); }
          if (stopped()) { try { await d.run(wc, d.call(d.PT.imgBusyFn, tok, it.k, 0)); } catch (e) { /* */ } return; }
          done++;
          if (out && out.blocks.length) {
            let n = -1;
            try { n = await d.run(wc, d.call(d.PT.imgApplyFn, tok, it.k, out.w, out.h, out.blocks)); } catch (e) { n = -1; }
            if (n < 0) { res.error = '다른 페이지로 이동해서 번역을 멈췄어요'; s.cancelled = true; return; }
            res.applied += n > 0 ? 1 : 0;
          } else { try { await d.run(wc, d.call(d.PT.imgBusyFn, tok, it.k, 0)); } catch (e) { /* */ } if (out && out.error && !res.error) res.error = out.error; }
          if (!onlyUrl && items.length > 1) d.toast('이미지 속 글자 번역 중 (' + done + '/' + items.length + ')');
        }
      };
      await Promise.all(Array.from({ length: Math.min(I.LIM.WORKERS, items.length) }, worker));
      res.cancelled = stopped();
      if (res.applied) res.error = '';
      return res;
    } catch (e) {
      res.error = String((e && e.message) || e).split('\n')[0].slice(0, 80);
      return res;
    } finally { if (this.st.get(id) === s) this.st.delete(id); d.changed(); }
  }

  // 이미지 한 장: 읽어 들이기 → 조각마다 Gemini → 원본 좌표의 덩어리들. 못 읽은 이미지는 { blocks: [] }
  async _image(wc, it, L, vk, s, tok, stopped) {
    const d = this.d;
    let info = await d.run(wc, d.call(d.PT.imgLoadFn, it.k, null));
    if (info && info.need) {
      const f = await d.fetchImage(wc, it.u).catch(() => null);
      if (!f) return { blocks: [], error: '이미지를 받지 못했어요' };
      info = await d.run(wc, d.call(d.PT.imgLoadFn, it.k, 'data:' + (f.mime || 'image/jpeg') + ';base64,' + f.buf.toString('base64')));
    }
    if (!info || !info.w) return { blocks: [], error: '' };
    const tiles = I.planTiles(info.w, info.h);
    const blocks = []; let err = '';
    for (const tile of tiles) {
      if (stopped()) return { blocks: [] };
      const b64 = await d.run(wc, d.call(d.PT.imgTileFn, it.k, tile.y0, tile.h, I.LIM.SEND_W));
      if (!b64) { err = '이미지를 읽지 못했어요'; continue; }
      let items = null;
      for (let attempt = 0; attempt < 2 && !items; attempt++) {
        let text = '';
        const c = d.makeClient(); s.clients.add(c);
        const r = await c.stream({ key: vk.key, model: vk.model, system: I.system(L.key), history: [{ role: 'user', text: I.user(), images: [{ mime: 'image/jpeg', base64: b64, name: 'tile.jpg' }] }], json: true, thinking: 'minimal', search: false, cb: { text: (x) => { text += x; } } });
        s.clients.delete(c);
        if (stopped()) return { blocks: [] };
        if (!r.ok) { err = String(r.error || '').split('\n')[0]; break; }
        items = I.parse(text);
      }
      if (items) blocks.push(...I.toBlocks(items, tile, info.w, L.key));
      else if (!err) err = '번역 답을 읽지 못했어요';
    }
    return { blocks, w: info.w, h: info.h, error: blocks.length ? '' : err };
  }
}

// 이미지 파일을 받는다: 그 탭의 세션(쿠키)으로 원래 페이지를 Referer 로 달아서 — 로그인·핫링크 방지 이미지도 받아진다. 15MB 넘으면 포기.
async function fetchImage(wc, url) {
  if (/^data:/i.test(url)) {
    const m = /^data:([^;,]+)?(;base64)?,(.*)$/s.exec(url); if (!m) return null;
    const buf = m[2] ? Buffer.from(m[3], 'base64') : Buffer.from(decodeURIComponent(m[3]));
    return buf.length <= I.LIM.MAX_BYTES ? { buf, mime: m[1] || 'image/png' } : null;
  }
  const ses = wc.session;
  const r = await ses.fetch(url, { headers: { Referer: wc.getURL() }, credentials: 'include', signal: AbortSignal.timeout(25000) });
  if (!r.ok) return null;
  const len = Number(r.headers.get('content-length') || 0); if (len > I.LIM.MAX_BYTES) return null;
  const buf = Buffer.from(await r.arrayBuffer()); if (buf.length > I.LIM.MAX_BYTES) return null;
  return { buf, mime: (r.headers.get('content-type') || 'image/jpeg').split(';')[0] };
}
module.exports = { ImageTranslator, fetchImage };
