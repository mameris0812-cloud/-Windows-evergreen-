'use strict';
// 6단계: AI 어시스턴트. 창 오른쪽에 붙는 패널(WebContentsView, src/ai/)과 그 뒤의 일을 맡는다.
//  - 키 보관(safeStorage) · 키 풀 · 모델 자동 선택 · 스트리밍 채팅 · 도구를 쓰는 에이전트 · 대화 기록 · 사용량
//  - 패널은 `ai:*` 채널로만 말한다. 이 파일은 패널(aiView)에서 온 메시지만 받는다.
const path = require('path');
const { WebContentsView, ipcMain, shell } = require('electron');
const G = require('../shared/gemini');
const Prompt = require('../shared/aiprompt');
const Routing = require('../shared/routing');
const { GeminiClient } = require('./gemini-client');
const { ModelSync } = require('./modelsync');
const { Usage, formatTokens, formatDuration } = require('./usage');
const { makeVault } = require('./vault');
const { ChatStore } = require('./chatstore');
const { AgentRunner, TOOL_LABEL } = require('./agent');
const PT = require('./pagetools');
const { PageTranslator } = require('./pagetranslate');
const { ImageTranslator, fetchImage } = require('./imgtranslate');
const Tr = require('../shared/translate');

const SRC = path.join(__dirname, '..');
const MIN_W = 320, MAX_W = 720, DEF_W = 400;
const SETTING_DEFAULTS = { search: true, sources: true, thoughts: true, agent: true, pageRef: true, auto: false, width: DEF_W };
const MAX_ATTACH = 5, MAX_ATTACH_BYTES = 8 * 1024 * 1024;
const HISTORY_CHARS = 60000;

class AiHost {
  // d: { win(), store, safeStorage, userData, fetch, toast, chromeH(), relayout(), tabs, data, downloads, sec, ext, cmd, resolveInput, prefs(), onChange() }
  constructor(d) {
    this.d = d;
    this.g = G.create();
    this.usage = new Usage(d.store, 'aiUsage');
    this.modelSync = new ModelSync({ g: this.g, store: d.store, fetch: d.fetch });
    this.modelSync.init();
    this.vault = makeVault(d.safeStorage);
    this.chats = new ChatStore(d.userData);
    this.client = null; this.runner = null; this.busy = false; this.open = false; this.ready = false; this.queue = [];
    this.chat = { id: null, messages: [], agent: false };
    this.lastWasAgent = false; this.pending = new Map(); this.seq = 0;
    this.g.pool.onEvent = (ev) => this.emit({ type: 'keyswitch', text: ev.text, from: ev.from, to: ev.to, total: ev.total });
    const pageRun = (wc, code) => { if (!wc || wc.isDestroyed()) return Promise.reject(new Error('탭을 찾지 못했어요')); return wc.executeJavaScript(code, true); };
    const makeClient = () => new GeminiClient({ g: this.g, usage: this.usage, modelSync: this.modelSync, fetch: d.fetch });
    this.img = new ImageTranslator({
      run: pageRun, call: PT.call, PT, toast: (m, a) => d.toast(m, a), changed: () => { if (d.onChange) d.onChange(); }, makeClient,
      pickVision: () => { const ks = this.keys(); return ks.length ? { key: this.g.pool.pick(ks), model: this.g.auto.visionModel() } : null; },
      fetchImage: (wc, url) => fetchImage(wc, url),
    });
    this.tr = new PageTranslator({
      images: this.img, imagesOn: () => !!this.d.store.get('trImages'),
      run: (wc, code) => { if (!wc || wc.isDestroyed()) return Promise.reject(new Error('탭을 찾지 못했어요')); return wc.executeJavaScript(code, true); },
      call: PT.call, PT, toast: (m, a) => d.toast(m, a), changed: () => { if (d.onChange) d.onChange(); },
      makeClient: () => new GeminiClient({ g: this.g, usage: this.usage, modelSync: this.modelSync, fetch: d.fetch }),
      pick: () => { const ks = this.keys(); return ks.length ? { key: this.g.pool.pick(ks), model: this.g.models.lite() } : null; },
    });
    this.view = new WebContentsView({ webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false } });
    this.view.setBackgroundColor('#00000000');
    this.view.setVisible(false);
    this.view.webContents.once('did-finish-load', () => { this.ready = true; const q = this.queue; this.queue = []; q.forEach((m) => this.view.webContents.send('ai:event', m)); });
    this.view.webContents.loadFile(path.join(SRC, 'ai', 'ai.html'));
    this.view.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    this.view.webContents.on('will-navigate', (e) => e.preventDefault());
    this._register();
  }

  // ───────── 페이지 번역 ─────────
  translate(wc, lang) { if (!wc || !/^https?:/i.test(wc.getURL())) { this.d.toast('웹 페이지에서만 번역할 수 있어요'); return Promise.resolve('idle'); } return this.tr.toggle(wc, lang); }
  trStatus(id) { return this.tr.status(id); }
  // 이미지 한 장 번역(우클릭) · 해제 · 번역돼 있는지
  translateImage(wc, url, lang) {
    if (!wc || !/^https?:/i.test(wc.getURL())) { this.d.toast('웹 페이지에서만 번역할 수 있어요'); return Promise.resolve(); }
    if (this.img.busy(wc.id)) { this.img.cancel(wc.id); return Promise.resolve(); }
    return this.img.translateOne(wc, lang, url);
  }
  // 자막 번역: 짧은 글 묶음을 번역한다(플레이어에서 부름). 반환: { out: [...] } | { error }
  async translateLines(texts, langKey) {
    const list = (Array.isArray(texts) ? texts : []).slice(0, 60).map((t) => String(t == null ? '' : t).slice(0, 600));
    if (!list.length) return { out: [] };
    const k = this.tr.d.pick();
    if (!k) return { error: 'Gemini API 키가 필요해요 (AI 창 설정에서 키를 넣어 주세요)' };
    const r = await this.tr._batch(list.map((t, i) => ({ i, t })), Tr.lang(langKey), { cancelled: false, client: null }, k);
    return r.error ? { error: r.error } : { out: r.out };
  }
  untranslateImage(wc, url) { return this.img.clear(wc, url).then((n) => { this.d.toast(n > 0 ? '이미지 번역을 해제했어요' : '해제할 번역이 없어요'); }); }
  imageTranslated(wc, url) { return this.img.has(wc, url); }
  trForget(id) { this.tr.forget(id); }

  // ───────── 설정 · 키 ─────────
  settings() { return Object.assign({}, SETTING_DEFAULTS, this.d.store.get('aiSettings') || {}); }
  setSetting(k, v) {
    if (!(k in SETTING_DEFAULTS)) return;
    const s = this.settings();
    s[k] = k === 'width' ? Math.max(MIN_W, Math.min(MAX_W, Math.round(Number(v) || DEF_W))) : !!v;
    this.d.store.set('aiSettings', s);
    if (k === 'width') this.d.relayout();
    if (k === 'search') this.g.search.clearRest();
  }
  keys() { return (this.d.store.get('aiKeys') || []).map((x) => this.vault.decrypt(x)).filter(Boolean); }
  addKey(raw) {
    const k = String(raw || '').trim();
    if (!/^[A-Za-z0-9_\-]{20,120}$/.test(k)) return { ok: false, error: 'API 키 모양이 아니에요. 구글 AI 스튜디오에서 받은 키(AIza…)를 그대로 붙여 넣어 주세요' };
    const list = this.keys();
    if (list.indexOf(k) >= 0) return { ok: false, error: '이미 등록한 키예요' };
    if (list.length >= 10) return { ok: false, error: '키는 10개까지 넣을 수 있어요' };
    this.d.store.set('aiKeys', (this.d.store.get('aiKeys') || []).concat(this.vault.encrypt(k)));
    this.g.pool.pick(this.keys());
    this.modelSync.refreshIfStale(k);
    return { ok: true };
  }
  removeKey(i) {
    const enc = (this.d.store.get('aiKeys') || []).slice();
    if (i >= 0 && i < enc.length) { enc.splice(i, 1); this.d.store.set('aiKeys', enc); this.g.pool.pick(this.keys()); }
  }
  // 키가 쓸 수 있는지: 모델 목록을 한 번 받아 본다
  async testKey(i) {
    const k = this.keys()[i];
    if (!k) return { ok: false, error: '없는 키예요' };
    try {
      const list = await this.modelSync._fetchList(k);
      return list ? { ok: true } : { ok: false, error: '키가 거부됐거나 연결할 수 없어요' };
    } catch (e) { return { ok: false, error: G.networkErrorMessage(e) }; }
  }
  mask(k) { return k.length > 10 ? k.slice(0, 4) + '…' + k.slice(-4) : '••••'; }
  info() {
    const keys = this.keys(); this.g.pool.pick(keys);
    const u = this.usage.summary(keys);
    const rest = this.g.pool.restingSummary();
    return {
      keys: keys.map((k, i) => ({ mask: this.mask(k), status: this.g.pool.statusOf(k), today: u.perKey[i] })),
      settings: this.settings(),
      models: { lite: G.labelOf(this.g.models.lite()), hydrogen: G.labelOf(this.g.models.hydrogen()) },
      resting: rest, keyNo: this.g.pool.currentNo(), keyCount: keys.length,
      usage: { today: u.today, tokens: formatTokens(u.today.tokIn + u.today.tokOut), byModel: u.byModel.map((m) => ({ model: G.labelOf(m.model), calls: m.tally.calls, limit: m.tally.limit, errors: m.tally.errors, tokens: formatTokens(m.tally.tokIn + m.tally.tokOut) })),
        days: u.days.map((x) => ({ day: x.day, calls: x.tally.calls, limit: x.tally.limit })), resetIn: formatDuration(u.resetIn), any: u.any },
      chats: this.chats.list(),
    };
  }

  // ───────── 창 · 배치 ─────────
  dockWidth() { return this.open ? this.settings().width : 0; }
  setOpen(on) {
    on = !!on;
    if (on === this.open) { if (on) this.focus(); return; }
    this.open = on;
    const w = this.d.win();
    if (!w || w.isDestroyed()) return;
    if (on) { w.contentView.addChildView(this.view); this.view.setVisible(true); this.d.relayout(); this.send({ type: 'opened', info: this.info() }); this.focus(); }
    else { this.view.setVisible(false); try { w.contentView.removeChildView(this.view); } catch (e) { /* */ } this.d.relayout(); const t = this.d.tabs.activeWc(); if (t && !t.isDestroyed()) t.focus(); }
    this.d.onChange();
  }
  toggle() { this.setOpen(!this.open); }
  focus() { if (this.open) { try { this.view.webContents.focus(); } catch (e) { /* */ } this.send({ type: 'focus' }); } }
  // 웹 화면 옆 자리: 창 오른쪽 끝에 dockWidth 만큼
  bounds(contentW, top, h) { const aw = this.dockWidth(); return { x: Math.max(0, contentW - aw), y: top, width: aw, height: Math.max(0, h) }; }
  relayout(contentW, top, h) { if (!this.open) return; this.view.setBounds(this.bounds(contentW, top, h)); }
  front() { const w = this.d.win(); if (this.open && w && !w.isDestroyed()) { try { w.contentView.addChildView(this.view); } catch (e) { /* */ } } }
  // 선택한 글로 묻기(우클릭 메뉴) · 페이지 요약
  ask(text, opts) { this.setOpen(true); this.send({ type: 'prefill', text: String(text || ''), send: !!(opts && opts.send) }); }
  sendState(s) { if (this.open) this.send({ type: 'state', state: s }); }

  send(msg) { if (this.ready) { try { this.view.webContents.send('ai:event', msg); } catch (e) { /* 닫히는 중 */ } } else this.queue.push(msg); }
  emit(msg) { this.send(msg); }

  // ───────── 대화 ─────────
  newChat() { if (this.busy) this.stop(); this.chat = { id: null, messages: [], agent: false }; this.lastWasAgent = false; this.g.auto.resetChat(); return true; }
  loadChat(id) { const c = this.chats.get(id); if (!c) return null; if (this.busy) this.stop(); this.chat = { id: c.id, messages: c.messages, agent: !!c.agent, title: c.title }; this.lastWasAgent = !!c.agent; this.g.auto.resetChat(); return c; }
  stop() { if (this.runner) this.runner.cancel(); if (this.client) this.client.cancel(); for (const [, f] of this.pending) f(false); this.pending.clear(); }
  _history(limitLast) {
    const out = []; let chars = 0;
    for (let i = this.chat.messages.length - 1; i >= 0; i--) {
      const m = this.chat.messages[i];
      if (m.error || !m.text) continue;
      chars += m.text.length; if (chars > HISTORY_CHARS && out.length) break;
      out.unshift({ role: m.role === 'model' ? 'model' : 'user', text: m.text });
    }
    while (out.length && out[0].role === 'model') out.shift(); // 첫 줄은 사용자 말이어야 한다
    return out.slice(-(limitLast || 40));
  }
  async _snapshot() {
    const wc = this.d.tabs.activeWc();
    const url = wc && !wc.isDestroyed() ? wc.getURL() : '';
    if (!url || !/^https?:/i.test(url)) return null;
    try { return await wc.executeJavaScript(PT.call(PT.snapshotFn, 15000), true); } catch (e) { return null; }
  }
  // 질문 하나. req: { text, shown?, search?(true/false/null), attach:[{name,mime,base64}], regen? }
  async ask1(req) {
    if (this.busy) return { ok: false, error: '아직 답하는 중이에요' };
    const s = this.settings(), keys = this.keys();
    const text = String(req.text || '').trim();
    if (!text && !(req.attach && req.attach.length)) return { ok: false };
    if (!keys.length) { this.emit({ type: 'error', code: 'nokey', text: 'API 키가 없어요. ⚙ 설정에서 구글 AI 스튜디오의 무료 API 키를 넣어 주세요' }); return { ok: false }; }
    this.busy = true; this.d.onChange();
    const attach = (req.attach || []).slice(0, MAX_ATTACH).filter((a) => a && typeof a.base64 === 'string' && a.base64.length * 0.75 <= MAX_ATTACH_BYTES && typeof a.mime === 'string');
    const user = { role: 'user', text: text || '(첨부 파일을 봐 줘)', shown: req.shown || undefined, attach: attach.map((a) => a.name || '파일') };
    const reply = { role: 'model', text: '', thought: '', thinkMs: 0, queries: [], sources: [], tools: [], model: '' };
    if (req.regen) { while (this.chat.messages.length && this.chat.messages[this.chat.messages.length - 1].role === 'model') this.chat.messages.pop(); }
    else this.chat.messages.push(user);
    this.chat.messages.push(reply);
    const t0 = Date.now(); let first = true;
    const hist = this._history();
    if (!req.regen && hist.length && hist[hist.length - 1].role === 'user') hist[hist.length - 1].images = attach.map((a) => ({ mime: a.mime, base64: a.base64, name: a.name }));
    const lastUser = hist[hist.length - 1];
    if (req.regen && lastUser && req.attach) lastUser.images = attach.map((a) => ({ mime: a.mime, base64: a.base64, name: a.name }));
    this.emit({ type: 'start', regen: !!req.regen });
    const snap = s.pageRef ? await this._snapshot() : null;
    const useSearch = req.search == null ? s.search : !!req.search;
    const route = s.agent && (Routing.wantsAuto(text) && s.auto ? 'auto' : (Routing.useAgent(text) || Routing.isFollowUp(text, this.lastWasAgent)) && !attach.length ? 'agent' : 'chat');
    const key = this.g.pool.pick(keys);
    const onText = (d) => { if (first) { first = false; reply.thinkMs = Date.now() - t0; this.emit({ type: 'think-ms', ms: reply.thinkMs }); } reply.text += d; this.emit({ type: 'text', delta: d }); };
    const onThought = (d) => { reply.thought += d; this.emit({ type: 'thought', delta: d }); };
    const setModel = (m) => { reply.model = G.labelOf(m); this.emit({ type: 'model', label: reply.model, reason: this.g.auto.lastReason }); };
    let res;
    try {
      if (route === 'chat') {
        const model = this.g.auto.forChat(text, this.chat.messages.length, !!snap, attach.filter((a) => /^image\//.test(a.mime)).length);
        this.g.auto.noteRule(model);
        setModel(model);
        this.client = new GeminiClient({ g: this.g, usage: this.usage, modelSync: this.modelSync, fetch: this.d.fetch });
        const system = Prompt.chatSystem(snap, { search: useSearch, agentEnabled: s.agent, chatOnly: true, attachNames: attach.map((a) => a.name || '파일') });
        res = await this.client.stream({ key, model, system, history: hist, search: useSearch, includeThoughts: s.thoughts, searchOptional: true,
          cb: { text: onText, thought: onThought, model: (m) => setModel(m),
            grounding: (q, src) => { reply.queries = q; reply.sources = src; this.emit({ type: 'grounding', queries: q, sources: s.sources ? src : [] }); },
            searchSkipped: () => this.emit({ type: 'notice', text: '웹 검색 한도가 차서 이번에는 검색 없이 답했어요' }),
            searchDropped: () => this.emit({ type: 'notice', text: '이 모델은 웹 검색을 받지 못해서 검색 없이 답했어요' }) } });
        this.lastWasAgent = false; this.chat.agent = false;
      } else {
        const model = this.g.auto.forChat(text, this.chat.messages.length, !!snap, 0);
        this.g.auto.noteRule(model, '앱 조작 질문');
        setModel(model);
        this.client = new GeminiClient({ g: this.g, usage: this.usage, modelSync: this.modelSync, fetch: this.d.fetch });
        this.runner = new AgentRunner({ client: this.client, g: this.g, host: this._agentHost(key), confirm: (card) => this._confirm(card),
          emit: (ev) => {
            if (ev.type === 'text') return onText(ev.delta);
            if (ev.type === 'thought') return onThought(ev.delta);
            if (ev.type === 'model') return setModel(ev.model);
            if (ev.type === 'tool') this._toolEvent(reply, ev);
          } });
        res = await this.runner.run({ key, model, history: hist, question: text, auto: route === 'auto', thoughts: s.thoughts,
          system: Prompt.chatSystem(snap, { search: false, agentEnabled: true, chatOnly: false }) });
        this.runner = null;
        this.lastWasAgent = true; this.chat.agent = true;
      }
    } catch (e) { res = { ok: false, error: '오류가 났어요: ' + String((e && e.message) || e) }; }
    this.busy = false; this.client = null;
    if (res && res.ok === false && res.error) { reply.error = res.error; this.emit({ type: 'error', text: res.error }); }
    if (!reply.text && !reply.error && !(res && res.cancelled) && !reply.tools.length) { reply.error = '응답이 비어 있어요'; this.emit({ type: 'error', text: reply.error }); }
    if (!reply.thinkMs) reply.thinkMs = Date.now() - t0;
    if (!reply.text && !reply.error && !reply.tools.length) this.chat.messages.pop(); else if (!reply.text && reply.error) { /* 오류만 남긴다 */ }
    this.chat.id = this.chats.save({ id: this.chat.id, title: this.chat.title, messages: this.chat.messages, agent: this.chat.agent });
    this.emit({ type: 'done', cancelled: !!(res && res.cancelled), thinkMs: reply.thinkMs, chats: this.chats.list(), id: this.chat.id, keyNo: this.g.pool.currentNo(), keyCount: keys.length });
    this.d.onChange();
    return { ok: true };
  }
  _toolEvent(reply, ev) {
    const label = TOOL_LABEL[ev.name] || ev.name;
    if (ev.status === 'run') { const t = { id: ++this.seq, name: ev.name, label, status: 'run', detail: this._detail(ev) }; reply.tools.push(t); this.emit({ type: 'tool', tool: t }); return; }
    for (let i = reply.tools.length - 1; i >= 0; i--) if (reply.tools[i].name === ev.name && reply.tools[i].status === 'run') { reply.tools[i].status = ev.status; if (ev.note) reply.tools[i].note = ev.note; this.emit({ type: 'tool', tool: reply.tools[i] }); break; }
  }
  _detail(ev) {
    const a = ev.args || {};
    const v = a.url || a.target || a.query || a.source || a.name || (a.number != null ? a.number + '번 탭' : '') || (a.element != null ? '요소 ' + a.element : '') || '';
    return String(v).slice(0, 80);
  }
  _confirm(card) {
    return new Promise((resolve) => {
      const id = ++this.seq;
      this.pending.set(id, (ok) => { this.pending.delete(id); resolve(!!ok); });
      this.emit({ type: 'confirm', id, tool: card.tool, text: card.text });
      this.focus();
    });
  }

  // ───────── 도구가 만지는 앱 ─────────
  _agentHost(key) {
    const d = this.d, T = d.tabs, self = this;
    const num = (n) => { const list = T.all(); const i = (n == null ? list.findIndex((t) => t.active) : n - 1); return list[i] || null; };
    const wcOf = (n) => { const t = num(n); return t ? T.wc(t.id) : null; };
    const run = async (wc, code) => { if (!wc || wc.isDestroyed()) throw new Error('탭을 찾지 못했어요'); const u = wc.getURL(); if (!/^https?:/i.test(u)) throw new Error('이 화면(새 탭 · 내부 페이지)에서는 웹 조작을 할 수 없어요'); return wc.executeJavaScript(code, true); };
    const pickLimit = (a) => a.slice(0, 40);
    return {
      listTabs: () => T.all().map((t, i) => ({ number: i + 1, title: t.title || '', url: t.url || '', active: !!t.active, incognito: !!t.incognito, loading: !!t.loading })),
      readPage: async (tab, all) => { const wc = wcOf(tab); const r = await run(wc, PT.call(PT.readPageFn, { all: !!all, maxText: 9000, maxEls: 120 })); if (!tab) T.markRead(); return r; },
      readTabs: async (nums) => {
        const list = T.all(), picks = (nums && nums.length ? nums : list.map((_t, i) => i + 1).slice(0, 8));
        const out = [];
        for (const n of picks) {
          const t = list[n - 1]; if (!t) { out.push({ tab: n, error: '그 번호의 탭이 없어요' }); continue; }
          const wc = T.wc(t.id);
          try { const r = await run(wc, PT.call(PT.snapshotFn, 6000)); out.push({ tab: n, title: r.title, url: r.url, text: r.text, truncated: r.truncated }); }
          catch (e) { out.push({ tab: n, title: t.title, url: t.url, error: t.lazy ? '아직 불러오지 않은 탭이에요' : String(e.message || e) }); }
        }
        return out;
      },
      webSearch: async (q) => {
        const c = new GeminiClient({ g: self.g, usage: self.usage, modelSync: self.modelSync, fetch: d.fetch });
        let answer = ''; let sources = [];
        const r = await c.stream({ key: self.g.pool.pick(self.keys()), model: self.g.models.lite(), system: '당신은 웹 검색 도구입니다. 질문에 답하기 전에 반드시 구글 검색을 실행하고, 검색 결과에 있는 사실만 한국어로 간결하게 정리해 답하세요. 출처 번호는 쓰지 마세요.',
          history: [{ role: 'user', text: q }], search: true, searchOptional: false, thinking: 'minimal',
          cb: { text: (t) => { answer += t; }, grounding: (_q, s) => { sources = s; } } });
        if (!r.ok) return { error: r.error };
        if (sources.length) self.emit({ type: 'grounding', queries: [q], sources: self.settings().sources ? sources : [] });
        return { answer: answer.slice(0, 6000), sources: sources.slice(0, 6) };
      },
      getSettings: () => d.prefs(),
      searchHistory: (q, limit) => { const s = String(q).toLowerCase(); return pickLimit(d.data.history().filter((h) => !s || (h.url + ' ' + h.title).toLowerCase().indexOf(s) >= 0).slice(0, Math.min(40, limit))).map((h) => ({ url: h.url, title: h.title, time: new Date(h.time).toISOString() })); },
      searchBookmarks: (q, limit) => {
        const s = String(q).toLowerCase(), fs = d.data.folders('bm');
        return d.data.bookmarks().map((b) => ({ url: b.url, title: b.title, folder: (fs.filter((f) => f.id === b.folderId)[0] || {}).name || '' })).filter((b) => !s || (b.url + ' ' + b.title + ' ' + b.folder).toLowerCase().indexOf(s) >= 0).slice(0, Math.min(60, limit));
      },
      bookmarkFolders: () => d.data.folders('bm').map((f) => f.name),
      listDownloads: () => { const sn = d.downloads.snapshot(); return { active: sn.active.map((a) => ({ id: a.id, name: a.name, received: a.received, total: a.total, paused: a.paused })), done: sn.done.slice(0, 30).map((x) => ({ name: x.name, size: x.size, time: new Date(x.time).toISOString() })) }; },
      listExtensions: () => (d.ext.list() || []).map((e) => ({ id: e.id, name: e.name, version: e.version, enabled: e.enabled, theme: !!e.theme })),
      listWindows: () => T.windows(),
      openTab: (target, o) => { const t = T.open(target, o); return { ok: true, number: t }; },
      closeTab: (n) => { const t = num(n); if (!t) return { error: '그 번호의 탭이 없어요' }; T.close(t.id); return { ok: true, closed: t.title || t.url }; },
      switchTab: (n) => { const t = num(n); if (!t) return { error: '그 번호의 탭이 없어요' }; T.activate(t.id); return { ok: true }; },
      moveTab: (n, to) => { const t = num(n); if (!t) return { error: '그 번호의 탭이 없어요' }; T.move(t.id, Math.max(1, to) - 1); return { ok: true }; },
      duplicateTab: (n) => { const t = num(n); if (!t) return { error: '그 번호의 탭이 없어요' }; T.duplicate(t.id); return { ok: true }; },
      reopenClosed: () => { T.reopen(); return { ok: true }; },
      goTo: (target) => { T.go(target); return { ok: true }; },
      pageNav: (act) => { T.nav(act); return { ok: true }; },
      openScreen: (s) => { const m = { history: 'panel:history', bookmarks: 'panel:bookmarks', downloads: 'panel:downloads', adstats: 'panel:adstats', secstats: 'panel:secstats', extensions: 'dialog:extensions' }[s]; if (!m) return { error: '모르는 화면이에요' }; d.cmd(m); return { ok: true, opened: s }; },
      addBookmark: (url, title, folder) => {
        const wc = T.activeWc(); url = url || (wc && !wc.isDestroyed() ? wc.getURL() : ''); title = title || (wc && !wc.isDestroyed() ? wc.getTitle() : '');
        if (!/^https?:/i.test(url || '')) return { error: '북마크에 추가할 수 없는 주소예요' };
        let fid = 0;
        if (folder && !/^(없음|none)$/i.test(folder)) { const fs = d.data.folders('bm'); const f = fs.filter((x) => x.name === folder)[0] || d.data.addFolder('bm', String(folder).slice(0, 30)); fid = f.id; }
        d.data.saveBookmark(url, String(title || '').slice(0, 200), fid); return { ok: true, url };
      },
      deleteBookmarks: (urls) => { const set = new Set(urls); const ids = d.data.bookmarks().filter((b) => set.has(b.url)).map((b) => b.id); if (!ids.length) return { error: '그 주소의 북마크가 없어요' }; d.data.removeBookmarks(ids); return { ok: true, deleted: ids.length }; },
      deleteHistory: (urls) => { const n = d.data.history().length; d.data.removeHistory(urls); return { ok: true, deleted: n - d.data.history().length }; },
      changeSetting: (name, value) => d.changeSetting(name, value),
      setExtension: async (id, on) => { const e = (d.ext.list() || []).filter((x) => x.id === id)[0]; if (!e) return { error: '그 확장 프로그램이 없어요' }; await d.ext.setEnabled(id, on); return { ok: true }; },
      installExtension: async (src) => { const r = await d.ext.installStore(src); return r && r.ok ? { ok: true, installed: r.ext && r.ext.name } : { error: (r && r.error) || '설치하지 못했어요' }; },
      scrollPage: (dir, amount) => run(wcOf(null), PT.call(PT.scrollFn, dir, amount)),
      elementInfo: async (n) => { try { return await run(wcOf(null), PT.call(PT.elementFn, n)); } catch (e) { return null; } },
      clickElement: (n) => run(wcOf(null), PT.call(PT.clickFn, n)),
      fillField: (n, text, submit) => run(wcOf(null), PT.call(PT.fillFn, n, text, submit)),
    };
  }

  // ───────── IPC (패널에서만) ─────────
  _register() {
    const from = (e) => e.sender === this.view.webContents;
    ipcMain.handle('ai:info', (e) => (from(e) ? this.info() : null));
    ipcMain.handle('ai:send', (e, req) => (from(e) && req ? this.ask1(req) : null));
    ipcMain.on('ai:stop', (e) => { if (from(e)) this.stop(); });
    ipcMain.handle('ai:new', (e) => { if (from(e)) { this.newChat(); return { chats: this.chats.list() }; } return null; });
    ipcMain.handle('ai:load', (e, id) => (from(e) ? this.loadChat(String(id)) : null));
    ipcMain.handle('ai:delete', (e, id) => { if (!from(e)) return null; this.chats.remove(String(id)); if (this.chat.id === id) this.newChat(); return this.chats.list(); });
    ipcMain.handle('ai:rename', (e, m) => { if (!from(e) || !m) return null; this.chats.rename(String(m.id), String(m.title || '')); return this.chats.list(); });
    ipcMain.handle('ai:clear-chats', (e) => { if (!from(e)) return null; this.chats.clear(); this.newChat(); return []; });
    ipcMain.on('ai:confirm', (e, m) => { if (from(e) && m) { const f = this.pending.get(m.id); if (f) f(!!m.ok); } });
    ipcMain.handle('ai:key-add', (e, k) => (from(e) ? Object.assign(this.addKey(k), { info: this.info() }) : null));
    ipcMain.handle('ai:key-remove', (e, i) => { if (!from(e)) return null; this.removeKey(Number(i)); return this.info(); });
    ipcMain.handle('ai:key-test', (e, i) => (from(e) ? this.testKey(Number(i)) : null));
    ipcMain.handle('ai:setting', (e, m) => { if (!from(e) || !m) return null; this.setSetting(String(m.key), m.value); return this.info(); });
    ipcMain.handle('ai:clear-usage', (e) => { if (!from(e)) return null; this.usage.clear(); return this.info(); });
    ipcMain.on('ai:resize', (e, m) => { if (from(e) && m && typeof m.screenX === 'number') { const w = this.d.win(); if (!w) return; const cb = w.getContentBounds(); this.setSetting('width', cb.x + cb.width - m.screenX); } });
    ipcMain.on('ai:open-url', (e, u) => { if (from(e) && /^https?:\/\//i.test(String(u))) this.d.tabs.open(String(u), { background: false }); });
    ipcMain.on('ai:external', (e, u) => { if (from(e) && /^https:\/\/aistudio\.google\.com\//i.test(String(u))) shell.openExternal(String(u)); });
    ipcMain.on('ai:close', (e) => { if (from(e)) this.setOpen(false); });
    ipcMain.on('ai:page-ask', (e, m) => { if (from(e) && m) this.ask(m.text, { send: true }); });
    ipcMain.handle('ai:page-title', (e) => { if (!from(e)) return null; const wc = this.d.tabs.activeWc(); return wc && !wc.isDestroyed() ? { title: wc.getTitle(), url: wc.getURL() } : null; });
  }
}
module.exports = { AiHost, MIN_W, MAX_W, DEF_W, SETTING_DEFAULTS };
