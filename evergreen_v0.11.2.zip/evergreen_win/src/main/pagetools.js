'use strict';
// 웹 페이지 안에서 돌리는 스크립트들 (executeJavaScript 로 지금 탭에 넣는다). 함수 그대로 문자열로 만들어 보내므로 바깥 변수를 쓰지 않는다.
//  - snapshot: 질문에 같이 보낼 페이지 글 (제목 · 주소 · 본문 · 선택한 글)
//  - readPage: 글 + 누를 수 있는 요소 목록(번호). 번호는 마지막으로 읽은 결과에서만 맞다
//  - click / fill / scroll: 번호로 조작
function snapshotFn(maxChars) {
  var sel = ''; try { sel = String(window.getSelection() || '').trim().slice(0, 4000); } catch (e) { /* */ }
  var t = '';
  try {
    var root = document.querySelector('article, main, [role=main]') || document.body;
    t = (root && root.innerText) || '';
    if (t.length < 400 && document.body) t = document.body.innerText || t;
  } catch (e) { /* */ }
  t = t.replace(/\n{3,}/g, '\n\n').replace(/[ \t]+/g, ' ').trim();
  return { url: location.href, title: document.title || '', text: t.slice(0, maxChars), selection: sel, truncated: t.length > maxChars };
}
function readPageFn(o) {
  var all = !!o.all, maxText = o.maxText, maxEls = o.maxEls;
  var vw = window.innerWidth, vh = window.innerHeight;
  function visible(el) {
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || +cs.opacity === 0) return false;
    if (!all && (r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw)) return false;
    return true;
  }
  function label(el) {
    var l = el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('alt') || el.getAttribute('placeholder') || '';
    if (!l && el.id) { var lb = document.querySelector('label[for="' + (window.CSS && CSS.escape ? CSS.escape(el.id) : el.id) + '"]'); if (lb) l = lb.innerText; }
    if (!l) l = el.innerText || el.value || '';
    if (!l) { var im = el.querySelector && el.querySelector('img[alt]'); if (im) l = im.getAttribute('alt'); }
    return String(l).replace(/\s+/g, ' ').trim().slice(0, 80);
  }
  var sel = 'a[href], button, input:not([type=hidden]), select, textarea, [role=button], [role=link], [role=tab], [role=checkbox], [role=menuitem], [role=switch], [contenteditable=""], [contenteditable=true], summary, [onclick]';
  var els = [], list = [], seen = new Set();
  Array.prototype.forEach.call(document.querySelectorAll(sel), function (el) {
    if (seen.has(el) || list.length >= maxEls || !visible(el)) return;
    seen.add(el); els.push(el);
    var tag = el.tagName.toLowerCase(), type = (el.getAttribute('type') || '').toLowerCase();
    var item = { n: els.length, tag: tag, label: label(el) };
    if (tag === 'input') item.type = type || 'text';
    if (tag === 'a') item.href = (el.href || '').slice(0, 120);
    if (tag === 'select') item.value = el.value;
    if ((tag === 'input' || tag === 'textarea') && type !== 'password' && type !== 'checkbox' && type !== 'radio') item.value = String(el.value || '').slice(0, 60);
    if (type === 'checkbox' || type === 'radio') item.checked = !!el.checked;
    if (el.disabled) item.disabled = true;
    list.push(item);
  });
  window.__evAi = { els: els };
  var text = '';
  try { text = (document.body.innerText || '').replace(/\n{3,}/g, '\n\n').replace(/[ \t]+/g, ' ').trim(); } catch (e) { /* */ }
  return { url: location.href, title: document.title || '', text: text.slice(0, maxText), truncated: text.length > maxText, elements: list, scrollY: Math.round(window.scrollY), pageHeight: document.documentElement.scrollHeight, viewHeight: vh };
}
function elementFn(n) {
  var st = window.__evAi, el = st && st.els && st.els[n - 1];
  if (!el || !el.isConnected) return null;
  var l = el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('placeholder') || el.innerText || el.value || '';
  return { label: String(l).replace(/\s+/g, ' ').trim().slice(0, 80), type: (el.getAttribute('type') || el.tagName || '').toLowerCase() };
}
function clickFn(n) {
  var st = window.__evAi, el = st && st.els && st.els[n - 1];
  if (!el || !el.isConnected) return { error: '그 번호의 요소를 찾지 못했어요. read_page 로 다시 읽어 주세요.' };
  try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) { /* */ }
  var r = el.getBoundingClientRect();
  var o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
  try { el.dispatchEvent(new PointerEvent('pointerdown', o)); el.dispatchEvent(new MouseEvent('mousedown', o)); el.dispatchEvent(new PointerEvent('pointerup', o)); el.dispatchEvent(new MouseEvent('mouseup', o)); } catch (e) { /* */ }
  el.click();
  return { ok: true, clicked: String(el.innerText || el.getAttribute('aria-label') || el.tagName).replace(/\s+/g, ' ').trim().slice(0, 60), note: '이동 · 변화가 있으면 read_page 로 다시 읽으세요' };
}
function fillFn(n, text, submit) {
  var st = window.__evAi, el = st && st.els && st.els[n - 1];
  if (!el || !el.isConnected) return { error: '그 번호의 요소를 찾지 못했어요. read_page 로 다시 읽어 주세요.' };
  var tag = el.tagName.toLowerCase();
  try { el.scrollIntoView({ block: 'center' }); el.focus(); } catch (e) { /* */ }
  if (tag === 'select') {
    var opt = Array.prototype.filter.call(el.options, function (o) { return o.text.trim() === text || o.value === text; })[0];
    if (!opt) return { error: '그 값의 선택지가 없어요: ' + Array.prototype.map.call(el.options, function (o) { return o.text.trim(); }).slice(0, 12).join(', ') };
    el.value = opt.value; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
    return { ok: true };
  }
  if (el.isContentEditable) { el.textContent = text; el.dispatchEvent(new InputEvent('input', { bubbles: true, data: text })); }
  else if (tag === 'input' || tag === 'textarea') {
    var proto = tag === 'input' ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
    var setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, text);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  } else return { error: '글을 넣을 수 있는 칸이 아니에요 (' + tag + ')' };
  if (submit) {
    var ko = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
    el.dispatchEvent(new KeyboardEvent('keydown', ko)); el.dispatchEvent(new KeyboardEvent('keypress', ko)); el.dispatchEvent(new KeyboardEvent('keyup', ko));
    var f = el.form; if (f) { try { f.requestSubmit ? f.requestSubmit() : f.submit(); } catch (e) { /* */ } }
  }
  return { ok: true, submitted: !!submit };
}
function scrollFn(dir, amount) {
  var h = window.innerHeight, a = (typeof amount === 'number' && amount > 0 ? amount : 0.8) * h, y0 = window.scrollY;
  if (dir === 'top') window.scrollTo({ top: 0 }); else if (dir === 'bottom') window.scrollTo({ top: document.documentElement.scrollHeight });
  else window.scrollBy({ top: dir === 'up' ? -a : a });
  return { ok: true, scrollY: Math.round(window.scrollY), moved: Math.round(window.scrollY - y0), pageHeight: document.documentElement.scrollHeight, viewHeight: h };
}

// ── 페이지 번역 (7단계 이후) ──
// 글 노드를 모아 번호를 매기고(window.__evTr), 번역이 오면 노드 글을 바꾼다. 원문은 노드마다 기억해 두었다가 되돌린다.
function trCollectFn(maxNodes) {
  var SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, CODE: 1, PRE: 1, TEXTAREA: 1, INPUT: 1, SELECT: 1, SVG: 1, CANVAS: 1, KBD: 1, SAMP: 1, MATH: 1 };
  var st = window.__evTr = window.__evTr || { nodes: [], orig: new Map(), on: false };
  st.nodes = []; var out = [];
  var w = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT, null), n;
  while ((n = w.nextNode()) && out.length < maxNodes) {
    var p = n.parentElement; if (!p || SKIP[p.tagName] || SKIP[String(p.tagName).toUpperCase()]) continue;
    if (p.closest('[contenteditable=""],[contenteditable=true],[translate=no],.notranslate')) continue;
    var raw = n.nodeValue, t = raw.replace(/\s+/g, ' ').trim(); if (t.length < 2) continue;
    var r = p.getBoundingClientRect(); var cs = getComputedStyle(p);
    if (cs.display === 'none' || cs.visibility === 'hidden') continue;
    if (!st.orig.has(n)) st.orig.set(n, raw); else if (st.orig.get(n) !== raw && !st.done) { /* 페이지가 바꾼 글은 새 원문으로 */ }
    st.nodes.push(n); out.push({ i: st.nodes.length - 1, t: t, y: Math.round(r.top + window.scrollY) });
  }
  return out;
}
function trApplyFn(pairs) {
  var st = window.__evTr; if (!st) return 0; var c = 0;
  pairs.forEach(function (p) {
    var n = st.nodes[p[0]]; if (!n || !n.parentNode) return;
    var raw = st.orig.has(n) ? st.orig.get(n) : n.nodeValue;
    var lead = (raw.match(/^\s*/) || [''])[0], trail = (raw.match(/\s*$/) || [''])[0];
    n.nodeValue = lead + String(p[1]).trim() + trail; c++;
  });
  st.on = true; document.documentElement.setAttribute('data-ev-translated', '1'); return c;
}
function trRestoreFn() {
  var st = window.__evTr; if (!st) return 0; var c = 0;
  st.orig.forEach(function (raw, n) { if (n.parentNode) { n.nodeValue = raw; c++; } });
  st.orig = new Map(); st.nodes = []; st.on = false; document.documentElement.removeAttribute('data-ev-translated'); return c;
}
function trStateFn() { var st = window.__evTr; return { on: !!(st && st.on) }; }
// ── 이미지 속 글자 번역 (v0.9.0) ──
// 안드로이드 PageTranslator 의 IMG_COLLECT_JS(덮개 층)를 그대로 옮기고, 글자 위치는 Gemini 가 알려 주는 대로 쓴다.
// 번역문은 페이지 글 안이 아니라 문서 맨 끝의 따로 둔 층에 올려서 이미지 위치를 따라다니게 한다. 이 함수들은 페이지 안에서 돌기 때문에 서로 밖의 것을 쓰지 않는다.
function imgCollectFn(max) {
  try {
    if (!window.__evImgInit) {
      window.__evImgInit = 1;
      (function () {
        var G = [], root = null, pend = 0;
        function ensureRoot() {
          if (root && root.isConnected) return root;
          root = document.createElement('div'); root.id = '__ev_img_root'; root.className = 'notranslate'; root.setAttribute('translate', 'no');
          root.style.cssText = 'position:absolute;left:0;top:0;width:0;height:0;overflow:visible;z-index:2147483000;pointer-events:none;';
          document.documentElement.appendChild(root); return root;
        }
        function fit(b, s) {
          var w = Math.max(4, b.w * s), h = Math.max(4, b.h * s), st = b.el.style;
          st.left = (b.x * s) + 'px'; st.top = (b.y * s) + 'px'; st.width = w + 'px'; st.height = h + 'px';
          var cap = b.fs ? Math.max(10, b.fs * s * 1.5) : 56, sp = b.sp;
          function run(v) {
            sp.style.writingMode = v ? 'vertical-rl' : 'horizontal-tb'; sp.style.textOrientation = v ? 'upright' : 'mixed';
            sp.style.width = v ? 'auto' : '100%'; sp.style.height = v ? '100%' : 'auto';
            var lo = 5, hi = Math.max(6, Math.min((v ? w : h) * 0.9, 56, cap)), m, i;
            for (i = 0; i < 7; i++) { m = (lo + hi) / 2; sp.style.fontSize = m + 'px'; if (sp.offsetHeight <= h - 2 && sp.scrollWidth <= w + 1) lo = m; else hi = m; }
            return lo;
          }
          var best = run(false), vert = false;
          // 한글은 가로로 쓰는 글이라, 긴 문장을 한 글자씩 세워 쓰면 어색하다 → 짧은 말(6글자 이하)만 세로로 쓴다
          if (h > w * 1.5 && sp.textContent.replace(/\s/g, '').length <= 6) { var vs = run(true); if (vs > best * 1.15) { vert = true; best = vs; } }
          if (!vert) run(false);
          sp.style.fontSize = best + 'px';
        }
        function place() {
          pend = 0; var sx = window.pageXOffset || 0, sy = window.pageYOffset || 0;
          for (var i = 0; i < G.length; i++) {
            var g = G[i], im = g.img, st = g.el.style;
            if (!im.isConnected) { st.display = 'none'; continue; }
            var r = im.getBoundingClientRect();
            if (r.width < 2 || r.height < 2) { st.display = 'none'; continue; }
            st.display = 'block'; st.left = (r.left + sx) + 'px'; st.top = (r.top + sy) + 'px'; st.width = r.width + 'px'; st.height = r.height + 'px';
            if (Math.abs(r.width - g.lw) > 1.5) { g.lw = r.width; var s = r.width / g.nw; for (var j = 0; j < g.boxes.length; j++) fit(g.boxes[j], s); }
          }
        }
        function sched() { if (!pend) { pend = 1; requestAnimationFrame(place); } }
        window.addEventListener('scroll', sched, true); window.addEventListener('resize', sched);
        setInterval(function () { if (G.length) sched(); }, 800);
        var E = window.__evImgEng = {};
        // 번역하는 동안 이미지를 살짝 어둡게 (끝나면 원래대로)
        E.busy = function (img, on) {
          try {
            if (on) { if (img.__evFilter === undefined) img.__evFilter = img.style.filter; img.style.transition = 'filter .35s'; img.style.filter = 'saturate(.55) brightness(.88)'; }
            else if (img.__evFilter !== undefined) { img.style.filter = img.__evFilter; delete img.__evFilter; }
          } catch (e) { /* 이미지가 사라짐 */ }
        };
        E.apply = function (img, nw, nh, boxes) {
          E.busy(img, false);
          if (!boxes.length) return 0;
          E.clearOne(img);
          img.__evHas = 1;
          var el = document.createElement('div'); el.style.cssText = 'position:absolute;pointer-events:none;overflow:visible;';
          var g = { img: img, el: el, nw: nw, nh: nh, lw: 0, boxes: [] };
          for (var i = 0; i < boxes.length; i++) {
            var o = boxes[i], d = document.createElement('div'), sp = document.createElement('span');
            var bl = o.bl === 1, hn = parseInt((o.bg || '#ffffff').slice(1), 16) || 0, rgb = (hn >> 16 & 255) + ',' + (hn >> 8 & 255) + ',' + (hn & 255);
            d.style.cssText = 'position:absolute;box-sizing:border-box;display:flex;align-items:center;justify-content:center;text-align:center;overflow:hidden;padding:1px 2px;border-radius:' + (bl ? 8 : 4) + 'px;background:' + (bl ? 'rgba(' + rgb + ',0.78)' : o.bg) + ';color:' + o.fg + ';' + (bl ? '-webkit-backdrop-filter:blur(9px);backdrop-filter:blur(9px);' : '');
            sp.style.cssText = 'display:block;width:100%;font-weight:700;line-height:1.18;letter-spacing:-0.01em;word-break:keep-all;overflow-wrap:anywhere;font-family:"Malgun Gothic","Segoe UI","Noto Sans KR","Yu Gothic UI","Microsoft YaHei UI",sans-serif;';
            if (bl) sp.style.textShadow = '0 0 2px rgb(' + rgb + '),0 0 4px rgb(' + rgb + '),0 0 7px rgb(' + rgb + ')';
            sp.textContent = o.t; d.appendChild(sp); el.appendChild(d);
            g.boxes.push({ el: d, sp: sp, x: o.x, y: o.y, w: o.w, h: o.h, fs: o.fs || 0 });
          }
          ensureRoot().appendChild(el); G.push(g); place();
          try {
            for (var j = 0; j < g.boxes.length; j++) g.boxes[j].el.animate([{ opacity: 0, filter: 'blur(8px)', transform: 'scale(1.06)' }, { opacity: 1, filter: 'blur(0px)', transform: 'scale(1)' }], { duration: 480, delay: Math.min(j * 70, 700), easing: 'ease-out', fill: 'backwards' });
          } catch (e) { /* 움직임 없이 */ }
          return boxes.length;
        };
        E.clearOne = function (img) {
          var n = 0;
          for (var i = G.length - 1; i >= 0; i--) if (G[i].img === img) { n += G[i].boxes.length; try { G[i].el.remove(); } catch (e) { /* */ } G.splice(i, 1); }
          try { img.__evHas = 0; } catch (e) { /* */ }
          return n;
        };
        E.clear = function () {
          var n = 0;
          for (var i = 0; i < G.length; i++) { n += G[i].boxes.length; try { G[i].el.remove(); } catch (e) { /* */ } try { G[i].img.__evHas = 0; } catch (e) { /* */ } try { E.busy(G[i].img, false); } catch (e) { /* */ } }
          G = []; return n;
        };
      })();
    }
    var vh = window.innerHeight || 800, list = [], imgs = document.images, i;
    window.__evImgs = []; window.__evImgBmp = {};
    for (i = 0; i < imgs.length; i++) {
      var m = imgs[i];
      if (m.__evHas) continue;
      var r = m.getBoundingClientRect();
      if (r.width < 80 || r.height < 40) continue;
      var cs = getComputedStyle(m);
      if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) === 0) continue;
      var u = m.currentSrc || m.src || '';
      var lz = m.getAttribute('data-src') || m.getAttribute('data-original') || m.getAttribute('data-lazy-src') || m.getAttribute('data-url') || '';
      var ph = !u || (u.indexOf('data:') === 0 && u.length < 2000) || m.naturalWidth === 0;
      if (ph && lz) u = lz;
      if (!u) continue;
      try { u = new URL(u, document.baseURI).href; } catch (e) { continue; }
      if (u.indexOf('http') !== 0 && u.indexOf('data:image/') !== 0) continue;
      if (u.indexOf('data:') === 0 && u.length > 400000) continue;
      if (/\.svg([?#]|$)/i.test(u) || u.indexOf('data:image/svg') === 0) continue;
      if (m.naturalWidth > 0 && (m.naturalWidth < 120 || m.naturalHeight < 60)) continue;
      window.__evImgs.push(m);
      list.push({ k: window.__evImgs.length - 1, u: u, y: r.top });
    }
    function vis(o) { return o.y > -vh * 0.5 && o.y < vh * 1.5; }
    list.sort(function (a, b) { var va = vis(a), vb = vis(b); if (va !== vb) return va ? -1 : 1; return va ? a.y - b.y : Math.abs(a.y) - Math.abs(b.y); });
    list = list.slice(0, max || 40);
    return { lang: (document.documentElement.lang || '').toLowerCase(), items: list.map(function (o) { return { k: o.k, u: o.u }; }) };
  } catch (e) { return { lang: '', items: [] }; }
}

// 이미지 k 를 읽어 들인다. dataUrl 이 없으면 페이지 안에서 직접(캔버스가 안 막히면 그대로, 아니면 fetch). 못 읽으면 { need: true } → 호출한 쪽이 받아서 dataUrl 로 다시 부른다.
async function imgLoadFn(k, dataUrl) {
  try {
    var img = window.__evImgs && window.__evImgs[k]; if (!img) return { err: 'gone' };
    var bm = null;
    function ok(el) { try { var c = document.createElement('canvas'); c.width = c.height = 2; var x = c.getContext('2d'); x.drawImage(el, 0, 0, 2, 2); x.getImageData(0, 0, 1, 1); return true; } catch (e) { return false; } }
    function load(src) { return new Promise(function (res, rej) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { rej(new Error('load')); }; im.src = src; }); }
    if (dataUrl) bm = await load(dataUrl);
    else {
      if (img.complete && img.naturalWidth > 0 && ok(img)) bm = img;
      else {
        try {
          var u = img.currentSrc || img.src || ''; if (!u) return { need: true };
          var r = await fetch(u, { credentials: 'include' }); if (!r.ok) return { need: true };
          var bl = await r.blob(); var ou = URL.createObjectURL(bl);
          try { bm = await load(ou); } finally { setTimeout(function () { URL.revokeObjectURL(ou); }, 5000); }
        } catch (e) { return { need: true }; }
      }
    }
    if (!bm || !bm.naturalWidth) return { need: true };
    window.__evImgBmp[k] = bm;
    return { w: bm.naturalWidth, h: bm.naturalHeight };
  } catch (e) { return { need: true }; }
}

// 이미지 k 의 세로 y0 부터 th(px) 높이를 Gemini 로 보낼 JPEG 로 만든다(가로가 maxW 를 넘으면 줄임)
function imgTileFn(k, y0, th, maxW) {
  try {
    var bm = window.__evImgBmp && window.__evImgBmp[k]; if (!bm) return null;
    var w = bm.naturalWidth, sc = Math.min(1, maxW / w), cw = Math.max(1, Math.round(w * sc)), ch = Math.max(1, Math.round(th * sc));
    var c = document.createElement('canvas'); c.width = cw; c.height = ch;
    var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cw, ch);   // 투명한 부분은 흰 바탕에 얹어서 읽는다
    x.drawImage(bm, 0, y0, w, th, 0, 0, cw, ch);
    return c.toDataURL('image/jpeg', 0.85).split(',')[1];
  } catch (e) { return null; }
}

function imgBusyFn(tok, k, on) {
  if (tok !== window.__evId) return -1;
  var E = window.__evImgEng, im = window.__evImgs && window.__evImgs[k];
  if (E && im) E.busy(im, !!on);
  return 1;
}

// 번역한 글(blocks: 원본 이미지 좌표의 {x,y,w,h,t,cjk,v})이 들어갈 덮개를 정해서 이미지 위에 올린다.
// 안드로이드 ImageOcr 의 말풍선 넓히기(bubbleRect) · 배경색(sampleBg) · 그림 위 글자 판별(flatRatio) · 겹침 풀기(separate)를 그대로 옮겼다.
function imgApplyFn(tok, k, nw, nh, blocks) {
  if (tok !== window.__evId) return -1;
  var E = window.__evImgEng, img = window.__evImgs && window.__evImgs[k], bm = window.__evImgBmp && window.__evImgBmp[k];
  if (!E || !img || !img.isConnected || !nw || !nh) return 0;
  if (!bm) { E.busy(img, false); return 0; }
  var cv = document.createElement('canvas'), cx = cv.getContext('2d', { willReadFrequently: true });
  function region(l, t, r, b) {
    l = Math.max(0, Math.floor(l)); t = Math.max(0, Math.floor(t)); r = Math.min(nw, Math.ceil(r)); b = Math.min(nh, Math.ceil(b));
    var w = Math.max(1, r - l), h = Math.max(1, b - t); cv.width = w; cv.height = h;
    cx.fillStyle = '#fff'; cx.fillRect(0, 0, w, h); cx.drawImage(bm, l, t, w, h, 0, 0, w, h);
    return { ox: l, oy: t, w: w, h: h, d: cx.getImageData(0, 0, w, h).data };
  }
  function px(R, x, y) { x -= R.ox; y -= R.oy; if (x < 0 || y < 0 || x >= R.w || y >= R.h) return null; var i = (y * R.w + x) * 4; return [R.d[i], R.d[i + 1], R.d[i + 2]]; }
  // 글자 덩어리 바로 바깥 둘레의 색들 중 가장 많은 색 = 배경색
  function sampleBg(R, rc) {
    var counts = {}, per = (rc.r - rc.l + rc.b - rc.t) * 2, step = Math.max(2, Math.floor(per / 300));
    function add(x, y) { var c = px(R, x, y); if (!c) return; var key = ((c[0] >> 4) << 8) | ((c[1] >> 4) << 4) | (c[2] >> 4), a = counts[key] || (counts[key] = [0, 0, 0, 0]); a[0]++; a[1] += c[0]; a[2] += c[1]; a[3] += c[2]; }
    [3, 6].forEach(function (off) {
      var l = rc.l - off, r = rc.r + off, t = rc.t - off, b = rc.b + off, x, y;
      for (x = l; x <= r; x += step) { add(x, t); add(x, b); }
      for (y = t; y <= b; y += step) { add(l, y); add(r, y); }
    });
    var best = null; for (var q in counts) if (!best || counts[q][0] > best[0]) best = counts[q];
    return best ? [Math.round(best[1] / best[0]), Math.round(best[2] / best[0]), Math.round(best[3] / best[0])] : [255, 255, 255];
  }
  // 글자 덩어리 바로 바깥 둘레 중 바탕색과 비슷한 곳의 비율 (말풍선·단색 바탕이면 높고, 그림 위 글자면 낮다)
  function flatRatio(R, rc, bg) {
    var tot = 0, hit = 0, step = Math.max(2, Math.floor((rc.r - rc.l + rc.b - rc.t) * 2 / 200));
    function test(x, y) { var c = px(R, x, y); if (!c) return; tot++; if (Math.abs(c[0] - bg[0]) + Math.abs(c[1] - bg[1]) + Math.abs(c[2] - bg[2]) <= 48) hit++; }
    [3, 6].forEach(function (off) {
      var l = rc.l - off, r = rc.r + off, t = rc.t - off, b = rc.b + off, x, y;
      for (x = l; x <= r; x += step) { test(x, t); test(x, b); }
      for (y = t; y <= b; y += step) { test(l, y); test(r, y); }
    });
    return tot ? hit / tot : 1;
  }
  // 둘레의 바탕색이 이어진 곳(말풍선 안쪽)을 찾아 윤곽선 쪽으로 최대한 넓힌 사각형. 못 찾으면 원래 범위(open = 열린 바탕)
  function bubbleRect(R, rc, bg, all) {
    try {
      var wl = R.ox, wt = R.oy, ww = R.w, wh = R.h;
      if (ww * wh > 1500000) return { r: rc, open: true };
      var fill = new Uint8Array(ww * wh), stack = new Int32Array(ww * wh), sp = 0;
      function close(i) { var j = i * 4; return Math.abs(R.d[j] - bg[0]) + Math.abs(R.d[j + 1] - bg[1]) + Math.abs(R.d[j + 2] - bg[2]) <= 60; }
      function seed(x, y) { if (x >= 0 && x < ww && y >= 0 && y < wh) { var i = y * ww + x; if (!fill[i] && close(i)) { fill[i] = 1; stack[sp++] = i; } } }
      var sl = rc.l - wl - 4, st = rc.t - wt - 4, sr = rc.r - wl + 4, sb = rc.b - wt + 4, x, y;
      for (x = sl; x <= sr; x += 3) { seed(x, st); seed(x, sb); }
      for (y = st; y <= sb; y += 3) { seed(sl, y); seed(sr, y); }
      if (!sp) return { r: rc, open: true };
      while (sp > 0) {
        var i = stack[--sp], cx0 = i % ww, cy0 = Math.floor(i / ww), j;
        if (cx0 > 0) { j = i - 1; if (!fill[j] && close(j)) { fill[j] = 1; stack[sp++] = j; } }
        if (cx0 < ww - 1) { j = i + 1; if (!fill[j] && close(j)) { fill[j] = 1; stack[sp++] = j; } }
        if (cy0 > 0) { j = i - ww; if (!fill[j] && close(j)) { fill[j] = 1; stack[sp++] = j; } }
        if (cy0 < wh - 1) { j = i + ww; if (!fill[j] && close(j)) { fill[j] = 1; stack[sp++] = j; } }
      }
      // 바탕색이 창 가장자리 두 변 이상에 닿으면 윤곽선으로 막힌 말풍선이 아니라 열린 바탕
      var lf = 0, rt = 0, tp = 0, bt = 0, yy, xx;
      for (yy = 0; yy < wh; yy++) { if (fill[yy * ww]) lf = 1; if (fill[yy * ww + ww - 1]) rt = 1; }
      for (xx = 0; xx < ww; xx++) { if (fill[xx]) tp = 1; if (fill[(wh - 1) * ww + xx]) bt = 1; }
      if (lf + rt + tp + bt >= 2) return { r: rc, open: true };
      // 글자로 읽은 자리도 바탕으로 친다 (글자 획은 바탕색이 아니라서)
      all.forEach(function (a) {
        var l0 = Math.max(a.l, wl) - wl, t0 = Math.max(a.t, wt) - wt, r0 = Math.min(a.r, wl + ww) - wl, b0 = Math.min(a.b, wt + wh) - wt;
        for (var y2 = t0; y2 < b0; y2++) for (var x2 = l0; x2 < r0; x2++) fill[y2 * ww + x2] = 1;
      });
      function okr(x0, y0, x1, y1) { var cnt = 0, tot = 0, a, b; for (a = y0; a < y1; a++) for (b = x0; b < x1; b++) { tot++; if (fill[a * ww + b]) cnt++; } return tot > 0 && cnt >= tot * 0.8; }
      var l = Math.min(ww, Math.max(0, rc.l - wl)), t = Math.min(wh, Math.max(0, rc.t - wt)), r = Math.min(ww, Math.max(0, rc.r - wl)), b = Math.min(wh, Math.max(0, rc.b - wt));
      var step = 3, grew = true, rounds = 0;
      while (grew && rounds < 120) {
        grew = false; rounds++;
        if (t - step >= 0 && okr(l, t - step, r, t)) { t -= step; grew = true; }
        if (b + step <= wh && okr(l, b, r, b + step)) { b += step; grew = true; }
        if (l - step >= 0 && okr(l - step, t, l, b)) { l -= step; grew = true; }
        if (r + step <= ww && okr(r, t, r + step, b)) { r += step; grew = true; }
      }
      return { r: { l: Math.min(rc.l, l + wl + 2), t: Math.min(rc.t, t + wt + 2), r: Math.max(rc.r, r + wl - 2), b: Math.max(rc.b, b + wt - 2) }, open: false };
    } catch (e) { return { r: rc, open: true }; }
  }
  var raws = blocks.map(function (b) { return { l: b.x, t: b.y, r: b.x + b.w, b: b.y + b.h }; });
  var out = [], cores = [];
  blocks.forEach(function (b, i) {
    var rc = raws[i], margin = Math.min(200, Math.floor(Math.max(rc.r - rc.l, rc.b - rc.t) * 0.8) + 24);
    var R = region(rc.l - margin, rc.t - margin, rc.r + margin, rc.b + margin);
    var bg = sampleBg(R, rc), bb = bubbleRect(R, rc, bg, raws), u = bb.r;
    var grown = (u.r - u.l) > (rc.r - rc.l) + 4 || (u.b - u.t) > (rc.b - rc.t) + 4;
    var big = (u.r - u.l) * (u.b - u.t) * 2 >= (rc.r - rc.l) * (rc.b - rc.t) * 3;
    var flat = big || flatRatio(R, rc, bg) >= 0.6;
    var l = u.l, t = u.t, r = u.r, bt = u.b, bw = r - l, bh = bt - t;
    // 세로쓰기처럼 좁고 긴 글은 번역문이 들어갈 만큼 가로로 넓힌다
    if (!grown && b.cjk && bh > bw * 2) { var nwid = Math.min(Math.floor(bh * 0.5), Math.floor(bw * 2.2)); if (nwid > bw) { var cxm = Math.floor((l + r) / 2); l = cxm - Math.floor(nwid / 2); r = l + nwid; } }
    var pad = grown ? 0 : 3;   // 글자 가장자리가 비치지 않게 조금 키운다
    l = Math.max(0, l - pad); t = Math.max(0, t - pad); r = Math.min(nw, r + pad); bt = Math.min(nh, bt + pad);
    var lum = (0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]) / 255;
    out.push({ l: l, t: t, r: r, b: bt, tx: b.t, bg: bg, fg: lum >= 0.55 ? '#111111' : '#ffffff', fs: Math.min(rc.r - rc.l, rc.b - rc.t), bl: flat ? 0 : 1 });
    cores.push(rc);
  });
  // 서로 다른 말풍선의 덮개가 겹치면 겹친 부분을 둘이 반씩 나눠 갖도록 맞닿는 가장자리를 자른다 (실제 글자 범위 안쪽은 건드리지 않음)
  var n = out.length, gap = 1;
  for (var pass = 0; pass < 3 && n > 1; pass++) {
    var changed = false;
    for (var a = 0; a < n; a++) for (var c = a + 1; c < n; c++) {
      var A = out[a], B = out[c], ix = Math.min(A.r, B.r) - Math.max(A.l, B.l), iy = Math.min(A.b, B.b) - Math.max(A.t, B.t);
      if (ix <= 0 || iy <= 0) continue;
      var ca = cores[a], cb = cores[c], xOk = ca.r <= cb.l || cb.r <= ca.l, yOk = ca.b <= cb.t || cb.b <= ca.t, useX;
      if (xOk && yOk) useX = ix <= iy; else if (xOk) useX = true; else if (yOk) useX = false; else continue;
      var aFirst, f, s, fc, sc, mid, cut;
      if (useX) {
        aFirst = ca.r <= cb.l; f = aFirst ? A : B; s = aFirst ? B : A; fc = aFirst ? ca : cb; sc = aFirst ? cb : ca;
        mid = Math.floor((f.r + s.l) / 2); cut = Math.min(Math.max(mid, fc.r), sc.l);
        f.r = Math.min(f.r, Math.max(fc.r, cut - gap)); s.l = Math.max(s.l, Math.min(sc.l, cut + gap));
      } else {
        aFirst = ca.b <= cb.t; f = aFirst ? A : B; s = aFirst ? B : A; fc = aFirst ? ca : cb; sc = aFirst ? cb : ca;
        mid = Math.floor((f.b + s.t) / 2); cut = Math.min(Math.max(mid, fc.b), sc.t);
        f.b = Math.min(f.b, Math.max(fc.b, cut - gap)); s.t = Math.max(s.t, Math.min(sc.t, cut + gap));
      }
      changed = true;
    }
    if (!changed) break;
  }
  function hex(c) { return '#' + [c[0], c[1], c[2]].map(function (v) { return ('0' + Math.max(0, Math.min(255, v)).toString(16)).slice(-2); }).join(''); }
  var boxes = out.map(function (o) { return { x: o.l, y: o.t, w: o.r - o.l, h: o.b - o.t, t: o.tx, bg: hex(o.bg), fg: o.fg, fs: o.fs, bl: o.bl }; });
  try { delete window.__evImgBmp[k]; } catch (e) { /* */ }
  return E.apply(img, nw, nh, boxes);
}

// url 이 가리키는 이미지(lazy 로딩 주소 포함)의 번역 덮개를 센다(mode 'has') 또는 걷어 낸다(mode 'clear'). url 이 비면 모든 이미지의 덮개를 걷는다.
function imgCoverFn(url, mode) {
  try {
    var E = window.__evImgEng; if (!E) return 0;
    if (!url) return mode === 'clear' ? E.clear() : 0;
    function key(u) { try { return new URL(u, document.baseURI).href.split('#')[0]; } catch (e) { return ''; } }
    var want = key(url), ims = document.images, n = 0;
    for (var i = 0; i < ims.length; i++) {
      var m = ims[i], c = [m.currentSrc, m.src, m.getAttribute('data-src'), m.getAttribute('data-original'), m.getAttribute('data-lazy-src'), m.getAttribute('data-url')];
      for (var j = 0; j < c.length; j++) if (c[j] && key(c[j]) === want) {
        if (m.__evHas) { if (mode === 'clear') E.clearOne(m); n++; }
        break;
      }
    }
    return n;
  } catch (e) { return -1; }
}

const call = (fn, ...args) => '(' + fn.toString() + ').apply(null,' + JSON.stringify(args) + ')';
module.exports = { snapshotFn, readPageFn, elementFn, clickFn, fillFn, scrollFn, trCollectFn, trApplyFn, trRestoreFn, trStateFn, imgCollectFn, imgLoadFn, imgTileFn, imgBusyFn, imgApplyFn, imgCoverFn, call };
