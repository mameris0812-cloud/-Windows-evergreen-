'use strict';
const fs = require('fs');
const path = require('path');

// 윈도우 파일 이름에 못 쓰는 글자·예약어를 정리한다
function safeName(name) {
  let n = String(name || '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/, '').trim();
  if (!n) n = 'download';
  if (/^(con|prn|aux|nul|com\d|lpt\d)(\..*)?$/i.test(n)) n = '_' + n;
  return n.slice(0, 200);
}
// 같은 이름이 있으면 "이름 (1).확장자"
function uniquePath(dir, name) {
  const ext = path.extname(name), base = path.basename(name, ext);
  let p = path.join(dir, name), i = 1;
  while (fs.existsSync(p) && i < 1000) p = path.join(dir, base + ' (' + i++ + ')' + ext);
  return p;
}

module.exports = { safeName, uniquePath };
