'use strict';
const { Store } = require('./store');
const L = require('../shared/lists');

// 안드로이드 DEFAULT_HOME_SHORTCUTS (주소만 PC 용으로)
const DEFAULT_SHORTCUTS = [
  { name: 'Google', url: 'https://www.google.com', glyph: 'G' },
  { name: '네이버', url: 'https://www.naver.com', glyph: 'N' },
  { name: 'YouTube', url: 'https://www.youtube.com', glyph: '▶' },
];
const FAVICON_MAX = 600;

// 북마크·방문 기록·폴더·즐겨찾기 타일·사이트 아이콘·받은 파일 기록.
// 설정(테마·검색 엔진·창 구성)은 evergreen-prefs.json, 이쪽은 evergreen-data.json 에 따로 둔다.
class Data {
  constructor(dir) {
    this.store = new Store(dir, 'evergreen-data.json', {
      history: [], bookmarks: [], folders: { bm: [], dl: [] }, dlFolderMap: {}, shortcuts: null, favicons: {}, downloads: [], dlSeq: 0,
    });
    this.listeners = new Set();
  }
  onChange(fn) { this.listeners.add(fn); }
  emit(kind) { this.listeners.forEach((fn) => { try { fn(kind); } catch (e) { /* 화면 쪽 오류는 무시 */ } }); }
  flush() { this.store.flush(); }

  // ── 방문 기록 ──
  history() { return this.store.get('history'); }
  addHistory(url, title) {
    const cur = this.history();
    const next = L.addHistory(cur, url, title, Date.now());
    if (next === cur) return;
    this.store.set('history', next);
    this.emit('history');
  }
  // 같은 주소의 맨 앞 기록 제목을 나중에 알게 된 제목으로 고친다 (페이지가 끝난 뒤 제목이 바뀌는 경우)
  touchHistoryTitle(url, title) {
    const h = this.history();
    if (h[0] && h[0].url === url && h[0].title !== title) { h[0].title = title; this.store.set('history', h); this.emit('history'); }
  }
  removeHistory(urls) { this.store.set('history', L.removeHistory(this.history(), urls)); this.emit('history'); }
  clearHistory() { this.store.set('history', []); this.emit('history'); }
  setHistory(items) { this.store.set('history', items); this.emit('history'); }

  // ── 북마크 · 폴더 (kind: 'bm' | 'dl') ──
  bookmarks() { return this.store.get('bookmarks'); }
  setBookmarks(list) { this.store.set('bookmarks', list); this.emit('bookmarks'); }
  findBookmark(url) { return L.findBookmark(this.bookmarks(), url); }
  saveBookmark(url, title, folderId, existingId) {
    const r = L.saveBookmark(this.bookmarks(), url, title, folderId, existingId);
    this.setBookmarks(r.list);
    return r.bookmark;
  }
  removeBookmarks(ids) { const s = new Set(ids); this.setBookmarks(this.bookmarks().filter((b) => !s.has(b.id))); }
  moveBookmarks(ids, folderId) { const s = new Set(ids); this.setBookmarks(this.bookmarks().map((b) => (s.has(b.id) ? Object.assign({}, b, { folderId }) : b))); }
  folders(kind) { return (this.store.get('folders') || {})[kind] || []; }
  _setFolders(kind, list) { const f = Object.assign({ bm: [], dl: [] }, this.store.get('folders')); f[kind] = list; this.store.set('folders', f); }
  addFolder(kind, name) { const r = L.addFolder(this.folders(kind), name); this._setFolders(kind, r.list); this.emit(kind === 'bm' ? 'bookmarks' : 'downloads'); return r.folder; }
  renameFolder(kind, id, name) { this._setFolders(kind, this.folders(kind).map((f) => (f.id === id ? { id, name } : f))); this.emit(kind === 'bm' ? 'bookmarks' : 'downloads'); }
  // 폴더 삭제: 안의 항목은 그대로 남는다(폴더 없음). 되돌리기용으로 지우기 전 상태를 돌려준다.
  removeFolder(kind, id) {
    const folders = this.folders(kind);
    const snap = { folder: folders.find((f) => f.id === id), index: folders.findIndex((f) => f.id === id) };
    if (!snap.folder) return null;
    if (kind === 'bm') {
      snap.members = this.bookmarks().filter((b) => b.folderId === id).map((b) => b.id);
      const r = L.removeFolder(folders, this.bookmarks(), id);
      this._setFolders('bm', r.folders); this.store.set('bookmarks', r.bookmarks); this.emit('bookmarks');
    } else {
      const map = this.dlFolderMap();
      snap.members = Object.keys(map).filter((k) => map[k] === id);
      snap.members.forEach((k) => delete map[k]);
      this._setFolders('dl', folders.filter((f) => f.id !== id)); this.store.set('dlFolderMap', map); this.emit('downloads');
    }
    return snap;
  }
  restoreFolder(kind, snap) {
    if (!snap || !snap.folder || this.folders(kind).some((f) => f.id === snap.folder.id)) return;
    const list = this.folders(kind).slice();
    list.splice(Math.max(0, Math.min(snap.index, list.length)), 0, snap.folder);
    this._setFolders(kind, list);
    if (kind === 'bm') { const s = new Set(snap.members); this.store.set('bookmarks', this.bookmarks().map((b) => (s.has(b.id) ? Object.assign({}, b, { folderId: snap.folder.id }) : b))); this.emit('bookmarks'); }
    else { const map = this.dlFolderMap(); snap.members.forEach((k) => { map[k] = snap.folder.id; }); this.store.set('dlFolderMap', map); this.emit('downloads'); }
  }
  importBookmarks(parsed) {
    const r = L.mergeImported(this.bookmarks(), this.folders('bm'), parsed);
    this._setFolders('bm', r.folders); this.setBookmarks(r.bookmarks);
    return r;
  }

  // ── 즐겨찾기 타일 (새 탭 화면) ──
  shortcuts() { return this.store.get('shortcuts') || DEFAULT_SHORTCUTS; }
  setShortcuts(list) { this.store.set('shortcuts', list); this.emit('shortcuts'); }
  resetShortcuts() { this.store.set('shortcuts', null); this.emit('shortcuts'); }

  // ── 사이트 아이콘 (호스트별로 웹페이지가 알려 준 주소) ──
  favicon(url) { const h = L.hostOf(url); return h ? (this.store.get('favicons')[h] || '') : ''; }
  setFavicon(pageUrl, iconUrl) {
    const h = L.hostOf(pageUrl);
    if (!h || !/^(https?:|data:image\/)/i.test(iconUrl || '') || String(iconUrl).length > 4000) return;
    const m = this.store.get('favicons');
    if (m[h] === iconUrl) return;
    delete m[h]; m[h] = iconUrl; // 최근에 쓴 것이 뒤로
    const keys = Object.keys(m);
    if (keys.length > FAVICON_MAX) keys.slice(0, keys.length - FAVICON_MAX).forEach((k) => delete m[k]);
    this.store.set('favicons', m);
    this.emit('favicons');
  }

  // ── 받은 파일 기록 (끝난 것만) ──
  downloads() { return this.store.get('downloads'); }
  nextDlKey() { const n = (this.store.get('dlSeq') || 0) + 1; this.store.set('dlSeq', n); return 'd:' + n; }
  addDownload(rec) { const l = this.downloads(); l.unshift(rec); this.store.set('downloads', l.slice(0, 500)); this.emit('downloads'); }
  setDownloads(list) { this.store.set('downloads', list); this.emit('downloads'); }
  removeDownloads(keys) {
    const s = new Set(keys), map = this.dlFolderMap();
    keys.forEach((k) => delete map[k]);
    this.store.set('dlFolderMap', map);
    this.setDownloads(this.downloads().filter((d) => !s.has(d.key)));
  }
  dlFolderMap() { return Object.assign({}, this.store.get('dlFolderMap')); }
  setDlFolder(keys, folderId) {
    const map = this.dlFolderMap();
    keys.forEach((k) => { if (!folderId) delete map[k]; else map[k] = folderId; });
    this.store.set('dlFolderMap', map); this.emit('downloads');
  }
}
module.exports = { Data, DEFAULT_SHORTCUTS };
