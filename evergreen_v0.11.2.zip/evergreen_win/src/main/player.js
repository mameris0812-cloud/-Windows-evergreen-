'use strict';
// 4단계: 내장 플레이어 · 미러링 · 자막 파일 · 영상 저장(HLS 포함).
//  - 내장 플레이어: 창 전체를 덮는 뷰(src/player/player.html)에서 <video> 로 재생한다. 요청마다 원래 페이지의 Referer · 쿠키 · UA 를 붙여 주려고 전용 세션을 쓴다.
//  - 미러링: 페이지 안의 영상을 화면에 맞춰 키우고(src/guard/mirror.js), 투명한 컨트롤 뷰를 그 위에 얹는다. 상태는 0.25초마다 읽는다.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');
const { WebContentsView, ipcMain, session, dialog, app } = require('electron');
const Hls = require('../shared/hls');
const hlsdl = require('./hlsdl');
const { safeName, uniquePath } = require('./fsutil');

const SRC = path.join(__dirname, '..');
const PART = 'evergreen-player';       // 메모리 전용(저장 안 함)
const MIRROR_JS = fs.readFileSync(path.join(SRC, 'guard', 'mirror.js'), 'utf8');
const CAP_RIGHT = 140;                 // 윈도우 단추(최소화·최대화·닫기)가 덮는 오른쪽 폭
const MEDIA_EXT = /\.(m3u8|mp4|m4v|webm|mkv|mov|mp3|m4a|aac|ogg|opus|flac|wav)$/i;
const NOT_MEDIA = /\.(ts|m4s|cmfv|cmfa|aac\.ts)$/i;
const VIDEO_FILES = ['mp4', 'm4v', 'webm', 'mkv', 'mov', 'avi', 'ogv', 'mp3', 'm4a', 'aac', 'ogg', 'opus', 'flac', 'wav', 'm3u8'];

function ffmpegPath() {
  const names = process.platform === 'win32' ? ['ffmpeg.exe'] : ['ffmpeg'];
  for (const n of names) {
    const p = path.join(SRC, 'vendor', n).replace('app.asar', 'app.asar.unpacked');
    try { if (fs.existsSync(p)) return p; } catch (e) { /* 없음 */ }
  }
  return null;
}
function runFfmpeg(bin, args, ctl) {
  return new Promise((resolve, reject) => {
    const p = spawn(bin, args, { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    p.stderr.on('data', (d) => { err = (err + d).slice(-600); });
    p.on('error', reject);
    p.on('close', (code) => (code === 0 ? resolve() : reject(new Error('ffmpeg ' + code + ' ' + err.trim().split('\n').pop()))));
    if (ctl) ctl.onAbort = () => { try { p.kill(); } catch (e) { /* 이미 끝남 */ } };
  });
}
const writeStream = (stream) => (buf) => new Promise((res, rej) => { if (stream.write(buf)) res(); else stream.once('drain', res); stream.once('error', rej); });
const closeStream = (s) => new Promise((res) => s.end(res));

// HLS 영상 받기: 조각을 모아 .ts / .mp4 로 이어 붙이고, ffmpeg 가 있으면 mp4 로 합친다(소리가 따로 있어도 하나로).
// ctl: Downloads.startJob 이 주는 조절기 { cancelled(), signal, bytes(n), segment(), setSegments(n) }
async function runHlsJob(ctl, dir, o) {
  const ctx = { headers: o.headers, cancelled: () => ctl.cancelled(), signal: ctl.signal, onBytes: (n) => ctl.bytes(n), onSegment: () => ctl.segment() };
  const plan = await hlsdl.plan(ctx, o.url);
  ctl.setSegments(plan.video.segs.length + (plan.audio ? plan.audio.segs.length : 0));
  const base = safeName(o.title || 'video').replace(/\.(m3u8?|mp4|ts)$/i, '');
  const vPath = uniquePath(dir, base + '.' + plan.video.rawExt);
  const aPath = plan.audio ? uniquePath(dir, base + '.audio.' + plan.audio.rawExt) : null;
  const temps = [];
  try {
    for (const [stream, p] of [[plan.video, vPath], [plan.audio, aPath]]) {
      if (!stream) continue;
      temps.push(p);
      const out = fs.createWriteStream(p);
      try { await hlsdl.download(ctx, stream, writeStream(out)); } finally { await closeStream(out); }
    }
    const bin = (plan.video.rawExt === 'ts' || plan.video.rawExt === 'mp4') ? ffmpegPath() : null;
    if (bin) {
      const mp4 = uniquePath(dir, base + '.mp4');
      try {
        ctl.phase('mp4 로 합치는 중');
        await runFfmpeg(bin, ['-y', '-i', vPath].concat(aPath ? ['-i', aPath] : [], ['-c', 'copy', '-movflags', '+faststart', mp4]), ctl);
        for (const t of temps) { try { fs.unlinkSync(t); } catch (e) { /* */ } }
        return { path: mp4, name: path.basename(mp4), note: '' };
      } catch (e) { try { fs.unlinkSync(mp4); } catch (x) { /* */ } if (ctl.cancelled()) throw e; /* 합치기 실패 → 이어 붙인 원본을 그대로 둔다 */ }
    }
    return { path: vPath, name: path.basename(vPath), note: aPath ? ' · 소리는 ' + path.basename(aPath) + ' 로 따로 저장됐어요' : (plan.video.rawExt === 'ts' ? ' · ts 파일이라 일부 플레이어에서만 열려요' : '') };
  } catch (e) {
    for (const t of temps) { try { fs.unlinkSync(t); } catch (x) { /* */ } }
    throw e;
  }
}

class PlayerHost {
  // h: { win(), store, toast(msg, action), raise(), downloads, tabByWcId(id), activeTab(), chromeH(), isDark(), cookiesFor(tab, url), onClosed() }
  constructor(h) {
    this.h = h;
    this.view = null; this.mode = null; this.media = null; this.tab = null; this.poll = null; this.muteWas = null;
    this.ses = session.fromPartition(PART);
    this._hooks();
    h.downloads.attach(this.ses, false, null);
    const from = (e) => this.view && e.sender === this.view.webContents;
    ipcMain.on('pl:ready', (e) => { if (from(e)) this._init(); });
    ipcMain.on('pl:close', (e) => { if (from(e)) this.close(); });
    ipcMain.on('pl:fullscreen', (e) => { if (from(e)) this.toggleFullscreen(); });
    ipcMain.on('pl:prefs', (e, p) => { if (from(e) && p && typeof p === 'object') this._savePrefs(p); });
    ipcMain.on('pl:save', (e, m) => { if (from(e) && m) this.save(m); });
    ipcMain.on('pl:cmd', (e, m) => { if (from(e) && m && this.mode === 'mirror' && this.tab) this._page('window.__evMir&&__evMir.cmd(' + JSON.stringify(String(m.a)) + ',' + JSON.stringify(m.v == null ? null : m.v) + ')'); });
    ipcMain.handle('pl:tr', async (e, m) => {   // 자막 번역(Gemini). 키가 없으면 안내만 돌려준다
      if (!from(e) || !m || !Array.isArray(m.texts)) return { error: 'blocked' };
      try { return await this.h.translate(m.texts, this.h.trLang()); } catch (err) { return { error: String((err && err.message) || err).split('\n')[0].slice(0, 80) }; }
    });
    ipcMain.handle('pl:subfile', async (e) => {
      if (!from(e)) return null;
      const r = await dialog.showOpenDialog(this.h.win(), { title: '자막 파일 열기', properties: ['openFile'], filters: [{ name: '자막', extensions: ['vtt', 'srt', 'ass', 'ssa', 'ttml', 'xml', 'dfxp'] }, { name: '모든 파일', extensions: ['*'] }] });
      if (r.canceled || !r.filePaths[0]) return null;
      try { return { name: path.basename(r.filePaths[0]), text: decodeText(fs.readFileSync(r.filePaths[0])) }; } catch (err) { return null; }
    });
  }

  // 전용 세션: 원래 페이지가 보내던 것처럼 Referer · Origin · UA · 쿠키를 붙이고, 다른 출처 요청(CORS)을 허락한다.
  _hooks() {
    const urls = ['http://*/*', 'https://*/*'];
    this.ses.webRequest.onBeforeSendHeaders({ urls }, async (d, cb) => {
      const m = this.media, hd = Object.assign({}, d.requestHeaders);
      if (m) {
        if (m.referer) { hd.Referer = m.referer; try { if (hd.Origin !== undefined || d.method === 'POST') hd.Origin = new URL(m.referer).origin; } catch (e) { /* */ } }
        if (m.ua) hd['User-Agent'] = m.ua;
        try { const c = m.tab ? await this.h.cookiesFor(m.tab, d.url) : ''; if (c) hd.Cookie = c; } catch (e) { /* 쿠키 없이 */ }
      }
      cb({ requestHeaders: hd });
    });
    this.ses.webRequest.onHeadersReceived({ urls }, (d, cb) => {
      const hd = Object.assign({}, d.responseHeaders);
      for (const k of Object.keys(hd)) if (/^access-control-allow-(origin|headers|methods)$|^access-control-expose-headers$/i.test(k)) delete hd[k];
      hd['Access-Control-Allow-Origin'] = ['*']; hd['Access-Control-Allow-Headers'] = ['*']; hd['Access-Control-Allow-Methods'] = ['GET, HEAD, OPTIONS']; hd['Access-Control-Expose-Headers'] = ['*'];
      cb(d.method === 'OPTIONS' ? { responseHeaders: hd, statusLine: 'HTTP/1.1 204 No Content' } : { responseHeaders: hd });
    });
  }

  // 탭 세션에서 오가는 영상 주소를 눈여겨 본다 (m3u8 · mp4 …) → 메뉴 '내장 플레이어로 열기' 에 쓴다. 광고·보안(secure.js)과 다른 이벤트라 겹치지 않는다.
  sniff(ses) {
    ses.webRequest.onResponseStarted({ urls: ['http://*/*', 'https://*/*'] }, (d) => {
      if (d.statusCode !== 200 && d.statusCode !== 206) return;
      const t = d.webContentsId != null ? this.h.tabByWcId(d.webContentsId) : null;
      if (!t) return;
      let mime = '';
      for (const k of Object.keys(d.responseHeaders || {})) if (k.toLowerCase() === 'content-type') mime = String(d.responseHeaders[k][0] || '');
      const p = d.url.split('#')[0].split('?')[0];
      const ok = Hls.looksLikeHls(d.url, mime) || (/^(video|audio)\//i.test(mime) && !/mp2t|iso\.segment/i.test(mime) && !NOT_MEDIA.test(p)) || (MEDIA_EXT.test(p) && !NOT_MEDIA.test(p) && d.resourceType === 'media');
      if (!ok) return;
      t.media = (t.media || []).filter((x) => x.url !== d.url);
      t.media.push({ url: d.url, mime, hls: Hls.looksLikeHls(d.url, mime), t: Date.now() });
      if (t.media.length > 20) t.media.shift();
    });
  }

  isOpen() { return !!this.view; }
  isMirror() { return this.mode === 'mirror'; }
  mirrorTab() { return this.mode === 'mirror' ? this.tab : null; }
  _prefs() { return Object.assign({ subSize: 1, subBg: 0, subPos: 1, subTr: 0, volume: 1, muted: false, swipe: true }, this.h.store.get('player') || {}); }
  _savePrefs(p) {
    const ok = {};
    for (const k of ['subSize', 'subBg', 'subPos']) if (Number.isInteger(p[k]) && p[k] >= 0 && p[k] <= 3) ok[k] = p[k];
    if (Number.isInteger(p.subTr) && p.subTr >= 0 && p.subTr <= 2) ok.subTr = p.subTr;   // 0 끔 · 1 번역만 · 2 번역+원문
    if (typeof p.volume === 'number' && p.volume >= 0 && p.volume <= 1) ok.volume = p.volume;
    if (typeof p.muted === 'boolean') ok.muted = p.muted;
    this.h.store.set('player', Object.assign(this._prefs(), ok));
  }
  _page(js) { const t = this.tab; if (!t || t.view.webContents.isDestroyed()) return Promise.resolve(null); return t.view.webContents.executeJavaScript(js, false).catch(() => null); }
  _send(ch, p) { if (this.view && !this.view.webContents.isDestroyed()) this.view.webContents.send(ch, p); }

  _make(mirror) {
    const view = new WebContentsView({ webPreferences: { partition: PART, preload: path.join(SRC, 'player', 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false, autoplayPolicy: 'no-user-gesture-required', backgroundThrottling: false } });
    view.setBackgroundColor(mirror ? '#00000000' : '#000000');
    this.h.win().contentView.addChildView(view);
    view.webContents.loadFile(path.join(SRC, 'player', 'player.html'), { query: { mode: mirror ? 'mirror' : 'player' } });
    view.webContents.on('before-input-event', (e, input) => { if (input.type === 'keyDown' && input.key === 'F12' ) view.webContents.toggleDevTools(); });
    view.webContents.on('render-process-gone', () => this.close());
    return view;
  }
  relayout() {
    const win = this.h.win();
    if (!this.view || !win || win.isDestroyed()) return;
    const [w, hh] = win.getContentSize();
    const top = this.mode === 'mirror' && !win.isFullScreen() ? this.h.chromeH() : 0;
    this.view.setBounds({ x: 0, y: top, width: w, height: Math.max(0, hh - top) });
    if (this.mode === 'mirror') this._send('pl:fs', { on: win.isFullScreen(), capRight: 0 });
    else this._send('pl:fs', { on: win.isFullScreen(), capRight: CAP_RIGHT });
  }
  _init() {
    const m = this.media, win = this.h.win();
    this._send('pl:init', { mode: this.mode, url: m.url || '', title: m.title || '', host: m.host || '', subs: m.subs || [], startAt: m.startAt || 0, prefs: this._prefs(), trLang: this.h.trLang ? this.h.trLang() : 'ko', dark: true,
      capRight: this.mode === 'mirror' || (win && win.isFullScreen()) ? 0 : CAP_RIGHT });
    this.relayout();
    if (this.view) this.view.webContents.focus();
  }
  _quiet(tab) { // 원래 탭의 소리를 멈춘다 (다른 곳(iframe)의 영상까지 막으려고 탭 소리를 끈다)
    if (!tab || tab.view.webContents.isDestroyed()) return;
    const wc = tab.view.webContents;
    this.muteWas = { tab, muted: wc.isAudioMuted() };
    wc.setAudioMuted(true);
    wc.executeJavaScript('document.querySelectorAll("video,audio").forEach(function(m){try{m.pause()}catch(e){}})', false).catch(() => {});
  }

  // media: { url, title, referer, ua, tab, subs, startAt }
  open(media) {
    this.close();
    let host = '';
    try { host = new URL(media.url).hostname.replace(/^www\./, ''); } catch (e) { /* 로컬 파일 */ }
    this.media = Object.assign({ host, subs: [] }, media);
    this.mode = 'player'; this.tab = media.tab || null;
    this._quiet(this.tab);
    this.view = this._make(false);
    this.h.raise();
    this.relayout();
  }

  async openMirror(tab) {
    if (!tab || tab.view.webContents.isDestroyed()) return false;
    if (!/^https?:/i.test(tab.view.webContents.getURL())) { this.h.toast('웹 페이지에서만 미러링할 수 있어요'); return false; }
    this.close();
    const r = await tab.view.webContents.executeJavaScript(MIRROR_JS + ';window.__evMir.on()', false).catch(() => null);
    if (!r || !r.ok) { this.h.toast('이 페이지에서 재생할 영상을 찾지 못했어요'); return false; }
    this.mode = 'mirror'; this.tab = tab; this.media = { url: '', title: '', host: '' };
    this.view = this._make(true);
    this.h.raise();
    this.relayout();
    this.poll = setInterval(async () => {
      const s = await this._page('window.__evMir?__evMir.state():null');
      if (!this.view) return;
      if (!s || s.gone) { this.h.toast('영상이 사라져 미러링을 끝냈어요'); this.close(); return; }
      this._send('pl:mstate', s);
    }, 250);
    return true;
  }

  front() { const w = this.h.win(); if (this.view && w && !w.isDestroyed()) { try { w.contentView.addChildView(this.view); } catch (e) { /* 닫히는 중 */ } } }
  // 탭 안 영상(컨텍스트 메뉴)을 바로 저장
  saveFor(tab, url, title) { const keep = this.tab; this.tab = tab; this.save({ url, title }); this.tab = keep; }

  toggleFullscreen() { const w = this.h.win(); if (w && !w.isDestroyed()) { w.setFullScreen(!w.isFullScreen()); setTimeout(() => this.relayout(), 60); } }

  // 탭이 바뀌거나 닫히면 미러링을 끝낸다
  tabGone(tab) { if (this.mode === 'mirror' && this.tab === tab) this.close(); }

  close() {
    clearInterval(this.poll); this.poll = null;
    const had = !!this.view, win = this.h.win();
    if (this.mode === 'mirror' && this.tab) this._page('window.__evMir&&__evMir.off()');
    if (this.muteWas) { const m = this.muteWas; this.muteWas = null; try { if (!m.tab.view.webContents.isDestroyed()) m.tab.view.webContents.setAudioMuted(m.muted); } catch (e) { /* */ } }
    if (this.view) {
      try { if (win && !win.isDestroyed()) win.contentView.removeChildView(this.view); } catch (e) { /* 이미 없음 */ }
      try { if (!this.view.webContents.isDestroyed()) this.view.webContents.close(); } catch (e) { /* */ }
    }
    this.view = null; this.mode = null; this.media = null; this.tab = null;
    if (had && win && !win.isDestroyed() && win.isFullScreen() && !this.h.keepFullscreen()) win.setFullScreen(false);
    if (had) this.h.onClosed();
  }

  // 영상 저장: m3u8 은 조각을 모아서, 일반 파일은 다운로드로
  save(m) {
    let url = String(m.url || '');
    const title = String(m.title || '').trim();
    const tab = this.tab;
    if (!/^https?:/i.test(url)) { // 미러링에서 blob: 이면 오간 주소 중 가장 최근 것을 쓴다
      const seen = tab && (tab.media || []).slice().reverse().find((x) => x.hls) || (tab && (tab.media || []).slice().reverse()[0]);
      if (seen) url = seen.url;
    }
    if (!/^https?:/i.test(url)) { this._send('pl:toast', '이 영상은 저장할 수 없어요 (주소를 알 수 없어요)'); return; }
    if (/\.(mpd|ism)(\?|$)/i.test(url)) { this._send('pl:toast', '이 방식(mpd/ism) 스트리밍 영상은 저장할 수 없어요'); return; }
    const media = this.media || {};
    const headers = (u) => { const h = {}; if (media.referer || (tab && tab.url)) h.Referer = media.referer || tab.url; if (media.ua) h['User-Agent'] = media.ua; return h; };
    if (Hls.looksLikeHls(url, '')) {
      this._send('pl:toast', '스트리밍 영상 저장을 시작했어요 · 다운로드 목록에서 볼 수 있어요');
      this.h.downloads.startJob({
        name: (title || 'video') + '.m3u8', url, mime: 'application/vnd.apple.mpegurl',
        run: async (ctl, dir) => {
          const cookie = media.tab || tab ? await this.h.cookiesFor(media.tab || tab, url) : '';
          return runHlsJob(ctl, dir, { url, title, headers: (u) => Object.assign(headers(u), cookie ? { Cookie: cookie } : {}) });
        },
      });
      return;
    }
    this._send('pl:toast', '저장을 시작했어요 · 다운로드 목록에서 볼 수 있어요');
    if (this.view && !this.view.webContents.isDestroyed()) this.view.webContents.downloadURL(url);
    else if (tab) tab.view.webContents.downloadURL(url);
  }
}

// 자막 파일 글자 풀기: UTF-8 먼저, 안 되면 한국어 윈도우 기본(EUC-KR/CP949)
function decodeText(buf) {
  try { return new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (e) { /* */ }
  try { return new TextDecoder('euc-kr').decode(buf); } catch (e) { return buf.toString('utf8'); }
}

async function pickMediaFile(win) {
  const r = await dialog.showOpenDialog(win, { title: '영상 · 음악 파일 열기', properties: ['openFile'], filters: [{ name: '영상 · 소리', extensions: VIDEO_FILES }, { name: '모든 파일', extensions: ['*'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  return { url: pathToFileURL(r.filePaths[0]).href, title: path.basename(r.filePaths[0]).replace(/\.[^.]+$/, '') };
}

module.exports = { PlayerHost, runHlsJob, pickMediaFile, decodeText, ffmpegPath };
