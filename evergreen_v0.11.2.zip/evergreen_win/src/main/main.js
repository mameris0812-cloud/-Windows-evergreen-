'use strict';
const fs = require('fs');
const path = require('path');
const { app, BrowserWindow, WebContentsView, Menu, ipcMain, nativeTheme, session, clipboard, net, dialog, shell, webContents, safeStorage } = require('electron');
const { Store } = require('./store');
const { Data } = require('./data');
const { Downloads } = require('./downloads');
const { Floats } = require('./floats');
const { Security } = require('./secure');
const { PlayerHost, pickMediaFile } = require('./player');
const { ExtManager } = require('./extensions');
const { AiHost } = require('./ai');
const { UpdateManager, loadAutoUpdater } = require('./updater');
const { AutoScroller } = require('./autoscroll');
const AS = require('../shared/autoscroll');
const CHANGELOG = require('../shared/changelog');
const U = require('./urlutil');
const TR = require('../shared/translate');
const L = require('../shared/lists');

const SRC = path.join(__dirname, '..');
const ASSETS = path.join(SRC, '..', 'assets');
const NEWTAB_FILE = path.join(SRC, 'renderer', 'newtab.html');
const ERROR_TPL = path.join(SRC, 'renderer', 'error.html');
const PART_NORMAL = 'persist:evergreen';
const PART_INCOG = 'evergreen-incognito'; // persist: 없음 → 메모리에만 (시크릿)
const STRIP_H = 44;
const TOOLBAR_H = 54;

// 안드로이드 values/colors.xml · values-night/colors.xml 과 같은 색
const THEME = {
  light: { strip: '#E9EDF4', symbol: '#202124', bg: '#F7F8FA' },
  dark: { strip: '#31363E', symbol: '#E6E8EB', bg: '#121316' },
};

let win = null;
let overlay = null;
let store = null;
const tabs = new Map(); // id → tab
let wins = []; // 「창」(탭 묶음): { id, num, name, tabIds, active }
let activeWin = 0;
let nextTab = 1;
let nextWin = 1;
let chromeH = STRIP_H + TOOLBAR_H;
let currentView = null;
let popupOpen = false;
let fsTab = null;
const closedStack = [];
let data = null; // 북마크 · 방문 기록 · 즐겨찾기 · 받은 파일 기록
let downloads = null;
let floats = null; // 토스트 · 주소창 추천 층
let sec = null; // 광고·보안 (3단계)
let player = null; // 내장 플레이어 · 미러링 (4단계)
let ext = null; // 확장 프로그램 (5단계)
let ai = null; // AI 어시스턴트 (6단계)
let updater = null; // 자동 업데이트 (7단계)
let autoScroll = null; // 자동 스크롤 (v0.11.0)
let suggestSeq = 0;

// ───────── 보조 ─────────
const activeW = () => wins.find((w) => w.id === activeWin);
const activeTab = () => { const w = activeW(); return w ? tabs.get(w.active) : null; };
const tabByWc = (wc) => { for (const t of tabs.values()) if (t.view.webContents === wc) return t; return null; };
const isDark = () => nativeTheme.shouldUseDarkColors;
const cleanUA = (ua) => ua.replace(/\sElectron\/[\d.]+/, '').replace(/\sEvergreen\/[\d.]+/i, '');
const nav = (wc) => wc.navigationHistory || wc;
const canBack = (wc) => (wc.navigationHistory ? wc.navigationHistory.canGoBack() : wc.canGoBack());
const canFwd = (wc) => (wc.navigationHistory ? wc.navigationHistory.canGoForward() : wc.canGoForward());
const goBack = (wc) => { const t = tabByWc(wc); if (t && sec) sec.noteBack(t); return wc.navigationHistory ? wc.navigationHistory.goBack() : wc.goBack(); };
const goFwd = (wc) => (wc.navigationHistory ? wc.navigationHistory.goForward() : wc.goForward());
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function userUrl(t) {
  const u = t.view.webContents.getURL();
  if (!u) return t.lazy || '';
  if (u.startsWith('file:') && /newtab\.html/.test(u)) return '';
  if (u.startsWith('data:text/html') && t.errUrl) return t.errUrl;
  return u;
}

// ───────── 상태 → 화면 ─────────
const effZoom = (t) => (t.zoom != null ? t.zoom : store.get('zoom'));
function tabInfo(t) {
  return { id: t.id, title: t.title, url: t.url, favicon: t.favicon, loading: t.loading, incognito: t.incognito,
    audible: t.audible, canBack: t.canBack, canFwd: t.canFwd, secure: t.secure,
    tr: ai && t.view && !t.view.webContents.isDestroyed() ? ai.trStatus(t.view.webContents.id) : 'idle', zoom: effZoom(t), zoomOnly: t.zoom != null, media: (t.media || []).length, bookmarked: !!(t.url && /^https?:/i.test(t.url) && data.findBookmark(t.url)) };
}
function snapshot() {
  return {
    activeWin,
    wins: wins.map((w) => ({ id: w.id, num: w.num, name: w.name, active: w.active, tabs: w.tabIds.map((id) => tabInfo(tabs.get(id))) })),
    prefs: { trLang: store.get('trLang'), trImages: !!store.get('trImages'), theme: store.get('theme'), engine: store.get('engine'), zoom: store.get('zoom'), bookmarkBar: store.get('bookmarkBar') },
    ai: { open: !!(ai && ai.open) },
    autoScroll: autoScroll ? autoScroll.snapshot() : { cfg: AS.normalize(store.get('autoScroll')), running: false, tabId: null, paused: false },
    sec: sec ? { summary: sec.summary(), adBlock: sec.get('adBlock') } : null,
    dl: downloads ? downloads.summary() : { count: 0, progress: 0 },
    version: app.getVersion(), update: updater ? Object.assign(updater.snapshot(), { auto: !!store.get('autoUpdate') }) : null, extTheme: ext ? ext.activeTheme() : null, changelog: CHANGELOG.ENTRIES,
    langs: TR.LANGS.map((l) => ({ key: l.key, name: l.name })), engines: Object.keys(U.ENGINES).map((k) => ({ key: k, name: U.ENGINES[k].name })),
  };
}
let pushTimer = null;
function pushState() {
  if (pushTimer) return;
  pushTimer = setTimeout(() => {
    pushTimer = null;
    if (!win || win.isDestroyed()) return;
    const s = snapshot();
    win.webContents.send('state', s);
    if (popupOpen) overlay.webContents.send('state', s);
    if (ai) ai.sendState(s);
    const t = activeTab();
    win.setTitle(t && (t.title || t.url) ? (t.title || t.url) + ' - Evergreen' : 'Evergreen');
  }, 16);
}

function saveSession() {
  const out = {
    activeWin: Math.max(0, wins.findIndex((w) => w.id === activeWin)),
    wins: wins.map((w) => {
      const list = w.tabIds.map((id) => tabs.get(id)).filter((t) => t && !t.incognito);
      return { num: w.num, name: w.name, active: Math.max(0, list.findIndex((t) => t.id === w.active)),
        tabs: list.map((t) => ({ url: t.url, title: t.title })) };
    }),
  };
  store.set('session', out);
}

// ───────── 배치 ─────────
function layout() {
  if (!win || win.isDestroyed()) return;
  const [w, h] = win.getContentSize();
  const top = fsTab ? 0 : chromeH;
  const aw = ai && !fsTab ? ai.dockWidth() : 0; // AI 패널이 열려 있으면 웹 화면은 그만큼 좁아진다
  if (currentView) currentView.setBounds({ x: 0, y: top, width: Math.max(0, w - aw), height: Math.max(0, h - top) });
  if (ai) { ai.view.setVisible(ai.open && !fsTab); ai.relayout(w, top, h - top); }
  overlay.setBounds({ x: 0, y: 0, width: w, height: h });
  if (floats) floats.relayout();
  if (player) player.relayout();
}
function showActive() {
  const t = activeTab();
  if (player && player.mirrorTab() && player.mirrorTab() !== t) player.close();
  if (currentView && (!t || currentView !== t.view)) {
    try { win.contentView.removeChildView(currentView); } catch (e) { /* 이미 없음 */ }
    currentView = null;
  }
  if (!t) return;
  if (t.lazy) { const u = t.lazy; t.lazy = null; load(t, u); }
  if (currentView !== t.view) { currentView = t.view; win.contentView.addChildView(t.view); }
  layout();
  raise(); // 팝업 · 토스트 · 추천 층은 항상 맨 위
  if (!popupOpen) {
    if (!t.url) { win.webContents.focus(); win.webContents.send('focus-url'); } else t.view.webContents.focus();
  }
}

// ───────── 탭 ─────────
function load(t, url) {
  const wc = t.view.webContents;
  t.errUrl = null;
  t.userDlAt = Date.now(); // 사용자가 연 주소가 파일이면 받아도 된다 (자동 다운로드 차단 예외)
  if (!url || url === U.NEWTAB) wc.loadFile(NEWTAB_FILE);
  else wc.loadURL(url).catch(() => { /* 오류는 did-fail-load 에서 */ });
}
function sync(t) {
  const wc = t.view.webContents;
  t.url = userUrl(t);
  t.canBack = canBack(wc);
  t.canFwd = canFwd(wc);
  t.secure = U.isSecure(t.url);
}
function showError(t, code, url) {
  const d = U.describeError(code, !net.isOnline());
  let host = '';
  try { host = new URL(url).host; } catch (e) { host = url || ''; }
  const next = U.nextNumbered(url);
  let html;
  try { html = fs.readFileSync(ERROR_TPL, 'utf8'); } catch (e) { return; }
  html = html.replace('__TITLE__', esc(d.title)).replace('__MSG__', esc(d.msg)).replace('__HOST__', esc(host))
    .replace('__CODE__', esc(code)).replace('__URL_JSON__', JSON.stringify(url || '').replace(/</g, '\\u003c'))
    .replace('__NEXT_JSON__', JSON.stringify(next).replace(/</g, '\\u003c'));
  t.errUrl = url;
  t.title = d.title;
  t.view.webContents.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html)).catch(() => {});
}

// 이미지를 우클릭하면 그 이미지에 번역이 덮여 있는지 페이지에 먼저 물어본 뒤(이미지 번역 ↔ 번역 해제) 메뉴를 띄운다
function contextMenu(t, p) {
  const wc = t.view.webContents;
  if (ai && p.mediaType === 'image' && p.srcURL && !p.linkURL && /^https?:/i.test(wc.getURL())) {
    let done = false; const go = (has) => { if (!done) { done = true; buildContextMenu(t, p, has); } };
    ai.imageTranslated(wc, p.srcURL).then(go, () => go(false)); setTimeout(() => go(false), 400);
  } else buildContextMenu(t, p, false);
}
function buildContextMenu(t, p, imgTr) {
  const wc = t.view.webContents;
  t.userDlAt = Date.now(); // 메뉴에서 파일 저장을 고르면 사용자가 시킨 다운로드
  const items = [];
  if (p.linkURL) {
    items.push({ label: '링크를 새 탭에서 열기', click: () => createTab(t.wid, p.linkURL, { afterId: t.id, incognito: t.incognito }) });
    items.push({ label: '링크 주소 복사', click: () => clipboard.writeText(p.linkURL) });
    items.push({ label: '링크된 파일 저장', click: () => wc.downloadURL(p.linkURL) });
    items.push({ type: 'separator' });
  }
  if (p.mediaType === 'image' && p.srcURL) {
    items.push({ label: '이미지를 새 탭에서 열기', click: () => createTab(t.wid, p.srcURL, { afterId: t.id, incognito: t.incognito }) });
    items.push({ label: '이미지 주소 복사', click: () => clipboard.writeText(p.srcURL) });
    items.push({ label: '이미지 복사', click: () => wc.copyImageAt(p.x, p.y) });
    if (ai && /^https?:/i.test(wc.getURL())) {
      if (imgTr) items.push({ label: '번역 해제', click: () => cmd('img:untranslate', p.srcURL) });
      else items.push({ label: '이미지 번역 (' + TR.lang(store.get('trLang')).name + ')', click: () => cmd('img:translate', p.srcURL) });
    }
    items.push({ label: '이미지를 다운로드', click: () => wc.downloadURL(p.srcURL) });
    items.push({ type: 'separator' });
  }
  if ((p.mediaType === 'video' || p.mediaType === 'audio')) {
    const direct = p.srcURL && /^https?:|^file:/i.test(p.srcURL);
    if (direct) items.push({ label: '내장 플레이어로 열기', click: () => openInPlayer({ url: p.srcURL, tab: t, title: t.title }) });
    if (p.mediaType === 'video') items.push({ label: '미러링 플레이어로 보기', click: () => player.openMirror(t) });
    if (direct) { items.push({ label: '영상 주소 복사', click: () => clipboard.writeText(p.srcURL) }); items.push({ label: '영상 저장', click: () => { t.userDlAt = Date.now(); if (player) player.saveFor(t, p.srcURL, t.title); } }); }
    items.push({ type: 'separator' });
  } else if ((t.media || []).length && !p.linkURL && !p.isEditable) {
    items.push({ label: '감지된 영상을 내장 플레이어로 열기', click: () => cmd('player:media') });
    items.push({ type: 'separator' });
  }
  if (p.isEditable) {
    items.push({ label: '잘라내기', role: 'cut', enabled: p.editFlags.canCut });
    items.push({ label: '복사', role: 'copy', enabled: p.editFlags.canCopy });
    items.push({ label: '붙여넣기', role: 'paste', enabled: p.editFlags.canPaste });
    items.push({ label: '전체 선택', role: 'selectAll' });
    items.push({ type: 'separator' });
  } else if (p.selectionText) {
    items.push({ label: '복사', role: 'copy' });
    const q = p.selectionText.trim().slice(0, 80);
    if (ai) items.push({ label: 'AI에게 물어보기', click: () => ai.ask('다음 글을 설명해 줘:\n"' + p.selectionText.trim().slice(0, 1500) + '"', { send: false }) });
    items.push({ label: '“' + (q.length > 24 ? q.slice(0, 24) + '…' : q) + '” 검색', click: () => createTab(t.wid, U.engine(store.get('engine')).search + encodeURIComponent(q), { afterId: t.id, incognito: t.incognito }) });
    items.push({ type: 'separator' });
  }
  if (!p.linkURL && !p.isEditable) {
    if (ai && /^https?:/i.test(wc.getURL())) { const st = ai.trStatus(wc.id); items.push({ label: st === 'done' ? '원문 보기' : st === 'running' ? '번역 멈추기' : '페이지 번역 (' + TR.lang(store.get('trLang')).name + ')', click: () => cmd('page:translate') }); items.push({ type: 'separator' }); }
    if (autoScroll && /^https?:/i.test(wc.getURL())) { items.push({ label: autoScroll.isRunningOn(t) ? '자동 스크롤 끝내기' : '자동 스크롤', click: () => cmd('ascroll:toggle') }); items.push({ type: 'separator' }); }
    items.push({ label: '뒤로', enabled: canBack(wc), click: () => goBack(wc) });
    items.push({ label: '앞으로', enabled: canFwd(wc), click: () => goFwd(wc) });
    items.push({ label: '새로고침', click: () => wc.reload() });
    items.push({ type: 'separator' });
  }
  items.push({ label: '검사', click: () => wc.inspectElement(p.x, p.y) });
  if (autoScroll) autoScroll.holdForMenu(t, true); // 메뉴가 떠 있는 동안 자동 스크롤은 잠깐 멈춘다
  Menu.buildFromTemplate(items).popup({ window: win, callback: () => { if (autoScroll) autoScroll.holdForMenu(t, false); } });
}

function wireTab(t) {
  const wc = t.view.webContents;
  const changed = () => pushState();
  wc.on('page-title-updated', (_e, title) => { t.title = title; if (!t.incognito && !t.errUrl && /^https?:/i.test(t.url)) data.touchHistoryTitle(t.url, title); changed(); });
  wc.on('page-favicon-updated', (_e, icons) => { t.favicon = icons[0] || ''; if (!t.incognito && t.favicon && /^https?:/i.test(t.url)) data.setFavicon(t.url, t.favicon); changed(); });
  wc.on('did-start-loading', () => { t.loading = true; changed(); });
  wc.on('did-stop-loading', () => {
    t.loading = false; sync(t);
    if (!t.incognito && !t.errUrl && /^https?:/i.test(t.url)) data.addHistory(t.url, t.title); // 방문 기록 (시크릿 탭·오류 화면은 남기지 않는다)
    applyZoom(t); changed(); saveSession();
  });
  wc.on('dom-ready', () => { applyZoom(t); if (autoScroll) autoScroll.onDomReady(t); });
  wc.on('zoom-changed', (_e, dir) => { if (activeTab() === t) cmd('zoom:step', dir === 'in' ? 10 : -10); });
  wc.on('did-start-navigation', (d) => { if (d.isMainFrame && !d.isSameDocument) { if (autoScroll) autoScroll.onNavigate(t); if (ai) ai.trForget(wc.id); t.favicon = ''; t.media = []; if (player) player.tabGone(t); } });
  wc.on('did-navigate', () => { sync(t); applyZoom(t); changed(); });
  wc.on('did-navigate-in-page', () => { sync(t); changed(); });
  wc.on('did-fail-load', (_e, code, _desc, url, isMain) => { if (!isMain) return; const handled = sec.handleFail(t, code, url); if (code !== -3 && !handled) showError(t, code, url); });
  wc.on('render-process-gone', (_e, d) => { if (d.reason !== 'clean-exit') showError(t, -1, t.url); });
  wc.on('media-started-playing', () => { t.audible = true; changed(); });
  wc.on('media-paused', () => { t.audible = false; changed(); });
  wc.on('context-menu', (_e, p) => contextMenu(t, p));
  wc.on('before-input-event', onKey);
  wc.on('enter-html-full-screen', () => { fsTab = t; win.setFullScreen(true); layout(); });
  wc.on('leave-html-full-screen', () => { fsTab = null; win.setFullScreen(false); layout(); });
  sec.wireTab(t);
  wc.setWindowOpenHandler(({ url, disposition }) => {
    if (url && url !== 'about:blank' && sec.checkPopup(t, url)) return { action: 'deny' };
    if (disposition === 'new-window') { // 로그인 팝업처럼 opener 가 필요한 창은 그대로 연다
      return { action: 'allow', overrideBrowserWindowOptions: { width: 520, height: 720, autoHideMenuBar: true, parent: win } };
    }
    if (url && url !== 'about:blank') createTab(t.wid, url, { afterId: t.id, incognito: t.incognito, activate: disposition !== 'background-tab', scriptPopup: true });
    return { action: 'deny' };
  });
}

function createTab(wid, rawUrl, o = {}) {
  const w = wins.find((x) => x.id === wid);
  if (!w) return null;
  const incognito = !!o.incognito;
  const view = new WebContentsView({
    webPreferences: { partition: incognito ? PART_INCOG : PART_NORMAL, preload: path.join(__dirname, 'tab-preload.js'),
      contextIsolation: true, sandbox: true, nodeIntegration: false, spellcheck: true },
  });
  view.setBackgroundColor(isDark() ? THEME.dark.bg : '#FFFFFF');
  const wc = view.webContents;
  wc.setUserAgent(cleanUA(wc.getUserAgent()));
  const id = nextTab++;
  const t = { id, wid, view, url: o.lazy ? rawUrl || '' : '', title: o.title || '', favicon: '', loading: false, incognito,
    audible: false, canBack: false, canFwd: false, secure: false, errUrl: null, lazy: null, zoom: null,
    curHost: null, adBlocked: 0, scriptPopup: !!o.scriptPopup, tapAt: 0, tapMark: 0, upgradedFrom: null, secBlock: null };
  tabs.set(id, t);
  let at = w.tabIds.length;
  if (o.afterId && w.tabIds.includes(o.afterId)) at = w.tabIds.indexOf(o.afterId) + 1;
  w.tabIds.splice(at, 0, id);
  wireTab(t);
  if (o.lazy) { t.lazy = rawUrl || U.NEWTAB; } else load(t, rawUrl);
  if (o.activate !== false) { w.active = id; activeWin = w.id; showActive(); }
  pushState(); saveSession();
  return t;
}

function closeTab(id) {
  const t = tabs.get(id);
  if (!t) return;
  const w = wins.find((x) => x.id === t.wid);
  const idx = w.tabIds.indexOf(id);
  if (!t.incognito && t.url) { closedStack.push({ url: t.url, wid: w.id }); if (closedStack.length > 20) closedStack.shift(); }
  if (player) player.tabGone(t);
  w.tabIds.splice(idx, 1);
  const wasActive = w.active === id;
  if (currentView === t.view) { try { win.contentView.removeChildView(currentView); } catch (e) { /* */ } currentView = null; }
  if (fsTab === t) { fsTab = null; win.setFullScreen(false); }
  tabs.delete(id);
  try { t.view.webContents.close(); } catch (e) { /* */ }
  if (!w.tabIds.length) { createTab(w.id, '', { activate: w.id === activeWin }); return; }
  if (wasActive) { w.active = w.tabIds[Math.min(idx, w.tabIds.length - 1)]; if (w.id === activeWin) showActive(); }
  pushState(); saveSession();
}

function activateTab(id) {
  const t = tabs.get(id);
  if (!t) return;
  const w = wins.find((x) => x.id === t.wid);
  w.active = id; activeWin = w.id;
  showActive(); pushState(); saveSession();
}

function moveTab(id, index) {
  const t = tabs.get(id);
  if (!t) return;
  const w = wins.find((x) => x.id === t.wid);
  const from = w.tabIds.indexOf(id);
  w.tabIds.splice(from, 1);
  w.tabIds.splice(Math.max(0, Math.min(index, w.tabIds.length)), 0, id);
  pushState(); saveSession();
}

// ───────── 「창」(탭 묶음) ─────────
function newWindowGroup(name) {
  const used = new Set(wins.map((w) => w.num));
  let num = 1;
  while (used.has(num)) num++;
  const w = { id: nextWin++, num, name: name || '창 ' + num, tabIds: [], active: 0 };
  wins.push(w);
  activeWin = w.id;
  createTab(w.id, '', {});
  return w;
}
function switchWindow(id) {
  const w = wins.find((x) => x.id === id);
  if (!w) return;
  activeWin = id;
  if (!tabs.has(w.active)) w.active = w.tabIds[0];
  showActive(); pushState(); saveSession();
}
function deleteWindow(id) {
  if (wins.length <= 1) return;
  const w = wins.find((x) => x.id === id);
  if (!w) return;
  const wasActive = id === activeWin;
  if (wasActive && currentView) { try { win.contentView.removeChildView(currentView); } catch (e) { /* */ } currentView = null; }
  for (const tid of w.tabIds.slice()) { const t = tabs.get(tid); tabs.delete(tid); try { t.view.webContents.close(); } catch (e) { /* */ } }
  const i = wins.indexOf(w);
  wins.splice(i, 1);
  if (wasActive) { activeWin = wins[Math.max(0, i - 1)].id; showActive(); }
  pushState(); saveSession();
}

// ───────── 명령 ─────────
function applyTheme() {
  nativeTheme.themeSource = store.get('theme');
  const c = isDark() ? THEME.dark : THEME.light;
  if (win && !win.isDestroyed()) {
    try { win.setTitleBarOverlay({ color: c.strip, symbolColor: c.symbol, height: STRIP_H }); } catch (e) { /* */ }
    win.setBackgroundColor(c.bg);
  }
}
// 내장 플레이어로 열기: 원래 탭의 주소 · UA 를 Referer/User-Agent 로 넘겨 로그인·핫링크 방지 영상도 열리게 한다
function openInPlayer(m) {
  if (!player || !m || !m.url) return;
  const t = m.tab || activeTab();
  player.open({ url: m.url, title: m.title || '', referer: t && /^https?:/i.test(t.view.webContents.getURL()) ? t.view.webContents.getURL() : '', ua: t ? t.view.webContents.getUserAgent() : '', tab: t, subs: m.subs || [], startAt: m.startAt || 0 });
}
async function cookiesFor(t, url) {
  const list = await t.view.webContents.session.cookies.get({ url });
  return list.map((c) => c.name + '=' + c.value).join('; ');
}
function cmd(name, arg) {
  const t = activeTab();
  const wc = t && t.view.webContents;
  switch (name) {
    case 'tab:new': createTab(activeWin, arg && arg.input ? U.resolveInput(arg.input, store.get('engine')) : '', { incognito: !!(arg && arg.incognito), afterId: arg && arg.after }); break;
    case 'tab:close': closeTab(arg); break;
    case 'tab:close-active': if (t) closeTab(t.id); break;
    case 'tab:activate': activateTab(arg); break;
    case 'tab:move': moveTab(arg.id, arg.index); break;
    case 'tab:duplicate': { const s = tabs.get(arg); if (s) createTab(s.wid, s.url, { afterId: s.id, incognito: s.incognito }); break; }
    case 'tab:reopen': { const c = closedStack.pop(); if (c) createTab(wins.some((w) => w.id === c.wid) ? c.wid : activeWin, c.url, {}); break; }
    case 'tab:next': case 'tab:prev': {
      const w = activeW(); if (!w || w.tabIds.length < 2) break;
      const i = w.tabIds.indexOf(w.active);
      const n = (i + (name === 'tab:next' ? 1 : -1) + w.tabIds.length) % w.tabIds.length;
      activateTab(w.tabIds[n]); break;
    }
    case 'tab:select-index': { const w = activeW(); if (!w) break; const n = Number(arg); activateTab(n === 9 ? w.tabIds[w.tabIds.length - 1] : w.tabIds[n - 1]); break; }
    case 'nav:go': if (t) { const u = U.resolveInput(arg, store.get('engine')); load(t, u); t.url = u === U.NEWTAB ? '' : u; if (t.lazy) t.lazy = null; pushState(); if (wc) wc.focus(); } break;
    case 'nav:back': if (wc && canBack(wc)) goBack(wc); break;
    case 'nav:forward': if (wc && canFwd(wc)) goFwd(wc); break;
    case 'nav:reload': if (wc) { if (t.errUrl) load(t, t.errUrl); else wc.reload(); } break;
    case 'nav:hard-reload': if (wc) wc.reloadIgnoringCache(); break;
    case 'nav:stop': if (wc) wc.stop(); break;
    case 'nav:home': if (t) { load(t, U.NEWTAB); t.url = ''; pushState(); } break;
    case 'win:new': newWindowGroup(); break;
    case 'win:switch': switchWindow(arg); break;
    case 'win:rename': { const w = wins.find((x) => x.id === arg.id); const n = String(arg.name || '').trim().slice(0, 30); if (w && n) { w.name = n; pushState(); saveSession(); } break; }
    case 'win:delete': deleteWindow(arg); break;
    case 'theme:set': if (['system', 'light', 'dark'].includes(arg)) { store.set('theme', arg); applyTheme(); pushState(); } break;
    case 'engine:set': if (U.ENGINES[arg]) { store.set('engine', arg); pushState(); } break;
    case 'player:media': { const m = t && (t.media || []).slice().reverse().find((x) => x.hls) || (t && (t.media || [])[(t.media || []).length - 1]); if (m) openInPlayer({ url: m.url, tab: t, title: t.title }); else toast('이 페이지에서 감지된 영상이 없어요 · 영상을 재생해 보세요'); break; }
    case 'player:mirror': if (player && t) player.openMirror(t); break;
    case 'player:open': { const u = String(arg || '').trim(); if (/^https?:\/\//i.test(u)) openInPlayer({ url: u, tab: t, title: '' }); else toast('영상 주소는 http:// 또는 https:// 로 시작해야 해요'); break; }
    case 'player:file': pickMediaFile(win).then((f) => { if (f) player.open({ url: f.url, title: f.title, tab: t }); }); break;
    case 'player:close': if (player) player.close(); break;
    case 'ai:toggle': if (ai) ai.toggle(); break;
    case 'ai:open': if (ai) ai.setOpen(true); break;
    case 'ai:ask': if (ai) ai.ask(arg && arg.text, { send: !!(arg && arg.send) }); break;
    case 'page:translate': if (ai && wc) ai.translate(wc, store.get('trLang')); break;
    case 'trimg:toggle': store.set('trImages', !store.get('trImages')); pushState(); toast(store.get('trImages') ? '페이지를 번역할 때 이미지 속 글자도 번역해요' : '이미지 속 글자는 번역하지 않아요'); break;
    case 'img:translate': if (ai && wc && arg) ai.translateImage(wc, arg, store.get('trLang')); break;
    case 'img:untranslate': if (ai && wc) ai.untranslateImage(wc, arg || ''); break;
    case 'trlang:set': if (TR.LANGS.some((l) => l.key === arg)) { store.set('trLang', arg); pushState(); } break;
    case 'ascroll:toggle': if (autoScroll && t) autoScroll.toggle(t); break;
    case 'ascroll:stop': if (autoScroll) autoScroll.stop('자동 스크롤을 멈췄어요'); break;
    case 'ascroll:set': if (autoScroll && arg && typeof arg === 'object') { const c = AS.normalize(arg); autoScroll.setCfg(c); autoScroll.applyControlsSetting(); } break;
    case 'dialog:ascroll': openDialog('ascroll', {}); break;
    case 'update:check': if (updater) updater.check(true); break;
    case 'update:install': if (updater && !updater.installNow()) toast('아직 설치할 새 버전이 없어요'); break;
    case 'update:auto': if (updater) updater.setAuto(!!arg); break;
    case 'app:devtools': if (wc) wc.toggleDevTools(); break;
    case 'focus-url': win.webContents.focus(); win.webContents.send('focus-url'); break;
    default: if (!sec.command(name, arg, t)) cmdData(name, arg, t); break;
  }
}

// ───────── AI 가 앱을 만지는 길 (6단계) ─────────
function aiChangeSetting(name, value) {
  const on = /^(true|on|켜|켬|1|yes)$/i.test(String(value)), off = /^(false|off|끄|끔|꺼|0|no)$/i.test(String(value));
  switch (name) {
    case 'theme': if (!['system', 'light', 'dark'].includes(value)) return { error: 'theme 은 system · light · dark 중 하나예요' }; cmd('theme:set', value); return { ok: true, name, value };
    case 'engine': if (!U.ENGINES[value]) return { error: 'engine 은 ' + Object.keys(U.ENGINES).join(' · ') + ' 중 하나예요' }; cmd('engine:set', value); return { ok: true, name, value };
    case 'zoom': { const n = Number(value); if (!(n >= 50 && n <= 500)) return { error: 'zoom 은 50~500 사이 숫자예요' }; const t = activeTab(); if (!t || isInternalUrl(t.view.webContents.getURL())) return { error: '웹 페이지를 연 탭에서만 확대/축소를 바꿀 수 있어요' }; cmd('zoom:set', { value: n, tabOnly: false }); return { ok: true, name, value: n }; }
    case 'bookmarkBar': if (!on && !off) return { error: 'true / false 로 주세요' }; if (store.get('bookmarkBar') !== on) cmd('bar:toggle'); return { ok: true, name, value: on };
    default: {
      if (!(name in (sec ? sec.settings() : {}))) return { error: '바꿀 수 없는 설정이에요: ' + name };
      if (!on && !off) return { error: 'true / false 로 주세요' };
      sec.set(name, on); pushState(); return { ok: true, name, value: on };
    }
  }
}
const aiTabs = {
  all: () => { const w = activeW(); return w ? w.tabIds.map((id) => tabs.get(id)).filter(Boolean).map((t) => ({ id: t.id, title: t.title, url: userUrl(t), active: w.active === t.id, incognito: t.incognito, loading: t.loading, lazy: !!t.lazy })) : []; },
  activeWc: () => { const t = activeTab(); return t ? t.view.webContents : null; },
  wc: (id) => { const t = tabs.get(id); return t ? t.view.webContents : null; },
  open: (target, o) => { const url = target ? U.resolveInput(target, store.get('engine')) : ''; const t = createTab(activeWin, url === U.NEWTAB ? '' : url, { incognito: !!o.incognito, activate: !o.background }); const w = activeW(); return t && w ? w.tabIds.indexOf(t.id) + 1 : 0; },
  close: (id) => closeTab(id), activate: (id) => activateTab(id), move: (id, index) => moveTab(id, index),
  duplicate: (id) => cmd('tab:duplicate', id), reopen: () => cmd('tab:reopen'), go: (target) => cmd('nav:go', target),
  nav: (act) => cmd({ back: 'nav:back', forward: 'nav:forward', reload: 'nav:reload', stop: 'nav:stop', home: 'nav:home' }[act] || 'nav:reload'),
  markRead: () => {},
  windows: () => wins.map((w) => ({ number: w.num, name: w.name, tabs: w.tabIds.length, current: w.id === activeWin })),
};

function onKey(e, input) {
  if (input.type !== 'keyDown') return;
  const ctrl = input.control || input.meta;
  const k = String(input.key || '').toLowerCase();
  let name = null; let arg;
  if (ctrl && !input.alt) {
    if (k === 't') name = input.shift ? 'tab:reopen' : 'tab:new';
    else if (k === 'n' && input.shift) { name = 'tab:new'; arg = { incognito: true }; }
    else if (k === 'w') name = 'tab:close-active';
    else if (k === 'l') name = 'focus-url';
    else if (k === 'r') name = input.shift ? 'nav:hard-reload' : 'nav:reload';
    else if (k === 'f5') name = 'nav:hard-reload';
    else if (k === 'tab') name = input.shift ? 'tab:prev' : 'tab:next';
    else if (k === 'pagedown') name = 'tab:next';
    else if (k === 'pageup') name = 'tab:prev';
    else if (/^[1-9]$/.test(k)) { name = 'tab:select-index'; arg = k; }
    else if (k === '=' || k === '+') { name = 'zoom:step'; arg = 10; }
    else if (k === '-' || k === '_') { name = 'zoom:step'; arg = -10; }
    else if (k === '0') name = 'zoom:reset';
    else if (k === 'd') name = 'bm:toggle';
    else if (k === 'h') name = 'panel:history';
    else if (k === 'j') name = 'panel:downloads';
    else if (k === 'o' && input.shift) name = 'panel:bookmarks';
    else if (k === 'b' && input.shift) name = 'bar:toggle';
    else if (k === 'i' && input.shift) name = 'app:devtools';
    else if (k === 'm' && input.shift) name = 'player:mirror';
    else if (k === 'a' && input.shift) name = 'ai:toggle';
    else if (k === 's' && input.shift) name = 'ascroll:toggle';
    else if (k === 'o' && !input.shift) name = 'player:file';
  } else if (input.alt && !ctrl) {
    if (k === 'arrowleft') name = 'nav:back';
    else if (k === 'arrowright') name = 'nav:forward';
    else if (k === 'home') name = 'nav:home';
    else if (k === 'd') name = 'focus-url';
  } else if (!ctrl && !input.alt) {
    if (k === 'f5') name = 'nav:reload';
    else if (k === 'f12') name = 'app:devtools';
    else if (k === 'f6') name = 'focus-url';
  }
  if (name) { e.preventDefault(); cmd(name, arg); }
}

// ───────── 팝업 층 ─────────
function hidePopup() {
  if (!popupOpen) return;
  popupOpen = false;
  overlay.setVisible(false);
  const t = activeTab();
  if (t && t.url) t.view.webContents.focus(); else { win.webContents.focus(); }
}

// ───────── 토스트 · 팝업 · 대화상자 ─────────
function toast(msg, action) {
  if (!floats) return;
  floats.toast(msg, action && { label: action.label, fn: action.fn || (() => cmd(action.name, action.arg)) });
}
function raise() {
  if (!win || win.isDestroyed()) return;
  if (ai) ai.front();
  if (player) player.front();
  if (ext) ext.front();
  win.contentView.addChildView(overlay);
  if (floats) floats.raise();
}
// 메뉴 단추(도구 줄 맨 오른쪽)의 자리 — 팝업을 메뉴 자리에서 열 때 쓴다
function menuAnchor() { const [w] = win.getContentSize(); return { x: w - 48, y: STRIP_H + 7, w: 40, h: 40 }; }
function openPopup(kind, anchor, left, payload) {
  if (floats) floats.suggestHide();
  popupOpen = true;
  overlay.setVisible(true);
  layout(); raise();
  overlay.webContents.focus();
  overlay.webContents.send('overlay:show', { kind, anchor: anchor || menuAnchor(), left: !!left, data: payload || null, state: snapshot() });
}
// 팝업 없이 대화상자만 (이미 팝업이 열려 있으면 그 위에)
function openDialog(kind, params) {
  if (!popupOpen) openPopup('none', null, false, null);
  overlay.webContents.send('overlay:dialog', { kind, params });
}

// ───────── 확대/축소 (안드로이드: 50~500%, 10% 단위, 전체 설정 + 이 탭만) ─────────
const isInternalUrl = (u) => !u || u.startsWith('file:') || u.startsWith('data:');
function applyZoom(t) {
  const wc = t.view.webContents;
  if (wc.isDestroyed()) return;
  const z = isInternalUrl(wc.getURL()) ? 1 : effZoom(t) / 100; // 새 탭·오류 화면은 확대하지 않는다
  try { if (Math.abs(wc.getZoomFactor() - z) > 0.001) wc.setZoomFactor(z); } catch (e) { /* 아직 준비 전 */ }
}
function setZoom(t, value, tabOnly) {
  const v = Math.max(50, Math.min(500, Math.round(value / 10) * 10));
  if (tabOnly) t.zoom = v; else { store.set('zoom', v); t.zoom = null; }
  tabs.forEach((x) => { if (x === t || x.zoom == null) applyZoom(x); });
  pushState();
  return v;
}

// ───────── 데이터 명령 (북마크 · 방문 기록 · 다운로드 · 즐겨찾기 · 확대/축소) ─────────
function bookmarkParams(url, title) {
  const ex = data.findBookmark(url);
  const folders = data.folders('bm');
  let fid = ex ? ex.folderId : store.get('bmLastFolder') || 0;
  if (fid && !folders.some((f) => f.id === fid)) fid = 0;
  return { id: ex ? ex.id : null, url, title: ex ? ex.title : title || '', folderId: fid, folders };
}
const asList = (a) => (Array.isArray(a) ? a : [a]);

async function importBookmarks() {
  const r = await dialog.showOpenDialog(win, { title: '북마크 가져오기', properties: ['openFile'], filters: [{ name: '북마크 HTML', extensions: ['html', 'htm'] }] });
  if (r.canceled || !r.filePaths[0]) return;
  try {
    if (fs.statSync(r.filePaths[0]).size > 10 * 1024 * 1024) { toast('파일이 너무 커요 (10MB 까지)'); return; }
    const parsed = L.parseBookmarksHtml(fs.readFileSync(r.filePaths[0], 'utf8'));
    if (!parsed.length) { toast('북마크를 찾지 못했어요 · 크롬·엣지·파이어폭스에서 내보낸 북마크 HTML 파일인지 확인해 주세요'); return; }
    const res = data.importBookmarks(parsed);
    toast('북마크 ' + res.added + '개를 가져왔습니다' + (res.skipped ? ' (이미 있는 ' + res.skipped + '개는 건너뜀)' : '') + (res.truncated ? ' · 앞의 ' + L.MAX_IMPORT + '개까지만' : ''));
  } catch (e) { toast('파일을 읽지 못했어요'); }
}
async function exportBookmarks() {
  const d = new Date(), pad = (n) => String(n).padStart(2, '0');
  const name = 'evergreen_bookmarks_' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes()) + '.html';
  const r = await dialog.showSaveDialog(win, { title: '북마크 내보내기', defaultPath: path.join(app.getPath('downloads'), name), filters: [{ name: '북마크 HTML', extensions: ['html'] }] });
  if (r.canceled || !r.filePath) return;
  try {
    fs.writeFileSync(r.filePath, L.bookmarksToHtml(data.bookmarks(), data.folders('bm'), Date.now()), 'utf8');
    toast('북마크를 내보냈습니다 · ' + path.basename(r.filePath), { label: '폴더 열기', fn: () => shell.showItemInFolder(r.filePath) });
  } catch (e) { toast('파일을 저장하지 못했어요'); }
}

function cmdData(name, arg, t) {
  switch (name) {
    // 확대/축소
    case 'zoom:step': if (t && !isInternalUrl(t.view.webContents.getURL())) { const v = setZoom(t, effZoom(t) + arg, t.zoom != null); toast('화면 확대/축소 ' + v + '%' + (t.zoom != null ? ' (이 탭만)' : '')); } break;
    case 'zoom:reset': if (t && !isInternalUrl(t.view.webContents.getURL())) { setZoom(t, 100, t.zoom != null); toast('화면 확대/축소 100%'); } break;
    case 'zoom:set': if (t && arg) setZoom(t, Number(arg.value), !!arg.tabOnly); break;
    case 'zoom:preview': if (t && !isInternalUrl(t.view.webContents.getURL())) { try { t.view.webContents.setZoomFactor(Math.max(50, Math.min(500, Number(arg))) / 100); } catch (e) { /* */ } } break;
    case 'zoom:preview-end': if (t) applyZoom(t); break;
    // 북마크
    case 'bm:toggle': {
      const url = t ? userUrl(t) : '';
      if (!url || !/^https?:/i.test(url)) { toast('이 페이지는 북마크에 추가할 수 없어요'); break; }
      openDialog('bookmark', bookmarkParams(url, t.title));
      break;
    }
    case 'bm:edit': { const b = data.bookmarks().find((x) => x.id === Number(arg)); if (b) openDialog('bookmark', bookmarkParams(b.url, b.title)); break; }
    case 'bm:save': {
      const v = arg || {};
      const raw = String(v.url || '').trim();
      if (!raw || /\s/.test(raw)) { toast('주소를 입력하세요'); break; }
      const fid = Number(v.folderId) || 0;
      data.saveBookmark(L.normalizeUrl(raw), String(v.title || '').trim().slice(0, 200), fid, v.id != null ? Number(v.id) : undefined);
      store.set('bmLastFolder', fid);
      toast(v.id != null ? '북마크를 수정했습니다' : '북마크에 추가했습니다');
      break;
    }
    case 'bm:delete': {
      const ids = asList(arg).map(Number), before = data.bookmarks();
      data.removeBookmarks(ids);
      toast('북마크 ' + ids.length + '개를 삭제했습니다', { label: '실행 취소', fn: () => data.setBookmarks(before) });
      break;
    }
    case 'bm:move': if (arg) { data.moveBookmarks(asList(arg.ids).map(Number), Number(arg.folderId) || 0); toast(arg.folderName ? "'" + arg.folderName + "' 폴더로 옮겼습니다" : '폴더에서 뺐습니다'); } break;
    case 'bm:import': importBookmarks(); break;
    case 'bm:export': exportBookmarks(); break;
    case 'bar:toggle': store.set('bookmarkBar', !store.get('bookmarkBar')); pushState(); toast(store.get('bookmarkBar') ? '북마크 막대를 보여 줍니다' : '북마크 막대를 숨깁니다'); break;
    case 'folder:rename': if (arg) data.renameFolder(arg.kind === 'dl' ? 'dl' : 'bm', Number(arg.id), String(arg.name || '').trim().slice(0, 30) || '폴더'); break;
    case 'folder:remove': {
      const kind = arg && arg.kind === 'dl' ? 'dl' : 'bm';
      const snap = data.removeFolder(kind, Number(arg && arg.id));
      if (snap) toast("'" + snap.folder.name + "' 폴더를 삭제했습니다", { label: '실행 취소', fn: () => data.restoreFolder(kind, snap) });
      break;
    }
    // 방문 기록
    case 'hist:delete': {
      const urls = asList(arg).map(String), before = data.history();
      if (urls.length >= before.length) data.clearHistory(); else data.removeHistory(urls);
      toast('방문 기록 ' + urls.length + '개를 삭제했습니다', { label: '실행 취소', fn: () => data.setHistory(before) });
      break;
    }
    // 다운로드
    case 'dl:cancel': downloads.cancel(Number(arg)); break;
    case 'dl:pause': downloads.pause(Number(arg)); break;
    case 'dl:resume': downloads.resume(Number(arg)); break;
    case 'dl:open': downloads.open(String(arg)); break;
    case 'dl:show': downloads.show(String(arg)); break;
    case 'dl:delete': downloads.remove(asList(arg).map(String)).then((n) => { if (n) toast('파일 ' + n + '개를 휴지통으로 옮겼습니다'); }); break;
    case 'dl:move': if (arg) { data.setDlFolder(asList(arg.keys).map(String), Number(arg.folderId) || 0); toast(arg.folderName ? "'" + arg.folderName + "' 폴더로 옮겼습니다" : '폴더에서 뺐습니다'); } break;
    // 새 탭 즐겨찾기 타일
    case 'sc:save': {
      let url = String((arg && arg.url) || '').trim();
      if (!url || /\s/.test(url)) { toast('올바른 주소를 입력해 주세요'); break; }
      if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(url)) url = 'https://' + url;
      const host = L.hostOf(url);
      if (!host) { toast('올바른 주소를 입력해 주세요'); break; }
      const nm = String(arg.name || '').trim().slice(0, 30) || host;
      const list = data.shortcuts().slice();
      const idx = arg.index != null ? Number(arg.index) : -1, old = list[idx];
      const sc = { name: nm, url, glyph: old && old.name === nm ? old.glyph : '' };
      if (old) list[idx] = sc; else list.push(sc);
      data.setShortcuts(list);
      break;
    }
    case 'sc:delete': data.setShortcuts(data.shortcuts().filter((_x, i) => i !== Number(arg))); break;
    case 'sc:move': {
      const list = data.shortcuts().slice(), i = Number(arg.index), j = i + (arg.dir < 0 ? -1 : 1);
      if (i >= 0 && j >= 0 && i < list.length && j < list.length) { list.splice(j, 0, list.splice(i, 1)[0]); data.setShortcuts(list); }
      break;
    }
    case 'sc:reset': data.resetShortcuts(); toast('기본 즐겨찾기로 되돌렸어요'); break;
    // 목록 팝업 열기 (단축키)
    case 'panel:bookmarks': openPopup('bookmarks', null, false); break;
    case 'panel:history': openPopup('history', null, false); break;
    case 'panel:downloads': openPopup('downloads', null, false); break;
    case 'panel:adstats': openDialog('adstats', { stats: sec.adPayload(t ? t.adBlocked : null) }); break;
    case 'panel:secstats': openDialog('secstats', { stats: sec.secPayload() }); break;
    case 'dialog:secset': openDialog('secset', { settings: sec.settings() }); break;
    case 'dialog:zoom': if (t && !isInternalUrl(t.view.webContents.getURL())) openDialog('zoom', {}); break;
    case 'toast': toast(String(arg)); break;
    default: break;
  }
}

// 데이터가 바뀌면 화면들에 알린다 (별 표시 · 북마크 막대 · 열려 있는 목록 · 새 탭 타일)
function broadcast(kind) {
  if (!win || win.isDestroyed()) return;
  if (kind === 'favicons') return;
  if (kind === 'sec') tabs.forEach((t) => { const wc = t.view.webContents; if (!wc.isDestroyed() && /newtab\.html/.test(wc.getURL())) wc.send('cards', sec.homeCards()); });
  if (kind === 'shortcuts') tabs.forEach((t) => { const wc = t.view.webContents; if (!wc.isDestroyed() && /newtab\.html/.test(wc.getURL())) wc.send('shortcuts', data.shortcuts()); });
  win.webContents.send('data:changed', kind);
  overlay.webContents.send('data:changed', kind);
  if (kind === 'bookmarks' || kind === 'downloads' || kind === 'sec') pushState();
}
const favOf = (u) => data.favicon(u);

// ───────── 시작 ─────────
function permissionAllowed(perm) { return ['fullscreen', 'clipboard-sanitized-write', 'pointerLock', 'window-management'].includes(perm); }

function createMainWindow() {
  const b = store.get('bounds') || {};
  const c = isDark() ? THEME.dark : THEME.light;
  win = new BrowserWindow({
    width: b.width || 1280, height: b.height || 820, x: b.x, y: b.y, minWidth: 520, minHeight: 400,
    show: false, backgroundColor: c.bg, title: 'Evergreen', icon: path.join(ASSETS, 'icon.ico'),
    titleBarStyle: 'hidden', titleBarOverlay: { color: c.strip, symbolColor: c.symbol, height: STRIP_H },
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false },
  });
  Menu.setApplicationMenu(null);
  if (b.maximized) win.maximize();
  overlay = new WebContentsView({ webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false } });
  overlay.setBackgroundColor('#00000000');
  overlay.setVisible(false);
  win.contentView.addChildView(overlay);
  overlay.webContents.loadFile(path.join(SRC, 'overlay', 'overlay.html'));
  win.webContents.loadFile(path.join(SRC, 'renderer', 'index.html'));
  win.webContents.on('before-input-event', onKey);
  overlay.webContents.on('before-input-event', onKey);
  win.once('ready-to-show', () => {
    // 처음 뜰 때 0.18초 동안 서서히 나타난다(실패해도 그냥 보여 준다)
    try { win.setOpacity(0); win.show(); let o = 0; const iv = setInterval(() => { o = Math.min(1, o + 0.12); try { win.setOpacity(o); } catch (e) { o = 1; } if (o >= 1) clearInterval(iv); }, 16); } catch (e) { win.show(); }
  });
  let bt = null;
  const saveBounds = () => {
    clearTimeout(bt);
    bt = setTimeout(() => { if (win.isDestroyed()) return; const r = win.getNormalBounds(); store.set('bounds', Object.assign({}, r, { maximized: win.isMaximized() })); }, 500);
  };
  win.on('resize', () => { layout(); if (floats) floats.suggestHide(); if (popupOpen) overlay.webContents.send('overlay:close'); saveBounds(); });
  win.on('move', saveBounds);
  win.on('maximize', layout); win.on('unmaximize', layout);
  win.on('enter-full-screen', layout); win.on('leave-full-screen', layout);
  win.on('blur', () => { if (popupOpen) overlay.webContents.send('overlay:close'); });
  win.on('close', () => { saveSession(); if (sec) sec.flush(); store.flush(); if (data) data.flush(); if (ai) ai.chats.flush(); });
  win.on('closed', () => { win = null; });
}

function restore(urlArg) {
  const s = store.get('session');
  if (s && Array.isArray(s.wins) && s.wins.length) {
    s.wins.forEach((sw, wi) => {
      const w = { id: nextWin++, num: sw.num || wi + 1, name: sw.name || '창 ' + (sw.num || wi + 1), tabIds: [], active: 0 };
      wins.push(w);
      const list = sw.tabs && sw.tabs.length ? sw.tabs : [{ url: '' }];
      list.forEach((st, i) => {
        const isAct = i === (sw.active || 0);
        const t = createTab(w.id, st.url || '', { lazy: !isAct && !!st.url, title: st.title, activate: false });
        if (isAct) w.active = t.id;
      });
    });
    activeWin = (wins[s.activeWin] || wins[0]).id;
  } else {
    newWindowGroup();
  }
  if (urlArg) cmd('tab:new', { input: urlArg });
  else showActive();
}

async function fetchSuggest(q) {
  const ctl = new AbortController();
  const to = setTimeout(() => ctl.abort(), 2500);
  try {
    const r = await net.fetch('https://suggestqueries.google.com/complete/search?client=firefox&q=' + encodeURIComponent(q), { signal: ctl.signal });
    const j = await r.json();
    return Array.isArray(j[1]) ? j[1].filter((x) => typeof x === 'string').slice(0, 8) : [];
  } finally { clearTimeout(to); }
}

function boot() {
  if (!app.requestSingleInstanceLock()) { app.quit(); return; }
  app.setAppUserModelId('com.example.evergreen.win');
  const urlOf = (argv) => argv.slice(1).find((a) => /^https?:\/\//i.test(a));
  app.on('second-instance', (_e, argv) => {
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.focus();
    const u = urlOf(argv);
    if (u) cmd('tab:new', { input: u });
  });
  app.whenReady().then(() => {
    store = new Store(app.getPath('userData'), 'evergreen-prefs.json', { theme: 'system', engine: 'google', session: null, bounds: null, zoom: 100, bookmarkBar: true, extTheme: null, bmLastFolder: 0, sec: null, secstats: null, player: null, autoUpdate: true, updCheckedAt: 0, trLang: 'ko', trImages: false, autoScroll: null });
    data = new Data(app.getPath('userData'));
    downloads = new Downloads(data, { changed: () => { broadcast('downloads'); pushState(); }, toast });
    data.onChange(broadcast);
    sec = new Security({
      store, userData: app.getPath('userData'),
      tabOf: tabByWc,
      tabById: (id) => { const wc = id == null ? null : webContents.fromId(id); return wc ? tabByWc(wc) : null; },
      tabByTabId: (id) => tabs.get(id) || null,
      toast,
      hooks: {
        closeTab: (t) => { if (tabs.has(t.id)) closeTab(t.id); },
        openTab: (t, url) => createTab(t.wid, url, { afterId: t.id, incognito: t.incognito }),
        load: (t, url) => { if (tabs.has(t.id)) { load(t, url); t.url = url; pushState(); } },
        warn: (t, html, url) => { if (!tabs.has(t.id)) return; t.errUrl = url || t.url; t.title = '악성 사이트 경고'; t.view.webContents.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html)).catch(() => {}); },
        leave: (t) => { const wc = t.view.webContents; if (canBack(wc)) goBack(wc); else { load(t, U.NEWTAB); t.url = ''; pushState(); } },
        dialog: (kind, params) => openDialog(kind, params),
        goBack: (t) => { const wc = t.view.webContents; if (tabs.has(t.id) && canBack(wc)) goBack(wc); },
        reloadActive: () => { const t = activeTab(); if (t && !isInternalUrl(t.view.webContents.getURL())) t.view.webContents.reload(); },
        notify: () => broadcast('sec'),
      },
    });
    sec.start();
    for (const part of [PART_NORMAL, PART_INCOG]) {
      const ses = session.fromPartition(part);
      sec.attachSession(ses);
      downloads.attach(ses, part === PART_INCOG, (url, wc) => sec.allowDownload(wc, url));
      ses.setPermissionRequestHandler((_wc, perm, cb) => cb(permissionAllowed(perm)));
      ses.setPermissionCheckHandler((_wc, perm) => permissionAllowed(perm));
    }
    nativeTheme.on('updated', () => { applyTheme(); pushState(); });
    createMainWindow();
    floats = new Floats(win, { isDark, pick: (text) => cmd('nav:go', text), autoCmd: (act) => { if (autoScroll) autoScroll.command(act); } });
    autoScroll = new AutoScroller({ store, toast, changed: pushState,
      allowed: (t) => tabs.has(t.id) && activeTab() === t && !fsTab && !(player && player.mirrorTab()) && !win.isMinimized(),
      pill: { show: (s) => floats.pillShow(s), update: (s) => floats.pillUpdate(s), hide: () => floats.pillHide(), shown: () => floats.pillShown() } });
    ai = new AiHost({ win: () => win, store, safeStorage, userData: app.getPath('userData'), fetch: (u, o) => net.fetch(u, o), toast, relayout: layout, onChange: pushState,
      tabs: aiTabs, data, downloads, sec, ext: null, cmd, changeSetting: aiChangeSetting,
      prefs: () => Object.assign({ theme: store.get('theme'), engine: store.get('engine'), zoom: store.get('zoom'), bookmarkBar: store.get('bookmarkBar') }, sec.settings()) });
    player = new PlayerHost({ win: () => win, store, toast, raise, downloads, tabByWcId: (id) => { const wc = webContents.fromId(id); return wc ? tabByWc(wc) : null; },
      activeTab, chromeH: () => chromeH, cookiesFor, translate: (texts, lang) => ai.translateLines(texts, lang), trLang: () => store.get('trLang'), keepFullscreen: () => !!fsTab, onClosed: () => { showActive(); } });
    for (const part of [PART_NORMAL, PART_INCOG]) player.sniff(session.fromPartition(part));
    ext = new ExtManager({ userData: app.getPath('userData'), ses: () => session.fromPartition(PART_NORMAL), toast, win: () => win, store, chromeH: () => chromeH, changed: pushState, raise,
      openTab: (u) => { const w = wins.find((x) => x.id === activeWin); if (w) createTab(w.id, u, {}); } });
    ai.d.ext = ext;
    ext.init().then(pushState).catch(() => {});
    updater = new UpdateManager({ updater: loadAutoUpdater(), packaged: app.isPackaged, store, version: app.getVersion(), toast, changed: pushState });
    updater.start();
    applyTheme();
    ipcMain.on('ui:ready', (e) => { if (e.sender === win.webContents) pushState(); });
    ipcMain.on('ui:chrome-height', (e, h) => { if (e.sender === win.webContents && h > 40 && h < 400) { chromeH = Math.round(h); layout(); } });
    ipcMain.on('app:cmd', (e, m) => { if ((e.sender === win.webContents || e.sender === overlay.webContents) && m && typeof m.name === 'string') cmd(m.name, m.arg); });
    ipcMain.on('popup:open', (e, p) => {
      if (e.sender !== win.webContents || !p) return;
      openPopup(p.kind, p.anchor, !!p.left, p.data);
    });
    ipcMain.on('popup:hide', (e) => { if (e.sender === overlay.webContents) hidePopup(); });
    // 새 탭 화면의 검색창 → 그 탭 이동
    ipcMain.on('nav:go', (e, m) => {
      const t = tabByWc(e.sender);
      if (!t || t.url !== '' || !m) return;
      const u = U.resolveInput(m.input, store.get('engine'));
      load(t, u); t.url = u === U.NEWTAB ? '' : u; pushState();
    });
    // ── 화면이 데이터를 가져가는 길 (앱 화면에서만) ──
    const fromUi = (e) => e.sender === win.webContents || e.sender === overlay.webContents;
    ipcMain.handle('data:get', (e, what) => {
      if (!fromUi(e)) return null;
      switch (what) {
        case 'bookmarks': return { bookmarks: data.bookmarks().map((b) => Object.assign({}, b, { fav: favOf(b.url) })), folders: data.folders('bm') };
        case 'history': return { items: data.history().map((h) => ({ url: h.url, title: h.title, time: h.time, fav: favOf(h.url) })), now: Date.now() };
        case 'downloads': return downloads.snapshot();
        case 'shortcuts': return data.shortcuts();
        case 'adstats': return sec.adPayload(activeTab() ? activeTab().adBlocked : null);
        case 'secstats': return sec.secPayload();
        default: return null;
      }
    });
    ext.register(fromUi);
    ipcMain.handle('app:call', (e, m) => {
      if (!fromUi(e) || !m) return null;
      if (m.name === 'folder:add') { const n = String((m.arg && m.arg.name) || '').trim().slice(0, 30); return n ? data.addFolder(m.arg.kind === 'dl' ? 'dl' : 'bm', n) : null; }
      return null;
    });
    // ── 새 탭 화면(웹 화면 안)에서 오는 요청 ──
    ipcMain.handle('newtab:shortcuts', (e) => (tabByWc(e.sender) ? data.shortcuts() : []));
    ipcMain.on('newtab:menu', (e, m) => {
      const t = tabByWc(e.sender); const sc = t && m && data.shortcuts()[m.index];
      if (!sc) return;
      openPopup('scmenu', { x: m.x, y: m.y + chromeH, w: 0, h: 0 }, true, { index: m.index, name: sc.name, url: sc.url, count: data.shortcuts().length });
    });
    ipcMain.handle('newtab:cards', (e) => (tabByWc(e.sender) ? sec.homeCards() : null));
    ipcMain.on('newtab:card', (e, m) => { const t = tabByWc(e.sender); if (!t || !m) return; if (m.which === 'sec') openDialog('secstats', { stats: sec.secPayload() }); else openDialog('adstats', { stats: sec.adPayload(null) }); });
    ipcMain.on('newtab:add', (e) => { if (tabByWc(e.sender)) openDialog('shortcut', { index: null, name: '', url: '' }); });
    // ── 주소창 추천: 북마크·방문 기록을 먼저 보여 주고, 구글 추천을 뒤따라 붙인다 ──
    ipcMain.on('suggest:query', (e, m) => {
      if (e.sender !== win.webContents || !m || !m.rect) return;
      const q = String(m.q || '').trim();
      if (!q || popupOpen) { floats.suggestHide(); return; }
      const local = L.suggestLocal(q, data.history(), data.bookmarks());
      const my = ++suggestSeq;
      floats.suggestShow(local, m.rect, String(m.q));
      const t = activeTab();
      if (t && t.incognito) return; // 시크릿 탭은 입력한 글자를 밖으로 보내지 않는다
      fetchSuggest(q).then((remote) => {
        if (my !== suggestSeq || !remote.length) return;
        floats.suggestShow(local.concat(remote.filter((x) => !local.includes(x))).slice(0, 8), m.rect, String(m.q));
      }).catch(() => { /* 추천 실패는 무시 */ });
    });
    ipcMain.on('suggest:move', (e, dir) => {
      if (e.sender !== win.webContents) return;
      const text = floats.suggestMove(dir < 0 ? -1 : 1);
      if (text != null) win.webContents.send('suggest:fill', text);
    });
    ipcMain.on('suggest:hide', (e) => { if (e.sender === win.webContents) { suggestSeq++; floats.suggestHide(); } });
    ipcMain.on('suggest:blur', (e) => { if (e.sender === win.webContents) setTimeout(() => { suggestSeq++; floats.suggestHide(); }, 180); });
    restore(urlOf(process.argv));
  });
  app.on('before-quit', () => { if (updater) updater.dispose(); });
  app.on('window-all-closed', () => app.quit());
}
boot();
