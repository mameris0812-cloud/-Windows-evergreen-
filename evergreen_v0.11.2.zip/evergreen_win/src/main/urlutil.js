'use strict';
// 주소창 입력 → 이동할 주소. (Prefs.kt 의 SearchEngine / shortcuts 와 같은 규칙)
const ENGINES = {
  google: { name: 'Google', search: 'https://www.google.com/search?q=', home: 'https://www.google.com' },
  naver: { name: '네이버', search: 'https://search.naver.com/search.naver?query=', home: 'https://www.naver.com' },
  ddg: { name: 'DuckDuckGo', search: 'https://duckduckgo.com/?q=', home: 'https://duckduckgo.com' },
  bing: { name: 'Bing', search: 'https://www.bing.com/search?q=', home: 'https://www.bing.com' },
};
const SHORTCUTS = {
  g: 'https://www.google.com/search?q=',
  n: 'https://search.naver.com/search.naver?query=',
  d: 'https://duckduckgo.com/?q=',
  b: 'https://www.bing.com/search?q=',
  yt: 'https://www.youtube.com/results?search_query=',
  w: 'https://ko.wikipedia.org/w/index.php?search=',
  map: 'https://www.google.com/maps/search/',
};
const NEWTAB = 'evergreen://newtab';

function engine(key) { return ENGINES[key] || ENGINES.google; }

function resolveInput(raw, engineKey) {
  const text = String(raw == null ? '' : raw).trim();
  if (!text) return NEWTAB;
  const sp = text.indexOf(' ');
  if (sp > 0) {
    const pre = text.slice(0, sp).toLowerCase();
    const rest = text.slice(sp + 1).trim();
    if (rest && SHORTCUTS[pre]) return SHORTCUTS[pre] + encodeURIComponent(rest);
  }
  if (text === 'evergreen://newtab' || text === 'about:blank') return text;
  if (/^(https?|file|ftp|view-source|chrome|devtools):/i.test(text)) return text;
  if (!/\s/.test(text)) {
    if (/^localhost(:\d+)?([/?#].*)?$/i.test(text) || /^\d{1,3}(\.\d{1,3}){3}(:\d+)?([/?#].*)?$/.test(text)) return 'http://' + text;
    if (/^([a-z0-9-]+\.)+[a-z]{2,}(:\d+)?([/?#].*)?$/i.test(text)) return 'https://' + text;
  }
  return engine(engineKey).search + encodeURIComponent(text);
}

// 주소창에 보여 줄 짧은 주소 (포커스 없을 때)
function displayUrl(url) {
  if (!url || url === NEWTAB) return '';
  return String(url).replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/$/, '');
}

function isSecure(url) { return /^https:/i.test(url || ''); }

// 크롬 net 오류 번호 → 사용자에게 보일 안내
function describeError(code, offline) {
  if (offline || code === -106) return { title: '인터넷에 연결되어 있지 않아요', msg: '네트워크 연결을 확인한 뒤 다시 시도해 주세요.' };
  if (code === -105 || code === -137) return { title: '웹사이트를 찾을 수 없어요', msg: '주소가 맞는지 확인해 주세요.' };
  if (code === -7 || code === -118) return { title: '응답이 너무 늦어요', msg: '잠시 후 다시 시도해 주세요.' };
  if (code <= -200 && code > -300) return { title: '연결이 안전하지 않아요', msg: '이 사이트의 보안 인증서에 문제가 있어요.' };
  return { title: '웹사이트에 연결할 수 없어요', msg: '잠시 후 다시 시도해 주세요.' };
}

// 주소 끝의 숫자를 1 올린 주소 (error.html '다음' 버튼, 번호가 없으면 null)
function nextNumbered(url) {
  const m = /^(.*?)(\d+)([^\d]*)$/.exec(url || '');
  if (!m) return null;
  const n = String(Number(m[2]) + 1).padStart(m[2].length, '0');
  return { url: m[1] + n + m[3], label: '다음 (' + n + ')' };
}

module.exports = { ENGINES, SHORTCUTS, NEWTAB, engine, resolveInput, displayUrl, isSecure, describeError, nextNumbered };
