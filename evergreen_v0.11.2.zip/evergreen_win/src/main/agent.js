'use strict';
// AI 에이전트: 모델이 도구를 부르면 앱이 실행하고 결과를 돌려주는 대화를 이어 간다 (안드로이드 Agent.kt · AgentAppTools · AgentPageTools).
//  - 도구는 host(앱 쪽 구현)만 건드린다 → 가짜 host 로 시험할 수 있다
//  - 쓰기 도구 중 위험한 것(삭제 · 보안 끄기 · 결제/제출 같은 버튼)은 실행 전에 사용자 확인 카드를 거친다
//  - 도구 선언은 매번 실려 가서 큰 몫이라, 질문과 관련 있는 묶음만 싣는다(AgentToolPicker). 안 실은 도구를 모델이 불러도 그 자리에서 실행한다
const Prompt = require('../shared/aiprompt');
const G = require('../shared/gemini');
const { content } = require('./gemini-client');

const MAX_STEPS = 16, MAX_STEPS_AUTO = 30, MAX_RESULT = 14000;

// ───────── 스키마 도우미 ─────────
const S = {
  str: (d) => ({ type: 'string', description: d }),
  int: (d) => ({ type: 'integer', description: d }),
  num: (d) => ({ type: 'number', description: d }),
  bool: (d) => ({ type: 'boolean', description: d }),
  oneOf: (d, ...vals) => ({ type: 'string', description: d, enum: vals }),
  obj: (props, req) => ({ type: 'object', properties: props, required: req || [] }),
};
const DANGER_LABEL = /결제|구매|주문|삭제|탈퇴|전송|제출|동의|송금|이체|가입|신청|예약|확정|pay|buy|purchase|order|delete|remove|submit|send|confirm|agree|transfer|checkout/i;
const SECURITY_OFF = new Set(['adBlock', 'ytAdBlock', 'strictTrackers', 'malwareWarning', 'httpsFirst', 'blockAutoDownload', 'blockHijackNav', 'blockBackRedirect']);
const trunc = (s, n) => { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n) + '…' : s; };

// group: always | bookmarks | history | downloads | settings | extensions | windows | media
// run(args, host) → 결과 객체(모델에게 JSON 으로 간다). write 가 true 면 확인 카드 대상이 될 수 있다. confirm(args, host) → 확인 문구 또는 null
function buildTools() {
  const T = [];
  const add = (t) => T.push(Object.assign({ group: 'always', write: false }, t));
  // ── 읽기 ──
  add({ name: 'list_tabs', description: '열려 있는 탭 목록 (number · 제목 · 주소 · 지금 보는 탭 여부 · 창). 탭 번호는 다른 도구가 쓴다', parameters: S.obj({}),
    run: async (_a, h) => ({ tabs: h.listTabs() }) });
  add({ name: 'read_page', description: '지금 보는 탭(또는 tab 번호)의 글과 누를 수 있는 요소 목록(element 번호)을 읽는다. click_element · fill_field 전에 꼭 부른다', parameters: S.obj({ tab: S.int('읽을 탭 번호 (비우면 지금 보는 탭)'), scope: S.oneOf('visible=화면에 보이는 것만(기본), all=페이지 전체', 'visible', 'all') }),
    run: async (a, h) => h.readPage(a.tab, a.scope === 'all') });
  add({ name: 'read_tabs', description: '여러 탭의 글을 한꺼번에 읽는다(탭을 옮기지 않는다). 비교 · 요약용. 번호를 안 주면 앞에서부터 최대 8개', parameters: S.obj({ tabs: { type: 'array', items: { type: 'integer' }, description: '읽을 탭 번호들 (최대 8개)' } }),
    run: async (a, h) => ({ pages: await h.readTabs(Array.isArray(a.tabs) ? a.tabs.slice(0, 8) : null) }) });
  add({ name: 'web_search', description: '구글 검색으로 최신 정보를 찾아 한국어로 정리한다', parameters: S.obj({ query: S.str('검색할 내용') }, ['query']),
    run: async (a, h) => h.webSearch(String(a.query || '')) });
  add({ name: 'get_settings', description: '지금 앱 설정값 (테마 · 검색 엔진 · 확대 · 북마크 막대 · 광고/보안 항목)', parameters: S.obj({}), group: 'settings', run: async (_a, h) => h.getSettings() });
  add({ name: 'search_history', description: '방문 기록에서 제목·주소로 찾는다 (query 를 비우면 최근 것)', parameters: S.obj({ query: S.str('찾을 말'), limit: S.int('최대 개수 (기본 20)') }), group: 'history', run: async (a, h) => ({ items: h.searchHistory(a.query || '', a.limit || 20) }) });
  add({ name: 'search_bookmarks', description: '북마크에서 제목·주소·폴더로 찾는다 (query 를 비우면 전부)', parameters: S.obj({ query: S.str('찾을 말'), limit: S.int('최대 개수 (기본 30)') }), group: 'bookmarks', run: async (a, h) => ({ items: h.searchBookmarks(a.query || '', a.limit || 30), folders: h.bookmarkFolders() }) });
  add({ name: 'list_downloads', description: '받은 파일 · 받는 중인 파일 목록', parameters: S.obj({}), group: 'downloads', run: async (_a, h) => h.listDownloads() });
  add({ name: 'list_extensions', description: '설치한 확장 프로그램 (id · 이름 · 켜짐 여부)', parameters: S.obj({}), group: 'extensions', run: async (_a, h) => ({ extensions: h.listExtensions() }) });
  add({ name: 'list_windows', description: '「창」(탭 묶음) 목록 (번호 · 이름 · 탭 수 · 지금 보는 창)', parameters: S.obj({}), group: 'windows', run: async (_a, h) => ({ windows: h.listWindows() }) });
  // ── 탭 · 이동 ──
  add({ name: 'open_tab', description: '새 탭을 연다. 주소 · 검색어 · 빠른 검색 단축어(g/n/d/b/yt/w/map)를 그대로 줄 수 있다', write: true, parameters: S.obj({ target: S.str('열 주소 또는 검색어 (비우면 새 탭 화면)'), incognito: S.bool('시크릿 탭으로'), background: S.bool('지금 탭을 바꾸지 않고 뒤에서 열기') }),
    run: async (a, h) => h.openTab(a.target || '', { incognito: !!a.incognito, background: !!a.background }) });
  add({ name: 'close_tab', description: '탭을 닫는다 (number 번 탭, 비우면 지금 탭). 닫은 탭은 reopen_closed_tab 으로 되살릴 수 있다', write: true, parameters: S.obj({ number: S.int('닫을 탭 번호') }), run: async (a, h) => h.closeTab(a.number) });
  add({ name: 'switch_tab', description: 'number 번 탭으로 옮겨 간다', write: true, parameters: S.obj({ number: S.int('탭 번호') }, ['number']), run: async (a, h) => h.switchTab(a.number) });
  add({ name: 'move_tab', description: 'number 번 탭을 to 번 자리로 옮긴다', write: true, parameters: S.obj({ number: S.int('옮길 탭 번호'), to: S.int('도착 자리(번호)') }, ['number', 'to']), run: async (a, h) => h.moveTab(a.number, a.to) });
  add({ name: 'duplicate_tab', description: '탭을 복제한다', write: true, parameters: S.obj({ number: S.int('탭 번호 (비우면 지금 탭)') }), run: async (a, h) => h.duplicateTab(a.number) });
  add({ name: 'reopen_closed_tab', description: '방금 닫은 탭을 다시 연다', write: true, parameters: S.obj({}), run: async (_a, h) => h.reopenClosed() });
  add({ name: 'go_to', description: '지금 탭을 주소 · 검색어로 이동한다', write: true, parameters: S.obj({ target: S.str('주소 또는 검색어') }, ['target']), run: async (a, h) => h.goTo(String(a.target || '')) });
  add({ name: 'page_nav', description: '지금 탭에서 뒤로 · 앞으로 · 새로고침 · 중지 · 홈', write: true, parameters: S.obj({ action: S.oneOf('동작', 'back', 'forward', 'reload', 'stop', 'home') }, ['action']), run: async (a, h) => h.pageNav(a.action) });
  add({ name: 'open_screen', description: '방문 기록 · 북마크 · 다운로드 · 광고 차단 현황 · 보안 현황 · 확장 프로그램 화면을 연다', write: true, parameters: S.obj({ screen: S.oneOf('열 화면', 'history', 'bookmarks', 'downloads', 'adstats', 'secstats', 'extensions') }, ['screen']), run: async (a, h) => h.openScreen(a.screen) });
  // ── 북마크 · 기록 ──
  add({ name: 'add_bookmark', description: '북마크에 추가한다 (url 을 비우면 지금 페이지)', write: true, group: 'bookmarks', parameters: S.obj({ url: S.str('주소'), title: S.str('제목'), folder: S.str('폴더 이름 (없는 이름이면 새로 만든다)') }), run: async (a, h) => h.addBookmark(a.url, a.title, a.folder) });
  add({ name: 'delete_bookmarks', description: '북마크를 주소로 지운다 (search_bookmarks 로 확인한 주소를 그대로)', write: true, group: 'bookmarks', parameters: S.obj({ urls: { type: 'array', items: { type: 'string' }, description: '지울 북마크 주소들' } }, ['urls']),
    confirm: (a) => '북마크 ' + (a.urls || []).length + '개를 지울까요?\n' + (a.urls || []).slice(0, 5).map((u) => '· ' + trunc(u, 70)).join('\n'), run: async (a, h) => h.deleteBookmarks(a.urls || []) });
  add({ name: 'delete_history', description: '방문 기록을 주소로 지운다 (search_history 로 확인한 주소를 그대로)', write: true, group: 'history', parameters: S.obj({ urls: { type: 'array', items: { type: 'string' }, description: '지울 기록 주소들' } }, ['urls']),
    confirm: (a) => '방문 기록 ' + (a.urls || []).length + '개를 지울까요?\n' + (a.urls || []).slice(0, 5).map((u) => '· ' + trunc(u, 70)).join('\n'), run: async (a, h) => h.deleteHistory(a.urls || []) });
  // ── 설정 · 확장 ──
  add({ name: 'change_setting', description: '앱 설정을 바꾼다. name: ' + 'theme(system/light/dark) · engine(google/naver/ddg/bing) · zoom(50~500) · bookmarkBar · adBlock · ytAdBlock · ytAdPrune · strictTrackers · skipCaptcha · malwareWarning · blockAutoDownload · blockBackRedirect · httpsFirst · blockHijackNav', write: true, group: 'settings',
    parameters: S.obj({ name: S.str('바꿀 설정 이름'), value: S.str('새 값 (켜기/끄기는 true / false)') }, ['name', 'value']),
    confirm: (a) => (SECURITY_OFF.has(a.name) && /^(false|off|끄|꺼|0)$/i.test(String(a.value)) ? '보안·광고 설정 「' + a.name + '」 을(를) 끌까요?' : null),
    run: async (a, h) => h.changeSetting(String(a.name), String(a.value)) });
  add({ name: 'set_extension', description: '확장 프로그램을 켜거나 끈다', write: true, group: 'extensions', parameters: S.obj({ id: S.str('list_extensions 의 id'), enabled: S.bool('켤지') }, ['id', 'enabled']), run: async (a, h) => h.setExtension(a.id, !!a.enabled) });
  add({ name: 'install_extension', description: '크롬 웹스토어 주소 또는 확장 ID 로 확장 프로그램을 설치한다', write: true, group: 'extensions', parameters: S.obj({ source: S.str('웹스토어 주소 또는 확장 ID'), name: S.str('확인 카드에 보여 줄 이름') }, ['source']),
    confirm: (a) => '확장 프로그램 「' + (a.name || a.source) + '」 을(를) 설치할까요?', run: async (a, h) => h.installExtension(String(a.source)) });
  // ── 웹 페이지 안 조작 (지금 보는 탭만) ──
  add({ name: 'scroll_page', description: '지금 탭을 스크롤한다', write: true, parameters: S.obj({ direction: S.oneOf('방향', 'down', 'up', 'top', 'bottom'), amount: S.num('화면 높이의 몇 배 (기본 0.8)') }, ['direction']), run: async (a, h) => h.scrollPage(a.direction, a.amount) });
  add({ name: 'click_element', description: 'read_page 로 읽은 요소 번호(element)를 누른다', write: true, parameters: S.obj({ element: S.int('요소 번호') }, ['element']),
    confirm: (a, h) => { const el = h.elementInfo(a.element); return el && DANGER_LABEL.test(el.label || '') ? '이 페이지에서 「' + trunc(el.label, 40) + '」 을(를) 누를까요?' : null; }, run: async (a, h) => h.clickElement(a.element) });
  add({ name: 'fill_field', description: 'read_page 로 읽은 입력칸(element)에 글을 넣는다. submit 이 true 면 엔터까지 누른다', write: true, parameters: S.obj({ element: S.int('요소 번호'), text: S.str('넣을 글'), submit: S.bool('입력 뒤 엔터(제출)') }, ['element', 'text']),
    confirm: (a, h) => { if (a.submit) { const el = h.elementInfo(a.element); return '입력칸 「' + trunc((el && el.label) || '입력칸', 30) + '」 에 글을 넣고 제출할까요?'; } const el2 = h.elementInfo(a.element); return el2 && el2.type === 'password' ? '비밀번호 칸에 글을 넣을까요?' : null; }, run: async (a, h) => h.fillField(a.element, String(a.text || ''), !!a.submit) });
  return T;
}

// 질문과 상관없는 묶음은 말에 관련 낱말이 있을 때만 싣는다
const GROUP_WORDS = {
  bookmarks: ['북마크', '즐겨찾기', '책갈피', '폴더'], history: ['기록', '히스토리', '방문', '지워', '삭제'], downloads: ['다운로드', '내려받', '받은', '받아'],
  settings: ['설정', '다크', '라이트', '테마', '확대', '축소', '줌', '검색엔진', '검색 엔진', '광고', '보안', '켜', '꺼', '끄', '해제', '북마크바', '북마크 막대', '자동', 'https'],
  extensions: ['확장', '애드온', '플러그인', '웹스토어', '설치', '제거'], windows: ['창', '묶음'],
};
function pickTools(all, question) {
  const q = String(question || '').toLowerCase();
  return all.filter((t) => t.group === 'always' || (GROUP_WORDS[t.group] || []).some((w) => q.indexOf(w) >= 0));
}
const declOf = (t) => ({ name: t.name, description: t.description, parameters: t.parameters });

// ───────── 실행기 ─────────
class AgentRunner {
  // o: { client, g, host, emit(ev), confirm(card) → Promise<boolean>, tools? }
  constructor(o) {
    this.client = o.client; this.g = o.g; this.host = o.host; this.emit = o.emit || (() => {}); this.confirm = o.confirm || (async () => true);
    this.all = o.tools || buildTools(); this.cancelled = false;
  }
  cancel() { this.cancelled = true; this.client.cancel(); }
  // opts: { key, model, history:[{role,text,images}], question, auto, pageSystem } → { ok, error, text, model, key }
  async run(opts) {
    const g = this.g, auto = !!opts.auto, max = auto ? MAX_STEPS_AUTO : MAX_STEPS;
    const picked = pickTools(this.all, opts.question), byName = new Map(this.all.map((t) => [t.name, t]));
    const decls = picked.map(declOf);
    const system = (opts.system || '') + Prompt.agentGuide(picked.map((t) => t.name), auto, max);
    const contents = opts.history.map(content);
    let key = opts.key, model = opts.model, canSwitch = true, text = '', lastError = null;
    for (let step = 0; step < max + 1 && !this.cancelled; step++) {
      const last = step === max; // 단계를 다 썼으면 도구 없이 마무리만
      this.emit({ type: 'step', n: step + 1 });
      const r = await this.client.step({ key, model, system, contents, decls, thoughts: !!opts.thoughts, allowCalls: !last, canSwitchModel: canSwitch,
        cb: { text: (t) => { text += t; this.emit({ type: 'text', delta: t }); }, thought: (t) => this.emit({ type: 'thought', delta: t }) } });
      key = r.key; if (r.model !== model) { model = r.model; this.emit({ type: 'model', model }); }
      if (this.cancelled) break;
      if (r.error) { lastError = r.error; break; }
      if (!r.calls.length) {
        if (!text.trim() && !r.parts.some((p) => p.text)) { lastError = G.emptyMessage(r); }
        break;
      }
      canSwitch = false; // 도구 대화를 이어 가는 중에는 모델을 바꾸지 않는다(생각 서명이 모델에 묶여 있다)
      contents.push({ role: 'model', parts: r.parts });
      const responses = [];
      for (const call of r.calls) {
        if (this.cancelled) break;
        responses.push({ functionResponse: Object.assign({ name: call.name, response: await this._exec(byName.get(call.name), call) }, call.id ? { id: call.id } : {}) });
      }
      if (this.cancelled) break;
      contents.push({ role: 'user', parts: responses });
      if (last) break;
    }
    if (this.cancelled) return { ok: true, cancelled: true, text, model, key };
    return lastError ? { ok: false, error: lastError, text, model, key } : { ok: true, text, model, key };
  }
  async _exec(tool, call) {
    const label = (tool && tool.name) || call.name;
    if (!tool) { this.emit({ type: 'tool', name: label, status: 'fail', note: '없는 도구' }); return { error: '없는 도구예요: ' + call.name }; }
    const args = call.args || {};
    this.emit({ type: 'tool', name: tool.name, args, status: 'run' });
    try {
      if (tool.confirm) {
        const ask = await tool.confirm(args, this.host);
        if (ask) {
          const ok = await this.confirm({ tool: tool.name, text: ask });
          if (!ok) { this.emit({ type: 'tool', name: tool.name, args, status: 'denied' }); return { error: '사용자가 거절했어요. 같은 일을 다시 시도하지 마세요.' }; }
        }
      }
      let res = await tool.run(args, this.host);
      if (res == null) res = { ok: true };
      if (typeof res !== 'object') res = { result: res };
      let s = JSON.stringify(res);
      if (s.length > MAX_RESULT) { res = { truncated: true, partial: s.slice(0, MAX_RESULT) }; }
      this.emit({ type: 'tool', name: tool.name, args, status: res && res.error ? 'fail' : 'ok', note: res && res.error ? String(res.error) : '' });
      return res;
    } catch (e) {
      this.emit({ type: 'tool', name: tool.name, args, status: 'fail', note: String(e && e.message || e) });
      return { error: String(e && e.message || e) };
    }
  }
}

// 도구 이름 → 사람이 읽는 한 줄 (진행 카드에 보인다)
const TOOL_LABEL = {
  list_tabs: '열린 탭 확인', read_page: '페이지 읽기', read_tabs: '여러 탭 읽기', web_search: '웹 검색', get_settings: '설정 확인', search_history: '방문 기록 찾기', search_bookmarks: '북마크 찾기',
  list_downloads: '다운로드 확인', list_extensions: '확장 프로그램 확인', list_windows: '창 목록 확인', open_tab: '새 탭 열기', close_tab: '탭 닫기', switch_tab: '탭 이동', move_tab: '탭 순서 바꾸기',
  duplicate_tab: '탭 복제', reopen_closed_tab: '닫은 탭 열기', go_to: '주소 이동', page_nav: '뒤로/앞으로/새로고침', open_screen: '화면 열기', add_bookmark: '북마크 추가', delete_bookmarks: '북마크 삭제',
  delete_history: '방문 기록 삭제', change_setting: '설정 바꾸기', set_extension: '확장 켜기/끄기', install_extension: '확장 설치', scroll_page: '스크롤', click_element: '버튼 누르기', fill_field: '입력칸 채우기',
};
module.exports = { AgentRunner, buildTools, pickTools, declOf, S, TOOL_LABEL, MAX_STEPS, MAX_STEPS_AUTO, DANGER_LABEL };
