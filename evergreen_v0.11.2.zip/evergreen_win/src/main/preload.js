'use strict';
// 앱 화면(주소창 · 팝업 · 토스트 · 추천)에만 붙는 다리. 웹페이지에는 붙지 않는다.
const { contextBridge, ipcRenderer } = require('electron');
const SEND = new Set(['app:cmd', 'ui:chrome-height', 'ui:ready', 'popup:open', 'popup:hide',
  'suggest:query', 'suggest:move', 'suggest:blur', 'suggest:hide', 'suggest:size', 'suggest:pick', 'toast:size', 'toast:action', 'as:cmd', 'as:size',
  'ai:stop', 'ai:confirm', 'ai:resize', 'ai:open-url', 'ai:external', 'ai:close', 'ai:page-ask']);
const RECV = new Set(['state', 'focus-url', 'overlay:show', 'overlay:close', 'overlay:dialog', 'data:changed',
  'suggest:show', 'suggest:hl', 'suggest:fill', 'toast:show', 'as:state', 'ai:event']);
const INVOKE = new Set(['data:get', 'app:call', 'ext:list', 'ext:store', 'ext:file', 'ext:toggle', 'ext:remove', 'ext:popup', 'ext:options', 'ext:theme',
  'ai:info', 'ai:send', 'ai:new', 'ai:load', 'ai:delete', 'ai:rename', 'ai:clear-chats', 'ai:key-add', 'ai:key-remove', 'ai:key-test', 'ai:setting', 'ai:clear-usage', 'ai:page-title']);
contextBridge.exposeInMainWorld('evergreen', {
  send: (ch, payload) => { if (SEND.has(ch)) ipcRenderer.send(ch, payload); },
  on: (ch, cb) => { if (RECV.has(ch)) ipcRenderer.on(ch, (_e, p) => cb(p)); },
  invoke: (ch, payload) => (INVOKE.has(ch) ? ipcRenderer.invoke(ch, payload) : Promise.reject(new Error('blocked'))),
});
