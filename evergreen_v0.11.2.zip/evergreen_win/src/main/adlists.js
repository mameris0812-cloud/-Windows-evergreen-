'use strict';
// 차단 목록 내려받기·저장·읽기 (안드로이드 AdBlocker.update()/load()).
// 도메인 목록, 화면 광고 숨김 규칙, 주소 규칙(EasyList 문법), 악성 사이트 목록을 userData/adlists/ 에 둔다.
// 큰 목록(수십만 줄)을 처리할 때 메인 스레드가 멈추지 않도록 중간중간 쉰다.
const fs = require('fs');
const path = require('path');
const { net } = require('electron');
const D = require('../shared/addata');
const { parse: parseNet } = require('../shared/netfilter');
const A = require('../shared/adengine');

/** 악성·피싱 사이트 목록 (안드로이드는 구글 세이프 브라우징을 쓰지만 일렉트론에는 없어서 공개 목록으로 대신한다) */
const MALWARE_SOURCES = [
  'https://urlhaus.abuse.ch/downloads/hostfile/',
  'https://phishing.army/download/phishing_army_blocklist.txt',
];
const tick = () => new Promise((res) => setImmediate(res));

async function eachLines(text, fn) {
  let start = 0; let n = 0;
  const len = text.length;
  while (start < len) {
    let end = text.indexOf('\n', start);
    if (end < 0) end = len;
    fn(text.substring(start, end).replace(/\r$/, ''));
    start = end + 1;
    if (++n % 30000 === 0) await tick();
  }
}

async function fetchText(url, ms) {
  const ctl = new AbortController();
  const to = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await net.fetch(url, { signal: ctl.signal, headers: { 'User-Agent': 'evergreen-win/1.1' } });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.text();
  } finally { clearTimeout(to); }
}

class AdLists {
  /** @param engine AdEngine  @param hooks { malware(Set) } */
  constructor(dir, engine, hooks) {
    this.dir = path.join(dir, 'adlists');
    this.engine = engine;
    this.hooks = hooks || {};
    this.updating = false;
    this.meta = { updated: 0, malware: 0 };
    try { this.meta = Object.assign(this.meta, JSON.parse(fs.readFileSync(path.join(this.dir, 'meta.json'), 'utf8'))); } catch (e) { /* 처음 실행 */ }
  }
  get lastUpdated() { return this.meta.updated || 0; }
  get malwareCount() { return this.meta.malware || 0; }
  _f(n) { return path.join(this.dir, n); }
  _read(n) { try { return fs.readFileSync(this._f(n), 'utf8'); } catch (e) { return null; } }
  _write(n, text) {
    fs.mkdirSync(this.dir, { recursive: true });
    fs.writeFileSync(this._f(n) + '.tmp', text);
    fs.renameSync(this._f(n) + '.tmp', this._f(n));
  }

  /** 저장해 둔 목록을 엔진에 올린다 (없으면 내장 목록만 쓴다) */
  async load() {
    try {
      const hosts = this._read('hosts.txt');
      if (hosts) { const set = new Set(); await eachLines(hosts, (l) => { if (l) set.add(l); }); this.engine.setHosts(set); }
      const css = this._read('css.txt');
      if (css) { const sels = []; await eachLines(css, (l) => { if (l.trim()) sels.push(l); }); this.engine.setGenericCss(sels); }
      const site = this._read('site.txt');
      if (site) { const lines = []; await eachLines(site, (l) => { if (l) lines.push(l); }); this.engine.setSiteLines(lines); }
      const rules = this._read('rules.txt');
      if (rules) { const lines = []; await eachLines(rules, (l) => { if (l) lines.push(l); }); await this.engine.setNetLinesAsync(lines); }
      const mal = this._read('malware.txt');
      if (mal && this.hooks.malware) { const set = new Set(); await eachLines(mal, (l) => { if (l) set.add(l); }); this.hooks.malware(set); }
    } catch (e) { /* 내장 목록만 사용 */ }
  }

  /** 네트워크 작업. 적용된 도메인 수를 돌려준다. 일부만 실패해도 받은 것은 적용하고, 도메인 목록을 전부 못 받으면 예외. */
  async update() {
    if (this.updating) throw new Error('이미 업데이트 중이에요');
    this.updating = true;
    try {
      const urls = [...new Set([...D.HOST_SOURCES, ...D.COSMETIC_SOURCES, ...D.NET_SOURCES, ...MALWARE_SOURCES])];
      const texts = new Map();
      let lastError = null;
      let next = 0;
      const worker = async () => {
        while (next < urls.length) {
          const u = urls[next++];
          try { texts.set(u, await fetchText(u, 40000)); } catch (e) { lastError = e; }
        }
      };
      await Promise.all(Array.from({ length: 4 }, worker));

      // 도메인 목록
      const merged = new Set();
      let ok = 0;
      for (const src of D.HOST_SOURCES) {
        const t = texts.get(src); if (t == null) continue;
        let n = 0;
        await eachLines(t, (raw) => { if (n >= 250000) return; const h = A.parseHostLine(raw); if (h) { merged.add(h); n++; } });
        ok++;
      }
      // EasyList 류의 "||도메인^" 규칙도 도메인 목록에 합친다
      for (const src of D.NET_SOURCES) {
        if (D.HOST_SOURCES.includes(src)) continue;
        const t = texts.get(src); if (t == null) continue;
        await eachLines(t, (raw) => { const r = parseNet(raw); if (r && !r.exception && r.isPureHost && A.HOST_REGEX.test(r.host)) merged.add(r.host); });
      }
      if (ok === 0 || merged.size === 0) throw lastError || new Error('빈 목록');
      this._write('hosts.txt', [...merged].join('\n'));
      this.engine.setHosts(merged);

      // 광고 영역 숨김 규칙
      const generic = new Set(); const site = new Set(); let cosmeticOk = 0;
      for (const src of D.COSMETIC_SOURCES) {
        const t = texts.get(src); if (t == null) continue;
        await eachLines(t, (raw) => {
          const r = A.parseCosmetic(raw); if (!r) return;
          if (r.doms === null) { if (generic.size < 8000) generic.add(r.sel); } else if (site.size < 80000) site.add(r.doms.join(',') + '\t' + r.sel);
        });
        cosmeticOk++;
      }
      if (generic.size) { this._write('css.txt', [...generic].join('\n')); this.engine.setGenericCss([...generic]); }
      if (cosmeticOk > 0 || !fs.existsSync(this._f('site.txt'))) { this._write('site.txt', [...site].join('\n')); this.engine.setSiteLines([...site]); }

      // 주소 규칙: 도메인만 막는 단순 규칙은 위의 도메인 목록이 빠르게 처리한다 (예외 규칙은 엔진에 둔다)
      const rules = new Set(); let netOk = 0;
      for (const src of D.NET_SOURCES) {
        const t = texts.get(src); if (t == null) continue;
        await eachLines(t, (raw) => {
          if (rules.size >= A.MAX_NET_RULES) return;
          const r = parseNet(raw); if (!r) return;
          if (!r.exception && r.isPureHost) return;
          rules.add(raw.trim());
        });
        netOk++;
      }
      if (netOk > 0 || !fs.existsSync(this._f('rules.txt'))) { this._write('rules.txt', [...rules].join('\n')); await this.engine.setNetLinesAsync([...rules]); }

      // 악성 사이트: URLhaus · Phishing Army 와 uBlock 의 badware 목록(도메인만 막는 규칙)
      const mal = new Set();
      for (const src of MALWARE_SOURCES) {
        const t = texts.get(src); if (t == null) continue;
        await eachLines(t, (raw) => { const h = A.parseHostLine(raw); if (h) mal.add(h); });
      }
      for (const src of D.NET_SOURCES) {
        if (!/badware/.test(src)) continue;
        const t = texts.get(src); if (t == null) continue;
        await eachLines(t, (raw) => { const r = parseNet(raw); if (r && !r.exception && r.isPureHost && A.HOST_REGEX.test(r.host)) mal.add(r.host); });
      }
      // 구글·깃허브처럼 사이트가 동작하는 데 꼭 필요한 곳은 악성 목록에서 뺀다 (잘못 막는 사고 방지)
      for (const h of [...mal]) if (A.matchesSet(h, A.ALLOW)) mal.delete(h);
      if (mal.size) { this._write('malware.txt', [...mal].join('\n')); if (this.hooks.malware) this.hooks.malware(mal); this.meta.malware = mal.size; }

      this.meta.updated = Date.now();
      this._write('meta.json', JSON.stringify(this.meta));
      return this.engine.hostRuleCount;
    } finally { this.updating = false; }
  }
}
module.exports = { AdLists, MALWARE_SOURCES };
