'use strict';
// Gemini API(generativelanguage.googleapis.com) 스트리밍 호출. 안드로이드 GeminiClient · GeminiAgentClient 의 흐름을 그대로 옮겼다.
//  - stream(): 글 채팅. 답이 토큰 한도로 잘리거나 연결이 끊기면 받은 부분을 붙여 "이어서 써 줘" 로 자동 재요청
//  - step():   도구 호출(function calling) 한 단계. 모델이 보낸 parts(생각 서명 포함)를 그대로 돌려받아 다음 요청에 되돌려 보낸다
//  - 공통: 한도(429)가 찬 키는 다른 키로, 모델 문제(없음·한도·서버)는 다른 모델로, 붐비면 잠깐 뒤 같은 모델로 다시 보낸다
const G = require('../shared/gemini');

const BASE = 'https://generativelanguage.googleapis.com/v1beta';
const MAX_OUTPUT_TOKENS = 65536;
const AGENT_MAX_OUTPUT_TOKENS = 16384;
const MAX_CONTINUE = 4;
const SEARCH_REST_MS = 5 * 60 * 1000;
const CONNECT_MS = 20000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 첨부 한 개 → 요청 조각. 사진·PDF 는 inlineData, 글 파일은 이름을 붙인 text (Gemini 에는 파일째가 아니라 글로 풀어서 보낸다)
function attachPart(a) {
  if (a.mime && a.mime.indexOf('text/') === 0) {
    let body = '';
    try { body = Buffer.from(a.base64, 'base64').toString('utf8'); } catch (e) { /* 깨진 첨부 */ }
    return { text: '[첨부 파일: ' + (a.name || '파일') + ']\n' + body + '\n[파일 끝]' };
  }
  return { inlineData: { mimeType: a.mime, data: a.base64 } };
}
// 글(과 사진) 한 줄 → 대화 JSON. 사진은 글보다 앞에 둔다 (Gemini 권장 순서)
function content(m) {
  const parts = (m.images || []).map(attachPart);
  parts.push({ text: m.text });
  return { role: m.role, parts };
}

class GeminiClient {
  // g: shared/gemini create() 결과, usage: { record }, modelSync: { refreshIfStale, refreshNow }, fetch / base: 시험에서 바꿔 끼운다
  constructor(o) {
    this.g = o.g; this.usage = o.usage || { record() {} }; this.modelSync = o.modelSync || { refreshIfStale() {}, refreshNow() { return Promise.resolve(false); } };
    this.fetch = o.fetch || ((...a) => globalThis.fetch(...a)); this.base = o.base || BASE;
    this.sleep = o.sleep || sleep;
    this.ctl = null; this.cancelled = false;
  }
  cancel() { this.cancelled = true; try { if (this.ctl) this.ctl.abort(); } catch (e) { /* 이미 끝난 연결 */ } }

  // 요청 한 번. 받은 글은 cb.text, 생각 요약은 cb.thought 로 흘려 보낸다. 반환: Round
  async _once(r, cb) {
    const g = this.g;
    let got = false, blocked = '', finish = '', tokIn = 0, tokOut = 0, status = 0;
    const queries = new Set(); const sources = new Map();
    const outParts = []; const calls = []; let textBuf = '', textSig = '';
    const flushText = () => {
      if (!textBuf && !textSig) return;
      const p = { text: textBuf }; if (textSig) p.thoughtSignature = textSig;
      outParts.push(p); textBuf = ''; textSig = '';
    };
    const ctl = new AbortController(); this.ctl = ctl;
    let connectTimer = null, idleTimer = null;
    const idleMs = r.agent ? 240000 : 300000;
    const bump = () => { clearTimeout(idleTimer); idleTimer = setTimeout(() => { r._timeout = true; ctl.abort(); }, idleMs); };
    try {
      const body = { contents: r.contents };
      const gen = { maxOutputTokens: r.agent ? AGENT_MAX_OUTPUT_TOKENS : MAX_OUTPUT_TOKENS };
      if (r.json) gen.responseMimeType = 'application/json';
      const thinkApplied = g.thinking.apply(gen, r.model, r.thinking, r.includeThoughts);
      let searchApplied = false;
      if (r.decls && r.decls.length) {
        body.tools = [{ functionDeclarations: r.decls }];
        body.toolConfig = { functionCallingConfig: { mode: r.allowCalls === false ? 'NONE' : 'AUTO' } };
      } else {
        // JSON 으로만 답하게 하는 요청에는 검색 도구를 같이 쓸 수 없다
        searchApplied = g.search.apply(body, r.model, r.search && !r.json);
        // 검색이 꼭 필요한 요청인데 이 모델이 검색 도구를 못 받는 걸로 알려져 있으면, 검색 없이 지어낸 답을 받지 않고 바로 다른 모델로 넘긴다
        if (r.requireSearch && r.search && !r.json && !searchApplied) return { finish: '', blocked: '', error: G.searchRejectedMessage(r.model, null), fatal: true, code: 0, badKey: false, body: '', searchRejected: true };
      }
      body.generationConfig = gen;
      body.safetySettings = G.safetySettings();
      if (r.system && r.system.trim()) body.systemInstruction = { parts: [{ text: r.system }] };

      connectTimer = setTimeout(() => { r._timeout = true; ctl.abort(); }, CONNECT_MS);
      const res = await this.fetch(this.base + '/models/' + r.model + ':streamGenerateContent?alt=sse', {
        method: 'POST', signal: ctl.signal,
        headers: { 'Content-Type': 'application/json; charset=utf-8', 'x-goog-api-key': r.key },
        body: JSON.stringify(body),
      });
      clearTimeout(connectTimer); connectTimer = null;
      status = res.status;
      if (status < 200 || status > 299) {
        let err = ''; try { err = await res.text(); } catch (e) { /* 본문 없음 */ }
        // 이 모델이 생각 설정을 모르면 설정 없이 한 번 더 보낸다
        if (g.thinking.rejected(status, err, r.model, thinkApplied)) return this._once(r, cb);
        // 이 모델이 검색 도구를 모르면: 검색이 꼭 필요한 요청은 다른 모델로 넘기고, 아니면 검색 없이 한 번 더 보낸다
        if (g.search.rejected(status, err, r.model, searchApplied)) {
          if (r.requireSearch) return { finish: '', blocked: '', error: G.searchRejectedMessage(r.model, err), fatal: true, code: 0, badKey: false, body: err, searchRejected: true };
          if (cb.searchDropped) cb.searchDropped(r.model);
          return this._once(r, cb);
        }
        this.usage.record(r.key, r.model, status, g.pool.isQuota(err), 0, 0);
        const bad = status === 401 || status === 403 || (status === 400 && /API key/i.test(err));
        return { finish: '', blocked: '', error: G.describeError(status, err, g.pool), fatal: true, code: status, badKey: bad, body: err };
      }

      const reader = res.body.getReader(); const dec = new TextDecoder('utf-8');
      let buf = '', done = false;
      bump();
      while (!done) {
        const { value, done: d } = await reader.read();
        if (d) break;
        bump();
        buf += dec.decode(value, { stream: true });
        let nl;
        while ((nl = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, nl).replace(/\r$/, ''); buf = buf.slice(nl + 1);
          if (line.indexOf('data:') !== 0) continue;
          const data = line.slice(5).trim();
          if (!data || data === '[DONE]') continue;
          let o; try { o = JSON.parse(data); } catch (e) { continue; }
          const br = o.promptFeedback && o.promptFeedback.blockReason; if (br) blocked = br;
          if (o.usageMetadata) { const tk = G.tokensOf(o.usageMetadata); if (tk.inTok > 0 || tk.outTok > 0) { tokIn = tk.inTok; tokOut = tk.outTok; } }
          const cand = o.candidates && o.candidates[0]; if (!cand) continue;
          const fr = cand.finishReason; if (fr) finish = fr;
          // 웹 검색을 했다면: 검색한 말과 참고한 사이트 목록이 실려 온다
          const gm = cand.groundingMetadata;
          if (gm) {
            if (Object.keys(gm).length && (gm.groundingChunks || gm.groundingSupports || gm.webSearchQueries || gm.searchEntryPoint || gm.retrievalQueries) && cb.searchRan) cb.searchRan();
            const before = queries.size + sources.size;
            (gm.webSearchQueries || gm.retrievalQueries || []).forEach((q) => { q = String(q).trim(); if (q) queries.add(q); });
            (gm.groundingChunks || []).forEach((c) => {
              const web = c && c.web; if (!web) return;
              const u = web.uri || ''; if (!u || sources.has(u)) return;
              sources.set(u, { title: (web.title || '').trim() || u, url: u });
            });
            if (queries.size + sources.size !== before && cb.grounding) cb.grounding(Array.from(queries), Array.from(sources.values()));
          }
          const parts = cand.content && cand.content.parts;
          if (parts) for (const p of parts) {
            if (p.thought === true) { // 모델이 정리한 생각의 요약: 답이 아니라 사고 과정 표시용으로만 넘긴다
              if (p.text) { got = true; if (cb.thought) cb.thought(p.text); }
              continue;
            }
            if (p.functionCall) {
              flushText(); got = true;
              calls.push({ name: p.functionCall.name || '', args: p.functionCall.args || {}, id: p.functionCall.id || '' });
              outParts.push(p); // 생각 서명이 붙어 있을 수 있어서 받은 그대로 둔다
              continue;
            }
            if (p.text) { got = true; textBuf += p.text; if (cb.text) cb.text(p.text); }
            if (p.thoughtSignature) { textSig = p.thoughtSignature; flushText(); }
          }
          // 끝 표시(finishReason)가 온 조각이 마지막이다. 서버가 연결을 늦게 닫아도 시간 초과까지 기다리지 않는다
          if (fr) { done = true; break; }
        }
      }
      try { if (done) await reader.cancel(); } catch (e) { /* 이미 닫힘 */ }
      flushText();
      this.usage.record(r.key, r.model, 200, false, tokIn, tokOut);
      // finishReason 없이 스트림이 끝났다면 중간에 끊긴 것으로 본다
      if (got && !finish && !this.cancelled) return { finish: '', blocked, error: '응답이 중간에 끊겼어요', fatal: false, parts: outParts, calls };
      return { finish, blocked, error: null, fatal: false, parts: outParts, calls };
    } catch (e) {
      flushText();
      const msg = r._timeout ? G.networkErrorMessage(new Error('timed out')) : G.networkErrorMessage(e);
      // 사용자가 멈춘 것(글자를 못 받은 채 끊김)은 실패로 세지 않는다
      if (got || !this.cancelled) this.usage.record(r.key, r.model, got ? 200 : 0, false, tokIn, tokOut);
      // 글자를 하나라도 받은 뒤의 오류는 이어받기를 시도하고, 처음부터 실패한 건 바로 오류로 알린다
      return { finish, blocked, error: msg, fatal: !got, code: 0, badKey: false, body: '', parts: outParts, calls };
    } finally {
      clearTimeout(connectTimer); clearTimeout(idleTimer);
      if (this.ctl === ctl) this.ctl = null;
    }
  }

  // ───────── 글 채팅 ─────────
  // o: { key, model, system, history:[{role,text,images}], json, thinking, search, includeThoughts, switchModel, searchOptional, cb }
  // cb: { text, thought, grounding, model, searchSkipped, searchDropped, searchRan }   반환: { ok, error }
  async stream(o) {
    const g = this.g, cb = o.cb || {};
    this.cancelled = false;
    const switchModel = o.switchModel !== false, searchOptional = o.searchOptional !== false;
    let curModel = switchModel ? g.auto.usableOrFallback(g.auto.live(o.model)) : g.auto.live(o.model);
    if (curModel !== o.model && cb.model) cb.model(curModel);
    let curKey = o.key;
    const tried = new Set([curModel]); const triedKeys = new Set();
    const msgs = o.history.slice();
    let total = 0, round = 0, busyRetries = 0, modelSynced = false, probing = false, probed = false;
    // 웹 검색(구글 검색 연결)은 채팅과 한도가 따로다. 검색 한도가 찬 걸로 알려진 동안은 처음부터 검색을 빼고 보낸다
    let useSearch = !!o.search && !o.json && !(searchOptional && g.search.resting());
    const thinking = o.thinking === undefined ? 'minimal' : o.thinking;
    this.modelSync.refreshIfStale(o.key);
    for (;;) {
      let roundText = '';
      g.pool.used(curKey);
      const r = await this._once({ key: curKey, model: curModel, system: o.system, contents: msgs.map(content), json: o.json, thinking, search: useSearch,
        includeThoughts: o.includeThoughts, requireSearch: !searchOptional }, Object.assign({}, cb, {
        text: (d) => { roundText += d; total += d.length; if (cb.text) cb.text(d); },
      }));
      if (this.cancelled) return { ok: true };
      if (probing) {
        probing = false;
        if (!r.error) { g.search.rest(SEARCH_REST_MS); if (cb.searchSkipped) cb.searchSkipped(); } // 검색만 빼니 됐다: 모델·키가 아니라 검색 한도였다
        else useSearch = !!o.search && !o.json && !(searchOptional && g.search.resting()); // 검색 탓이 아니니 다음 모델에는 다시 붙인다
      }
      if (r.error && r.fatal) {
        const quota429 = r.code === 429 && g.pool.isQuota(r.body);
        // 검색을 붙인 요청이 한도로 막혔으면 모델·키 탓이 아닐 수 있다: 같은 모델·키로 검색만 빼고 한 번 더
        if (total === 0 && quota429 && useSearch && searchOptional && !probed) { probed = true; probing = true; useSearch = false; continue; }
        // 키 한도가 찼거나 키가 거부됐으면 다른 키로 같은 요청을 다시 보낸다 (한도가 아닌 429 는 서버가 붐비는 것이라 키를 바꾸지 않는다)
        if (total === 0 && (quota429 || r.badKey)) {
          g.pool.onLimit(curKey, curModel, r.body, r.badKey);
          triedKeys.add(curKey);
          const alt = g.pool.alternative(triedKeys, curModel);
          if (alt) { g.pool.notifySwitch(curKey, alt, r.badKey); curKey = alt; continue; }
        }
        // 모델이 없어졌다(404): 구글의 모델 목록을 새로 받아 같은 계열의 새 모델로 (요청당 한 번)
        if (r.code === 404 && !modelSynced && total === 0) {
          modelSynced = true;
          if (await this.modelSync.refreshNow(curKey)) {
            const sub = g.models.successor(curModel);
            if (sub !== curModel && !tried.has(sub)) { tried.add(sub); curModel = sub; if (cb.model) cb.model(sub); continue; }
          }
        }
        if (r.code === 404) g.auto.markDead(curModel);
        // Hydrogen 이 이 키·지역에서 열려 있지 않으면(권한 없음 403 · 모델 없음 400) 쓸 수 없는 모델로 기억하고 다른 모델로
        const hydrogenDenied = curModel === g.models.hydrogen() && (r.code === 403 || r.code === 400);
        if (hydrogenDenied) g.auto.markDead(curModel);
        const retryable = total === 0 && (r.code === 404 || r.code === 429 || (r.code >= 500 && r.code <= 599) || hydrogenDenied || r.searchRejected);
        const cands = retryable && switchModel ? g.auto.fallbacks(curModel).filter((m) => !tried.has(m) && !(o.search && !searchOptional && g.search.isUnsupported(m))) : [];
        const next = cands.filter((m) => g.pool.usable(m))[0] || cands[0];
        if (next) {
          tried.add(next); curModel = next; if (cb.model) cb.model(next);
          triedKeys.clear(); probed = false;
          curKey = g.pool.forModel(curKey, next); // 다음 모델에서는 막히지 않은 키로
          continue;
        }
        // 서버가 붐빌 때(한도 아닌 429 · 5xx)나 네트워크 오류는 다른 모델이 없으면 같은 모델로 잠깐 뒤 다시
        const netFail = r.code === 0 && !r.searchRejected && r.error && /시간 초과|네트워크|인터넷/.test(r.error);
        if (total === 0 && ((r.code >= 500 && r.code <= 599) || (r.code === 429 && !quota429) || netFail) && busyRetries < 2) {
          busyRetries++;
          await this.sleep(1500 * busyRetries);
          if (this.cancelled) return { ok: true };
          continue;
        }
        // 어느 키도 못 쓴 것이면 알리고, 어느 모델이 얼마나 쉬는지 · 어느 한도인지 같이 보여 준다
        let extra = '';
        const n = g.pool.count(), resting = g.pool.restingSummary(), qn = g.pool.quotaName(r.body);
        if (quota429 && n > 1) extra += '\n등록한 키 ' + n + '개가 모두 지금은 한도예요';
        if (quota429 && resting) extra += '\n쉬는 모델: ' + resting;
        if (quota429 && qn) extra += '\n한도 종류: ' + qn;
        return { ok: false, error: r.error + extra };
      }
      if (!r.error && r.finish !== 'MAX_TOKENS') { // 정상 종료
        if (total === 0) return { ok: false, error: r.blocked ? '요청이 안전 정책에 의해 차단되었어요 (' + r.blocked + ')' : r.finish ? '응답이 비어 있어요 (' + r.finish + ')' : '응답이 비어 있어요' };
        return { ok: true };
      }
      // 토큰 한도로 잘렸거나(MAX_TOKENS) 중간에 연결이 끊긴 경우: 받은 부분을 붙여 이어서 쓰게 한다
      round++;
      if (!roundText || round > MAX_CONTINUE) return total > 0 && !r.error ? { ok: true } : { ok: false, error: r.error || '응답이 중간에 끊겼어요' };
      msgs.push({ role: 'model', text: roundText });
      msgs.push({ role: 'user', text: '끊긴 바로 그 지점부터 이어서 계속 써 줘. 앞에 쓴 내용은 반복하지 말고, 인사말이나 설명 없이 본문만 이어 써.' });
    }
  }

  // ───────── 도구 호출 한 단계 ─────────
  // o: { key, model, system, contents(JSON 대화), decls, thoughts, allowCalls, canSwitchModel, cb:{text, thought} }
  // 반환: { parts, calls, finish, blocked, error, key, model }   (key · model 은 이 단계에서 실제로 쓴 것 — 다음 단계가 이어 쓴다)
  async step(o) {
    const g = this.g, cb = o.cb || {};
    this.cancelled = false;
    const canSwitch = o.canSwitchModel !== false;
    let curModel = canSwitch ? g.auto.usableOrFallback(g.auto.live(o.model)) : g.auto.live(o.model);
    let curKey = o.key; const tried = new Set([curModel]); const triedKeys = new Set();
    let delivered = 0, sameRetries = 0, modelSynced = false;
    this.modelSync.refreshIfStale(o.key);
    for (;;) {
      g.pool.used(curKey);
      const r = await this._once({ key: curKey, model: curModel, system: o.system, contents: o.contents, decls: o.decls, thinking: 'low', includeThoughts: o.thoughts, allowCalls: o.allowCalls, agent: true },
        { text: (t) => { delivered += t.length; if (cb.text) cb.text(t); }, thought: (t) => { delivered += t.length; if (cb.thought) cb.thought(t); } });
      const out = (error) => ({ parts: r.parts || [], calls: r.calls || [], finish: r.finish || '', blocked: r.blocked || '', error, key: curKey, model: curModel });
      if (this.cancelled || !r.error) return out(r.error || null);
      if (delivered > 0) return out(r.error); // 이미 화면에 흘려 보낸 게 있으면 다시 보내면 글이 겹친다
      const code = r.code || 0;
      if ((code === 429 && g.pool.isQuota(r.body)) || r.badKey) {
        g.pool.onLimit(curKey, curModel, r.body, r.badKey);
        triedKeys.add(curKey);
        const alt = g.pool.alternative(triedKeys, curModel);
        if (alt) { g.pool.notifySwitch(curKey, alt, r.badKey); curKey = alt; continue; }
      }
      if (code === 404 && !modelSynced) {
        modelSynced = true;
        if (await this.modelSync.refreshNow(curKey)) {
          const sub = g.models.successor(curModel);
          if (sub !== curModel && !tried.has(sub)) { tried.add(sub); curModel = sub; triedKeys.clear(); continue; }
        }
      }
      const gone = code === 404 || (curModel === g.models.hydrogen() && modelUnavailable(code, r.body || ''));
      if (gone) g.auto.markDead(curModel);
      const transient = code === 429 || (code >= 500 && code <= 599) || code === 0;
      if ((gone || transient) && canSwitch) {
        const cands = g.auto.fallbacks(curModel).filter((m) => !tried.has(m));
        const next = cands.filter((m) => g.pool.usable(m))[0] || cands[0];
        if (next) { tried.add(next); curModel = next; triedKeys.clear(); curKey = g.pool.forModel(curKey, next); continue; }
      }
      // 작업 중간(모델을 못 바꾸는 단계)에는 한 번 실패로 이미 한 일이 헛수고가 되니 같은 모델로 더 끈질기게 다시 보낸다
      const maxSame = canSwitch ? 2 : 4;
      if (transient && sameRetries < maxSame) {
        sameRetries++;
        await this.sleep(1500 * sameRetries);
        if (this.cancelled) return out(r.error);
        triedKeys.clear();
        continue;
      }
      return out(r.error);
    }
  }
}

// 이 키·지역에서 이 모델을 못 쓰는 경우 (권한 없음 · 모델 없음). 요청 모양이 틀려서 난 400 과 구별한다
function modelUnavailable(code, body) {
  if (code === 403) return true;
  if (code !== 400) return false;
  const b = String(body).toLowerCase();
  return b.indexOf('model') >= 0 && (b.indexOf('not found') >= 0 || b.indexOf('not supported') >= 0 || b.indexOf('not available') >= 0 || b.indexOf('permission') >= 0);
}

module.exports = { GeminiClient, content, attachPart, BASE };
